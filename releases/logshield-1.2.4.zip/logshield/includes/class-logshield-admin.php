<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LogShield_Admin {

	const SLUG      = 'logshield-settings';
	const SLUG_DASH = 'logshield';

	/** Отдельный раздел в меню: «LogShield» → «Дашборд», «Настройки». */
	public static function add_menu() {
		// Кружок со счётчиком, как у комментариев: новые атакующие с прошлого
		// просмотра дашборда. Открыли дашборд — счётчик сбрасывается.
		if ( current_user_can( 'manage_options' ) && isset( $_GET['page'] ) && $_GET['page'] === self::SLUG_DASH ) {
			LogShield_Dashboard::mark_seen();
		}
		$new   = current_user_can( 'manage_options' ) ? LogShield_Dashboard::unseen_count() : 0;
		$title = 'LogShield';
		if ( $new ) {
			$title .= sprintf(
				' <span class="awaiting-mod count-%1$d"><span class="pending-count" aria-hidden="true">%1$d</span><span class="screen-reader-text">%2$s</span></span>',
				$new,
				esc_html( sprintf( 'новых атакующих: %d', $new ) )
			);
		}
		$dash = add_menu_page( 'LogShield', $title, 'manage_options', self::SLUG_DASH, [ 'LogShield_Dashboard', 'render' ], 'dashicons-shield', 81 );
		add_submenu_page( self::SLUG_DASH, 'LogShield — дашборд', 'Дашборд', 'manage_options', self::SLUG_DASH, [ 'LogShield_Dashboard', 'render' ] );
		$settings = add_submenu_page( self::SLUG_DASH, 'LogShield — настройки', 'Настройки', 'manage_options', self::SLUG, [ __CLASS__, 'render_page' ] );
		add_action( 'admin_enqueue_scripts', function ( $hook ) use ( $dash, $settings ) {
			if ( $hook === $dash ) LogShield_Dashboard::enqueue();
			if ( $hook === $settings ) wp_enqueue_script( 'logshield-settings', LOGSHIELD_URL . 'assets/settings.js', [], LOGSHIELD_VERSION, true );
		} );
	}

	/** Старый адрес «Настройки → LogShield» ведёт на новую страницу. */
	public static function legacy_redirect() {
		global $pagenow;
		if ( $pagenow === 'options-general.php' && isset( $_GET['page'] ) && $_GET['page'] === self::SLUG ) {
			wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG ) );
			exit;
		}
	}

	public static function notices() {
		if ( ! isset( $_GET['page'] ) || ! in_array( $_GET['page'], [ self::SLUG, self::SLUG_DASH ], true ) ) return;
		if ( ! isset( $_GET['logshield_msg'] ) ) return;
		$msg  = sanitize_text_field( wp_unslash( $_GET['logshield_msg'] ) );
		$type = ( isset( $_GET['logshield_type'] ) && $_GET['logshield_type'] === 'error' ) ? 'error' : 'success';
		printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $type ), esc_html( $msg ) );
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_save_settings' );

		$opts = LogShield_Plugin::get_options();
		$old_interval = $opts['interval'];

		$opts['log_path'] = isset( $_POST['log_path'] ) ? sanitize_text_field( wp_unslash( $_POST['log_path'] ) ) : '';
		$opts['interval']  = ( isset( $_POST['interval'] ) && in_array( $_POST['interval'], [ 'logshield_2h', 'logshield_3h', 'logshield_4h' ], true ) )
			? $_POST['interval'] : 'logshield_3h';
		$opts['dry_run']                 = isset( $_POST['dry_run'] );
		$opts['rpm_threshold']           = max( 10, (int) ( $_POST['rpm_threshold'] ?? 300 ) );
		$opts['brute_attempts']          = max( 3, (int) ( $_POST['brute_attempts'] ?? 10 ) );
		$opts['scan_unique_paths']       = max( 5, (int) ( $_POST['scan_unique_paths'] ?? 15 ) );
		$opts['scan_min_requests']       = max( 5, (int) ( $_POST['scan_min_requests'] ?? 20 ) );
		$opts['error_rate_pct']          = min( 100, max( 1, (int) ( $_POST['error_rate_pct'] ?? 50 ) ) );
		$opts['error_rate_min_requests'] = max( 5, (int) ( $_POST['error_rate_min_requests'] ?? 20 ) );
		$opts['sensitive_min_hits']      = min( 50, max( 1, (int) ( $_POST['sensitive_min_hits'] ?? 3 ) ) );
		$opts['enum_min_hits']           = min( 50, max( 1, (int) ( $_POST['enum_min_hits'] ?? 3 ) ) );
		$opts['subnet_min_ips']          = min( 256, max( 2, (int) ( $_POST['subnet_min_ips'] ?? 5 ) ) );
		$opts['subnet_min_attempts']     = max( 5, (int) ( $_POST['subnet_min_attempts'] ?? 30 ) );
		$opts['max_read_mb']             = min( 50, max( 1, (int) ( $_POST['max_read_mb'] ?? 5 ) ) );
		$opts['ipinfo_enabled']          = isset( $_POST['ipinfo_enabled'] );
		$opts['ban_expiry_days']         = max( 0, (int) ( $_POST['ban_expiry_days'] ?? 7 ) );
		$opts['notify_email']            = isset( $_POST['notify_email'] ) ? sanitize_email( wp_unslash( $_POST['notify_email'] ) ) : '';

		// Токен на страницу не выводится: пустое поле — оставить сохранённый.
		$tg_error = '';
		$token    = isset( $_POST['telegram_token'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['telegram_token'] ) ) ) : '';
		if ( ! empty( $_POST['telegram_token_clear'] ) ) {
			$opts['telegram_token'] = '';
		} elseif ( $token !== '' ) {
			if ( LogShield_Notifier::is_valid_token( $token ) ) {
				$opts['telegram_token'] = $token;
			} else {
				$tg_error = ' Токен Telegram не сохранён: неверный формат.';
			}
		}
		$chat_id = isset( $_POST['telegram_chat_id'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['telegram_chat_id'] ) ) ) : '';
		if ( $chat_id === '' || LogShield_Notifier::is_valid_chat_id( $chat_id ) ) {
			$opts['telegram_chat_id'] = $chat_id;
		} else {
			$tg_error .= ' chat_id не сохранён: неверный формат.';
		}

		$whitelist_raw = isset( $_POST['whitelist_ips'] ) ? wp_unslash( $_POST['whitelist_ips'] ) : '';
		$whitelist     = array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', $whitelist_raw ) ) );
		$whitelist     = array_values( array_filter( $whitelist, array( 'LogShield_IP', 'is_valid_entry' ) ) );
		$opts['whitelist_ips'] = $whitelist;

		update_option( LOGSHIELD_OPTION, $opts );

		if ( $old_interval !== $opts['interval'] ) {
			LogShield_Plugin::reschedule( $opts['interval'] );
		}
		// Включили определение страны, а баз ещё нет — скачать в фоне, не задерживая страницу.
		if ( $opts['ipinfo_enabled'] && ! is_file( LogShield_IPInfo::dir() . 'country.mmdb' ) && ! wp_next_scheduled( LOGSHIELD_CLEANUP_HOOK, [ 'geo' ] ) ) {
			wp_schedule_single_event( time() + 10, LOGSHIELD_CLEANUP_HOOK, [ 'geo' ] );
		}

		self::redirect_with_message( 'Настройки сохранены.' . $tg_error, $tg_error ? 'error' : 'success' );
	}

	/** Кнопка «Обновить базы сейчас»: скачивает все четыре файла. */
	public static function geo_update() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_geo_update' );
		$errors = [];
		foreach ( LogShield_IPInfo::update( true ) as $file => $res ) {
			if ( $res !== true ) $errors[] = $file . ': ' . $res;
		}
		self::redirect_with_message( $errors ? 'Не все базы скачались. ' . implode( '; ', $errors ) : 'Базы стран и сетей обновлены.', $errors ? 'error' : 'success' );
	}

	public static function ping_rotate() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Нет прав' );
		check_admin_referer( 'logshield_ping_rotate' );
		LogShield_Ping::rotate();
		self::redirect_with_message( 'Создан новый адрес проверки доступности. Старый больше не работает — замените адрес в настройках воркера и выполните deploy.' );
	}

	public static function run_now() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_run_now' );

		$summary = LogShield_Detector::run();
		self::redirect_with_message( $summary['message'], $summary['ok'] ? 'success' : 'error' );
	}

	public static function unban_ip() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_unban' );
		$ip = isset( $_REQUEST['ip'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['ip'] ) ) : '';
		if ( $ip && ! LogShield_Htaccess::unban_ip( $ip ) ) {
			self::redirect_with_message( 'IP ' . $ip . ' убран из списка, но .htaccess не обновлён: ' . LogShield_Htaccess::last_error() . '.', 'error' );
		}
		self::redirect_with_message( 'IP ' . $ip . ' разблокирован.' );
	}

	public static function unban_all() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_unban_all' );
		if ( ! LogShield_Htaccess::unban_all() ) {
			self::redirect_with_message( 'Список банов очищен, но .htaccess не обновлён: ' . LogShield_Htaccess::last_error() . '.', 'error' );
		}
		self::redirect_with_message( 'Все блокировки сняты.' );
	}

	public static function add_my_ip() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_add_my_ip' );
		$ip = LogShield_Whitelist::get_client_ip();
		if ( $ip ) {
			LogShield_Whitelist::add_admin_ip( $ip, false, wp_get_current_user()->user_login );
			self::redirect_with_message( 'Ваш IP (' . $ip . ') добавлен в белый список.' );
		} else {
			self::redirect_with_message( 'Не удалось определить ваш IP.', 'error' );
		}
	}

	public static function telegram_test() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_telegram_test' );
		$opts = LogShield_Plugin::get_options();
		if ( ! LogShield_Notifier::telegram_configured( $opts ) ) {
			self::redirect_with_message( 'Сначала сохраните токен бота и chat_id.', 'error' );
		}
		$host   = wp_parse_url( home_url(), PHP_URL_HOST );
		$result = LogShield_Notifier::send_telegram(
			$opts['telegram_token'],
			$opts['telegram_chat_id'],
			'🛡 <b>LogShield</b> · ' . esc_html( $host ) . "\nТестовое сообщение: уведомления работают."
		);
		if ( $result === true ) {
			delete_option( LogShield_Notifier::FAIL_OPTION );
			self::redirect_with_message( 'Тестовое сообщение отправлено в Telegram.' );
		}
		self::redirect_with_message( $result, 'error' );
	}

	private static function found_key() {
		return 'logshield_found_logs_' . get_current_user_id();
	}

	public static function detect_log() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_detect_log' );
		$found = LogShield_LogFinder::find();
		set_transient( self::found_key(), $found, 15 * MINUTE_IN_SECONDS );

		$opts = LogShield_Plugin::get_options();
		if ( ! $found ) {
			self::redirect_with_message( 'Лог не найден в типичных местах. Укажите путь вручную.', 'error' );
		}
		// Текущий путь не работает, а уверенный кандидат есть — сразу ставим его.
		$current = LogShield_LogFinder::describe( $opts['log_path'] );
		$best    = LogShield_LogFinder::best_confident();
		if ( ! $current['ok'] && $best ) {
			$opts['log_path'] = $best;
			update_option( LOGSHIELD_OPTION, $opts );
			self::redirect_with_message( 'Лог найден и сохранён: ' . $best );
		}
		self::redirect_with_message( 'Найдено файлов лога: ' . count( $found ) . '. Выберите нужный в списке под полем пути.' );
	}

	public static function use_log() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_use_log' );
		$path  = isset( $_POST['path'] ) ? wp_unslash( $_POST['path'] ) : '';
		$found = get_transient( self::found_key() );
		// Принимаем только путь из списка найденных.
		if ( ! is_array( $found ) || ! in_array( $path, array_column( $found, 'path' ), true ) ) {
			self::redirect_with_message( 'Этого файла нет в списке найденных. Запустите поиск ещё раз.', 'error' );
		}
		$opts             = LogShield_Plugin::get_options();
		$opts['log_path'] = $path;
		update_option( LOGSHIELD_OPTION, $opts );
		self::redirect_with_message( 'Путь к логу сохранён: ' . $path );
	}

	/** Возврат на ту страницу, с которой пришло действие (поле ls_back). */
	public static function redirect_with_message( $msg, $type = 'success' ) {
		$page = ( isset( $_REQUEST['ls_back'] ) && $_REQUEST['ls_back'] === self::SLUG_DASH ) ? self::SLUG_DASH : self::SLUG;
		$url  = add_query_arg(
			[ 'page' => $page, 'logshield_msg' => rawurlencode( $msg ), 'logshield_type' => $type ],
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$opts      = LogShield_Plugin::get_options();
		$admin_ips = LogShield_Whitelist::get_admin_ips();
		$next_run  = wp_next_scheduled( LOGSHIELD_CRON_HOOK );
		$my_ip     = LogShield_Whitelist::get_client_ip();
		// Результат кнопки «Найти автоматически» (null — поиск не запускали).
		$found     = get_transient( self::found_key() );
		$found     = is_array( $found ) ? $found : null;
		?>
		<div class="wrap">
			<h1>LogShield — настройки</h1>

			<?php if ( $opts['dry_run'] ) : ?>
				<div class="notice notice-warning"><p><strong>Тестовый режим включён.</strong> IP обнаруживаются и записываются в историю сканирований, но не блокируются. Проверьте результаты ниже, прежде чем отключать тестовый режим.</p></div>
			<?php endif; ?>

			<p>
				Ваш текущий IP: <code><?php echo esc_html( $my_ip ?: 'не определён' ); ?></code>
				— <?php echo in_array( $my_ip, $admin_ips, true ) ? 'в белом списке ✅' : 'не в белом списке ⚠️'; ?>
				<?php if ( $my_ip && ! in_array( $my_ip, $admin_ips, true ) ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
						<input type="hidden" name="action" value="logshield_add_my_ip">
						<?php wp_nonce_field( 'logshield_add_my_ip' ); ?>
						<button class="button button-small">Добавить мой IP в белый список</button>
					</form>
				<?php endif; ?>
			</p>

			<div style="display:flex;gap:24px;flex-wrap:wrap;margin-top:16px">
				<div style="flex:1;min-width:420px">
					<h2>Настройки</h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="logshield_save_settings">
						<?php wp_nonce_field( 'logshield_save_settings' ); ?>
						<table class="form-table">
							<tr>
								<th><label for="log_path">Путь к access_log</label></th>
								<td>
									<input type="text" id="log_path" name="log_path" class="regular-text code" value="<?php echo esc_attr( $opts['log_path'] ); ?>" placeholder="/home/user/access-logs/example.com" aria-describedby="log_path-state log_path-desc">
									<button type="submit" form="logshield-detect-log" class="button">Найти автоматически</button>
									<?php $state = LogShield_LogFinder::describe( $opts['log_path'] ); ?>
									<p id="log_path-state"><?php echo $state['ok'] ? '✅' : '⚠️'; ?> <?php echo esc_html( $state['text'] ); ?></p>
									<?php if ( is_array( $found ) ) : ?>
										<?php if ( ! $found ) : ?>
											<p><strong>Лог не найден в типичных местах.</strong> Узнайте путь у хостинга или в панели управления (раздел «Логи»). Возможно, PHP не разрешено читать каталог с логами (open_basedir).</p>
										<?php else : ?>
											<p><strong>Найдено:</strong></p>
											<ul style="margin-top:0">
												<?php foreach ( $found as $f ) : ?>
													<li>
														<button type="submit" form="logshield-use-log" name="path" value="<?php echo esc_attr( $f['path'] ); ?>" class="button button-small"<?php disabled( $f['path'], $opts['log_path'] ); ?>><?php echo $f['path'] === $opts['log_path'] ? 'Выбран' : 'Использовать'; ?></button>
														<code><?php echo esc_html( $f['path'] ); ?></code>
														— <?php echo esc_html( size_format( $f['size'] ) . ', ' . wp_date( 'd.m.Y H:i', $f['mtime'] ) ); ?>
														<?php if ( $f['own_domain'] ) : ?> · есть ваш домен<?php elseif ( ! $f['near_site'] ) : ?> · <em>общий лог сервера, могут быть чужие сайты</em><?php endif; ?>
													</li>
												<?php endforeach; ?>
											</ul>
										<?php endif; ?>
									<?php endif; ?>
									<p class="description" id="log_path-desc">Полный путь на сервере (не URL). Если путь пуст, LogShield ищет лог сам при каждом сканировании. Типичные места: папка над сайтом (<code>…/access_log</code>), cPanel — <code>/home/USER/access-logs/DOMAIN</code>, ISPmanager — <code>/var/www/httpd-logs/DOMAIN.access.log</code>, Plesk — <code>/var/www/vhosts/DOMAIN/logs/access_log</code>.</p>
								</td>
							</tr>
							<tr>
								<th><label for="interval">Интервал сканирования</label></th>
								<td>
									<select id="interval" name="interval">
										<option value="logshield_2h" <?php selected( $opts['interval'], 'logshield_2h' ); ?>>Каждые 2 часа</option>
										<option value="logshield_3h" <?php selected( $opts['interval'], 'logshield_3h' ); ?>>Каждые 3 часа</option>
										<option value="logshield_4h" <?php selected( $opts['interval'], 'logshield_4h' ); ?>>Каждые 4 часа</option>
									</select>
									<p class="description">Следующий запуск: <?php echo $next_run ? esc_html( wp_date( 'd.m.Y H:i:s', $next_run ) ) : 'не запланирован'; ?></p>
								</td>
							</tr>
							<tr>
								<th><label for="dry_run">Тестовый режим</label></th>
								<td><label><input type="checkbox" id="dry_run" name="dry_run" <?php checked( $opts['dry_run'] ); ?>> Обнаруживать, но не блокировать (рекомендуется для начала)</label></td>
							</tr>
							<tr>
								<th><label for="ban_expiry_days">Срок блокировки, дней</label></th>
								<td><input type="number" id="ban_expiry_days" name="ban_expiry_days" min="0" value="<?php echo esc_attr( $opts['ban_expiry_days'] ); ?>"> <p class="description">0 = блокировать навсегда</p></td>
							</tr>
							<tr>
								<th><label for="rpm_threshold">Порог запросов от одного IP за период</label></th>
								<td>
									<input type="number" id="rpm_threshold" name="rpm_threshold" min="10" value="<?php echo esc_attr( $opts['rpm_threshold'] ); ?>" aria-describedby="rpm_threshold-desc">
									<p class="description" id="rpm_threshold-desc">Считаются все запросы между запусками. Успешные фоновые запросы WordPress (<code>admin-ajax.php</code>, <code>wp-cron.php</code>) не учитываются.</p>
								</td>
							</tr>
							<tr>
								<th><label for="brute_attempts">Порог неудачных входов с одного IP</label></th>
								<td>
									<input type="number" id="brute_attempts" name="brute_attempts" min="3" value="<?php echo esc_attr( $opts['brute_attempts'] ); ?>" aria-describedby="brute_attempts-desc">
									<p class="description" id="brute_attempts-desc">Неудачный вход — <code>POST</code> на <code>wp-login.php</code> в любом каталоге с ответом не 302 (WordPress на неверный пароль отвечает 200, на успешный вход — перенаправлением).</p>
								</td>
							</tr>
							<tr>
								<th><label for="subnet_min_ips">Распределённый подбор: IP из одной подсети</label></th>
								<td>
									<input type="number" id="subnet_min_ips" name="subnet_min_ips" min="2" max="256" value="<?php echo esc_attr( $opts['subnet_min_ips'] ); ?>" aria-describedby="subnet-desc">
								</td>
							</tr>
							<tr>
								<th><label for="subnet_min_attempts">Распределённый подбор: неудачных входов из подсети</label></th>
								<td>
									<input type="number" id="subnet_min_attempts" name="subnet_min_attempts" min="5" value="<?php echo esc_attr( $opts['subnet_min_attempts'] ); ?>" aria-describedby="subnet-desc">
									<p class="description" id="subnet-desc">Если из одной подсети (<code>/24</code> для IPv4, <code>/64</code> для IPv6) пароль подбирают столько адресов и набирают столько неудачных входов, банится вся подсеть. Подсеть, в которой есть адрес из белого списка, не банится.</p>
								</td>
							</tr>
							<tr>
								<th><label for="scan_unique_paths">Порог разных путей с ошибкой 4xx (сканирование)</label></th>
								<td>
									<input type="number" id="scan_unique_paths" name="scan_unique_paths" min="5" value="<?php echo esc_attr( $opts['scan_unique_paths'] ); ?>" aria-describedby="scan_unique_paths-desc">
									<p class="description" id="scan_unique_paths-desc">Считаются только пути, на которые сервер ответил 4xx (нет страницы, доступ закрыт). Поисковые боты и посетители ходят по живым страницам и под правило не попадают.</p>
								</td>
							</tr>
							<tr>
								<th><label for="scan_min_requests">Мин. запросов для детекта сканирования</label></th>
								<td><input type="number" id="scan_min_requests" name="scan_min_requests" min="5" value="<?php echo esc_attr( $opts['scan_min_requests'] ); ?>"></td>
							</tr>
							<tr>
								<th><label for="error_rate_pct">Порог процента ошибок (4xx/5xx)</label></th>
								<td><input type="number" id="error_rate_pct" name="error_rate_pct" min="1" max="100" value="<?php echo esc_attr( $opts['error_rate_pct'] ); ?>">%</td>
							</tr>
							<tr>
								<th><label for="error_rate_min_requests">Мин. запросов для детекта по ошибкам</label></th>
								<td><input type="number" id="error_rate_min_requests" name="error_rate_min_requests" min="5" value="<?php echo esc_attr( $opts['error_rate_min_requests'] ); ?>"></td>
							</tr>
							<tr>
								<th><label for="sensitive_min_hits">Разных чувствительных путей для бана</label></th>
								<td>
									<input type="number" id="sensitive_min_hits" name="sensitive_min_hits" min="1" max="50" value="<?php echo esc_attr( $opts['sensitive_min_hits'] ); ?>">
									<p class="description">Сколько разных путей вроде <code>/.env</code>, <code>/.git/config</code>, <code>/wp-config.php.bak</code> должен запросить IP, чтобы его забанили. Повторы одного пути и query string не считаются. 1 — банить за любое обращение (больше ложных срабатываний).</p>
								</td>
							</tr>
							<tr>
								<th><label for="enum_min_hits">Перебор пользователей: разных ID для бана</label></th>
								<td>
									<input type="number" id="enum_min_hits" name="enum_min_hits" min="1" max="50" value="<?php echo esc_attr( $opts['enum_min_hits'] ); ?>" aria-describedby="enum_min_hits-desc">
									<p class="description" id="enum_min_hits-desc">Сканеры узнают логины, перебирая <code>/?author=1</code>, <code>/?author=2</code>… (WordPress перенаправляет на <code>/author/логин/</code>) или запрашивая <code>/wp-json/wp/v2/users</code>. Это разведка перед подбором пароля. Посетители открывают авторов по ссылкам <code>/author/имя/</code>, они не считаются.</p>
								</td>
							</tr>
							<tr>
								<th><label for="max_read_mb">Макс. объём чтения лога за один запуск, МБ</label></th>
								<td><input type="number" id="max_read_mb" name="max_read_mb" min="1" max="50" value="<?php echo esc_attr( $opts['max_read_mb'] ); ?>"> <p class="description">Ограничивает нагрузку при больших логах — если накопился большой хвост, он будет обработан за несколько последующих запусков.</p></td>
							</tr>
							<tr>
								<th><label for="notify_email">E-mail для уведомлений</label></th>
								<td><input type="email" id="notify_email" name="notify_email" class="regular-text" value="<?php echo esc_attr( $opts['notify_email'] ); ?>" autocomplete="email" aria-describedby="notify_email-desc"> <p class="description" id="notify_email-desc">Необязательно. Письмо приходит после сканирования, если кого-то поймали.</p></td>
							</tr>
							<tr>
								<th><label for="telegram_token">Telegram: токен бота</label></th>
								<td>
									<input type="password" id="telegram_token" name="telegram_token" class="regular-text code" value="" autocomplete="off" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="telegram_token-desc">
									<p class="description" id="telegram_token-desc">
										<?php if ( ! empty( $opts['telegram_token'] ) ) : ?>
											Токен сохранён (…<?php echo esc_html( substr( $opts['telegram_token'], -4 ) ); ?>). Оставьте поле пустым, чтобы не менять.
										<?php else : ?>
											Создайте бота у <code>@BotFather</code> командой <code>/newbot</code> и вставьте выданный токен.
										<?php endif; ?>
									</p>
									<?php if ( ! empty( $opts['telegram_token'] ) ) : ?>
										<p><input type="checkbox" id="telegram_token_clear" name="telegram_token_clear" value="1"> <label for="telegram_token_clear">Удалить токен (отключить Telegram)</label></p>
									<?php endif; ?>
								</td>
							</tr>
							<tr>
								<th><label for="telegram_chat_id">Telegram: chat_id</label></th>
								<td>
									<input type="text" id="telegram_chat_id" name="telegram_chat_id" class="regular-text code" value="<?php echo esc_attr( $opts['telegram_chat_id'] ); ?>" autocomplete="off" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="telegram_chat_id-desc">
									<p class="description" id="telegram_chat_id-desc">Куда слать: ваш числовой id (напишите боту <code>/start</code>, затем узнайте id, например у <code>@userinfobot</code>), id группы (начинается с минуса, бота нужно добавить в группу) или <code>@имя_канала</code>.</p>
								</td>
							</tr>
							<tr>
								<th scope="row">Страна и сеть атакующих</th>
								<td>
									<p><input type="checkbox" id="ipinfo_enabled" name="ipinfo_enabled" value="1" <?php checked( ! empty( $opts['ipinfo_enabled'] ) ); ?> aria-describedby="ipinfo_enabled-desc"> <label for="ipinfo_enabled">Определять страну, сеть, Tor, VPN и дата-центр</label></p>
									<p class="description" id="ipinfo_enabled-desc">Только для информации, на блокировку не влияет. Определяется для пойманных правилами и для адресов, у которых за сканирование <?php echo (int) LogShield_IPInfo::MIN_HITS; ?>+ ошибок или неудачных входов; остальных посетителей не трогает. Нужны локальные базы (около 20 МБ в <code>wp-content/logshield-geo</code>): страна и сеть обновляются раз в месяц, Tor — раз в сутки, VPN — раз в неделю. Внешних запросов на каждый адрес нет.</p>
									<?php if ( ! empty( $opts['ipinfo_enabled'] ) ) : ?>
										<ul class="ls-geo-status">
											<?php foreach ( LogShield_IPInfo::status() as $file => $st ) : ?>
												<li><code><?php echo esc_html( $file ); ?></code> —
													<?php if ( $st['exists'] ) : ?>
														<?php echo esc_html( size_format( $st['size'] ) . ', ' . wp_date( 'j.m.Y H:i', $st['time'] ) ); ?>
													<?php else : ?>
														ещё не скачан
													<?php endif; ?>
													<?php if ( $st['error'] ) : ?><span style="color:#b32d2e">(ошибка: <?php echo esc_html( $st['error'] ); ?>)</span><?php endif; ?>
												</li>
											<?php endforeach; ?>
										</ul>
										<p><button type="submit" form="logshield-geo-update" class="button">Обновить базы сейчас</button></p>
									<?php endif; ?>
									<p class="description">Источники: <a href="https://db-ip.com">IP Geolocation by DB-IP</a> (CC BY 4.0), список выходных узлов Tor Project, список VPN <a href="https://github.com/X4BNet/lists_vpn">X4BNet/lists_vpn</a>. Метки приблизительные: обычный пользователь с VPN — не атакующий.</p>
								</td>
							</tr>
							<tr>
								<th><label for="whitelist_ips">Белый список IP (вручную)</label></th>
								<td>
									<textarea id="whitelist_ips" name="whitelist_ips" rows="4" class="large-text code" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="whitelist_ips-desc"><?php echo esc_textarea( implode( "\n", $opts['whitelist_ips'] ) ); ?></textarea>
									<p class="description" id="whitelist_ips-desc">Один IP или диапазон на строку, например <code>203.0.113.7</code> или <code>203.0.113.0/24</code>. Неверные строки при сохранении отбрасываются.</p>
								</td>
							</tr>
						</table>
						<?php submit_button( 'Сохранить настройки' ); ?>
					</form>
					<?php // Формы для кнопок у поля пути: вложенные формы в HTML запрещены. ?>
					<form id="logshield-detect-log" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" hidden>
						<input type="hidden" name="action" value="logshield_detect_log">
						<?php wp_nonce_field( 'logshield_detect_log' ); ?>
					</form>
					<form id="logshield-geo-update" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" hidden>
						<input type="hidden" name="action" value="logshield_geo_update">
						<?php wp_nonce_field( 'logshield_geo_update' ); ?>
					</form>
					<form id="logshield-use-log" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" hidden>
						<input type="hidden" name="action" value="logshield_use_log">
						<?php wp_nonce_field( 'logshield_use_log' ); ?>
					</form>

					<?php if ( LogShield_Notifier::telegram_configured( $opts ) ) : ?>
						<?php $tg_queue = (array) get_option( LogShield_Notifier::RETRY_OPTION, [] ); $tg_fail = get_option( LogShield_Notifier::FAIL_OPTION ); ?>
						<?php if ( $tg_queue ) : $tg_next = wp_next_scheduled( LogShield_Notifier::RETRY_HOOK ); ?>
							<div class="notice notice-warning inline"><p>Не доставлено в Telegram: <?php echo count( $tg_queue ); ?> — <?php echo esc_html( end( $tg_queue )['error'] ); ?>. Повтор <?php echo $tg_next ? esc_html( wp_date( 'H:i', $tg_next ) ) : 'при следующем запуске WP-Cron'; ?>.</p></div>
						<?php elseif ( $tg_fail ) : ?>
							<div class="notice notice-error inline"><p>Уведомление <?php echo esc_html( wp_date( 'd.m H:i', $tg_fail['time'] ) ); ?> так и не дошло до Telegram: <?php echo esc_html( $tg_fail['error'] ); ?></p></div>
						<?php endif; ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="logshield_telegram_test">
							<?php wp_nonce_field( 'logshield_telegram_test' ); ?>
							<?php submit_button( 'Отправить тестовое сообщение в Telegram', 'secondary', 'submit', false ); ?>
						</form>
					<?php endif; ?>

					<p class="description">Версия <?php echo esc_html( LOGSHIELD_VERSION ); ?>. Последняя проверка обновлений на GitHub: <?php echo esc_html( LogShield_Updater::is_dev_checkout() ? 'не проверяется (рабочая копия из git)' : LogShield_Updater::last_check_text() ); ?></p>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="logshield_run_now">
						<?php wp_nonce_field( 'logshield_run_now' ); ?>
						<?php submit_button( 'Запустить сканирование сейчас', 'secondary' ); ?>
					</form>
				</div>

				<div style="flex:1;min-width:420px">
					<p>Заблокированные адреса, графики и история сканирований — на странице <a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::SLUG_DASH ) ); ?>">LogShield → Дашборд</a>.</p>

					<h2>Сотрудники в белом списке</h2>
					<?php if ( empty( $admin_ips ) ) : ?>
						<p>Пока нет данных (появятся, когда автор, редактор или администратор зайдёт в панель WordPress).</p>
					<?php else : ?>
						<ul>
							<?php foreach ( LogShield_Whitelist::get_admin_users() as $ip => $logins ) : ?>
								<li><code><?php echo esc_html( $ip ); ?></code>
									<?php if ( $logins ) : ?>
										— <?php echo esc_html( implode( ', ', $logins ) ); ?>
									<?php else : ?>
										— <span class="description">логин появится при следующем заходе</span>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>

					<h2>Адреса сервера в белом списке</h2>
					<?php $server_ips = LogShield_Whitelist::get_server_ips(); ?>
					<?php if ( empty( $server_ips ) ) : ?>
						<p>Пока нет данных (появятся после первого запуска WP-Cron).</p>
					<?php else : ?>
						<ul><?php foreach ( $server_ips as $ip ) echo '<li><code>' . esc_html( $ip ) . '</code></li>'; ?></ul>
					<?php endif; ?>

					<h2 id="logshield-ping">Адрес для проверки доступности</h2>
					<p>Внешний пинг (воркер Cloudflare из <code>tools/uptime-worker</code>, UptimeRobot и т. п.) должен открывать этот адрес, а не главную. Ответ <code><?php echo esc_html( LogShield_Ping::REPLY ); ?></code> приходит, только когда WordPress загрузился полностью и база данных отвечает. Такие запросы LogShield не учитывает: они не попадают в правила, графики и хвост лога.</p>
					<p><input type="text" class="large-text code" readonly value="<?php echo esc_attr( LogShield_Ping::url() ); ?>" aria-label="Адрес для проверки доступности" data-select-on-focus></p>
					<p class="description">Ключ в адресе держите в секрете: запрос с ним LogShield пропускает. Ключевое слово для проверки — <code><?php echo esc_html( LogShield_Ping::REPLY ); ?></code>.</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-confirm="Старый адрес перестанет работать, и пинг начнёт сообщать, что сайт недоступен, пока вы не обновите адрес у воркера. Продолжить?">
						<input type="hidden" name="action" value="logshield_ping_rotate">
						<?php wp_nonce_field( 'logshield_ping_rotate' ); ?>
						<?php submit_button( 'Сменить ключ', 'secondary', 'submit', false ); ?>
					</form>

				</div>
			</div>
		</div>
		<?php
	}
}
