<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Секретный адрес для внешней проверки доступности (tools/uptime-worker).
 *
 * https://сайт/?logshield_ping=<ключ> отвечает «logshield-ok» после полной загрузки
 * WordPress (плагины, тема, запрос к БД). Значит, сайт по-настоящему работает, а не
 * просто отвечает Apache. Если загрузка упала (БД, фатальная ошибка в теме), ответа
 * «logshield-ok» не будет, и воркер сочтёт сайт недоступным.
 *
 * Детектор такие строки лога пропускает: только GET/HEAD на главную с ровно этим
 * запросом, верным ключом и ответом 200. Неверный ключ или другой путь —
 * обычный запрос, который учитывается правилами.
 */
class LogShield_Ping {

	const OPTION = 'logshield_ping_key';
	const PARAM  = 'logshield_ping';
	const REPLY  = 'logshield-ok';

	private static $cache = null; // [ ключ, путь главной ]

	/** Ключ; создаётся при первом обращении из админки (на фронте не создаётся). */
	public static function key( $create = false ) {
		$key = (string) get_option( self::OPTION, '' );
		if ( $key === '' && $create ) $key = self::rotate();
		return $key;
	}

	public static function rotate() {
		$key = wp_generate_password( 32, false );
		update_option( self::OPTION, $key, false );
		self::$cache = null;
		return $key;
	}

	public static function url( $create = true ) {
		$key = self::key( $create );
		return $key === '' ? '' : add_query_arg( self::PARAM, $key, home_url( '/' ) );
	}

	/** wp_loaded: всё загружено. Отвечаем коротко, без темы и кэша. */
	public static function maybe_respond() {
		if ( ! isset( $_GET[ self::PARAM ] ) ) return;
		$key = self::key();
		if ( $key === '' || ! is_string( $_GET[ self::PARAM ] ) || ! hash_equals( $key, wp_unslash( $_GET[ self::PARAM ] ) ) ) return;

		if ( ! defined( 'DONOTCACHEPAGE' ) ) define( 'DONOTCACHEPAGE', true );
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );

		global $wpdb;
		$db = $wpdb->get_var( 'SELECT 1' );
		if ( (string) $db !== '1' ) {
			status_header( 503 );
			echo 'db error';
			exit;
		}
		status_header( 200 );
		echo self::REPLY;
		exit;
	}

	/** Строка лога — проверка воркера с верным ключом? */
	public static function is_ping( array $entry ) {
		if ( (int) ( $entry['status'] ?? 0 ) !== 200 ) return false;
		$method = strtoupper( (string) ( $entry['method'] ?? '' ) );
		if ( $method !== 'GET' && $method !== 'HEAD' ) return false;
		$path = (string) ( $entry['path'] ?? '' );
		if ( strpos( $path, self::PARAM ) === false ) return false; // быстрый выход для остальных строк

		if ( self::$cache === null ) {
			$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
			self::$cache = [ self::key(), '/' . ltrim( trailingslashit( $home ), '/' ) ];
		}
		list( $key, $home ) = self::$cache;
		if ( $key === '' ) return false;

		$q = strpos( $path, '?' );
		if ( $q === false ) return false;
		$p = substr( $path, 0, $q );
		if ( $p !== $home && $p !== $home . 'index.php' ) return false;
		return hash_equals( self::PARAM . '=' . $key, substr( $path, $q + 1 ) );
	}

	/** Для тестов: сбросить запомненный ключ. */
	public static function reset_cache() {
		self::$cache = null;
	}
}
