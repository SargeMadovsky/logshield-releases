<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit;

delete_option( 'logshield_options' );
delete_site_transient( 'logshield_update_manifest' );
delete_option( 'logshield_admin_ips' );
delete_option( 'logshield_server_ips' );
delete_option( 'logshield_ping_key' );
delete_option( 'logshield_update_last' );
delete_option( 'logshield_stats' );
delete_option( 'logshield_backfilled' );
delete_metadata( 'user', 0, 'logshield_seen_at', '', true );
delete_option( 'logshield_banned_ips' );
delete_option( 'logshield_offset_state' );
delete_option( 'logshield_scan_log' );
delete_option( 'logshield_api_token_hash' );
delete_option( 'logshield_ipinfo' );
delete_option( 'logshield_geo_state' );
delete_option( 'logshield_tg_queue' );
delete_option( 'logshield_tg_failed' );

// Базы стран и сетей.
$logshield_geo = trailingslashit( WP_CONTENT_DIR ) . 'logshield-geo/';
foreach ( (array) glob( $logshield_geo . '*' ) as $logshield_f ) @unlink( $logshield_f );
@rmdir( $logshield_geo );

wp_clear_scheduled_hook( 'logshield_scan_event' );
wp_clear_scheduled_hook( 'logshield_cleanup_event' );
wp_clear_scheduled_hook( 'logshield_cleanup_event', [ 'geo' ] );
wp_clear_scheduled_hook( 'logshield_update_fetch' );
wp_clear_scheduled_hook( 'logshield_telegram_retry' );

// Примечание: правила в .htaccess НЕ удаляются автоматически при удалении
// плагина, чтобы случайно не снять действующие блокировки без вашего ведома.
// Если нужно — удалите вручную блок между
// "# BEGIN LogShield" и "# END LogShield" в файле .htaccess.
