// Страница настроек LogShield: подтверждение опасных действий (<form data-confirm="…">)
// и выделение адреса проверки доступности при фокусе — без inline-обработчиков.
document.addEventListener('submit', (e) => {
	const f = e.target.closest('form[data-confirm]');
	if (f && !window.confirm(f.dataset.confirm)) e.preventDefault();
});
document.addEventListener('focusin', (e) => {
	if (e.target.matches('input[data-select-on-focus]')) e.target.select();
});
