/* LogShield — дашборд. Без библиотек: графики рисуются в SVG. */
(() => {
	'use strict';
	const SVG = 'http://www.w3.org/2000/svg';
	const HOUR = 3600;
	const nf = new Intl.NumberFormat('ru-RU');
	const pad = (n) => String(n).padStart(2, '0');
	let uid = 0; // уникальные id градиентов, если источников на странице несколько

	/**
	 * Дашборд одного источника. root — контейнер с [data-metric], [data-chart], [data-types];
	 * D — { now, stats, types, banned }. Возвращает { render(hours) }.
	 */
	function mount(root, D) {
		// Строки статистики: [час (unix), запросы, 4xx, 5xx, неудачные входы, IP, {тип: число}]
		const byHour = new Map(D.stats.map((r) => [r[0], r]));
		const inst = ++uid;

		/** Корзины для периода: 24 ч → по часу, 7 дней → по 6 ч, 30 дней → по суткам (по местному времени). */
		function buckets(hours) {
			const step = hours <= 24 ? 1 : hours <= 168 ? 6 : 24;
			const end = new Date(D.now * 1000);
			end.setMinutes(0, 0, 0);
			end.setHours(Math.floor(end.getHours() / step) * step);
			const list = [];
			const count = Math.ceil(hours / step);
			for (let i = count - 1; i >= 0; i--) {
				const start = new Date(end);
				start.setHours(end.getHours() - i * step);
				list.push({ start, step, req: 0, err: 0, fails: 0, ips: 0, flag: {}, scans: 0, found: 0, errors: 0, bans: 0 });
			}
			// События (сканирования и баны) раскладываем по тем же корзинам.
			const at = (t) => list.findIndex((b) => t >= b.start / 1000 && t < b.start / 1000 + b.step * HOUR);
			for (const [t, ok, n] of D.events?.scans || []) {
				const b = list[at(t)];
				if (!b) continue;
				b.scans++;
				b.found += n;
				if (!ok) b.errors++;
			}
			for (const t of D.events?.bans || []) {
				const b = list[at(t)];
				if (b) b.bans++;
			}
			for (const b of list) {
				const from = b.start.getTime() / 1000;
				for (let h = from; h < from + b.step * HOUR; h += HOUR) {
					const r = byHour.get(h);
					if (!r) continue;
					b.req += r[1];
					b.err += r[2] + r[3];
					b.fails += r[4];
					b.ips = Math.max(b.ips, r[5]);
					for (const [t, n] of Object.entries(r[6] || {})) b.flag[t] = (b.flag[t] || 0) + n;
				}
			}
			return list;
		}

		function label(b, short) {
			const d = b.start;
			if (b.step === 1) return `${pad(d.getHours())}:00`;
			if (b.step === 24 || short) return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}`;
			return `${pad(d.getDate())}.${pad(d.getMonth() + 1)} ${pad(d.getHours())}:00`;
		}

		function el(name, attrs = {}, parent) {
			const node = document.createElementNS(SVG, name);
			for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
			if (parent) parent.append(node);
			return node;
		}

		/** «Красивый» максимум оси: 1, 2, 5 × 10^n. */
		function niceMax(v) {
			if (v <= 0) return 1;
			const p = 10 ** Math.floor(Math.log10(v));
			return [1, 2, 5, 10].map((m) => m * p).find((m) => m >= v);
		}

		/**
		 * Рисует график. series: [{ key, color, kind: 'area' | 'line' | 'bar' }].
		 * Подсказка показывает значения корзины под курсором.
		 */
		function chart(box, list, series, describe) {
			box.textContent = '';
			const H = box.dataset.chart === 'fails' ? 180 : 220;
			const L = 44, R = 8, T = 22, B = 22; // сверху — полоса для отметок событий
			const svg = el('svg', { role: 'img' }, box);
			// viewBox по реальной ширине: единица SVG = пиксель, подписи и столбцы
			// не растягиваются на широком экране. Перерисовка при смене ширины — ниже.
			const W = Math.round(svg.getBoundingClientRect().width) || 800;
			svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
			const max = niceMax(Math.max(0, ...list.flatMap((b) => series.map((s) => b[s.key]))));
			const x = (i) => L + (list.length === 1 ? 0 : (i / (list.length - 1)) * (W - L - R));
			const y = (v) => T + (1 - v / max) * (H - T - B);
			const slot = (W - L - R) / list.length;

			for (let k = 0; k <= 4; k++) {
				const v = (max / 4) * k;
				el('line', { class: 'ls-grid-line', x1: L, x2: W - R, y1: y(v), y2: y(v) }, svg);
				el('text', { class: 'ls-axis', x: L - 6, y: y(v) + 3, 'text-anchor': 'end' }, svg).textContent = v >= 1000 ? `${+(v / 1000).toFixed(1)}k` : +v.toFixed(1);
			}
			const every = Math.ceil(list.length / Math.max(2, Math.floor((W - L - R) / 80)));
			list.forEach((b, i) => {
				if (i % every) return;
				const cx = series.some((s) => s.kind === 'bar') ? L + slot * (i + 0.5) : x(i);
				el('text', { class: 'ls-axis', x: cx, y: H - 6, 'text-anchor': 'middle' }, svg).textContent = label(b, true);
			});

			const total = list.reduce((s, b) => s + series.reduce((a, se) => a + b[se.key], 0), 0);
			if (!total) {
				el('text', { class: 'ls-nodata', x: (W + L) / 2, y: H / 2, 'text-anchor': 'middle' }, svg).textContent = 'Нет данных за период';
			}

			for (const s of series) {
				if (s.kind === 'bar') {
					list.forEach((b, i) => {
						if (!b[s.key]) return;
						const w = Math.max(2, slot * 0.7);
						el('rect', { x: L + slot * i + (slot - w) / 2, y: y(b[s.key]), width: w, height: y(0) - y(b[s.key]), rx: 2, fill: s.color }, svg);
					});
					continue;
				}
				const pts = list.map((b, i) => `${x(i)},${y(b[s.key])}`).join(' ');
				if (s.kind === 'area') {
					const grad = `ls-g${inst}-${box.dataset.chart}-${s.key}`;
					const defs = el('defs', {}, svg);
					const lg = el('linearGradient', { id: grad, x1: 0, x2: 0, y1: 0, y2: 1 }, defs);
					el('stop', { offset: '0%', 'stop-color': s.color, 'stop-opacity': 0.35 }, lg);
					el('stop', { offset: '100%', 'stop-color': s.color, 'stop-opacity': 0 }, lg);
					el('polygon', { points: `${x(0)},${y(0)} ${pts} ${x(list.length - 1)},${y(0)}`, fill: `url(#${grad})` }, svg);
				}
				el('polyline', { points: pts, fill: 'none', stroke: s.color, 'stroke-width': 2, 'vector-effect': 'non-scaling-stroke', 'stroke-linejoin': 'round' }, svg);
			}
			const bar = series.some((s) => s.kind === 'bar');
			const cxOf = (i) => (bar ? L + slot * (i + 0.5) : x(i));

			// Отметки событий над графиком: форма и цвет говорят об одном и том же,
			// подробности — в подсказке и в таблице данных.
			list.forEach((b, i) => {
				const cx = cxOf(i);
				const both = b.scans && b.bans;
				if (b.scans) {
					const sx = both ? cx - 6 : cx;
					if (b.errors) el('path', { class: 'ls-mk-err', d: `M${sx - 5} 13h10L${sx} 4z` }, svg);
					else if (b.found) el('path', { class: 'ls-mk-hit', d: `M${sx - 5} 4h10L${sx} 13z` }, svg);
					else el('circle', { class: 'ls-mk-scan', cx: sx, cy: 9, r: 3 }, svg);
				}
				if (b.bans) el('rect', { class: 'ls-mk-ban', x: (both ? cx + 6 : cx) - 4, y: 5, width: 8, height: 8, rx: 1 }, svg);
				if (b.found || b.bans) el('line', { class: 'ls-mk-guide', x1: cx, x2: cx, y1: 15, y2: H - B }, svg);
			});

			// Подсказка: мышь, касание и клавиатура (стрелки, Home/End).
			svg.setAttribute('role', 'group');
			svg.setAttribute('aria-roledescription', 'график');
			svg.setAttribute('aria-label', `${describe}. Стрелки влево и вправо — значения по периодам.`);
			svg.setAttribute('tabindex', '0');
			const cursor = el('line', { class: 'ls-cursor', y1: T, y2: H - B, visibility: 'hidden' }, svg);
			const tip = document.createElement('div');
			tip.className = 'ls-tip';
			tip.hidden = true;
			box.append(tip);
			// Для скринридера — только при переходах с клавиатуры, мышь не озвучиваем.
			const live = document.createElement('div');
			live.className = 'screen-reader-text';
			live.setAttribute('role', 'status');
			box.append(live);
			let cur = -1;

			const describeBucket = (b) => {
				const parts = [label(b), ...series.map((s) => `${s.name}: ${nf.format(b[s.key])}`)];
				if (b.scans) parts.push(`сканирований: ${b.scans}` + (b.found ? `, найдено: ${nf.format(b.found)}` : '') + (b.errors ? `, с ошибкой: ${b.errors}` : ''));
				if (b.bans) parts.push(`блокировок: ${b.bans}`);
				return parts.join(' · ');
			};
			function show(i, announce) {
				cur = Math.min(list.length - 1, Math.max(0, i));
				const cx = cxOf(cur);
				cursor.setAttribute('x1', cx);
				cursor.setAttribute('x2', cx);
				cursor.setAttribute('visibility', 'visible');
				tip.textContent = describeBucket(list[cur]);
				tip.hidden = false;
				// Подсказка не вылезает за края карточки.
				// У SVG нет offsetLeft/offsetTop: считаем от рамки карточки.
				const sr = svg.getBoundingClientRect(), br = box.getBoundingClientRect();
				const bw = box.clientWidth, tw = tip.offsetWidth;
				const px = sr.left - br.left + (cx / W) * sr.width;
				tip.style.left = `${Math.min(bw - tw / 2 - 4, Math.max(tw / 2 + 4, px))}px`;
				tip.style.top = `${sr.top - br.top + (T / H) * sr.height}px`;
				if (announce) live.textContent = tip.textContent;
			}
			function hide() {
				tip.hidden = true;
				cursor.setAttribute('visibility', 'hidden');
			}
			const indexAt = (clientX) => {
				const rect = svg.getBoundingClientRect();
				const px = ((clientX - rect.left) / rect.width) * W;
				return bar ? Math.floor((px - L) / slot) : Math.round(((px - L) / (W - L - R)) * (list.length - 1));
			};
			svg.addEventListener('pointermove', (e) => show(indexAt(e.clientX), false));
			svg.addEventListener('pointerdown', (e) => show(indexAt(e.clientX), false));
			// После касания подсказка остаётся, пока не коснутся другого места.
			svg.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse' && document.activeElement !== svg) hide(); });
			svg.addEventListener('focus', () => show(cur < 0 ? list.length - 1 : cur, true));
			svg.addEventListener('blur', hide);
			svg.addEventListener('keydown', (e) => {
				const step = { ArrowLeft: -1, ArrowRight: 1, PageUp: -6, PageDown: 6 }[e.key];
				if (step) show(cur + step, true);
				else if (e.key === 'Home') show(0, true);
				else if (e.key === 'End') show(list.length - 1, true);
				else if (e.key === 'Escape') { hide(); return; }
				else return;
				e.preventDefault();
			});
			// Перерисовка создаёт график заново: прежний обработчик на document снимаем.
			box.lsAbort?.abort();
			box.lsAbort = new AbortController();
			document.addEventListener('pointerdown', (e) => { if (!box.contains(e.target) && document.activeElement !== svg) hide(); }, { signal: box.lsAbort.signal });

			fillTable(box.dataset.chart, list, series);
		}

		/** Те же корзины таблицей: подсказка графика доступна только мышью. */
		function fillTable(name, list, series) {
			const table = root.querySelector(`[data-chart-table="${name}"]`);
			if (!table) return;
			table.textContent = '';
			const head = table.createTHead().insertRow();
			const withEvents = list.some((b) => b.scans || b.bans);
			const heads = ['Период', ...series.map((s) => s.name[0].toUpperCase() + s.name.slice(1))];
			if (withEvents) heads.push('События');
			for (const text of heads) {
				const th = document.createElement('th');
				th.scope = 'col';
				th.textContent = text;
				head.append(th);
			}
			const body = table.createTBody();
			for (const b of list) {
				const tr = body.insertRow();
				const th = document.createElement('th');
				th.scope = 'row';
				th.textContent = label(b);
				tr.append(th);
				for (const s of series) tr.insertCell().textContent = nf.format(b[s.key]);
				if (withEvents) {
					const ev = [];
					if (b.scans) ev.push(`скан.: ${b.scans}` + (b.found ? `, найдено ${b.found}` : '') + (b.errors ? `, ошибок ${b.errors}` : ''));
					if (b.bans) ev.push(`блок.: ${b.bans}`);
					const td = tr.insertCell();
					td.className = 'ls-ev-cell';
					td.textContent = ev.join('; ') || '—';
				}
			}
		}

		function setMetric(name, text) {
			const node = root.querySelector(`[data-metric="${name}"]`);
			if (node) node.textContent = text;
		}

		function renderTypes(list) {
			const ul = root.querySelector('[data-types]');
			if (!ul) return;
			const sums = {};
			for (const b of list) for (const [t, n] of Object.entries(b.flag)) sums[t] = (sums[t] || 0) + n;
			const rows = Object.entries(D.types).map(([k, name]) => [name, sums[k] || 0, k]).sort((a, b) => b[1] - a[1]);
			const max = Math.max(1, ...rows.map((r) => r[1]));
			ul.textContent = '';
			for (const [name, n] of rows) {
				const li = document.createElement('li');
				const t = document.createElement('span');
				t.textContent = name;
				const v = document.createElement('span');
				v.className = 'ls-num';
				v.textContent = nf.format(n);
				const bar = document.createElement('span');
				bar.className = 'ls-bar';
				const fill = document.createElement('span');
				fill.style.width = `${(n / max) * 100}%`;
				bar.append(fill);
				li.append(t, v, bar);
				ul.append(li);
			}
		}

		function render(hours) {
			const list = buckets(hours);
			const sum = (k) => list.reduce((s, b) => s + b[k], 0);
			const req = sum('req'), err = sum('err'), fails = sum('fails');
			const flag = list.reduce((s, b) => s + Object.values(b.flag).reduce((a, n) => a + n, 0), 0);
			setMetric('req', nf.format(req));
			setMetric('err', req ? `${nf.format(err)} · ${(err / req * 100).toFixed(1)}%` : '0');
			setMetric('fails', nf.format(fails));
			setMetric('flag', nf.format(flag));
			setMetric('banned', nf.format(D.banned));

			const period = hours <= 24 ? 'за 24 часа' : hours <= 168 ? 'за 7 дней' : 'за 30 дней';
			const traffic = root.querySelector('[data-chart="traffic"]');
			const failsBox = root.querySelector('[data-chart="fails"]');
			// Цвета серий — из CSS-переменных темы, чтобы не расходились со стилями.
			const css = getComputedStyle(root);
			const color = (name, fallback) => css.getPropertyValue(name).trim() || fallback;
			if (traffic) chart(traffic, list, [
				{ key: 'req', name: 'запросы', color: color('--ls-accent', '#00ff88'), kind: 'area' },
				{ key: 'err', name: 'ошибки', color: color('--ls-danger', '#ff2e44'), kind: 'line' },
			], `Трафик ${period}: ${nf.format(req)} запросов, ${nf.format(err)} ошибок`);
			if (failsBox) chart(failsBox, list, [
				{ key: 'fails', name: 'неудачные входы', color: color('--ls-warn', '#ffb020'), kind: 'bar' },
			], `Неудачные входы ${period}: ${nf.format(fails)}`);
			renderTypes(list);
		}

		return { render };
	}

	// Подтверждение опасных действий без inline-обработчиков: <form data-confirm="…">.
	document.addEventListener('submit', (e) => {
		const f = e.target.closest('form[data-confirm]');
		if (f && !window.confirm(f.dataset.confirm)) e.preventDefault();
	});
	// Кнопка «Копировать» для только что выпущенного токена.
	document.addEventListener('click', async (e) => {
		const btn = e.target.closest('[data-copy]');
		if (!btn) return;
		const input = document.getElementById(btn.dataset.copy);
		if (!input) return;
		try {
			await navigator.clipboard.writeText(input.value);
			btn.textContent = 'Скопировано';
		} catch {
			input.select();
		}
	});

	const all = [];
	const main = document.querySelector('.ls-dash');
	if (!main) return;
	if (window.LogShieldData) {
		all.push(mount(main, window.LogShieldData));
		const empty = main.querySelector('.ls-empty');
		if (empty) empty.hidden = window.LogShieldData.stats.length > 0;
	}
	if (!all.length) return;
	const renderAll = (h) => all.forEach((m) => m.render(h));

	// Период
	const rangeBtns = main.querySelectorAll('[data-range]');
	let hours = 24;
	try { hours = Number(localStorage.getItem('logshield-range')) || 24; } catch {}
	if (![24, 168, 720].includes(hours)) hours = 24;
	function pickRange(h) {
		hours = h;
		rangeBtns.forEach((b) => b.setAttribute('aria-pressed', String(Number(b.dataset.range) === h)));
		try { localStorage.setItem('logshield-range', String(h)); } catch {}
		renderAll(h);
	}
	rangeBtns.forEach((b) => b.addEventListener('click', () => pickRange(Number(b.dataset.range))));
	pickRange(hours);

	// Перерисовка только при смене ширины: раскрытие таблицы данных меняет лишь высоту.
	let resizeTimer;
	let lastWidth = 0;
	const firstCard = main.querySelector('.ls-chart-card');
	if (firstCard) {
		new ResizeObserver(([entry]) => {
			const w = Math.round(entry.contentRect.width);
			if (w === lastWidth) return;
			lastWidth = w;
			clearTimeout(resizeTimer);
			resizeTimer = setTimeout(() => renderAll(hours), 150);
		}).observe(firstCard);
	}

	// Подтверждение «Разблокировать все» — <dialog>. Кнопка открывает его через
	// command="show-modal"; где Invoker Commands ещё нет, открываем сами.
	if (!('commandForElement' in HTMLButtonElement.prototype)) {
		main.querySelectorAll('button[command="show-modal"][commandfor]').forEach((b) => b.addEventListener('click', () => {
			document.getElementById(b.getAttribute('commandfor'))?.showModal();
		}));
	}

	// ---- Атакующие: сортировка по заголовкам и фильтры ----
	const atTable = main.querySelector('[data-attackers]');
	if (atTable) {
		const tbody = atTable.tBodies[0];
		const rows = [...tbody.rows];
		const collator = new Intl.Collator('ru', { numeric: true, sensitivity: 'base' });
		const fBox = main.querySelector('[data-attack-filters]');
		const fQ = fBox.querySelector('[data-f-q]');
		const fType = fBox.querySelector('[data-f-type]');
		const fStatus = fBox.querySelector('[data-f-status]');
		const fCount = fBox.querySelector('[data-f-count]');
		fBox.hidden = false;

		// Текст для поиска считаем один раз: адрес и причина.
		const haystack = new Map(rows.map((r) => [r, r.textContent.toLowerCase()]));
		const value = (row, i) => row.cells[i].dataset.value ?? row.cells[i].textContent.trim();

		function sortBy(th, direction) {
			for (const h of atTable.tHead.rows[0].cells) h.removeAttribute('aria-sort');
			th.setAttribute('aria-sort', direction);
			const i = th.cellIndex;
			const k = direction === 'ascending' ? 1 : -1;
			const sorted = [...tbody.rows].sort((a, b) => k * (th.dataset.type === 'number'
				? Number(value(a, i)) - Number(value(b, i))
				: collator.compare(value(a, i), value(b, i))));
			// Переставляем те же строки, не пересоздавая их (фокус на кнопках сохраняется).
			for (const r of sorted) (tbody.moveBefore ? tbody.moveBefore(r, null) : tbody.append(r));
			fCount.textContent = `Сортировка: ${th.textContent.trim().toLowerCase()}, ${direction === 'ascending' ? 'по возрастанию' : 'по убыванию'}.`;
		}
		function onSort(btn) {
			const th = btn.closest('th');
			sortBy(th, th.getAttribute('aria-sort') === 'ascending' ? 'descending' : 'ascending');
		}
		// Invoker Commands: command="--sort" commandfor="ls-attackers"; иначе — обычный click.
		if ('commandForElement' in HTMLButtonElement.prototype) {
			atTable.addEventListener('command', (e) => { if (e.command === '--sort') onSort(e.source); });
		} else {
			atTable.querySelectorAll('.ls-sort').forEach((b) => b.addEventListener('click', () => onSort(b)));
		}

		function applyFilters() {
			const q = fQ.value.trim().toLowerCase();
			const t = fType.value;
			const st = fStatus.value;
			let shown = 0;
			for (const r of rows) {
				const ok = (!q || haystack.get(r).includes(q))
					&& (!t || r.dataset.types.split(' ').includes(t))
					&& (!st || r.dataset.status === st);
				r.hidden = !ok;
				if (ok) shown++;
			}
			fCount.textContent = shown === rows.length ? `Всего: ${rows.length}` : `Показано ${shown} из ${rows.length}`;
		}
		let fTimer;
		fQ.addEventListener('input', () => { clearTimeout(fTimer); fTimer = setTimeout(applyFilters, 150); });
		fType.addEventListener('change', applyFilters);
		fStatus.addEventListener('change', applyFilters);
		applyFilters();
	}

	// ---- Хвост лога ----
	const root = main;
	const D = window.LogShieldData;
	const tailBox = root.querySelector('[data-tail]');
	if (!D || !tailBox) return;
	const tailStatus = root.querySelector('[data-tail-status]');
	const liveBtn = root.querySelector('[data-live]');
	const filterBtns = root.querySelectorAll('[data-filter]');
	const suspects = D.suspects;
	const isSuspect = (ip) => suspects.some((s) => s === ip || (s.includes('/') && inSubnet(ip, s)));
	const MAX_ROWS = 300;
	let offset = -1;
	let filter = 'all';
	let timer = null;
	let busy = false;

	/** Только /24 для IPv4 и /64 для IPv6 — других подсетей детектор не создаёт. */
	function inSubnet(ip, cidr) {
		const [net, bits] = cidr.split('/');
		if (net.includes(':') !== ip.includes(':')) return false;
		if (!ip.includes(':')) {
			const toInt = (a) => a.split('.').reduce((s, o) => s * 256 + Number(o), 0);
			const size = 2 ** (32 - Number(bits));
			return Math.floor(toInt(ip) / size) === Math.floor(toInt(net) / size);
		}
		const groups = (a) => {
			const [h, t = ''] = a.split('::');
			const hs = h ? h.split(':') : [], ts = t ? t.split(':') : [];
			return [...hs, ...Array(8 - hs.length - ts.length).fill('0'), ...ts].map((g) => parseInt(g || '0', 16));
		};
		const n = Math.floor(Number(bits) / 16);
		const a = groups(ip), b = groups(net);
		return a.slice(0, n).every((g, i) => g === b[i]);
	}

	function matchesFilter(row) {
		const s = Number(row.dataset.status);
		if (filter === '4xx') return s >= 400 && s < 500;
		if (filter === '5xx') return s >= 500;
		if (filter === 'bad') return row.classList.contains('ls-bad');
		return true;
	}

	function addRows(lines, fresh) {
		const frag = document.createDocumentFragment();
		for (const l of lines) {
			const row = document.createElement('div');
			row.className = 'ls-row' + (isSuspect(l.ip) ? ' ls-bad' : '') + (fresh ? ' ls-new' : '');
			row.dataset.status = l.s;
			// User-Agent — отдельная ячейка, а не title: так он виден с клавиатуры и на сенсорном экране.
			const cells = [[l.t, 'ls-t'], [l.ip, 'ls-ip'], [l.m, 'ls-m'], [l.s, `ls-s${String(l.s)[0]}`], [l.p, 'ls-p'], [l.ua || '—', 'ls-ua']];
			for (const [text, cls] of cells) {
				const c = document.createElement('span');
				c.className = cls;
				c.textContent = text;
				row.append(c);
			}
			row.hidden = !matchesFilter(row);
			frag.prepend(row); // новые сверху
		}
		tailBox.prepend(frag);
		while (tailBox.childElementCount > MAX_ROWS) tailBox.lastElementChild.remove();
	}

	async function poll() {
		if (busy) return;
		busy = true;
		try {
			const url = new URL(D.tail.url);
			url.search = new URLSearchParams({ action: 'logshield_tail', nonce: D.tail.nonce, offset: String(offset) });
			const res = await fetch(url, { credentials: 'same-origin' });
			const json = await res.json();
			if (!json.success) { tailStatus.textContent = json.data || 'Не удалось прочитать лог.'; stopLive(); return; }
			const first = offset < 0 || json.data.reset;
			if (first) tailBox.textContent = '';
			addRows(json.data.lines, !first);
			offset = json.data.offset;
			tailStatus.textContent = tailBox.childElementCount ? '' : 'Записей пока нет.';
		} catch {
			tailStatus.textContent = 'Ошибка сети при чтении лога.';
		} finally {
			busy = false;
		}
	}

	function startLive() {
		liveBtn.setAttribute('aria-pressed', 'true');
		clearInterval(timer);
		timer = setInterval(() => { if (!document.hidden) poll(); }, 5000);
	}
	function stopLive() {
		liveBtn.setAttribute('aria-pressed', 'false');
		clearInterval(timer);
		timer = null;
	}
	liveBtn.addEventListener('click', () => (timer ? stopLive() : (startLive(), poll())));

	// Показ User-Agent под каждой записью; выбор запоминается.
	const uaBtn = root.querySelector('[data-ua]');
	if (uaBtn) {
		const setUa = (on) => {
			uaBtn.setAttribute('aria-pressed', String(on));
			tailBox.classList.toggle('ls-show-ua', on);
			try { localStorage.setItem('logshield-ua', on ? '1' : '0'); } catch {}
		};
		let uaOn = false;
		try { uaOn = localStorage.getItem('logshield-ua') === '1'; } catch {}
		setUa(uaOn);
		uaBtn.addEventListener('click', () => setUa(uaBtn.getAttribute('aria-pressed') !== 'true'));
	}
	document.addEventListener('visibilitychange', () => { if (!document.hidden && timer) poll(); });

	filterBtns.forEach((b) => b.addEventListener('click', () => {
		filter = b.dataset.filter;
		filterBtns.forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
		for (const row of tailBox.children) row.hidden = !matchesFilter(row);
	}));

	if (!tailStatus.textContent.startsWith('Лог недоступен')) poll();
})();
