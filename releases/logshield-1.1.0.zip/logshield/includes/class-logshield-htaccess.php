<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LogShield_Htaccess {

	const BANNED_OPTION = 'logshield_banned_ips';
	const MARK_START    = '# BEGIN LogShield';
	const MARK_END      = '# END LogShield';

	public static function get_banned() {
		// ip => [ 'reason' => .., 'banned_at' => .., 'expires_at' => .. ]
		return get_option( self::BANNED_OPTION, [] );
	}

	public static function ban_ip( $ip, $reason, $expiry_days = 0 ) {
		if ( ! LogShield_IP::is_valid_entry( $ip ) ) return false;
		return self::ban_ips( [ $ip => $reason ], $expiry_days );
	}

	/**
	 * Банит сразу несколько IP одной записью в .htaccess (и одним бэкапом).
	 * Ключ может быть одиночным IP или диапазоном CIDR (216.73.160.0/24).
	 *
	 * @param array $ips ip или cidr => причина
	 */
	public static function ban_ips( array $ips, $expiry_days = 0 ) {
		$banned = self::get_banned();
		$added  = false;
		foreach ( $ips as $ip => $reason ) {
			$ip = self::canonical( $ip );
			if ( $ip === null ) continue;
			if ( isset( $banned[ $ip ] ) ) continue; // уже забанен
			$banned[ $ip ] = [
				'reason'     => $reason,
				'banned_at'  => time(),
				'expires_at' => $expiry_days > 0 ? time() + ( $expiry_days * DAY_IN_SECONDS ) : 0,
			];
			$added = true;
		}
		if ( ! $added ) return true;
		update_option( self::BANNED_OPTION, $banned, false );
		return self::write_block( array_keys( $banned ) );
	}

	public static function unban_ip( $ip ) {
		$banned = self::get_banned();
		unset( $banned[ $ip ] );
		update_option( self::BANNED_OPTION, $banned, false );
		return self::write_block( array_keys( $banned ) );
	}

	public static function unban_all() {
		update_option( self::BANNED_OPTION, [], false );
		return self::write_block( [] );
	}

	public static function cleanup_expired() {
		$banned = self::get_banned();
		$now     = time();
		$changed = false;
		foreach ( $banned as $ip => $info ) {
			if ( ! empty( $info['expires_at'] ) && $info['expires_at'] < $now ) {
				unset( $banned[ $ip ] );
				$changed = true;
			}
		}
		if ( $changed ) {
			update_option( self::BANNED_OPTION, $banned, false );
			self::write_block( array_keys( $banned ) );
		}
	}

	/**
	 * Полностью пересобирает управляемый блок LogShield в .htaccess на основе
	 * актуального списка забаненных IP. Используется mod_rewrite (а не
	 * Require/Deny), чтобы блок не конфликтовал с другими правилами доступа
	 * в файле (например, с блоком All In One WP Security).
	 */
	private static function write_block( array $ips ) {
		$htaccess_path = self::get_htaccess_path();
		if ( ! $htaccess_path ) return false;

		$content = self::read_file( $htaccess_path );
		if ( $content === false ) $content = '';

		$block = self::build_block( $ips );

		$start_pos = strpos( $content, self::MARK_START );
		$end_pos   = strpos( $content, self::MARK_END );

		if ( $start_pos !== false && $end_pos !== false && $end_pos > $start_pos ) {
			$end_pos_full = $end_pos + strlen( self::MARK_END );
			$before       = substr( $content, 0, $start_pos );
			$after        = substr( $content, $end_pos_full );
		} else {
			// Вставляем блок в самое начало файла, чтобы блокировка
			// срабатывала как можно раньше — до правил WordPress.
			$before = '';
			$after  = $content;
		}
		// Срезаем переводы строк в начале хвоста и ставим ровно одну пустую
		// строку-разделитель — иначе при каждой записи пустые строки копятся.
		$after = ltrim( $after, "\r\n" );
		$eol   = ( strpos( $content, "\r\n" ) !== false ) ? "\r\n" : "\n";
		if ( $eol !== "\n" ) $block = str_replace( "\n", $eol, $block );
		$new_content = $before . $block . ( $after !== '' ? $eol . $after : '' );

		return self::write_file( $htaccess_path, $new_content );
	}

	private static function build_block( array $ips ) {
		if ( empty( $ips ) ) {
			return self::MARK_START . "\n" . self::MARK_END . "\n";
		}
		$lines = [ self::MARK_START, '<IfModule mod_rewrite.c>', 'RewriteEngine On' ];
		$conds = [];
		foreach ( $ips as $ip ) {
			$ip = self::canonical( $ip );
			if ( $ip === null ) continue;
			if ( strpos( $ip, '/' ) !== false ) {
				// Диапазон: выражение Apache 2.4 (ap_expr), оператор -R сравнивает
				// REMOTE_ADDR с подсетью. Адрес проверен parse_cidr, кавычек в нём быть не может.
				$conds[] = "RewriteCond expr \"-R '{$ip}'\"";
			} else {
				$escaped = str_replace( '.', '\.', $ip );
				$conds[] = "RewriteCond %{REMOTE_ADDR} ^{$escaped}\$";
			}
		}
		// RewriteRule без единого условия закрыл бы сайт для всех.
		if ( empty( $conds ) ) {
			return self::MARK_START . "\n" . self::MARK_END . "\n";
		}
		foreach ( $conds as $i => $cond ) {
			$isLast  = ( $i === count( $conds ) - 1 );
			$lines[] = $isLast ? $cond : ( $cond . ' [OR]' );
		}
		$lines[] = 'RewriteRule ^ - [F,L]';
		$lines[] = '</IfModule>';
		$lines[] = self::MARK_END;
		return implode( "\n", $lines ) . "\n";
	}

	/** IP как есть, CIDR — в каноническом виде (биты хоста обнулены); мусор — null. */
	private static function canonical( $entry ) {
		$entry = trim( (string) $entry );
		if ( filter_var( $entry, FILTER_VALIDATE_IP ) ) return $entry;
		$c = LogShield_IP::parse_cidr( $entry );
		return $c ? $c['canonical'] : null;
	}

	public static function get_htaccess_path() {
		return trailingslashit( ABSPATH ) . '.htaccess';
	}

	/**
	 * Возвращает WP_Filesystem только если он работает напрямую (direct).
	 * В cron нет учётных данных FTP/SSH: WP_Filesystem() для ftpext/ssh2 не
	 * подключится, но оставит в $wp_filesystem объект без соединения, и любой
	 * вызов на нём падает с TypeError. В этом случае работаем через PHP напрямую.
	 */
	private static function get_wp_filesystem() {
		global $wp_filesystem;
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		if ( $wp_filesystem instanceof WP_Filesystem_Direct ) {
			return $wp_filesystem;
		}
		if ( get_filesystem_method() !== 'direct' ) {
			return null;
		}
		if ( ! WP_Filesystem() || ! ( $wp_filesystem instanceof WP_Filesystem_Direct ) ) {
			return null;
		}
		return $wp_filesystem;
	}

	private static function read_file( $path ) {
		$fs = self::get_wp_filesystem();
		if ( $fs && $fs->exists( $path ) ) {
			return $fs->get_contents( $path );
		}
		if ( file_exists( $path ) && is_readable( $path ) ) {
			return file_get_contents( $path );
		}
		return false;
	}

	private static function write_file( $path, $content ) {
		// Бэкап перед каждой записью — на случай, если что-то пойдёт не так.
		self::backup( $path );

		$fs = self::get_wp_filesystem();
		if ( $fs ) {
			$result = $fs->put_contents( $path, $content, defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : 0644 );
			if ( $result ) return true;
		}
		if ( is_writable( dirname( $path ) ) && ( ! file_exists( $path ) || is_writable( $path ) ) ) {
			return ( file_put_contents( $path, $content ) !== false );
		}
		return false;
	}

	private static function backup( $path ) {
		if ( ! file_exists( $path ) ) return;
		$backup_dir = trailingslashit( WP_CONTENT_DIR ) . 'logshield-backups/';
		if ( ! file_exists( $backup_dir ) ) {
			@mkdir( $backup_dir, 0755, true );
			// Закрываем папку с бэкапами от прямого веб-доступа.
			@file_put_contents( $backup_dir . '.htaccess', "Require all denied\n" );
			@file_put_contents( $backup_dir . 'index.php', "<?php // silence\n" );
		}
		// Несколько записей в одну секунду не должны затирать друг друга.
		$base        = $backup_dir . 'htaccess-' . gmdate( 'Y-m-d-His' );
		$backup_file = $base . '.bak';
		for ( $n = 2; file_exists( $backup_file ); $n++ ) {
			$backup_file = $base . '-' . $n . '.bak';
		}
		@copy( $path, $backup_file );

		// Оставляем только последние 10 бэкапов.
		$files = glob( $backup_dir . 'htaccess-*.bak' );
		if ( $files && count( $files ) > 10 ) {
			usort( $files, function ( $a, $b ) { return filemtime( $a ) <=> filemtime( $b ); } );
			$to_delete = array_slice( $files, 0, count( $files ) - 10 );
			foreach ( $to_delete as $f ) @unlink( $f );
		}
	}
}
