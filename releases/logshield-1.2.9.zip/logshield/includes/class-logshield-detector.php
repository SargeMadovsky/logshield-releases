<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LogShield_Detector {

	const OFFSET_OPTION  = 'logshield_offset_state'; // [ 'path' => .., 'offset' => .., 'fp' => [ 'hash', 'len' ] ]
	const SCANLOG_OPTION = 'logshield_scan_log';

	/**
	 * Чувствительные пути: метка => регулярка по нормализованному пути
	 * (без query string, URL-декодирован, в нижнем регистре).
	 * Регулярки привязаны к сегментам пути, а не к подстроке: '/catalog/actuators'
	 * или '/.github/' не совпадут. xmlrpc.php сюда намеренно не входит — к нему
	 * легально ходят Jetpack, мобильное приложение WP и пингбеки; подбор пароля
	 * через xmlrpc ловится правилом brute-force.
	 */
	const SENSITIVE_PATTERNS = [
		'.env'           => '~(^|/)\.env([._-][^/]*)?$~',
		'.git/.svn'      => '~(^|/)\.(git|svn|hg)(/|$)~',
		'wp-config'      => '~(^|/)wp-config(\.php)?[^/]*$~',
		'.htpasswd'      => '~(^|/)\.ht(passwd|access)$~',
		'phpmyadmin'     => '~(^|/)(phpmyadmin[^/]*|myadmin|pma)(/|$)~',
		'дамп БД'        => '~(^|/)[^/]+\.sql(\.(gz|zip|bz2|tar))?$~',
		'config.php'     => '~^/(config|configuration)\.php$~',
		'server-status'  => '~^/server-(status|info)(/|$)~',
		'actuator'       => '~^/actuator(/|$)~',
		'веб-шелл'       => '~(^|/)(shell|c99|r57|wso|alfa)\.php$~',
		'.aws'           => '~(^|/)\.aws(/|$)~',
	];

	/**
	 * Входы не на WordPress (самописные формы): неудача — только 401/403.
	 * xmlrpc.php сюда не входит: Jetpack и приложение WP ходят к нему постоянно,
	 * а по ответу (всегда 200 или 403 от .htaccess) неудачу не отличить.
	 */
	const OTHER_LOGIN_PATHS = [ '/login', 'admin/login', 'auth/login', 'signin' ];

	/**
	 * Фоновые запросы WordPress: heartbeat и редактор (admin-ajax.php), планировщик
	 * (wp-cron.php). У сотрудника в админке их сотни — в частоту не считаются,
	 * если ответ успешный (атака на admin-ajax обычно получает 400).
	 */
	const BACKGROUND_PATHS_RE = '~/(wp-admin/admin-ajax|wp-cron)\.php$~';

	/**
	 * Служебные файлы в корне сайта, которые браузеры и легальные краулеры
	 * (рекламные, WebPageTest, Safari, поисковики) запрашивают «на всякий случай».
	 * 404 на них — не признак сканирования и не считается ошибкой.
	 */
	const SERVICE_PATHS_RE = '~^/(\.well-known/.*|ads\.txt|app-ads\.txt|sellers\.json|llms(-full)?\.txt|robots\.txt|humans\.txt|security\.txt|dsrdelete\.json|favicon\.ico|apple-touch-icon[^/]*\.png|browserconfig\.xml|site\.webmanifest|manifest\.json)$~';

	/**
	 * Статика: стили, скрипты, картинки, шрифты. 404 на неё со страницы самого
	 * сайта (Referer — свой домен) — битая ссылка в теме или плагине, её получает
	 * каждый посетитель страницы. Ошибкой посетителя это не считается.
	 */
	const STATIC_ASSET_RE = '~\.(css|js|mjs|map|png|jpe?g|gif|webp|avif|svg|ico|bmp|woff2?|ttf|otf|eot)$~';

	/**
	 * Правило «процент ошибок» требует столько разных путей с ошибкой: посетитель,
	 * который несколько раз повторил одно действие (неверный промокод — 422 на
	 * admin-ajax.php), набирает высокий процент на 1–2 путях, а сканер ошибается
	 * на многих разных. Фильтр logshield_error_rate_min_paths.
	 */
	const ERROR_RATE_MIN_PATHS = 5;

	/**
	 * Перебор пользователей: REST-список пользователей WordPress. Вместе с ?author=N
	 * (см. enum_target()) сканеры так узнают логины перед подбором пароля.
	 */
	const USERS_REST_RE = '~^/wp/v2/users(/\d+)?/?$~';

	const LOCK_OPTION        = 'logshield_scan_lock';       // время начала идущего сканирования
	const LOCK_TTL           = 900;                         // старше 15 минут — сканирование упало, замок ничей
	const WRITE_ERROR_OPTION = 'logshield_htaccess_error';  // [ 'error' => .., 'time' => .. ] — последняя неудачная запись

	/**
	 * Неудачные входы между сканированиями: ip => [ 'n' => попыток, 't' => последняя (время лога) ].
	 * Медленный подбор (по несколько попыток за сканирование) и атака, разрезанная
	 * границей куска, иначе не набирают порога.
	 */
	const CARRY_OPTION = 'logshield_login_carry';
	const CARRY_WINDOW = 86400; // запись живёт сутки после последней неудачи
	const CARRY_MAX    = 2000;  // больше — выбрасываются адреса с наименьшим числом попыток

	/** Догоняющие запуски, когда непрочитанный хвост лога большой. */
	const CATCHUP_OPTION    = 'logshield_catchup_runs'; // сколько догоняющих подряд
	const CATCHUP_MIN_BYTES = 1048576;                  // остаток от 1 МБ
	const CATCHUP_MAX_RUNS  = 12;
	const CATCHUP_DELAY     = 300;                      // через 5 минут
	const CATCHUP_WINDOW    = 600;                      // уже есть запуск в ближайшие 10 минут — не ставим

	/**
	 * Сканирование по расписанию или кнопкой. Cron и ручной запуск могут
	 * совпасть — тогда один кусок лога разобрали бы дважды. Поэтому запуск
	 * под замком; занят — ничего не делаем и возвращаем 'locked' => true.
	 */
	public static function run() {
		$lock = self::acquire_lock();
		if ( $lock === null ) {
			return [
				'time'    => time(),
				'ok'      => false,
				'locked'  => true,
				'lines'   => 0,
				'flagged' => [],
				'applied' => [],
				'message' => __( 'Сканирование уже выполняется. Попробуйте через минуту.', 'logshield' ),
			];
		}
		try {
			return self::run_locked();
		} finally {
			self::release_lock( $lock );
		}
	}

	/**
	 * Атомарный замок. add_option() не подходит: WordPress пишет его как
	 * INSERT … ON DUPLICATE KEY UPDATE, и два одновременных вызова оба
	 * «успешны». INSERT IGNORE вставляет строку только одному (затронута
	 * 1 строка), второй получает 0. Зависший замок (старше LOCK_TTL)
	 * перехватывается условным UPDATE — тоже выиграет только один.
	 *
	 * @return string|null значение замка (для снятия) или null, если занято
	 */
	private static function acquire_lock() {
		global $wpdb;
		$now    = (string) time();
		$insert = function () use ( $wpdb, $now ) {
			$n = $wpdb->query( $wpdb->prepare(
				"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
				self::LOCK_OPTION, $now
			) );
			wp_cache_delete( self::LOCK_OPTION, 'options' );
			wp_cache_delete( 'notoptions', 'options' );
			return $n === 1;
		};
		if ( $insert() ) return $now;

		$old = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::LOCK_OPTION ) );
		if ( $old === null ) {
			// Замок сняли между нашими запросами — пробуем ещё раз.
			return $insert() ? $now : null;
		}
		if ( (int) $old > time() - self::LOCK_TTL ) return null;

		$taken = $wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
			$now, self::LOCK_OPTION, $old
		) );
		wp_cache_delete( self::LOCK_OPTION, 'options' );
		return $taken === 1 ? $now : null;
	}

	/** Снимает замок, только если он всё ещё наш (его могли перехватить как зависший). */
	private static function release_lock( $value ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
			self::LOCK_OPTION, $value
		) );
		wp_cache_delete( self::LOCK_OPTION, 'options' );
	}

	private static function run_locked() {
		$opts     = LogShield_Plugin::get_options();
		$log_path = $opts['log_path'];

		$summary = [
			'time'    => time(),
			'ok'      => false,
			'lines'   => 0,
			'ips_seen'=> 0,
			'flagged' => [],
			'applied' => [],
			'dry_run' => (bool) $opts['dry_run'],
			'message' => '',
			'read_lines' => 0, // непустых строк прочитано из лога
			'unparsed'   => 0, // из них не распознано парсером
		];

		$found_note = '';
		if ( empty( $log_path ) ) {
			// Путь не указан — ищем сами (только если лог явно относится к сайту).
			$auto = LogShield_LogFinder::best_confident();
			if ( $auto ) {
				$log_path         = $auto;
				$opts['log_path'] = $auto;
				update_option( LOGSHIELD_OPTION, $opts );
				/* translators: %s: путь к файлу лога. */
				$found_note = sprintf( __( 'Путь к логу найден автоматически: %s.', 'logshield' ), $auto ) . ' ';
			}
		}

		if ( empty( $log_path ) || ! is_readable( $log_path ) ) {
			$summary['message'] = empty( $log_path )
				? __( 'Путь к логу не указан, и найти лог автоматически не удалось. Укажите путь в настройках.', 'logshield' )
				/* translators: %s: путь к файлу лога. */
				: sprintf( __( 'Файл лога недоступен для чтения: %s', 'logshield' ), $log_path );
			self::log_run( $summary );
			return $summary;
		}

		$offset_state = get_option( self::OFFSET_OPTION, [ 'path' => '', 'offset' => 0 ] );
		if ( ! is_array( $offset_state ) ) $offset_state = [ 'path' => '', 'offset' => 0 ];
		$offset_state += [ 'path' => '', 'offset' => 0 ];

		if ( $offset_state['path'] !== $log_path ) {
			// Новый (или первый) путь к логу: фиксируем текущий конец файла
			// и НЕ анализируем всю историю разом — только новые записи начиная
			// со следующего запуска. Это важно для слабого сервера с большими логами.
			clearstatcache();
			$size = @filesize( $log_path );
			update_option( self::OFFSET_OPTION, [ 'path' => $log_path, 'offset' => $size, 'fp' => LogShield_Parser::fingerprint( $log_path ) ], false );
			delete_option( self::CATCHUP_OPTION );

			$summary['ok']      = true;
			$summary['message'] = $found_note . sprintf(
				/* translators: %d: размер лога в байтах (с этого места начнётся чтение). */
				__( 'Путь к логу зафиксирован. Стартовая позиция: %d байт. Анализ новых записей начнётся со следующего запуска.', 'logshield' ),
				$size
			);
			self::log_run( $summary );
			return $summary;
		}

		$offset    = (int) $offset_state['offset'];
		$max_bytes = max( 1, (int) $opts['max_read_mb'] ) * 1024 * 1024;
		// Строки разбирает только analyze() (он же считает нераспознанные) — не дважды.
		$chunk     = LogShield_Parser::read_chunk( $log_path, $offset, $max_bytes, isset( $offset_state['fp'] ) ? $offset_state['fp'] : null, false );

		if ( isset( $chunk['error'] ) ) {
			/* translators: %s: текст ошибки чтения. */
			$summary['message'] = sprintf( __( 'Ошибка чтения лога: %s', 'logshield' ), $chunk['error'] );
			self::log_run( $summary );
			return $summary;
		}

		update_option( self::OFFSET_OPTION, [ 'path' => $log_path, 'offset' => $chunk['new_offset'], 'fp' => $chunk['fingerprint'] ], false );

		// Большой непрочитанный хвост — догоняющий запуск через 5 минут.
		$catchup_note = self::schedule_catchup( (int) $chunk['size'] - (int) $chunk['new_offset'] );
		$rotated_note = $chunk['rotated'] ? __( 'Лог был ротирован — чтение начато с начала нового файла.', 'logshield' ) . ' ' : '';

		// Нераспознанные строки правила не видят — дашборд предупредит, если их много.
		// Их число приходит из analyze() ниже (пустой кусок — 0).
		$summary['read_lines'] = count( $chunk['lines'] );

		if ( empty( $chunk['lines'] ) ) {
			$summary['ok']      = true;
			$summary['message'] = $found_note . ( $chunk['rotated']
				? __( 'Лог был ротирован — позиция сброшена, новые записи будут проанализированы в следующий раз.', 'logshield' )
				: __( 'Новых записей в логе не найдено.', 'logshield' ) );
			$retry = self::retry_pending_write( $opts );
			if ( $retry !== '' ) $summary['message'] .= ' ' . $retry;
			if ( $catchup_note !== '' ) $summary['message'] .= ' ' . $catchup_note;
			self::log_run( $summary );
			return $summary;
		}

		$whitelist = LogShield_Whitelist::get_full_whitelist( (array) $opts['whitelist_ips'] );
		$carry     = get_option( self::CARRY_OPTION, [] );
		$summary   = self::analyze( $chunk['lines'], $opts, $whitelist, is_array( $carry ) ? $carry : [] ) + $summary;
		self::save_carry( $summary['carry'] );
		// Уже забаненные адреса продолжают стучаться и получают 403 — в логе
		// они снова выглядят как атака. Повторно не помечаем и не уведомляем.
		$summary['flagged'] = self::without_banned( $summary['flagged'], array_keys( LogShield_Htaccess::get_banned() ) );
		$flagged            = $summary['flagged'];
		$summary['types']   = array_intersect_key( $summary['types'], $flagged );
		LogShield_Stats::record( $summary['hourly'], $summary['types'] );
		// Страна и сеть: только для информации, на баны не влияет.
		LogShield_IPInfo::remember( $summary['noisy'], array_keys( $flagged ), null, $summary['noisy_info'] );
		unset( $summary['hourly'], $summary['noisy'], $summary['noisy_info'], $summary['carry'] ); // в историю сканирований не нужно

		$applied     = [];
		$write_error = '';
		if ( ! $opts['dry_run'] && ! empty( $flagged ) ) {
			$to_ban = [];
			foreach ( $flagged as $ip => $reasons ) {
				$to_ban[ $ip ] = implode( '; ', $reasons );
			}
			// Одна запись в .htaccess на всё сканирование.
			if ( LogShield_Htaccess::ban_ips( $to_ban, (int) $opts['ban_expiry_days'] ) ) {
				$applied = array_keys( $to_ban );
				self::clear_write_error();
			} else {
				$write_error = (string) LogShield_Htaccess::last_error();
				if ( $write_error === '' ) $write_error = __( 'неизвестная ошибка записи', 'logshield' );
				self::remember_write_error( $write_error );
			}
		}
		// Новых нет, но прошлая запись не удалась — переписываем блок из списка банов.
		$retry = empty( $flagged ) ? self::retry_pending_write( $opts ) : '';

		$summary['ok']       = $write_error === '';
		$summary['applied']  = $applied;
		$summary['message']  = $found_note . $rotated_note . sprintf(
			$opts['dry_run']
				/* translators: 1: число строк, 2: число IP, 3: число подозрительных адресов. */
				? __( 'Обработано %1$d строк, %2$d IP, обнаружено подозрительных: %3$d (тестовый режим — блокировка не применена)', 'logshield' )
				/* translators: 1: число строк, 2: число IP, 3: число подозрительных адресов. */
				: __( 'Обработано %1$d строк, %2$d IP, обнаружено подозрительных: %3$d', 'logshield' ),
			$summary['lines'],
			$summary['ips_seen'],
			count( $flagged )
		);
		if ( $write_error !== '' ) {
			$summary['write_error'] = $write_error;
			$summary['message']    .= '. ' . sprintf(
				/* translators: %s: причина, по которой не удалось записать .htaccess. */
				__( 'Блокировка НЕ записана в .htaccess: %s. Адреса остались в списке банов — запись повторится при следующем сканировании.', 'logshield' ),
				$write_error
			);
		}
		if ( $summary['unparsed'] > 0 ) {
			/* translators: %d: число нераспознанных строк лога. */
			$summary['message'] .= '. ' . sprintf( __( 'Не распознано строк: %d', 'logshield' ), $summary['unparsed'] );
		}
		if ( $retry !== '' ) $summary['message'] .= '. ' . $retry;

		// В тестовом режиме никто не банится, и те же адреса помечаются каждый
		// запуск. В истории они остаются (из неё строится таблица атакующих),
		// а в уведомление попадают только те, о ком не сообщали последние сутки.
		$to_notify = LogShield_Notifier::not_recently_notified( $flagged );
		$channels  = ! empty( $opts['notify_email'] ) || LogShield_Notifier::telegram_configured( $opts );
		if ( $channels && $flagged && ! $to_notify ) {
			$summary['message'] .= '. ' . __( 'Уведомление не отправлено: обо всех уже сообщали за последние 24 ч', 'logshield' );
		} elseif ( $channels && count( $to_notify ) < count( $flagged ) ) {
			/* translators: %d: число адресов в уведомлении. */
			$summary['message'] .= '. ' . sprintf( __( 'В уведомлении только новые: %d (об остальных сообщали за последние 24 ч)', 'logshield' ), count( $to_notify ) );
		}
		if ( $catchup_note !== '' ) $summary['message'] .= '. ' . $catchup_note;

		self::log_run( $summary );
		if ( $to_notify && LogShield_Notifier::notify( [ 'flagged' => $to_notify ] + $summary, $opts ) ) {
			LogShield_Notifier::remember_notified( array_keys( $to_notify ) );
		}

		return $summary;
	}

	/**
	 * Непрочитанный хвост лога большой — ставит разовый догоняющий запуск
	 * через 5 минут. Не больше CATCHUP_MAX_RUNS подряд, дальше — обычное
	 * расписание; счётчик сбрасывается, когда хвост догнан.
	 *
	 * @param int $remaining сколько байт лога осталось непрочитанными
	 * @return string пометка для сообщения сканирования ('' — ничего не запланировано)
	 */
	private static function schedule_catchup( $remaining ) {
		if ( $remaining < self::CATCHUP_MIN_BYTES ) {
			if ( get_option( self::CATCHUP_OPTION, null ) !== null ) delete_option( self::CATCHUP_OPTION );
			return '';
		}
		$mb   = round( $remaining / 1048576, 1 );
		$runs = (int) get_option( self::CATCHUP_OPTION, 0 );
		if ( $runs >= self::CATCHUP_MAX_RUNS ) {
			/* translators: 1: остаток лога в МБ, 2: число догоняющих запусков подряд. */
			return sprintf( __( 'Непрочитанный остаток лога: %1$s МБ. Догоняющих запусков было уже %2$d подряд — остаток дочитается по обычному расписанию', 'logshield' ), $mb, $runs );
		}
		$next = wp_next_scheduled( LOGSHIELD_CRON_HOOK );
		if ( $next && $next <= time() + self::CATCHUP_WINDOW ) {
			/* translators: %s: остаток лога в МБ. */
			return sprintf( __( 'Непрочитанный остаток лога: %s МБ — дочитается при ближайшем запуске', 'logshield' ), $mb );
		}
		$ok = wp_schedule_single_event( time() + self::CATCHUP_DELAY, LOGSHIELD_CRON_HOOK );
		if ( $ok === false || is_wp_error( $ok ) ) {
			/* translators: %s: остаток лога в МБ. */
			return sprintf( __( 'Непрочитанный остаток лога: %s МБ. Догоняющий запуск запланировать не удалось', 'logshield' ), $mb );
		}
		update_option( self::CATCHUP_OPTION, $runs + 1, false );
		/* translators: 1: остаток лога в МБ, 2: номер догоняющего запуска, 3: наибольшее число таких запусков. */
		return sprintf( __( 'Непрочитанный остаток лога: %1$s МБ — запланирован догоняющий запуск через 5 минут (%2$d из %3$d)', 'logshield' ), $mb, $runs + 1, self::CATCHUP_MAX_RUNS );
	}

	/** Сохраняет перенос неудачных входов (без автозагрузки). */
	private static function save_carry( array $carry ) {
		if ( ! $carry ) {
			if ( get_option( self::CARRY_OPTION, null ) !== null ) delete_option( self::CARRY_OPTION );
			return;
		}
		update_option( self::CARRY_OPTION, $carry, false );
	}

	/**
	 * Применяет правила к строкам лога. Ничего не пишет и не банит.
	 *
	 * @param string[] $lines     строки access_log
	 * @param array    $opts      настройки плагина
	 * @param string[] $whitelist IP и диапазоны CIDR, которые не трогаем
	 * @param array    $carry     неудачные входы прошлых сканирований: ip => [ 'n' => .., 't' => .. ]
	 *                            (см. CARRY_OPTION); обновлённый перенос возвращается в 'carry'
	 * @return array [ 'lines' => int, 'ips_seen' => int, 'flagged' => [ ip|cidr => [причины] ], 'carry' => [...], … ]
	 */
	public static function analyze( array $lines, array $opts, array $whitelist, array $carry = [] ) {
		$wl_exact  = [];
		$wl_ranges = [];
		foreach ( $whitelist as $w ) {
			if ( strpos( $w, '/' ) !== false ) $wl_ranges[] = $w; else $wl_exact[ $w ] = true;
		}
		$wl_cache = [];
		$is_white = function ( $ip ) use ( &$wl_cache, $wl_exact, $wl_ranges ) {
			if ( ! isset( $wl_cache[ $ip ] ) ) {
				$wl_cache[ $ip ] = isset( $wl_exact[ $ip ] ) || ( $wl_ranges && LogShield_IP::matches_any( $ip, $wl_ranges ) );
			}
			return $wl_cache[ $ip ];
		};

		// Referer со страницы самого сайта: хост главной (без www.) или домен из строки лога.
		$own_hosts = [];
		$home_host = function_exists( 'home_url' ) ? wp_parse_url( home_url(), PHP_URL_HOST ) : '';
		if ( $home_host ) $own_hosts[ preg_replace( '~^www\.~', '', strtolower( $home_host ) ) ] = true;
		$ref_cache   = [];
		$is_own_page = function ( $referer, $domain ) use ( &$ref_cache, $own_hosts ) {
			if ( ! isset( $ref_cache[ $referer ] ) ) {
				$ref_cache[ $referer ] = preg_match( '~^https?://(?:www\.)?([^/:?#]+)~i', $referer, $m ) ? strtolower( $m[1] ) : '';
			}
			$host = $ref_cache[ $referer ];
			if ( $host === '' ) return false;
			return isset( $own_hosts[ $host ] ) || ( $domain !== '' && $host === preg_replace( '~^www\.~', '', strtolower( $domain ) ) );
		};

		$ip_records = [];
		$processed  = 0;
		$hourly     = [];  // час => счётчики для графиков (весь трафик, и whitelist тоже)
		$hour_ips   = [];
		$hour_cache = [];
		$last_time  = null; // самое позднее время строки в куске (по логу)
		$unparsed   = 0;    // непустые строки, которые парсер не распознал

		foreach ( $lines as $line ) {
			$entry = LogShield_Parser::parse_line( $line );
			if ( ! $entry ) {
				if ( trim( $line ) !== '' ) $unparsed++;
				continue;
			}
			if ( LogShield_Whitelist::is_own_request( $entry ) ) continue;

			$ip     = $entry['ip'];
			$status = $entry['status'];
			$norm   = self::normalize_path( $entry['path'] );
			$failed = self::is_failed_login( $entry, $norm );

			$hour = self::hour_of( $entry['date'], $hour_cache );
			$time = null;
			if ( $hour !== null ) {
				if ( ! isset( $hourly[ $hour ] ) ) $hourly[ $hour ] = [ 'req' => 0, 'e4' => 0, 'e5' => 0, 'fails' => 0, 'ips' => 0 ];
				$hourly[ $hour ]['req']++;
				if ( $status >= 500 ) $hourly[ $hour ]['e5']++;
				elseif ( $status >= 400 ) $hourly[ $hour ]['e4']++;
				if ( $failed ) $hourly[ $hour ]['fails']++;
				$hour_ips[ $hour ][ $ip ] = true;
				// «dd/Mon/yyyy:HH:mm:ss zone» — минуты и секунды к началу часа.
				$time = $hour + 60 * (int) substr( $entry['date'], 15, 2 ) + (int) substr( $entry['date'], 18, 2 );
				if ( $last_time === null || $time > $last_time ) $last_time = $time;
			}

			if ( $is_white( $ip ) ) continue;

			$processed++;

			if ( ! isset( $ip_records[ $ip ] ) ) {
				$ip_records[ $ip ] = [ 'total' => 0, 'rate' => 0, 'ts' => '', 'errors' => 0, 'err_paths' => [], 'error_paths' => [],'login_fails' => 0, 'fail_time' => null, 'sensitive' => [], 'enum' => [], 'bad' => 0, 'danger' => 0, 'ua' => [], 'ua_more' => false ];
			}
			$r =& $ip_records[ $ip ];

			$r['total']++;
			if ( $status >= 400 || ! preg_match( self::BACKGROUND_PATHS_RE, $norm ) ) {
				$r['rate']++;
				// Время учитываемого запроса — 4 байта в строку: дешевле массива на
				// каждый IP. Окна считаются потом и только у тех, кого набралось много.
				if ( $time !== null ) $r['ts'] .= pack( 'N', $time );
			}
			$is_error = $status >= 400
				&& ! ( $status < 500 && preg_match( self::SERVICE_PATHS_RE, $norm ) )
				&& ! ( $status === 404 && preg_match( self::STATIC_ASSET_RE, $norm ) && $is_own_page( $entry['referer'], (string) $entry['domain'] ) );
			if ( $is_error ) {
				$r['errors']++;
				$r['err_paths'][ $norm ] = true;
			}
			// Сканер перебирает несуществующие пути; обычный посетитель и
			// поисковый бот ходят по живым страницам и ошибок почти не получают.
			if ( $is_error && $status < 500 ) $r['error_paths'][ $norm ] = true;

			$label = self::match_sensitive( $norm );
			if ( $label !== null ) {
				$r['sensitive'][ $norm ] = $label; // считаем разные пути, не повторы
			}

			$enum = self::enum_target( $entry['path'], $norm );
			if ( $enum !== null ) $r['enum'][ $enum ] = true; // разные ID, не повторы

			if ( $failed ) {
				$r['login_fails']++;
				if ( $time !== null && ( $r['fail_time'] === null || $time > $r['fail_time'] ) ) $r['fail_time'] = $time;
			}
			if ( $failed || $is_error ) {
				$r['bad']++;
				// «Опасная» ошибка: вход, чувствительный путь, перебор пользователей, xmlrpc.php.
				// Только для подсказки в карточке «Настойчивые адреса», на правила не влияет.
				if ( $failed || $label !== null || $enum !== null || substr( $norm, -11 ) === '/xmlrpc.php' || substr( $norm, -13 ) === '/wp-login.php' ) $r['danger']++;
			}
			// User-Agent для подсказки «кто это»: не больше UA_TRACK разных на адрес.
			$ua = $entry['user_agent'];
			if ( isset( $r['ua'][ $ua ] ) ) $r['ua'][ $ua ]++;
			elseif ( count( $r['ua'] ) < self::UA_TRACK ) $r['ua'][ $ua ] = 1;
			else $r['ua_more'] = true;
			unset( $r );
		}

		// Перенос с прошлых сканирований: без просроченных (сутки по времени лога)
		// и без адресов, попавших с тех пор в белый список.
		$now = $last_time;
		if ( $now === null ) {
			// В куске нет строк с датой — отсчитываем от самой свежей записи переноса.
			$ts = [];
			foreach ( $carry as $c ) {
				if ( is_array( $c ) && isset( $c['t'] ) ) $ts[] = (int) $c['t'];
			}
			$now = $ts ? max( $ts ) : time();
		}
		$prev = [];
		foreach ( $carry as $ip => $c ) {
			$ip = (string) $ip;
			if ( ! is_array( $c ) || ! isset( $c['n'], $c['t'] ) || (int) $c['n'] < 1 ) continue;
			if ( (int) $c['t'] < $now - self::CARRY_WINDOW ) continue;
			if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) || $is_white( $ip ) ) continue;
			$prev[ $ip ] = [ 'n' => (int) $c['n'], 't' => (int) $c['t'] ];
		}

		$flagged    = [];
		$types      = [];
		$rate_limit = (int) ( $opts['rate_per_min'] ?? 0 ); // 0 — правило частоты выключено
		$err_min_paths = max( 1, (int) apply_filters( 'logshield_error_rate_min_paths', self::ERROR_RATE_MIN_PATHS ) );
		foreach ( $ip_records as $ip => $r ) {
			$reasons = [];
			$t       = [];

			// Меньше порога за весь кусок — и за минуту не наберётся, окна не считаем.
			if ( $rate_limit > 0 && $r['rate'] >= $rate_limit ) {
				$peak = self::peak_per_minute( $r['ts'] );
				if ( $peak['count'] >= $rate_limit ) {
					/* translators: 1: запросов за минуту, 2: время пика. */
					$reasons[] = sprintf( __( 'высокая частота запросов (%1$d за минуту, пик %2$s)', 'logshield' ), $peak['count'], self::format_time( $peak['start'] ) );
					$t[]       = 'rate';
				}
			}
			// Неудачные входы: этот кусок лога плюс перенос с прошлых сканирований.
			$prev_fails = $r['login_fails'] > 0 && isset( $prev[ $ip ] ) ? $prev[ $ip ]['n'] : 0;
			$fails      = $r['login_fails'] + $prev_fails;
			if ( $r['login_fails'] > 0 && $fails >= $opts['brute_attempts'] ) {
				$reasons[] = $prev_fails > 0
					/* translators: %d: число неудачных входов. */
					? sprintf( __( 'подбор пароля (%d неудачных входов за 24 ч)', 'logshield' ), $fails )
					/* translators: %d: число неудачных входов. */
					: sprintf( __( 'подбор пароля (%d неудачных входов)', 'logshield' ), $fails );
				$t[]       = 'brute';
			}
			$error_paths = count( $r['error_paths'] );
			if ( $error_paths >= $opts['scan_unique_paths'] && $r['total'] >= $opts['scan_min_requests'] ) {
				/* translators: %d: число разных путей с ошибкой 4xx. */
				$reasons[] = sprintf( __( 'сканирование (%d несуществующих или закрытых путей)', 'logshield' ), $error_paths );
				$t[]       = 'scan';
			}
			if ( $r['total'] >= $opts['error_rate_min_requests'] && count( $r['err_paths'] ) >= $err_min_paths ) {
				$err_pct = ( $r['errors'] / $r['total'] ) * 100;
				if ( $err_pct >= $opts['error_rate_pct'] ) {
					/* translators: 1: процент ответов с ошибкой, 2: число разных путей с ошибкой. */
					$reasons[] = sprintf( __( 'высокий процент ошибок (%1$.0f%%, %2$d разных путей)', 'logshield' ), $err_pct, count( $r['err_paths'] ) );
					$t[]       = 'errors';
				}
			}
			// Одно случайное обращение — не повод для бана: сканеры перебирают
			// много разных чувствительных путей за раз.
			$sensitive_count = count( $r['sensitive'] );
			if ( $sensitive_count >= max( 1, (int) $opts['sensitive_min_hits'] ) ) {
				$examples  = array_map( [ __CLASS__, 'sensitive_label' ], array_slice( array_keys( $r['sensitive'] ), 0, 3 ) );
				$reasons[] = sprintf(
					/* translators: 1: число разных путей, 2: примеры через запятую, 3: «, …», если примеров больше трёх. */
					__( 'обращения к чувствительным путям (%1$d: %2$s%3$s)', 'logshield' ),
					$sensitive_count,
					implode( ', ', $examples ),
					$sensitive_count > 3 ? ', …' : ''
				);
				$t[]       = 'sensitive';
			}

			// Перебор авторов (?author=1, 2, 3…) и REST-списка пользователей —
			// разведка логинов перед подбором пароля. Посетитель открывает
			// автора по ссылке /author/имя/, а не по номерам подряд.
			$enum_count = count( $r['enum'] );
			if ( $enum_count >= max( 1, (int) $opts['enum_min_hits'] ) ) {
				/* translators: 1: число разных целей, 2: примеры через запятую, 3: «, …», если примеров больше трёх. */
				$reasons[] = sprintf( __( 'перебор пользователей (%1$d: %2$s%3$s)', 'logshield' ), $enum_count, implode( ', ', array_slice( array_keys( $r['enum'] ), 0, 3 ) ), $enum_count > 3 ? ', …' : '' );
				$t[]       = 'enum';
			}

			if ( ! empty( $reasons ) ) {
				$flagged[ $ip ] = $reasons;
				$types[ $ip ]   = $t;
			}
		}

		// Распределённый подбор пароля: каждый адрес подсети делает немного
		// попыток (меньше порога на один IP), но вместе их много.
		// Считается вместе с переносом: адреса, приходившие в прошлые сканирования, тоже в счёт.
		$fails_by_ip = [];
		foreach ( $prev as $ip => $c ) $fails_by_ip[ $ip ] = [ 'now' => 0, 'prev' => $c['n'] ];
		foreach ( $ip_records as $ip => $r ) {
			if ( $r['login_fails'] < 1 ) continue;
			$ip = (string) $ip;
			if ( ! isset( $fails_by_ip[ $ip ] ) ) $fails_by_ip[ $ip ] = [ 'now' => 0, 'prev' => 0 ];
			$fails_by_ip[ $ip ]['now'] = $r['login_fails'];
		}
		$subnets = [];
		foreach ( $fails_by_ip as $ip => $fc ) {
			$net = LogShield_IP::subnet_of( $ip );
			if ( $net === null ) continue;
			if ( ! isset( $subnets[ $net ] ) ) $subnets[ $net ] = [ 'ips' => [], 'fails' => 0, 'prev' => 0, 'now' => 0 ];
			$subnets[ $net ]['ips'][] = $ip;
			$subnets[ $net ]['fails'] += $fc['now'] + $fc['prev'];
			$subnets[ $net ]['prev']  += $fc['prev'];
			$subnets[ $net ]['now']   += $fc['now'];
		}
		$min_ips      = max( 2, (int) $opts['subnet_min_ips'] );
		$min_attempts = max( 1, (int) $opts['subnet_min_attempts'] );
		$caught_nets  = [];
		foreach ( $subnets as $net => $sn ) {
			// Без новых попыток в этом куске подсеть уже проверялась раньше.
			if ( $sn['now'] < 1 ) continue;
			if ( count( $sn['ips'] ) < $min_ips || $sn['fails'] < $min_attempts ) continue;
			// В подсети сотрудник или сервер — диапазон не баним (отдельные IP — по своим правилам).
			$protected = false;
			foreach ( $whitelist as $w ) {
				if ( LogShield_IP::overlaps( $w, $net ) ) { $protected = true; break; }
			}
			if ( $protected ) continue;

			$flagged[ $net ] = [ sprintf(
				$sn['prev'] > 0
					/* translators: 1: число адресов подсети, 2: число неудачных входов. */
					? __( 'распределённый подбор пароля (%1$d IP из подсети, %2$d неудачных входов за 24 ч)', 'logshield' )
					/* translators: 1: число адресов подсети, 2: число неудачных входов. */
					: __( 'распределённый подбор пароля (%1$d IP из подсети, %2$d неудачных входов)', 'logshield' ),
				count( $sn['ips'] ),
				$sn['fails']
			) ];
			$types[ $net ] = [ 'subnet' ];
			$caught_nets[] = $net;
			// Адреса внутри диапазона отдельно банить не нужно.
			foreach ( $sn['ips'] as $ip ) unset( $flagged[ $ip ], $types[ $ip ] );
		}

		// Новый перенос: прошлые записи плюс неудачи этого куска. Пойманные
		// (адресом или подсетью) из него выходят — счёт для них начнётся заново.
		$new_carry = $prev;
		foreach ( $ip_records as $ip => $r ) {
			if ( $r['login_fails'] < 1 ) continue;
			$ip = (string) $ip;
			$t  = $r['fail_time'] !== null ? $r['fail_time'] : $now;
			if ( isset( $new_carry[ $ip ] ) ) {
				$new_carry[ $ip ]['n'] += $r['login_fails'];
				$new_carry[ $ip ]['t']  = max( $new_carry[ $ip ]['t'], $t );
			} else {
				$new_carry[ $ip ] = [ 'n' => $r['login_fails'], 't' => $t ];
			}
		}
		foreach ( array_keys( $flagged ) as $key ) unset( $new_carry[ (string) $key ] );
		if ( $caught_nets ) {
			foreach ( $caught_nets as $net ) {
				foreach ( $subnets[ $net ]['ips'] as $ip ) unset( $new_carry[ $ip ] );
			}
		}
		if ( count( $new_carry ) > self::CARRY_MAX ) {
			// Оставляем самых настойчивых; при равенстве — недавних.
			uasort( $new_carry, function ( $a, $b ) {
				return $b['n'] <=> $a['n'] ?: $b['t'] <=> $a['t'];
			} );
			$new_carry = array_slice( $new_carry, 0, self::CARRY_MAX, true );
		}

		foreach ( $hour_ips as $hour => $set ) $hourly[ $hour ]['ips'] = count( $set );

		// Настойчивые адреса: много ошибок или неудачных входов. Для них (и для
		// пойманных) определяются страна и сеть — только для информации.
		$noisy    = [];
		$min_hits = max( 1, (int) apply_filters( 'logshield_ipinfo_min_hits', LogShield_IPInfo::MIN_HITS ) );
		$info     = [];
		foreach ( $ip_records as $ip => $r ) {
			$ip = (string) $ip;
			if ( $r['bad'] >= $min_hits ) $noisy[ $ip ] = $r['bad'];
			// Подсказки (UA и разбивка ошибок) — для настойчивых и пойманных правилами.
			if ( isset( $noisy[ $ip ] ) || isset( $flagged[ $ip ] ) ) $info[ $ip ] = self::ip_hint( $r );
		}

		return [
			'lines'    => $processed,
			'ips_seen' => count( $ip_records ),
			'flagged'  => $flagged,
			'types'    => $types,   // ip|cidr => [ ключ из LogShield_Stats::TYPES ]
			'hourly'   => $hourly,  // час (unix) => [ req, e4, e5, fails, ips ]
			'noisy'    => $noisy,   // ip => ошибок и неудачных входов (≥ порога)
			'noisy_info' => $info,  // ip => [ ua, uas, bad, danger ] — для настойчивых и пойманных (см. ip_hint())
			'carry'    => $new_carry, // ip => [ 'n', 't' ] — неудачные входы для следующего сканирования
			'unparsed' => $unparsed,  // непустых строк не распознано (как 'unparsed' у read_chunk())
		];
	}

	/** Сколько разных User-Agent запоминать на адрес за сканирование (дальше — «больше»). */
	const UA_TRACK = 32;

	/** Длина сохраняемого User-Agent, байт (по границе символа UTF-8). */
	const UA_MAX = 300;

	/**
	 * Подсказка об адресе для карточки «Настойчивые адреса»: самый частый UA
	 * (обрезанный до UA_MAX), число разных UA (UA_TRACK + 1 — «больше UA_TRACK»),
	 * ошибок всего и из них «опасных». Только для информации.
	 */
	private static function ip_hint( array $r ) {
		$ua = '';
		if ( $r['ua'] ) {
			arsort( $r['ua'] );
			$ua = (string) array_key_first( $r['ua'] );
			if ( strlen( $ua ) > self::UA_MAX ) $ua = mb_strcut( $ua, 0, self::UA_MAX, 'UTF-8' );
		}
		return [
			'ua'     => $ua,
			'uas'    => count( $r['ua'] ) + ( $r['ua_more'] ? 1 : 0 ),
			'bad'    => (int) $r['bad'],
			'danger' => (int) $r['danger'],
		];
	}

	/** Окно правила частоты, секунд. */
	const RATE_WINDOW = 60;

	/**
	 * На сколько секунд строка лога может отставать от более поздних строк
	 * того же IP (Apache пишет запрос по завершении: долгий запрос оказывается
	 * ниже быстрых). На реальном логе — до ~20 с. Опоздавшая сильнее строка
	 * не теряется: тогда метки просто сортируются целиком.
	 */
	const RATE_SLACK = 120;

	/**
	 * Наибольшее число запросов в любом окне RATE_WINDOW секунд.
	 *
	 * Метки идут почти по порядку, поэтому держим счётчики по секундам только
	 * для последних нескольких минут: окна, которые уже не может задеть
	 * опоздавшая строка, считаются и выбрасываются. У атакующего с ~10 тыс.
	 * запросов так не нужен массив на все метки. Результат точный.
	 *
	 * @param string $packed метки времени (unix), pack( 'N', … ) подряд
	 * @return array [ 'count' => int, 'start' => int|null — время первого запроса в пиковом окне ]
	 */
	public static function peak_per_minute( $packed ) {
		$best = [ 'count' => 0, 'start' => null ];
		$n    = intdiv( strlen( $packed ), 4 );
		if ( $n === 0 ) return $best;
		$w     = self::RATE_WINDOW;
		$cnt   = [];   // секунда => запросов
		$first = null; // самая ранняя секунда (до первого подсчёта)
		$last  = null; // самая поздняя секунда
		$done  = null; // окна, начинающиеся не позже этой секунды, уже посчитаны
		for ( $i = 0; $i < $n; $i++ ) {
			$t = unpack( 'N', $packed, $i * 4 )[1];
			if ( $done !== null && $t < $done + $w ) {
				return self::peak_sorted( $packed ); // опоздала больше чем на RATE_SLACK
			}
			$cnt[ $t ] = ( $cnt[ $t ] ?? 0 ) + 1;
			if ( $last === null || $t > $last ) $last = $t;
			if ( $first === null || $t < $first ) $first = $t;
			// Окна с началом не позже $upto кончаются раньше, чем $last - RATE_SLACK.
			$upto = $last - self::RATE_SLACK - $w;
			if ( $upto >= ( $done ?? $first ) + self::RATE_SLACK ) {
				self::peak_flush( $cnt, $done, $upto, $best );
				$done = $upto;
			}
		}
		self::peak_flush( $cnt, $done, PHP_INT_MAX, $best );
		return $best;
	}

	/**
	 * Считает окна с началом в ( $after, $upto ] по счётчикам секунд и
	 * выбрасывает секунды, которые больше ни в одно непосчитанное окно не входят.
	 */
	private static function peak_flush( array &$cnt, $after, $upto, array &$best ) {
		ksort( $cnt, SORT_NUMERIC );
		$k   = array_keys( $cnt );
		$v   = array_values( $cnt );
		$m   = count( $k );
		$sum = 0;
		for ( $a = 0, $b = 0; $a < $m && $k[ $a ] <= $upto; $a++ ) {
			// Лучшее окно всегда начинается с какого-то запроса — перебираем только их.
			while ( $b < $m && $k[ $b ] < $k[ $a ] + self::RATE_WINDOW ) $sum += $v[ $b++ ];
			if ( ( $after === null || $k[ $a ] > $after ) && $sum > $best['count'] ) {
				$best = [ 'count' => $sum, 'start' => $k[ $a ] ];
			}
			$sum -= $v[ $a ];
			unset( $cnt[ $k[ $a ] ] );
		}
	}

	/** То же по всем меткам сразу (запасной путь, если строки сильно не по порядку). */
	private static function peak_sorted( $packed ) {
		$ts = unpack( 'N*', $packed );
		sort( $ts, SORT_NUMERIC );
		$n    = count( $ts );
		$best = [ 'count' => 0, 'start' => null ];
		for ( $i = 0, $j = 0; $i < $n; $i++ ) {
			while ( $ts[ $i ] - $ts[ $j ] >= self::RATE_WINDOW ) $j++;
			if ( $i - $j + 1 > $best['count'] ) $best = [ 'count' => $i - $j + 1, 'start' => $ts[ $j ] ];
		}
		return $best;
	}

	/** Время пика для причины: ЧЧ:ММ в часовом поясе сайта. */
	private static function format_time( $ts ) {
		if ( $ts === null ) return '?';
		return function_exists( 'wp_date' ) ? wp_date( 'H:i', $ts ) : gmdate( 'H:i', $ts );
	}

	/**
	 * «12/Nov/2026:00:03:12 +0300» → начало часа (unix). Кэш по часу и поясу:
	 * DateTime на каждую строку дорог.
	 */
	private static function hour_of( $date, array &$cache ) {
		$key = substr( $date, 0, 14 ) . substr( $date, 20 );
		if ( ! array_key_exists( $key, $cache ) ) {
			$dt            = DateTime::createFromFormat( 'd/M/Y:H:i:s O', substr( $date, 0, 14 ) . ':00:00' . substr( $date, 20 ) );
			$cache[ $key ] = $dt ? $dt->getTimestamp() : null;
		}
		return $cache[ $key ];
	}

	/**
	 * Неудачная попытка входа.
	 *
	 * WordPress на неверный пароль отвечает 200 (форма с ошибкой), на успешный
	 * вход — 302. Поэтому для POST на wp-login.php в любом каталоге
	 * (/wp-login.php, /wp/wp-login.php, /wordpress/… — пробы получают 404)
	 * неудача — любой ответ, кроме перенаправления. Остальные действия формы
	 * (lostpassword, register, postpass) не считаются.
	 */
	public static function is_failed_login( array $entry, $norm ) {
		$status = (int) $entry['status'];
		if ( strtoupper( $entry['method'] ) === 'POST' && substr( $norm, -13 ) === '/wp-login.php' ) {
			$query = (string) parse_url( 'http://x' . $entry['path'], PHP_URL_QUERY );
			parse_str( $query, $q );
			$action = isset( $q['action'] ) && is_string( $q['action'] ) ? strtolower( $q['action'] ) : 'login';
			if ( $action !== 'login' ) return false;
			return $status < 300 || $status >= 400;
		}
		if ( $status === 401 || $status === 403 ) {
			foreach ( self::OTHER_LOGIN_PATHS as $lp ) {
				if ( strpos( $norm, $lp ) !== false ) return true;
			}
		}
		return false;
	}

	/**
	 * Путь из лога → вид для сравнения: без query string и фрагмента,
	 * URL-декодирован (сканеры шлют %2e вместо точки), нижний регистр,
	 * повторные слэши схлопнуты.
	 */
	public static function normalize_path( $path ) {
		$path = (string) $path;
		$cut  = strcspn( $path, '?#' );
		$path = substr( $path, 0, $cut );
		$path = strtolower( rawurldecode( $path ) );
		$path = preg_replace( '~/{2,}~', '/', $path );
		if ( $path === '' || $path[0] !== '/' ) $path = '/' . $path;
		return $path;
	}

	/**
	 * Цель перебора пользователей или null: «author=7» для ?author=7 на любой
	 * странице, «users», «users/3» для REST (/wp-json/wp/v2/users и ?rest_route=).
	 * /author/имя/ не считается — это обычная ссылка с сайта.
	 */
	public static function enum_target( $path, $norm ) {
		// Быстрый выход для обычных запросов: без /wp-json/ цель может прийти только
		// из query string, а в ней — ключ author или rest_route. parse_str() меняет
		// в ключах «.», « », «[» на «_» и декодирует %XX, но буквы «author» и «rest»
		// без «%» остаются как есть.
		if ( strpos( $norm, '/wp-json/' ) === false ) {
			$qpos = strpos( $path, '?' );
			if ( $qpos === false ) return null;
			if ( strpos( $path, 'author', $qpos ) === false && strpos( $path, 'rest', $qpos ) === false && strpos( $path, '%', $qpos ) === false ) return null;
		}
		$query = (string) parse_url( 'http://x' . $path, PHP_URL_QUERY );
		$q     = [];
		if ( $query !== '' ) parse_str( $query, $q );
		if ( isset( $q['author'] ) && is_string( $q['author'] ) && preg_match( '~^\d+$~', $q['author'] ) ) {
			return 'author=' . (int) $q['author'];
		}
		$route = null;
		if ( strpos( $norm, '/wp-json/' ) !== false ) {
			$route = substr( $norm, strpos( $norm, '/wp-json/' ) + 8 );
		} elseif ( isset( $q['rest_route'] ) && is_string( $q['rest_route'] ) ) {
			$route = strtolower( $q['rest_route'] );
		}
		if ( $route !== null && preg_match( self::USERS_REST_RE, $route, $m ) ) {
			// /users/me — свой профиль в редакторе; у сотрудников он в whitelist, но на всякий случай.
			return 'users' . ( isset( $m[1] ) ? $m[1] : '' );
		}
		return null;
	}

	/**
	 * Быстрая проверка перед SENSITIVE_PATTERNS: в каждой из тех регулярок есть
	 * хотя бы одна из этих подстрок. Нет ни одной — путь точно не чувствительный,
	 * и обычная страница или картинка не гоняется через 11 регулярок.
	 * Добавляя шаблон в SENSITIVE_PATTERNS, добавьте его подстроку и сюда.
	 */
	const SENSITIVE_HINT_RE = '~\.(env|git|svn|hg|ht|aws|sql)|wp-config|myadmin|pma|config|server-|actuator|shell|c99|r57|wso|alfa~';

	/** Метка чувствительного пути или null. Ожидает результат normalize_path(). */
	public static function match_sensitive( $norm_path ) {
		if ( ! preg_match( self::SENSITIVE_HINT_RE, $norm_path ) ) return null;
		foreach ( self::SENSITIVE_PATTERNS as $label => $re ) {
			if ( preg_match( $re, $norm_path ) ) return $label;
		}
		return null;
	}

	private static function log_run( $summary ) {
		$log = get_option( self::SCANLOG_OPTION, [] );
		array_unshift( $log, $summary );
		$log = array_slice( $log, 0, 50 );
		update_option( self::SCANLOG_OPTION, $log, false );
	}

	/** Убирает из найденных то, что уже покрыто банами (IP или диапазоном). */
	public static function without_banned( array $flagged, array $banned ) {
		if ( empty( $banned ) ) return $flagged;
		$exact  = array_flip( $banned );
		$ranges = array_values( array_filter( $banned, function ( $b ) { return strpos( $b, '/' ) !== false; } ) );
		foreach ( array_keys( $flagged ) as $key ) {
			$key = (string) $key;
			if ( isset( $exact[ $key ] ) ) { unset( $flagged[ $key ] ); continue; }
			if ( ! $ranges ) continue;
			// Одиночный IP внутри забаненной сети или подсеть внутри более широкой.
			foreach ( $ranges as $r ) {
				$inside = strpos( $key, '/' ) === false
					? LogShield_IP::matches( $key, $r )
					: ( LogShield_IP::overlaps( $key, $r ) && LogShield_IP::parse_cidr( $key )['bits'] >= LogShield_IP::parse_cidr( $r )['bits'] );
				if ( $inside ) { unset( $flagged[ $key ] ); break; }
			}
		}
		return $flagged;
	}

	/** Последняя неудачная запись в .htaccess или null: [ 'error' => .., 'time' => .. ]. */
	public static function get_write_error() {
		$e = get_option( self::WRITE_ERROR_OPTION, null );
		return is_array( $e ) && ! empty( $e['error'] ) ? $e : null;
	}

	/** Запоминает ошибку записи. Время — первой неудачи подряд: дашборд показывает, с какого момента блок не записан. */
	public static function remember_write_error( $error ) {
		$prev = self::get_write_error();
		$time = $prev ? (int) $prev['time'] : time();
		update_option( self::WRITE_ERROR_OPTION, [ 'error' => (string) $error, 'time' => $time ], false );
	}

	/**
	 * Прошлая запись в .htaccess не удалась, а новых нарушителей нет: адреса
	 * остались в списке банов, without_banned() их скрывает, и без этого блок
	 * не записался бы до следующего пойманного. ban_ips([]) ничего не добавляет,
	 * но переписывает блок из сохранённого списка (файл догоняется до списка).
	 *
	 * @return string пометка для сообщения сканирования ('' — повтор не нужен)
	 */
	private static function retry_pending_write( array $opts ) {
		if ( ! empty( $opts['dry_run'] ) || ! self::get_write_error() ) return '';
		if ( LogShield_Htaccess::ban_ips( [], (int) $opts['ban_expiry_days'] ) ) {
			self::clear_write_error();
			return __( 'Блок в .htaccess дописан после прошлой неудачи.', 'logshield' );
		}
		$err = (string) LogShield_Htaccess::last_error();
		if ( $err === '' ) $err = __( 'неизвестная ошибка записи', 'logshield' );
		self::remember_write_error( $err );
		/* translators: %s: причина, по которой не удалось записать .htaccess. */
		return sprintf( __( 'Блок в .htaccess по-прежнему не записан: %s.', 'logshield' ), $err );
	}

	/** Подпись группы чувствительных путей для причины бана (ключи SENSITIVE_PATTERNS). */
	private static function sensitive_label( $key ) {
		if ( $key === 'дамп БД' ) return __( 'дамп БД', 'logshield' );
		if ( $key === 'веб-шелл' ) return __( 'веб-шелл', 'logshield' );
		return $key;
	}

	/** Запись удалась — предупреждение на дашборде больше не нужно. */
	public static function clear_write_error() {
		if ( get_option( self::WRITE_ERROR_OPTION, null ) !== null ) delete_option( self::WRITE_ERROR_OPTION );
	}

	public static function get_scan_log() {
		return get_option( self::SCANLOG_OPTION, [] );
	}
}
