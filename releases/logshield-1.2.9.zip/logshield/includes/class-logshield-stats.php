<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Почасовая статистика для дашборда (и, в будущем, для центральной панели).
 *
 * Считается при сканировании из уже прочитанного куска лога — отдельного
 * чтения нет. Хранится 30 дней в опции logshield_stats (без автозагрузки):
 *
 *   час (unix, UTC, кратно 3600) => [
 *     'req'   => запросов,
 *     'e4'    => ответов 4xx,
 *     'e5'    => ответов 5xx,
 *     'fails' => неудачных входов,
 *     'ips'   => разных IP (в пределах одного сканирования; если час попал
 *                в два сканирования — берётся максимум, оценка снизу),
 *     'flag'  => [ тип => сколько адресов помечено ] — по времени сканирования,
 *   ]
 */
class LogShield_Stats {

	const OPTION    = 'logshield_stats';
	const KEEP_DAYS = 30;

	/** Типы атак: ключ => подпись. Порядок — порядок в легенде. */
	const TYPES = [
		'brute'     => 'Подбор пароля',
		'subnet'    => 'Распределённый подбор',
		'scan'      => 'Сканирование',
		'sensitive' => 'Чувствительные пути',
		'enum'      => 'Перебор пользователей',
		'rate'      => 'Частые запросы',
		'errors'    => 'Много ошибок',
	];

	/**
	 * Подписи типов на языке сайта. Константа TYPES остаётся исходной:
	 * её ключи — машинные коды, а подписи в ответе API — данные для программ.
	 */
	public static function labels() {
		return [
			'brute'     => __( 'Подбор пароля', 'logshield' ),
			'subnet'    => __( 'Распределённый подбор', 'logshield' ),
			'scan'      => __( 'Сканирование', 'logshield' ),
			'sensitive' => __( 'Чувствительные пути', 'logshield' ),
			'enum'      => __( 'Перебор пользователей', 'logshield' ),
			'rate'      => __( 'Частые запросы', 'logshield' ),
			'errors'    => __( 'Много ошибок', 'logshield' ),
		];
	}

	public static function get() {
		$s = get_option( self::OPTION, [] );
		return is_array( $s ) ? $s : [];
	}

	/**
	 * @param array $hourly  час => [ req, e4, e5, fails, ips ] из analyze()
	 * @param array $types   ip|cidr => [ тип, … ] — помеченные в этом сканировании
	 * @param int   $now     время сканирования
	 */
	public static function record( array $hourly, array $types, $now = null ) {
		$now   = $now ?? time();
		$stats = self::get();
		foreach ( $hourly as $hour => $h ) {
			$hour = (int) $hour;
			$cur  = $stats[ $hour ] ?? self::blank();
			$cur['req']   += (int) $h['req'];
			$cur['e4']    += (int) $h['e4'];
			$cur['e5']    += (int) $h['e5'];
			$cur['fails'] += (int) $h['fails'];
			$cur['ips']    = max( $cur['ips'], (int) $h['ips'] );
			$stats[ $hour ] = $cur;
		}
		if ( $types ) {
			$hour = $now - ( $now % HOUR_IN_SECONDS );
			$cur  = $stats[ $hour ] ?? self::blank();
			foreach ( $types as $list ) {
				foreach ( array_unique( (array) $list ) as $t ) {
					$cur['flag'][ $t ] = ( $cur['flag'][ $t ] ?? 0 ) + 1;
				}
			}
			$stats[ $hour ] = $cur;
		}
		// Старше 30 дней — не нужно; будущее (кривые даты в логе) — тоже.
		$min = $now - self::KEEP_DAYS * DAY_IN_SECONDS;
		$max = $now + DAY_IN_SECONDS;
		foreach ( array_keys( $stats ) as $hour ) {
			if ( $hour < $min || $hour > $max ) unset( $stats[ $hour ] );
		}
		ksort( $stats );
		update_option( self::OPTION, $stats, false );
	}

	private static function blank() {
		return [ 'req' => 0, 'e4' => 0, 'e5' => 0, 'fails' => 0, 'ips' => 0, 'flag' => [] ];
	}
}
