<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LogShield_Admin {

	const SLUG      = 'logshield-settings';
	const SLUG_DASH = 'logshield';

	/** Отдельный раздел в меню: «LogShield» → «Дашборд», «Настройки». */
	public static function add_menu() {
		// Кружок со счётчиком, как у комментариев: новые атакующие с прошлого
		// просмотра дашборда. Открыли дашборд — счётчик сбрасывается.
		if ( current_user_can( 'manage_options' ) && isset( $_GET['page'] ) && $_GET['page'] === self::SLUG_DASH ) {
			// Число до сброса — для бейджа вкладки «Адреса».
			LogShield_Dashboard::remember_unseen();
			LogShield_Dashboard::mark_seen();
		}
		$new   = current_user_can( 'manage_options' ) ? LogShield_Dashboard::unseen_count() : 0;
		$title = 'LogShield';
		if ( $new ) {
			$title .= sprintf(
				' <span class="awaiting-mod count-%1$d"><span class="pending-count" aria-hidden="true">%1$d</span><span class="screen-reader-text">%2$s</span></span>',
				$new,
				/* translators: %d: число новых атакующих (для экранного диктора). */
				esc_html( sprintf( __( 'новых атакующих: %d', 'logshield' ), $new ) )
			);
		}
		$dash = add_menu_page( 'LogShield', $title, 'manage_options', self::SLUG_DASH, [ 'LogShield_Dashboard', 'render' ], 'dashicons-shield', 81 );
		add_submenu_page( self::SLUG_DASH, __( 'LogShield — дашборд', 'logshield' ), __( 'Дашборд', 'logshield' ), 'manage_options', self::SLUG_DASH, [ 'LogShield_Dashboard', 'render' ] );
		$settings = add_submenu_page( self::SLUG_DASH, __( 'LogShield — настройки', 'logshield' ), __( 'Настройки', 'logshield' ), 'manage_options', self::SLUG, [ __CLASS__, 'render_page' ] );
		add_action( 'admin_enqueue_scripts', function ( $hook ) use ( $dash, $settings ) {
			if ( $hook === $dash ) LogShield_Dashboard::enqueue();
			if ( $hook === $settings ) self::enqueue_settings();
		} );
	}

	/**
	 * Стили и скрипт страницы настроек: общий dashboard.css (переменные темы,
	 * карточки, кнопки) и свой settings.css поверх него.
	 */
	public static function enqueue_settings() {
		$ver = function ( $file ) { return LOGSHIELD_VERSION . '-' . @filemtime( LOGSHIELD_DIR . 'assets/' . $file ); };
		wp_enqueue_style( 'logshield-dashboard', LOGSHIELD_URL . 'assets/dashboard.css', [], $ver( 'dashboard.css' ) );
		wp_enqueue_style( 'logshield-settings', LOGSHIELD_URL . 'assets/settings.css', [ 'logshield-dashboard' ], $ver( 'settings.css' ) );
		wp_enqueue_script( 'logshield-settings', LOGSHIELD_URL . 'assets/settings.js', [], $ver( 'settings.js' ), [ 'in_footer' => true, 'strategy' => 'defer' ] );
		wp_add_inline_script( 'logshield-settings', 'window.LogShieldSettingsL10n = ' . wp_json_encode( self::settings_l10n() ) . ';', 'before' );
	}

	/** Тексты для settings.js на языке сайта: ключ — имя, «%s»/«%1$s» подставляет скрипт. */
	public static function settings_l10n() {
		return [
			'dryConfirm'  => __( 'Выключить тестовый режим?', 'logshield' ),
			'dirty'       => __( 'Есть несохранённые изменения', 'logshield' ),
			/* translators: %d: число адресов. */
			'addr'        => LogShield_Plugin::js_plural( _n_noop( '%d адрес', '%d адресов', 'logshield' ), '%d адреса' ),
			/* translators: 1: дата первой строки, 2: дата последней строки. */
			'span'        => __( '(%1$s — %2$s)', 'logshield' ),
			/* translators: 1: дата первой строки, 2: дата последней строки, 3: объём в мегабайтах. */
			'spanTail'    => __( '(%1$s — %2$s, последние %3$s МБ)', 'logshield' ),
			/* translators: 1: число строк, 2: период в скобках с пробелом впереди или пусто. */
			'readLines'   => __( 'Прочитано строк: %1$s%2$s.', 'logshield' ),
			/* translators: 1: поймано с сохранёнными порогами, 2: поймано с порогами из формы. */
			'changed'     => __( 'Сейчас поймано: %1$s → с новыми порогами: %2$s.', 'logshield' ),
			/* translators: %s: «N адресов». */
			'saved'       => __( 'С сохранёнными порогами поймано: %s.', 'logshield' ),
			/* translators: %s: «N адресов». */
			'lost'        => __( 'Перестанут попадаться: %s.', 'logshield' ),
			/* translators: %s: число строк. */
			'unparsed'    => __( 'Не разобрано строк: %s.', 'logshield' ),
			'onlyNew'     => __( 'только с новыми порогами', 'logshield' ),
			'banned'      => __( 'уже заблокирован', 'logshield' ),
			/* translators: %s: «N адресов». */
			'more'        => __( '…и ещё %s.', 'logshield' ),
			'checking'    => __( 'Проверяю на последних данных лога…', 'logshield' ),
			/* translators: %s: HTTP-код ответа. */
			'errStatus'   => __( 'Не удалось проверить: сервер ответил %s.', 'logshield' ),
			'errGeneric'  => __( 'Не удалось проверить.', 'logshield' ),
			'errNetwork'  => __( 'Не удалось проверить: нет связи с сервером.', 'logshield' ),
			'copied'      => __( 'Скопировано', 'logshield' ),
		];
	}

	/**
	 * Поля правил обнаружения: имя => [ минимум, максимум (0 — без верхней границы), по умолчанию ].
	 * Общие для сохранения настроек и предпросмотра — значения приводятся одинаково.
	 */
	const RULE_FIELDS = [
		'rate_per_min'            => [ 10, 0, 40 ],
		'brute_attempts'          => [ 3, 0, 10 ],
		'subnet_min_ips'          => [ 2, 256, 5 ],
		'subnet_min_attempts'     => [ 5, 0, 30 ],
		'scan_unique_paths'       => [ 5, 0, 15 ],
		'scan_min_requests'       => [ 5, 0, 20 ],
		'error_rate_pct'          => [ 1, 100, 50 ],
		'error_rate_min_requests' => [ 5, 0, 20 ],
		'sensitive_min_hits'      => [ 1, 50, 3 ],
		'enum_min_hits'           => [ 1, 50, 3 ],
	];

	/** Поля, у которых 0 выключает правило (иначе действует минимум из RULE_FIELDS). */
	const RULE_ZERO_OFF = [ 'rate_per_min' ];

	/**
	 * Пороги правил из присланных полей: целое, в границах RULE_FIELDS.
	 * Поля нет — берётся $fallback[имя], а без него значение по умолчанию.
	 *
	 * @param array $src      $_POST (уже без слэшей) или его часть
	 * @param array $fallback значения для отсутствующих полей
	 * @return int[] имя => значение
	 */
	public static function sanitize_rules( array $src, array $fallback = [] ) {
		$out = [];
		foreach ( self::RULE_FIELDS as $name => list( $min, $max, $def ) ) {
			$v = ( isset( $src[ $name ] ) && is_scalar( $src[ $name ] ) ) ? (int) $src[ $name ] : (int) ( $fallback[ $name ] ?? $def );
			if ( $v <= 0 && in_array( $name, self::RULE_ZERO_OFF, true ) ) {
				$out[ $name ] = 0;
				continue;
			}
			$v = max( $min, $v );
			if ( $max ) $v = min( $max, $v );
			$out[ $name ] = $v;
		}
		return $out;
	}

	/**
	 * Старые адреса ведут на новые: «Настройки → LogShield» — на страницу настроек,
	 * бывшая страница «Доступ по API» — на её карточку в настройках.
	 */
	public static function legacy_redirect() {
		global $pagenow;
		$page = isset( $_GET['page'] ) ? (string) $_GET['page'] : '';
		if ( $pagenow === 'options-general.php' && $page === self::SLUG ) {
			wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG ) );
			exit;
		}
		if ( $pagenow === 'admin.php' && $page === LogShield_API::SLUG && current_user_can( 'manage_options' ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG ) . '#ls-sec-api' );
			exit;
		}
	}

	/**
	 * Адрес формы admin-post.php с маркером в query: admin-post.php?action=logshield_….
	 * Тело POST в access_log не видно, а по маркеру в адресе
	 * LogShield_Whitelist::is_own_request() узнаёт свои запросы. Скрытое поле
	 * action в форме остаётся (WordPress читает $_REQUEST['action']).
	 */
	public static function post_url( $action ) {
		return admin_url( 'admin-post.php?action=' . sanitize_key( $action ) );
	}

	/** То же для admin-ajax.php: admin-ajax.php?action=logshield_…; остальные параметры — в теле POST. */
	public static function ajax_url( $action ) {
		return admin_url( 'admin-ajax.php?action=' . sanitize_key( $action ) );
	}

	/** Параметры сообщения после действия (см. redirect_with_message()). */
	const MSG_ARGS = [ 'logshield_msg', 'logshield_type' ];

	/**
	 * Фильтр removable_query_args: WordPress пишет на странице канонический
	 * адрес без этих параметров и подменяет им адресную строку. Сообщение
	 * выводится один раз — при обновлении страницы или из закладки его нет.
	 */
	public static function removable_query_args( $args ) {
		return array_values( array_unique( array_merge( (array) $args, self::MSG_ARGS ) ) );
	}

	public static function notices() {
		if ( ! isset( $_GET['page'] ) || ! in_array( $_GET['page'], [ self::SLUG, self::SLUG_DASH ], true ) ) return;
		if ( ! isset( $_GET['logshield_msg'] ) ) return;
		$msg  = sanitize_text_field( wp_unslash( $_GET['logshield_msg'] ) );
		$type = ( isset( $_GET['logshield_type'] ) && $_GET['logshield_type'] === 'error' ) ? 'error' : 'success';
		printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $type ), esc_html( $msg ) );
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_save_settings' );

		$opts = LogShield_Plugin::get_options();
		$old_interval = $opts['interval'];

		$opts['log_path'] = isset( $_POST['log_path'] ) ? sanitize_text_field( wp_unslash( $_POST['log_path'] ) ) : '';
		$opts['interval']  = ( isset( $_POST['interval'] ) && in_array( $_POST['interval'], [ 'logshield_2h', 'logshield_3h', 'logshield_4h' ], true ) )
			? $_POST['interval'] : 'logshield_3h';
		$opts['dry_run']                 = isset( $_POST['dry_run'] );
		// Пороги правил: отсутствующее поле — значение по умолчанию (как раньше).
		foreach ( self::sanitize_rules( wp_unslash( $_POST ) ) as $name => $v ) $opts[ $name ] = $v;
		unset( $opts['rpm_threshold'] ); // старый порог «за период», больше не используется
		$opts['max_read_mb']             = min( 50, max( 1, (int) ( $_POST['max_read_mb'] ?? 5 ) ) );
		$opts['ipinfo_enabled']          = isset( $_POST['ipinfo_enabled'] );
		$opts['ban_expiry_days']         = max( 0, (int) ( $_POST['ban_expiry_days'] ?? 7 ) );
		$opts['notify_email']            = isset( $_POST['notify_email'] ) ? sanitize_email( wp_unslash( $_POST['notify_email'] ) ) : '';

		// Токен на страницу не выводится: пустое поле — оставить сохранённый.
		$tg_error = '';
		$token    = isset( $_POST['telegram_token'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['telegram_token'] ) ) ) : '';
		if ( ! empty( $_POST['telegram_token_clear'] ) ) {
			$opts['telegram_token'] = '';
		} elseif ( $token !== '' ) {
			if ( LogShield_Notifier::is_valid_token( $token ) ) {
				$opts['telegram_token'] = $token;
			} else {
				$tg_error = ' ' . __( 'Токен Telegram не сохранён: неверный формат.', 'logshield' );
			}
		}
		$chat_id = isset( $_POST['telegram_chat_id'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['telegram_chat_id'] ) ) ) : '';
		if ( $chat_id === '' || LogShield_Notifier::is_valid_chat_id( $chat_id ) ) {
			$opts['telegram_chat_id'] = $chat_id;
		} else {
			$tg_error .= ' ' . __( 'chat_id не сохранён: неверный формат.', 'logshield' );
		}

		// Ручной белый список и доверенные прокси: неверные строки отбрасываются
		// и перечисляются в сообщении, чтобы опечатка не потерялась молча.
		$list_error = '';
		$whitelist  = LogShield_Whitelist::parse_entries( isset( $_POST['whitelist_ips'] ) ? wp_unslash( $_POST['whitelist_ips'] ) : '' );
		$proxies    = LogShield_Whitelist::parse_entries( isset( $_POST['trusted_proxies'] ) ? wp_unslash( $_POST['trusted_proxies'] ) : '' );
		if ( $whitelist['invalid'] ) {
			/* translators: %s: отброшенные строки через запятую. */
			$list_error .= ' ' . sprintf( __( 'Белый список: отброшены неверные строки — %s.', 'logshield' ), self::short_list( array_map( 'sanitize_text_field', $whitelist['invalid'] ) ) );
		}
		if ( $proxies['invalid'] ) {
			/* translators: %s: отброшенные строки через запятую. */
			$list_error .= ' ' . sprintf( __( 'Доверенные прокси: отброшены неверные строки — %s.', 'logshield' ), self::short_list( array_map( 'sanitize_text_field', $proxies['invalid'] ) ) );
		}
		$old_whitelist           = array_values( (array) ( $opts['whitelist_ips'] ?? [] ) );
		$old_proxies             = array_values( (array) ( $opts['trusted_proxies'] ?? [] ) );
		$opts['whitelist_ips']   = $whitelist['valid'];
		$opts['trusted_proxies'] = $proxies['valid'];

		update_option( LOGSHIELD_OPTION, $opts );

		// Белый список или прокси изменились — снимаем баны, которые их теперь
		// задевают (так администратор выпускает сотрудника, которого Apache уже
		// не пускает, а бан адреса прокси закрыл бы сайт для всех).
		$released = [];
		if ( $whitelist['valid'] !== $old_whitelist || $proxies['valid'] !== $old_proxies ) {
			$released = LogShield_Whitelist::release_bans();
		}
		$rel_note = self::released_note( $released );

		if ( $old_interval !== $opts['interval'] ) {
			LogShield_Plugin::reschedule( $opts['interval'] );
		}
		// Включили определение страны, а баз ещё нет — скачать в фоне, не задерживая страницу.
		if ( $opts['ipinfo_enabled'] && ! is_file( LogShield_IPInfo::dir() . 'country.mmdb' ) && ! wp_next_scheduled( LOGSHIELD_CLEANUP_HOOK, [ 'geo' ] ) ) {
			wp_schedule_single_event( time() + 10, LOGSHIELD_CLEANUP_HOOK, [ 'geo' ] );
		}

		$is_error = $tg_error !== '' || $list_error !== '' || $released === false;
		self::redirect_with_message( __( 'Настройки сохранены.', 'logshield' ) . $rel_note . $list_error . $tg_error, $is_error ? 'error' : 'success' );
	}

	/**
	 * Пояснение к сообщению о снятых банах (с пробелом в начале) или ''.
	 *
	 * @param array|false $released результат LogShield_Whitelist::release_bans()
	 */
	public static function released_note( $released ) {
		if ( $released === false ) {
			$list = LogShield_Htaccess::last_released();
			return ' ' . sprintf(
				/* translators: 1: адреса через запятую, 2: причина ошибки записи. */
				__( 'Не удалось снять блокировки, которые задевают белый список (%1$s): .htaccess не обновлён — %2$s.', 'logshield' ),
				self::short_list( $list ),
				LogShield_Htaccess::last_error()
			);
		}
		if ( ! $released ) return '';
		return ' ' . sprintf(
			/* translators: 1: число снятых блокировок, 2: адреса через запятую. */
			__( 'Сняты блокировки, которые задевали белый список (%1$d): %2$s.', 'logshield' ),
			count( $released ),
			self::short_list( $released )
		);
	}

	/** До 10 адресов через запятую, остальное — «и ещё N». */
	public static function short_list( array $items ) {
		$shown = array_slice( $items, 0, 10 );
		$more  = count( $items ) - count( $shown );
		if ( $more <= 0 ) return implode( ', ', $shown );
		/* translators: 1: первые элементы через запятую, 2: сколько ещё не показано. */
		return sprintf( __( '%1$s и ещё %2$d', 'logshield' ), implode( ', ', $shown ), $more );
	}

	/** Кнопка «Обновить базы сейчас»: скачивает все четыре файла. */
	public static function geo_update() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_geo_update' );
		$errors = [];
		foreach ( LogShield_IPInfo::update( true ) as $file => $res ) {
			if ( $res !== true ) $errors[] = $file . ': ' . $res;
		}
		self::redirect_with_message( $errors
			/* translators: %s: ошибки по файлам через точку с запятой. */
			? sprintf( __( 'Не все базы скачались. %s', 'logshield' ), implode( '; ', $errors ) )
			: __( 'Базы стран и сетей обновлены.', 'logshield' ), $errors ? 'error' : 'success' );
	}

	public static function ping_rotate() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Нет прав', 'logshield' ) );
		check_admin_referer( 'logshield_ping_rotate' );
		LogShield_Ping::rotate();
		self::redirect_with_message( __( 'Создан новый адрес проверки доступности. Старый больше не работает — замените адрес в настройках воркера и выполните deploy.', 'logshield' ) );
	}

	public static function run_now() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_run_now' );

		$summary = LogShield_Detector::run();
		if ( ! empty( $summary['locked'] ) ) {
			// Идёт сканирование по расписанию (или вторая вкладка) — второй раз тот же кусок не разбираем.
			self::redirect_with_message( __( 'Сканирование уже выполняется. Результат появится в истории сканирований.', 'logshield' ), 'error' );
		}
		self::redirect_with_message( $summary['message'], $summary['ok'] ? 'success' : 'error' );
	}

	public static function unban_ip() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_unban' );
		$ip = isset( $_REQUEST['ip'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['ip'] ) ) : '';
		if ( $ip && ! LogShield_Htaccess::unban_ip( $ip ) ) {
			/* translators: 1: IP-адрес, 2: причина ошибки записи. */
			self::redirect_with_message( sprintf( __( 'IP %1$s убран из списка, но .htaccess не обновлён: %2$s.', 'logshield' ), $ip, LogShield_Htaccess::last_error() ), 'error' );
		}
		// Блок переписан целиком по списку — прошлая неудачная запись больше не важна.
		if ( $ip ) LogShield_Detector::clear_write_error();
		$foreign = $ip ? LogShield_Dashboard::foreign_note( [ $ip ] ) : '';
		/* translators: %s: IP-адрес. */
		self::redirect_with_message( sprintf( __( 'IP %s разблокирован.', 'logshield' ), $ip ) . $foreign, $foreign ? 'error' : 'success' );
	}

	public static function unban_all() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_unban_all' );
		// Одна запись .htaccess; список банов меняется только после удачной записи.
		$removed = LogShield_Htaccess::unban_ips( array_map( 'strval', array_keys( LogShield_Htaccess::get_banned() ) ) );
		if ( $removed === false ) {
			/* translators: %s: причина ошибки записи. */
			self::redirect_with_message( sprintf( __( 'Блокировки не сняты: .htaccess не обновлён (%s). Список блокировок не изменился.', 'logshield' ), LogShield_Htaccess::last_error() ), 'error' );
		}
		if ( ! $removed ) self::redirect_with_message( __( 'Снимать нечего: блокировок нет.', 'logshield' ) );
		LogShield_Detector::clear_write_error();
		$foreign = LogShield_Dashboard::foreign_note( $removed );
		/* translators: %d: число снятых блокировок. */
		self::redirect_with_message( sprintf( __( 'Все блокировки сняты: %d.', 'logshield' ), count( $removed ) ) . $foreign, $foreign ? 'error' : 'success' );
	}

	public static function add_my_ip() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_add_my_ip' );
		$ip = LogShield_Whitelist::get_client_ip();
		if ( $ip ) {
			$first = LogShield_Whitelist::add_admin_ip( $ip, false, wp_get_current_user()->user_login );
			// Новый адрес уже прошёл проверку в add_admin_ip; полный проход ловит
			// и баны, оставшиеся с прошлых версий для давно известных адресов.
			$released = $first === false ? false : LogShield_Whitelist::release_bans();
			if ( is_array( $released ) && is_array( $first ) ) $released = array_values( array_unique( array_merge( $first, $released ) ) );
			/* translators: %s: IP-адрес. */
			self::redirect_with_message( sprintf( __( 'Ваш IP (%s) добавлен в белый список.', 'logshield' ), $ip ) . self::released_note( $released ), $released === false ? 'error' : 'success' );
		} else {
			self::redirect_with_message( __( 'Не удалось определить ваш IP.', 'logshield' ), 'error' );
		}
	}

	public static function telegram_test() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_telegram_test' );
		$opts = LogShield_Plugin::get_options();
		if ( ! LogShield_Notifier::telegram_configured( $opts ) ) {
			self::redirect_with_message( __( 'Сначала сохраните токен бота и chat_id.', 'logshield' ), 'error' );
		}
		$host   = wp_parse_url( home_url(), PHP_URL_HOST );
		$result = LogShield_Notifier::send_telegram(
			$opts['telegram_token'],
			$opts['telegram_chat_id'],
			'🛡 <b>LogShield</b> · ' . esc_html( $host ) . "\n" . esc_html__( 'Тестовое сообщение: уведомления работают.', 'logshield' )
		);
		if ( $result === true ) {
			delete_option( LogShield_Notifier::FAIL_OPTION );
			self::redirect_with_message( __( 'Тестовое сообщение отправлено в Telegram.', 'logshield' ) );
		}
		self::redirect_with_message( $result, 'error' );
	}

	private static function found_key() {
		return 'logshield_found_logs_' . get_current_user_id();
	}

	public static function detect_log() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_detect_log' );
		$found = LogShield_LogFinder::find();
		set_transient( self::found_key(), $found, 15 * MINUTE_IN_SECONDS );

		$opts = LogShield_Plugin::get_options();
		if ( ! $found ) {
			self::redirect_with_message( __( 'Лог не найден в типичных местах. Укажите путь вручную.', 'logshield' ), 'error' );
		}
		// Текущий путь не работает, а уверенный кандидат есть — сразу ставим его.
		$current = LogShield_LogFinder::describe( $opts['log_path'] );
		$best    = LogShield_LogFinder::best_confident();
		if ( ! $current['ok'] && $best ) {
			$opts['log_path'] = $best;
			update_option( LOGSHIELD_OPTION, $opts );
			/* translators: %s: путь к файлу лога. */
			self::redirect_with_message( sprintf( __( 'Лог найден и сохранён: %s', 'logshield' ), $best ) );
		}
		/* translators: %d: число найденных файлов. */
		self::redirect_with_message( sprintf( __( 'Найдено файлов лога: %d. Выберите нужный в списке под полем пути.', 'logshield' ), count( $found ) ) );
	}

	public static function use_log() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_use_log' );
		$path  = isset( $_POST['path'] ) ? wp_unslash( $_POST['path'] ) : '';
		$found = get_transient( self::found_key() );
		// Принимаем только путь из списка найденных.
		if ( ! is_array( $found ) || ! in_array( $path, array_column( $found, 'path' ), true ) ) {
			self::redirect_with_message( __( 'Этого файла нет в списке найденных. Запустите поиск ещё раз.', 'logshield' ), 'error' );
		}
		$opts             = LogShield_Plugin::get_options();
		$opts['log_path'] = $path;
		update_option( LOGSHIELD_OPTION, $opts );
		/* translators: %s: путь к файлу лога. */
		self::redirect_with_message( sprintf( __( 'Путь к логу сохранён: %s', 'logshield' ), $path ) );
	}

	/**
	 * Возврат на ту страницу, с которой пришло действие (поле ls_back),
	 * а на дашборде — и на ту же вкладку (поле ls_tab → #hash; только имена из
	 * LogShield_Dashboard::TABS, иначе без вкладки).
	 */
	public static function redirect_with_message( $msg, $type = 'success' ) {
		$page = ( isset( $_REQUEST['ls_back'] ) && $_REQUEST['ls_back'] === self::SLUG_DASH ) ? self::SLUG_DASH : self::SLUG;
		$url  = add_query_arg(
			[ 'page' => $page, 'logshield_msg' => rawurlencode( $msg ), 'logshield_type' => $type ],
			admin_url( 'admin.php' )
		);
		if ( $page === self::SLUG_DASH && isset( $_REQUEST['ls_tab'] ) ) {
			$tab = LogShield_Dashboard::sanitize_tab( wp_unslash( $_REQUEST['ls_tab'] ) );
			if ( $tab !== '' ) $url .= '#' . $tab;
		}
		wp_safe_redirect( $url );
		exit;
	}


	/** Сколько байт с конца лога читает предпросмотр (фильтр logshield_preview_bytes, не меньше 64 КБ). */
	public static function preview_bytes() {
		return max( 65536, (int) apply_filters( 'logshield_preview_bytes', 2 * MB_IN_BYTES ) );
	}

	/**
	 * Предпросмотр «кого поймал бы этот порог» (admin-ajax, POST: nonce и поля правил).
	 * Читает хвост текущего лога и дважды прогоняет LogShield_Detector::analyze():
	 * с сохранёнными порогами и с присланными. Ничего не сохраняет: analyze()
	 * не пишет, перенос неудачных входов (carry) не берётся и не записывается.
	 */
	public static function ajax_preview() {
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( __( 'Недостаточно прав.', 'logshield' ), 403 );
		check_ajax_referer( 'logshield_preview', 'nonce' );
		$saved = LogShield_Plugin::get_options();
		$path  = (string) $saved['log_path'];
		if ( $path === '' || ! @is_file( $path ) || ! @is_readable( $path ) ) {
			wp_send_json_error( $path === ''
				? __( 'Лог не найден: путь к access_log не указан. Укажите его в разделе «Лог и расписание» (или нажмите «Найти автоматически») и сохраните настройки.', 'logshield' )
				/* translators: %s: путь к файлу лога. */
				: sprintf( __( 'Лог не найден или недоступен для чтения: %s. Проверьте путь в разделе «Лог и расписание».', 'logshield' ), $path ) );
		}
		clearstatcache();
		$size  = (int) @filesize( $path );
		$start = max( 0, $size - self::preview_bytes() );
		$lines = self::read_tail( $path, $start, $size - $start );
		if ( ! $lines ) wp_send_json_error( __( 'В логе пока нет записей — проверять не на чем.', 'logshield' ) );

		$rules = self::sanitize_rules( wp_unslash( $_POST ), $saved );
		$new   = array_merge( $saved, $rules );
		$wl    = LogShield_Whitelist::get_full_whitelist( (array) $saved['whitelist_ips'] );
		$cur   = LogShield_Detector::analyze( $lines, $saved, $wl );
		$same  = true;
		foreach ( $rules as $k => $v ) if ( (int) $saved[ $k ] !== $v ) $same = false;
		$res   = $same ? $cur : LogShield_Detector::analyze( $lines, $new, $wl );

		// Период — по первой и последней распознанной строке.
		$from = $to = '';
		foreach ( $lines as $l ) { $e = LogShield_Parser::parse_line( $l ); if ( $e ) { $from = $e['date']; break; } }
		for ( $i = count( $lines ) - 1; $i >= 0; $i-- ) { $e = LogShield_Parser::parse_line( $lines[ $i ] ); if ( $e ) { $to = $e['date']; break; } }

		$banned    = array_keys( LogShield_Htaccess::get_banned() );
		$not_yet   = LogShield_Detector::without_banned( $res['flagged'], $banned );
		$labels    = LogShield_Stats::labels();
		$items     = [];
		foreach ( $res['flagged'] as $ip => $reasons ) {
			$ip      = (string) $ip;
			$items[] = [
				'ip'     => $ip,
				'types'  => array_values( array_map( function ( $t ) use ( $labels ) { return $labels[ $t ] ?? $t; }, (array) ( $res['types'][ $ip ] ?? [] ) ) ),
				'reason' => mb_substr( implode( '; ', (array) $reasons ), 0, 300 ),
				'new'    => ! isset( $cur['flagged'][ $ip ] ),
				'banned' => ! isset( $not_yet[ $ip ] ),
			];
		}
		// Сначала те, кого ловят только новые пороги, затем ещё не заблокированные.
		usort( $items, function ( $a, $b ) { return [ $b['new'], ! $b['banned'] ] <=> [ $a['new'], ! $a['banned'] ]; } );
		$lost = count( array_diff_key( $cur['flagged'], $res['flagged'] ) );

		wp_send_json_success( [
			'lines'    => count( $lines ),
			'unparsed' => (int) $res['unparsed'],
			'from'     => substr( $from, 0, 20 ),
			'to'       => substr( $to, 0, 20 ),
			'whole'    => $start === 0,
			'mb'       => round( ( $size - $start ) / MB_IN_BYTES, 1 ),
			'changed'  => ! $same,
			'current'  => count( $cur['flagged'] ),
			'flagged'  => count( $res['flagged'] ),
			'lost'     => $lost,
			'items'    => array_slice( $items, 0, 20 ),
			'more'     => max( 0, count( $items ) - 20 ),
		] );
	}

	/**
	 * Строки из куска файла [start, start+len): первая обрезанная (если start > 0)
	 * и последняя без перевода строки отбрасываются. Как чтение хвоста на дашборде.
	 */
	private static function read_tail( $path, $start, $len ) {
		if ( $len <= 0 ) return [];
		$fp = @fopen( $path, 'rb' );
		if ( ! $fp ) return [];
		fseek( $fp, $start );
		$data = (string) fread( $fp, $len );
		fclose( $fp );
		$lines = explode( "\n", $data );
		if ( $start > 0 ) array_shift( $lines );
		array_pop( $lines );
		return array_values( array_filter( array_map( 'rtrim', $lines ), 'strlen' ) );
	}

	/** Разделы страницы настроек: id => заголовок (оглавление и карточки). */
	const SECTIONS = [
		'ls-sec-log'     => 'Лог и расписание',
		'ls-sec-rules'   => 'Правила обнаружения',
		'ls-sec-ban'     => 'Блокировка',
		'ls-sec-notify'  => 'Уведомления',
		'ls-sec-geo'     => 'Гео и сведения об адресах',
		'ls-sec-white'   => 'Белый список и прокси',
		'ls-sec-service' => 'Служебное',
		'ls-sec-api'     => 'Доступ по API',
	];

	/** Разделы с заголовками на языке сайта (ключи — как в SECTIONS). */
	public static function sections() {
		return [
			'ls-sec-log'     => __( 'Лог и расписание', 'logshield' ),
			'ls-sec-rules'   => __( 'Правила обнаружения', 'logshield' ),
			'ls-sec-ban'     => __( 'Блокировка', 'logshield' ),
			'ls-sec-notify'  => __( 'Уведомления', 'logshield' ),
			'ls-sec-geo'     => __( 'Гео и сведения об адресах', 'logshield' ),
			'ls-sec-white'   => __( 'Белый список и прокси', 'logshield' ),
			'ls-sec-service' => __( 'Служебное', 'logshield' ),
			'ls-sec-api'     => __( 'Доступ по API', 'logshield' ),
		];
	}

	/** Пояснение к полю: в описании разрешён только <code>. */
	private static function desc( $id, $html ) {
		echo '<p class="ls-field-desc" id="' . esc_attr( $id ) . '">' . wp_kses( $html, [ 'code' => [] ] ) . '</p>';
	}

	/** Числовое поле с подписью и пояснением (aria-describedby). */
	private static function number_field( $name, $label, $value, $min, $max, $desc, $suffix = '' ) {
		?>
		<div class="ls-field">
			<label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>
			<span class="ls-field-ctl">
				<input type="number" class="ls-input ls-num" id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" min="<?php echo (int) $min; ?>"<?php echo $max ? ' max="' . (int) $max . '"' : ''; ?> step="1" inputmode="numeric" value="<?php echo esc_attr( $value ); ?>" aria-describedby="<?php echo esc_attr( $name ); ?>-desc">
				<?php if ( $suffix !== '' ) : ?><span class="ls-dim" aria-hidden="true"><?php echo esc_html( $suffix ); ?></span><?php endif; ?>
			</span>
			<?php self::desc( $name . '-desc', $desc ); ?>
		</div>
		<?php
	}

	/** Заголовок карточки раздела. */
	private static function section_head( $id ) {
		echo '<div class="ls-card-head"><h2 id="' . esc_attr( $id ) . '-title">' . esc_html( self::sections()[ $id ] ) . '</h2></div>';
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$opts      = LogShield_Plugin::get_options();
		$admin_ips = LogShield_Whitelist::get_admin_ips();
		$next_run  = wp_next_scheduled( LOGSHIELD_CRON_HOOK );
		$my_ip     = LogShield_Whitelist::get_client_ip();
		// Полный белый список (сотрудники, ручной список с диапазонами, сервер, прокси, localhost).
		$my_why    = $my_ip ? LogShield_Whitelist::whitelist_reason( $my_ip, (array) $opts['whitelist_ips'] ) : null;
		// Результат кнопки «Найти автоматически» (null — поиск не запускали).
		$found     = get_transient( self::found_key() );
		$found     = is_array( $found ) ? $found : null;
		$state     = LogShield_LogFinder::describe( $opts['log_path'] );
		// Сколько адресов тестовый режим заблокировал бы за 7 дней — для подтверждения выключения.
		$would     = $opts['dry_run'] ? LogShield_Dashboard::would_ban( 7 ) : null;
		if ( $would ) {
			if ( ! $would['ips'] && ! $would['nets'] ) {
				$would_text = __( 'За последние 7 дней блокировать было бы некого.', 'logshield' );
			} elseif ( $would['nets'] ) {
				/* translators: 1: число адресов, 2: число подсетей. */
				$would_text = sprintf( __( 'За последние 7 дней тестовый режим отметил бы для блокировки адресов: %1$d, подсетей: %2$d.', 'logshield' ), $would['ips'], $would['nets'] );
			} else {
				/* translators: %d: число адресов. */
				$would_text = sprintf( __( 'За последние 7 дней тестовый режим отметил бы для блокировки адресов: %d.', 'logshield' ), $would['ips'] );
			}
		}
		?>
		<div class="wrap ls-wrap">
		<h1 class="screen-reader-text"><?php esc_html_e( 'LogShield — настройки', 'logshield' ); ?></h1>
		<?php // Уведомления WordPress вставляет после первого заголовка, до панели. ?>
		<div class="ls-dash ls-settings" data-theme="<?php echo esc_attr( LogShield_Dashboard::get_theme() ); ?>">

			<header class="ls-head">
				<p class="ls-brand">
					<span class="ls-logo dashicons dashicons-shield" aria-hidden="true"></span>
					<span class="ls-title"><?php esc_html_e( 'Настройки', 'logshield' ); ?></span>
				</p>
				<?php if ( $opts['dry_run'] ) : ?>
					<span class="ls-badge ls-badge-warn"><span class="ls-dot" aria-hidden="true"></span><?php esc_html_e( 'Тестовый режим', 'logshield' ); ?></span>
				<?php else : ?>
					<span class="ls-badge ls-badge-ok"><span class="ls-dot" aria-hidden="true"></span><?php esc_html_e( 'Защита включена', 'logshield' ); ?></span>
				<?php endif; ?>
				<div class="ls-head-actions">
					<a class="ls-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::SLUG_DASH ) ); ?>"><span class="dashicons dashicons-chart-area" aria-hidden="true"></span> <?php esc_html_e( 'Дашборд', 'logshield' ); ?></a>
				</div>
			</header>

			<?php if ( $opts['dry_run'] ) : ?>
				<section class="ls-dry" aria-label="<?php esc_attr_e( 'Тестовый режим', 'logshield' ); ?>">
					<p><span aria-hidden="true">⚠</span> <strong class="ls-dry-title"><?php esc_html_e( 'Тестовый режим включён.', 'logshield' ); ?></strong> <?php esc_html_e( 'Адреса обнаруживаются и записываются в историю сканирований, но не блокируются.', 'logshield' ); ?> <?php echo esc_html( $would_text ); ?> <?php echo LogShield_Plugin::kses( __( 'Проверьте их на дашборде, прежде чем отключать тестовый режим в разделе <a href="#ls-sec-ban">«Блокировка»</a>.', 'logshield' ) ); ?></p>
				</section>
			<?php endif; ?>
			<?php if ( $my_ip && ! $my_why ) : ?>
				<section class="ls-dry" aria-label="<?php esc_attr_e( 'Ваш адрес', 'logshield' ); ?>">
					<p><span aria-hidden="true">⚠</span> <strong class="ls-dry-title"><?php
							/* translators: %s: IP-адрес в теге <code>. */
							echo LogShield_Plugin::kses( sprintf( __( 'Ваш адрес %s не в белом списке.', 'logshield' ), '<code>' . esc_html( $my_ip ) . '</code>' ) );
						?></strong> <?php esc_html_e( 'Добавьте его, чтобы правила случайно не заблокировали вас.', 'logshield' ); ?></p>
					<button type="submit" form="logshield-add-my-ip" class="ls-btn ls-btn-sm"><?php esc_html_e( 'Добавить мой IP в белый список', 'logshield' ); ?></button>
				</section>
			<?php endif; ?>

			<div class="ls-set">
				<nav class="ls-toc" aria-label="<?php esc_attr_e( 'Разделы настроек', 'logshield' ); ?>">
					<ul>
						<?php foreach ( self::sections() as $id => $title ) : ?>
							<li><a href="#<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $title ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</nav>

				<div class="ls-set-main">
					<form id="ls-settings-form" class="ls-set-form" method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_save_settings' ) ); ?>" aria-label="<?php esc_attr_e( 'Настройки LogShield', 'logshield' ); ?>">
						<input type="hidden" name="action" value="logshield_save_settings">
						<?php wp_nonce_field( 'logshield_save_settings' ); ?>

						<section class="ls-card ls-sec" id="ls-sec-log" tabindex="-1" aria-labelledby="ls-sec-log-title">
							<?php self::section_head( 'ls-sec-log' ); ?>
							<div class="ls-sec-body">
								<div class="ls-field">
									<label for="log_path"><?php esc_html_e( 'Путь к access_log', 'logshield' ); ?></label>
									<span class="ls-field-ctl ls-field-wide">
										<input type="text" id="log_path" name="log_path" class="ls-input" value="<?php echo esc_attr( $opts['log_path'] ); ?>" placeholder="/home/user/access-logs/example.com" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="log_path-state log_path-desc">
										<button type="submit" form="logshield-detect-log" class="ls-btn"><?php esc_html_e( 'Найти автоматически', 'logshield' ); ?></button>
									</span>
									<p id="log_path-state" class="<?php echo $state['ok'] ? 'ls-accent' : 'ls-warn'; ?>"><span aria-hidden="true"><?php echo $state['ok'] ? '✓' : '⚠'; ?></span> <?php echo esc_html( $state['text'] ); ?></p>
									<?php if ( is_array( $found ) ) : ?>
										<?php if ( ! $found ) : ?>
											<p><strong><?php esc_html_e( 'Лог не найден в типичных местах.', 'logshield' ); ?></strong> <?php esc_html_e( 'Узнайте путь у хостинга или в панели управления (раздел «Логи»). Возможно, PHP не разрешено читать каталог с логами (open_basedir).', 'logshield' ); ?></p>
										<?php else : ?>
											<p><strong><?php esc_html_e( 'Найдено:', 'logshield' ); ?></strong></p>
											<ul class="ls-found">
												<?php foreach ( $found as $f ) : ?>
													<li>
														<button type="submit" form="logshield-use-log" name="path" value="<?php echo esc_attr( $f['path'] ); ?>" class="ls-btn ls-btn-sm"<?php disabled( $f['path'], $opts['log_path'] ); ?>><?php echo esc_html( $f['path'] === $opts['log_path'] ? __( 'Выбран', 'logshield' ) : __( 'Использовать', 'logshield' ) ); ?></button>
														<span><code><?php echo esc_html( $f['path'] ); ?></code>
														— <?php echo esc_html( size_format( $f['size'] ) . ', ' . wp_date( 'd.m.Y H:i', $f['mtime'] ) ); ?>
														<?php if ( $f['own_domain'] ) : ?> · <?php esc_html_e( 'есть ваш домен', 'logshield' ); ?><?php elseif ( ! $f['near_site'] ) : ?> · <em><?php esc_html_e( 'общий лог сервера, могут быть чужие сайты', 'logshield' ); ?></em><?php endif; ?></span>
													</li>
												<?php endforeach; ?>
											</ul>
										<?php endif; ?>
									<?php endif; ?>
									<?php self::desc( 'log_path-desc', __( 'Полный путь на сервере (не URL). Если путь пуст, LogShield ищет лог сам при каждом сканировании. Типичные места: папка над сайтом (<code>…/access_log</code>), cPanel — <code>/home/USER/access-logs/DOMAIN</code>, ISPmanager — <code>/var/www/httpd-logs/DOMAIN.access.log</code>, Plesk — <code>/var/www/vhosts/DOMAIN/logs/access_log</code>.', 'logshield' ) ); ?>
								</div>
								<div class="ls-fields">
									<div class="ls-field">
										<label for="interval"><?php esc_html_e( 'Интервал сканирования', 'logshield' ); ?></label>
										<select id="interval" name="interval" class="ls-input" aria-describedby="interval-desc">
											<option value="logshield_2h" <?php selected( $opts['interval'], 'logshield_2h' ); ?>><?php esc_html_e( 'Каждые 2 часа', 'logshield' ); ?></option>
											<option value="logshield_3h" <?php selected( $opts['interval'], 'logshield_3h' ); ?>><?php esc_html_e( 'Каждые 3 часа', 'logshield' ); ?></option>
											<option value="logshield_4h" <?php selected( $opts['interval'], 'logshield_4h' ); ?>><?php esc_html_e( 'Каждые 4 часа', 'logshield' ); ?></option>
										</select>
										<p class="ls-field-desc" id="interval-desc"><?php
											/* translators: %s: дата и время следующего запуска или «не запланирован». */
											echo esc_html( sprintf( __( 'Следующий запуск: %s', 'logshield' ), $next_run ? wp_date( 'd.m.Y H:i:s', $next_run ) : __( 'не запланирован', 'logshield' ) ) );
										?></p>
									</div>
									<?php self::number_field( 'max_read_mb', __( 'Макс. объём чтения лога за один запуск, МБ', 'logshield' ), $opts['max_read_mb'], 1, 50, __( 'Ограничивает нагрузку при больших логах — если накопился большой хвост, он будет обработан за несколько последующих запусков.', 'logshield' ) ); ?>
								</div>
							</div>
						</section>

						<section class="ls-card ls-sec" id="ls-sec-rules" tabindex="-1" aria-labelledby="ls-sec-rules-title">
							<?php self::section_head( 'ls-sec-rules' ); ?>
							<div class="ls-sec-body">
								<div class="ls-fields">
									<?php
									self::number_field( 'rate_per_min', __( 'Запросов от одного IP за минуту', 'logshield' ), $opts['rate_per_min'], 0, 0, __( 'Наибольшее число запросов в любом окне 60 секунд по времени строк лога. Считаются и страницы, и файлы (картинки, стили, скрипты); успешные фоновые запросы WordPress (<code>admin-ajax.php</code>, <code>wp-cron.php</code>) не учитываются. 0 — правило выключено, наименьший порог — 10.', 'logshield' ) );
									self::number_field( 'brute_attempts', __( 'Порог неудачных входов с одного IP', 'logshield' ), $opts['brute_attempts'], 3, 0, __( 'Неудачный вход — <code>POST</code> на <code>wp-login.php</code> в любом каталоге с ответом не 302 (WordPress на неверный пароль отвечает 200, на успешный вход — перенаправлением).', 'logshield' ) );
									self::number_field( 'subnet_min_ips', __( 'Распределённый подбор: IP из одной подсети', 'logshield' ), $opts['subnet_min_ips'], 2, 256, __( 'Сколько разных адресов одной подсети (<code>/24</code> для IPv4, <code>/64</code> для IPv6) должны подбирать пароль.', 'logshield' ) );
									self::number_field( 'subnet_min_attempts', __( 'Распределённый подбор: неудачных входов из подсети', 'logshield' ), $opts['subnet_min_attempts'], 5, 0, __( 'Если из одной подсети пароль подбирают столько адресов и набирают столько неудачных входов, банится вся подсеть. Подсеть, в которой есть адрес из белого списка, не банится.', 'logshield' ) );
									self::number_field( 'scan_unique_paths', __( 'Порог разных путей с ошибкой 4xx (сканирование)', 'logshield' ), $opts['scan_unique_paths'], 5, 0, __( 'Считаются только пути, на которые сервер ответил 4xx (нет страницы, доступ закрыт). Поисковые боты и посетители ходят по живым страницам и под правило не попадают.', 'logshield' ) );
									self::number_field( 'scan_min_requests', __( 'Мин. запросов для детекта сканирования', 'logshield' ), $opts['scan_min_requests'], 5, 0, __( 'Адреса с меньшим числом запросов правило сканирования не проверяет.', 'logshield' ) );
									self::number_field( 'error_rate_pct', __( 'Порог процента ошибок (4xx/5xx)', 'logshield' ), $opts['error_rate_pct'], 1, 100, __( 'Доля ответов с ошибкой среди всех запросов адреса, в процентах.', 'logshield' ), '%' );
									self::number_field( 'error_rate_min_requests', __( 'Мин. запросов для детекта по ошибкам', 'logshield' ), $opts['error_rate_min_requests'], 5, 0, __( 'Адреса с меньшим числом запросов правило процента ошибок не проверяет.', 'logshield' ) );
									self::number_field( 'sensitive_min_hits', __( 'Разных чувствительных путей для бана', 'logshield' ), $opts['sensitive_min_hits'], 1, 50, __( 'Сколько разных путей вроде <code>/.env</code>, <code>/.git/config</code>, <code>/wp-config.php.bak</code> должен запросить IP, чтобы его забанили. Повторы одного пути и query string не считаются. 1 — банить за любое обращение (больше ложных срабатываний).', 'logshield' ) );
									self::number_field( 'enum_min_hits', __( 'Перебор пользователей: разных ID для бана', 'logshield' ), $opts['enum_min_hits'], 1, 50, __( 'Сканеры узнают логины, перебирая <code>/?author=1</code>, <code>/?author=2</code>… (WordPress перенаправляет на <code>/author/логин/</code>) или запрашивая <code>/wp-json/wp/v2/users</code>. Это разведка перед подбором пароля. Посетители открывают авторов по ссылкам <code>/author/имя/</code>, они не считаются.', 'logshield' ) );
									?>
								</div>
								<?php // Предпросмотр работает только со скриптом — он и показывает блок. ?>
								<div class="ls-preview" data-preview data-url="<?php echo esc_url( self::ajax_url( 'logshield_preview' ) ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'logshield_preview' ) ); ?>" hidden>
									<div class="ls-preview-head">
										<button type="button" class="ls-btn" data-preview-run aria-describedby="ls-preview-hint"><?php esc_html_e( 'Проверить на последних данных лога', 'logshield' ); ?></button>
										<p class="ls-field-desc" id="ls-preview-hint"><?php
										/* translators: %s: объём хвоста лога, например «2 MB». */
										echo esc_html( sprintf( __( 'Правила с порогами из формы применяются к последним %s лога. Ничего не сохраняется и не блокируется; после изменения порога проверка запускается сама.', 'logshield' ), size_format( self::preview_bytes() ) ) );
									?></p>
									</div>
									<p class="ls-preview-status" role="status" data-preview-status></p>
									<div data-preview-list></div>
								</div>
							</div>
						</section>

						<section class="ls-card ls-sec" id="ls-sec-ban" tabindex="-1" aria-labelledby="ls-sec-ban-title">
							<?php self::section_head( 'ls-sec-ban' ); ?>
							<div class="ls-sec-body">
								<div class="ls-field">
									<span class="ls-checkrow">
										<input type="checkbox" id="dry_run" name="dry_run" <?php checked( $opts['dry_run'] ); ?> aria-describedby="dry_run-desc" data-dry-run>
										<label for="dry_run"><?php esc_html_e( 'Тестовый режим: обнаруживать, но не блокировать', 'logshield' ); ?></label>
									</span>
									<?php self::desc( 'dry_run-desc', __( 'Рекомендуется для начала: адреса попадают в историю сканирований, но в <code>.htaccess</code> не записываются. Снимите флажок, когда убедитесь, что правила не задевают своих.', 'logshield' ) ); ?>
								</div>
								<div class="ls-fields">
									<?php self::number_field( 'ban_expiry_days', __( 'Срок блокировки, дней', 'logshield' ), $opts['ban_expiry_days'], 0, 0, __( '0 — блокировать навсегда.', 'logshield' ) ); ?>
								</div>
							</div>
						</section>

						<section class="ls-card ls-sec" id="ls-sec-notify" tabindex="-1" aria-labelledby="ls-sec-notify-title">
							<?php self::section_head( 'ls-sec-notify' ); ?>
							<div class="ls-sec-body">
								<div class="ls-fields">
									<div class="ls-field">
										<label for="notify_email"><?php esc_html_e( 'E-mail для уведомлений', 'logshield' ); ?></label>
										<input type="email" id="notify_email" name="notify_email" class="ls-input" value="<?php echo esc_attr( $opts['notify_email'] ); ?>" autocomplete="email" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="notify_email-desc">
										<?php self::desc( 'notify_email-desc', __( 'Необязательно. Письмо приходит после сканирования, если кого-то поймали.', 'logshield' ) ); ?>
									</div>
									<div class="ls-field">
										<label for="telegram_token"><?php esc_html_e( 'Telegram: токен бота', 'logshield' ); ?></label>
										<input type="password" id="telegram_token" name="telegram_token" class="ls-input" value="" autocomplete="off" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="telegram_token-desc">
										<p class="ls-field-desc" id="telegram_token-desc">
											<?php if ( ! empty( $opts['telegram_token'] ) ) : ?>
												<?php
												/* translators: %s: последние 4 символа токена. */
												echo esc_html( sprintf( __( 'Токен сохранён (…%s). Оставьте поле пустым, чтобы не менять.', 'logshield' ), substr( $opts['telegram_token'], -4 ) ) );
											?>

											<?php else : ?>
												<?php echo LogShield_Plugin::kses( __( 'Создайте бота у <code>@BotFather</code> командой <code>/newbot</code> и вставьте выданный токен.', 'logshield' ) ); ?>

											<?php endif; ?>
										</p>
										<?php if ( ! empty( $opts['telegram_token'] ) ) : ?>
											<span class="ls-checkrow">
												<input type="checkbox" id="telegram_token_clear" name="telegram_token_clear" value="1">
												<label for="telegram_token_clear"><?php esc_html_e( 'Удалить токен (отключить Telegram)', 'logshield' ); ?></label>
											</span>
										<?php endif; ?>
									</div>
									<div class="ls-field">
										<label for="telegram_chat_id">Telegram: chat_id</label>
										<input type="text" id="telegram_chat_id" name="telegram_chat_id" class="ls-input" value="<?php echo esc_attr( $opts['telegram_chat_id'] ); ?>" autocomplete="off" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="telegram_chat_id-desc">
										<?php self::desc( 'telegram_chat_id-desc', __( 'Куда слать: ваш числовой id (напишите боту <code>/start</code>, затем узнайте id, например у <code>@userinfobot</code>), id группы (начинается с минуса, бота нужно добавить в группу) или <code>@имя_канала</code>.', 'logshield' ) ); ?>
									</div>
								</div>
								<?php if ( LogShield_Notifier::telegram_configured( $opts ) ) : ?>
									<?php $tg_queue = (array) get_option( LogShield_Notifier::RETRY_OPTION, [] ); $tg_fail = get_option( LogShield_Notifier::FAIL_OPTION ); ?>
									<?php if ( $tg_queue ) : $tg_next = wp_next_scheduled( LogShield_Notifier::RETRY_HOOK ); ?>
										<p class="ls-note ls-note-warn"><span aria-hidden="true">⚠</span> <?php
											/* translators: 1: число недоставленных сообщений, 2: последняя ошибка, 3: время повтора или «при следующем запуске WP-Cron». */
											echo esc_html( sprintf( __( 'Не доставлено в Telegram: %1$d — %2$s. Повтор %3$s.', 'logshield' ), count( $tg_queue ), end( $tg_queue )['error'], $tg_next ? wp_date( 'H:i', $tg_next ) : __( 'при следующем запуске WP-Cron', 'logshield' ) ) );
										?></p>
									<?php elseif ( $tg_fail ) : ?>
										<p class="ls-note ls-note-err"><span aria-hidden="true">✕</span> <?php
											/* translators: 1: дата и время уведомления, 2: ошибка. */
											echo esc_html( sprintf( __( 'Уведомление %1$s так и не дошло до Telegram: %2$s', 'logshield' ), wp_date( 'd.m H:i', $tg_fail['time'] ), $tg_fail['error'] ) );
										?></p>
									<?php endif; ?>
									<p><button type="submit" form="logshield-telegram-test" class="ls-btn"><?php esc_html_e( 'Отправить тестовое сообщение в Telegram', 'logshield' ); ?></button></p>
								<?php endif; ?>
							</div>
						</section>

						<section class="ls-card ls-sec" id="ls-sec-geo" tabindex="-1" aria-labelledby="ls-sec-geo-title">
							<?php self::section_head( 'ls-sec-geo' ); ?>
							<div class="ls-sec-body">
								<div class="ls-field">
									<span class="ls-checkrow">
										<input type="checkbox" id="ipinfo_enabled" name="ipinfo_enabled" value="1" <?php checked( ! empty( $opts['ipinfo_enabled'] ) ); ?> aria-describedby="ipinfo_enabled-desc">
										<label for="ipinfo_enabled"><?php esc_html_e( 'Определять страну, сеть, Tor, VPN и дата-центр', 'logshield' ); ?></label>
									</span>
									<p class="ls-field-desc" id="ipinfo_enabled-desc"><?php
										/* translators: %d: порог ошибок или неудачных входов за сканирование. */
										echo LogShield_Plugin::kses( sprintf( __( 'Только для информации, на блокировку не влияет. Определяется для пойманных правилами и для адресов, у которых за сканирование %d+ ошибок или неудачных входов; остальных посетителей не трогает. Нужны локальные базы (около 20 МБ в <code>wp-content/logshield-geo</code>): страна и сеть обновляются раз в месяц, Tor — раз в сутки, VPN — раз в неделю. Внешних запросов на каждый адрес нет.', 'logshield' ), (int) LogShield_IPInfo::MIN_HITS ) );
									?></p>
								</div>
								<?php if ( ! empty( $opts['ipinfo_enabled'] ) ) : ?>
									<ul class="ls-geo-status ls-list">
										<?php foreach ( LogShield_IPInfo::status() as $file => $st ) : ?>
											<li><code><?php echo esc_html( $file ); ?></code> —
												<?php if ( $st['exists'] ) : ?>
													<?php echo esc_html( size_format( $st['size'] ) . ', ' . wp_date( 'j.m.Y H:i', $st['time'] ) ); ?>
												<?php else : ?>
													<?php esc_html_e( 'ещё не скачан', 'logshield' ); ?>

												<?php endif; ?>
												<?php if ( $st['error'] ) : ?><span class="ls-danger"><?php
												/* translators: %s: текст ошибки загрузки. */
												echo esc_html( sprintf( __( '(ошибка: %s)', 'logshield' ), $st['error'] ) );
											?></span><?php endif; ?>
											</li>
										<?php endforeach; ?>
									</ul>
									<p><button type="submit" form="logshield-geo-update" class="ls-btn"><?php esc_html_e( 'Обновить базы сейчас', 'logshield' ); ?></button></p>
								<?php endif; ?>
								<p class="ls-field-desc"><?php echo LogShield_Plugin::kses( __( 'Источники: <a href="https://db-ip.com">IP Geolocation by DB-IP</a> (CC BY 4.0), список выходных узлов Tor Project, список VPN <a href="https://github.com/X4BNet/lists_vpn">X4BNet/lists_vpn</a>. Метки приблизительные: обычный пользователь с VPN — не атакующий.', 'logshield' ) ); ?></p>
							</div>
						</section>

						<section class="ls-card ls-sec" id="ls-sec-white" tabindex="-1" aria-labelledby="ls-sec-white-title">
							<?php self::section_head( 'ls-sec-white' ); ?>
							<div class="ls-sec-body">
								<div class="ls-myip">
									<p><?php esc_html_e( 'Ваш текущий IP:', 'logshield' ); ?> <code><?php echo esc_html( $my_ip ?: __( 'не определён', 'logshield' ) ); ?></code>
									— <?php echo $my_why
										/* translators: %s: почему адрес в белом списке. */
										? '<span class="ls-accent"><span aria-hidden="true">✓</span> ' . esc_html( sprintf( __( 'в белом списке (%s)', 'logshield' ), $my_why['text'] ) ) . '</span>'
										: '<span class="ls-warn"><span aria-hidden="true">⚠</span> ' . esc_html__( 'не в белом списке', 'logshield' ) . '</span>'; ?></p>
									<?php if ( $my_ip && ! $my_why ) : ?>
										<button type="submit" form="logshield-add-my-ip" class="ls-btn ls-btn-sm"><?php esc_html_e( 'Добавить мой IP в белый список', 'logshield' ); ?></button>
									<?php endif; ?>
								</div>
								<div class="ls-field">
									<label for="whitelist_ips"><?php esc_html_e( 'Белый список IP (вручную)', 'logshield' ); ?></label>
									<textarea id="whitelist_ips" name="whitelist_ips" rows="4" class="ls-input" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="whitelist_ips-desc"><?php echo esc_textarea( implode( "\n", $opts['whitelist_ips'] ) ); ?></textarea>
									<?php self::desc( 'whitelist_ips-desc', __( 'Один IP или диапазон на строку, например <code>203.0.113.7</code> или <code>203.0.113.0/24</code>. Неверные строки при сохранении отбрасываются (они будут перечислены в сообщении).', 'logshield' ) ); ?>
								</div>
								<div class="ls-field">
									<label for="trusted_proxies"><?php esc_html_e( 'Доверенные прокси', 'logshield' ); ?></label>
									<textarea id="trusted_proxies" name="trusted_proxies" rows="4" class="ls-input" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="trusted_proxies-desc"><?php echo esc_textarea( implode( "\n", (array) $opts['trusted_proxies'] ) ); ?></textarea>
									<p><button type="button" class="ls-btn ls-btn-sm" data-fill-target="trusted_proxies" data-fill-lines="<?php echo esc_attr( implode( "\n", LogShield_Whitelist::CLOUDFLARE_RANGES ) ); ?>" hidden><?php esc_html_e( 'Вставить диапазоны Cloudflare', 'logshield' ); ?></button></p>
									<div class="ls-field-desc" id="trusted_proxies-desc">
										<p><?php echo LogShield_Plugin::kses( __( 'Заполняйте, только если сайт стоит за Cloudflare или другим прокси, а на сервере нет <code>mod_remoteip</code>: тогда Apache видит у всех посетителей адрес прокси. Для запросов с этих адресов LogShield берёт адрес посетителя из заголовков <code>CF-Connecting-IP</code>, <code>X-Real-IP</code> или <code>X-Forwarded-For</code> — так в белый список попадает настоящий адрес сотрудника. Сами прокси тоже входят в белый список и никогда не блокируются: иначе бан закрыл бы сайт для всех.', 'logshield' ) ); ?></p>
										<p><?php esc_html_e( 'Один IP или диапазон на строку. Указывайте только адреса своего прокси. Если ошибиться: чужой адрес в списке никогда не будет заблокирован, а запросы с него смогут подделать эти заголовки и выдать себя за другой адрес; если же пропустить адрес своего прокси, все посетители будут выглядеть одним адресом прокси, и правила могут его забанить. Без прокси оставьте поле пустым.', 'logshield' ); ?></p>
									</div>
								</div>
								<div class="ls-fields">
									<div class="ls-field">
										<h3 class="ls-sub-title"><?php esc_html_e( 'Сотрудники в белом списке', 'logshield' ); ?></h3>
										<?php if ( empty( $admin_ips ) ) : ?>
											<p class="ls-field-desc"><?php esc_html_e( 'Пока нет данных (появятся, когда автор, редактор или администратор зайдёт в панель WordPress).', 'logshield' ); ?></p>
										<?php else : ?>
											<ul class="ls-list">
												<?php foreach ( LogShield_Whitelist::get_admin_users() as $ip => $logins ) : ?>
													<li><code><?php echo esc_html( $ip ); ?></code>
														<?php if ( $logins ) : ?>
															— <?php echo esc_html( implode( ', ', $logins ) ); ?>
														<?php else : ?>
															— <span class="ls-dim"><?php esc_html_e( 'логин появится при следующем заходе', 'logshield' ); ?></span>
														<?php endif; ?>
													</li>
												<?php endforeach; ?>
											</ul>
										<?php endif; ?>
									</div>
									<div class="ls-field">
										<h3 class="ls-sub-title"><?php esc_html_e( 'Адреса сервера в белом списке', 'logshield' ); ?></h3>
										<?php $server_ips = LogShield_Whitelist::get_server_ips(); ?>
										<?php if ( empty( $server_ips ) ) : ?>
											<p class="ls-field-desc"><?php esc_html_e( 'Пока нет данных (появятся после первого запуска WP-Cron).', 'logshield' ); ?></p>
										<?php else : ?>
											<ul class="ls-list"><?php foreach ( $server_ips as $ip ) echo '<li><code>' . esc_html( $ip ) . '</code></li>'; ?></ul>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</section>

						<?php // Закреплённая кнопка сохранения: прилипает к низу окна, пока видна форма. ?>
						<div class="ls-savebar">
							<p class="ls-save-hint" role="status" data-dirty-hint></p>
							<button type="submit" class="ls-btn ls-btn-accent"><?php esc_html_e( 'Сохранить настройки', 'logshield' ); ?></button>
						</div>
					</form>

					<section class="ls-card ls-sec" id="ls-sec-service" tabindex="-1" aria-labelledby="ls-sec-service-title">
						<?php self::section_head( 'ls-sec-service' ); ?>
						<div class="ls-sec-body">
							<div class="ls-service-row">
								<p><?php
									/* translators: %s: адрес дашборда. */
									echo LogShield_Plugin::kses( sprintf( __( 'Заблокированные адреса, графики и история сканирований — на странице <a href="%s">LogShield → Дашборд</a>.', 'logshield' ), esc_url( admin_url( 'admin.php?page=' . self::SLUG_DASH ) ) ) );
								?></p>
								<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_run_now' ) ); ?>">
									<input type="hidden" name="action" value="logshield_run_now">
									<?php wp_nonce_field( 'logshield_run_now' ); ?>
									<button type="submit" class="ls-btn"><span class="dashicons dashicons-update" aria-hidden="true"></span> <?php esc_html_e( 'Запустить сканирование сейчас', 'logshield' ); ?></button>
								</form>
							</div>

							<div class="ls-field">
								<h3 class="ls-sub-title" id="logshield-ping"><?php esc_html_e( 'Адрес для проверки доступности', 'logshield' ); ?></h3>
								<p class="ls-field-desc"><?php
									/* translators: %s: ответ адреса проверки (logshield-ok). */
									echo LogShield_Plugin::kses( sprintf( __( 'Внешний пинг (воркер Cloudflare из <code>tools/uptime-worker</code>, UptimeRobot и т. п.) должен открывать этот адрес, а не главную. Ответ <code>%s</code> приходит, только когда WordPress загрузился полностью и база данных отвечает. Такие запросы LogShield не учитывает: они не попадают в правила, графики и хвост лога.', 'logshield' ), esc_html( LogShield_Ping::REPLY ) ) );
								?></p>
								<label for="ls-ping-url" class="screen-reader-text"><?php esc_html_e( 'Адрес для проверки доступности', 'logshield' ); ?></label>
								<input type="text" id="ls-ping-url" class="ls-input" readonly value="<?php echo esc_attr( LogShield_Ping::url() ); ?>" data-select-on-focus aria-describedby="ls-ping-desc">
								<p class="ls-field-desc" id="ls-ping-desc"><?php
									/* translators: %s: ответ адреса проверки (logshield-ok). */
									echo LogShield_Plugin::kses( sprintf( __( 'Ключ в адресе держите в секрете: запрос с ним LogShield пропускает. Ключевое слово для проверки — <code>%s</code>.', 'logshield' ), esc_html( LogShield_Ping::REPLY ) ) );
								?></p>
								<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_ping_rotate' ) ); ?>" data-confirm="<?php esc_attr_e( 'Старый адрес перестанет работать, и пинг начнёт сообщать, что сайт недоступен, пока вы не обновите адрес у воркера. Продолжить?', 'logshield' ); ?>">
									<input type="hidden" name="action" value="logshield_ping_rotate">
									<?php wp_nonce_field( 'logshield_ping_rotate' ); ?>
									<button type="submit" class="ls-btn"><?php esc_html_e( 'Сменить ключ', 'logshield' ); ?></button>
								</form>
							</div>

							<p class="ls-field-desc"><?php
								/* translators: 1: версия плагина, 2: время и результат последней проверки обновлений. */
								echo esc_html( sprintf( __( 'Версия %1$s. Последняя проверка обновлений на GitHub: %2$s', 'logshield' ), LOGSHIELD_VERSION, LogShield_Updater::is_dev_checkout() ? __( 'не проверяется (рабочая копия из git)', 'logshield' ) : LogShield_Updater::last_check_text() ) );
							?></p>
						</div>
					</section>

					<?php // Вне формы настроек: у карточки свои формы (выпуск и отзыв токена). ?>
					<?php LogShield_API::render_card(); ?>
				</div>
			</div>

			<?php // Формы для кнопок внутри основной формы (form="…"): вложенные формы в HTML запрещены. ?>
			<form id="logshield-detect-log" method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_detect_log' ) ); ?>" hidden>
				<input type="hidden" name="action" value="logshield_detect_log">
				<?php wp_nonce_field( 'logshield_detect_log' ); ?>
			</form>
			<form id="logshield-geo-update" method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_geo_update' ) ); ?>" hidden>
				<input type="hidden" name="action" value="logshield_geo_update">
				<?php wp_nonce_field( 'logshield_geo_update' ); ?>
			</form>
			<form id="logshield-use-log" method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_use_log' ) ); ?>" hidden>
				<input type="hidden" name="action" value="logshield_use_log">
				<?php wp_nonce_field( 'logshield_use_log' ); ?>
			</form>
			<?php if ( $my_ip && ! $my_why ) : ?>
				<form id="logshield-add-my-ip" method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_add_my_ip' ) ); ?>" hidden>
					<input type="hidden" name="action" value="logshield_add_my_ip">
					<?php wp_nonce_field( 'logshield_add_my_ip' ); ?>
				</form>
			<?php endif; ?>
			<form id="logshield-telegram-test" method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_telegram_test' ) ); ?>" hidden>
				<input type="hidden" name="action" value="logshield_telegram_test">
				<?php wp_nonce_field( 'logshield_telegram_test' ); ?>
			</form>

			<?php // Подтверждения (settings.js). Без <dialog> скрипт спрашивает через confirm(), без скрипта — не спрашивает. ?>
			<dialog id="ls-confirm" class="ls-dialog" closedby="any" aria-labelledby="ls-confirm-title" aria-describedby="ls-confirm-text">
				<h2 id="ls-confirm-title"><?php esc_html_e( 'Подтвердите действие', 'logshield' ); ?></h2>
				<p id="ls-confirm-text" class="ls-confirm-text" data-confirm-text></p>
				<form method="dialog" class="ls-dialog-actions">
					<button value="cancel" class="ls-btn" autofocus><?php esc_html_e( 'Отмена', 'logshield' ); ?></button>
					<button value="ok" class="ls-btn ls-btn-accent"><?php esc_html_e( 'Продолжить', 'logshield' ); ?></button>
				</form>
			</dialog>
			<?php if ( $opts['dry_run'] ) : ?>
				<dialog id="ls-dry-confirm" class="ls-dialog" closedby="any" aria-labelledby="ls-dry-confirm-title" aria-describedby="ls-dry-confirm-desc"
					data-fallback="<?php
					/* translators: %s: итог тестового режима за 7 дней. */
					echo esc_attr( sprintf( __( 'Выключить тестовый режим? %s Со следующего сканирования нарушители будут блокироваться в .htaccess.', 'logshield' ), $would_text ) );
				?>">
					<h2 id="ls-dry-confirm-title"><?php esc_html_e( 'Выключить тестовый режим?', 'logshield' ); ?></h2>
					<div id="ls-dry-confirm-desc">
						<p><?php echo esc_html( $would_text ); ?></p>
						<p><?php echo LogShield_Plugin::kses( __( 'Со следующего сканирования новые нарушители будут блокироваться в <code>.htaccess</code>.', 'logshield' ) ); ?></p>
						<?php if ( $my_why ) : ?>
							<p><span aria-hidden="true">✓</span> <?php
							/* translators: 1: IP-адрес в теге <code>, 2: почему адрес в белом списке. */
							echo LogShield_Plugin::kses( sprintf( __( 'Ваш адрес %1$s в белом списке: %2$s.', 'logshield' ), '<code>' . esc_html( $my_ip ) . '</code>', esc_html( $my_why['text'] ) ) );
						?></p>
						<?php else : ?>
							<p class="ls-warn-text"><span aria-hidden="true">⚠</span> <?php
							/* translators: %s: IP-адрес в теге <code>. */
							echo LogShield_Plugin::kses( sprintf( __( 'Ваш адрес %s не найден в белом списке.', 'logshield' ), '<code>' . esc_html( $my_ip ?: __( 'не определён', 'logshield' ) ) . '</code>' ) );
						?></p>
						<?php endif; ?>
					</div>
					<form method="dialog" class="ls-dialog-actions">
						<button value="cancel" class="ls-btn" autofocus><?php esc_html_e( 'Отмена', 'logshield' ); ?></button>
						<button value="ok" class="ls-btn ls-btn-accent"><?php esc_html_e( 'Выключить и сохранить', 'logshield' ); ?></button>
					</form>
				</dialog>
			<?php endif; ?>
		</div>
		</div>
		<?php
	}
}

// Предпросмотр правил на странице настроек.
add_action( 'wp_ajax_logshield_preview', [ 'LogShield_Admin', 'ajax_preview' ] );
