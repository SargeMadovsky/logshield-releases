<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LogShield_Parser {

	// Формат: [домен] IP ident user [date] "METHOD path proto" status size "referer" "ua"
	// Ведущая часть до "[date]" разбирается отдельно, т.к. количество полей
	// перед датой отличается: 3 поля (IP ident user) в стандартном Apache
	// Combined Log Format, либо 4 поля (domain IP ident user), если лог
	// объединяет несколько виртуальных хостов (частый вариант на shared-хостингах).
	//
	// Поля в кавычках принимают экранированные символы (Apache пишет \" и \\):
	// иначе атакующий прятал бы строку от правил, поставив кавычку в Referer.
	// Referer и User-Agent необязательны (Common Log Format).
	const LOG_PREFIX_REGEX = '/^(.+?)\s+\[([^\]]+)\]\s+"((?:[^"\\\\]++|\\\\.)*+)"\s+(\d{3})\s+(\d+|-)(?:\s*"((?:[^"\\\\]++|\\\\.)*+)"(?:\s+"((?:[^"\\\\]++|\\\\.)*+)")?)?/';

	/** Протокол в конце строки запроса: HTTP/1.1, HTTP/2.0, HTTP/2. */
	const PROTOCOL_REGEX = '~^HTTP/\d+(\.\d+)?$~i';

	public static function parse_line( $line ) {
		$line = trim( $line );
		if ( $line === '' ) return null;
		if ( ! preg_match( self::LOG_PREFIX_REGEX, $line, $m ) ) return null;

		$prefix_tokens = preg_split( '/\s+/', trim( $m[1] ) );
		if ( count( $prefix_tokens ) < 3 ) return null;

		// Последние 3 поля перед [date] — это всегда IP, ident, user.
		// Всё, что осталось перед ними (обычно ничего или одно слово) — домен.
		$user   = array_pop( $prefix_tokens );
		$ident  = array_pop( $prefix_tokens );
		$ip     = array_pop( $prefix_tokens );
		$domain = implode( ' ', $prefix_tokens );

		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) return null;

		// Строка запроса: метод — первое слово, протокол — последнее, если похоже
		// на HTTP/x; всё между ними — путь (в нём бывают пробелы: «GET /a b/.env»).
		// «-» и двоичные пробы TLS («\x16\x03…») дают метод без пути, как раньше.
		$request  = self::unescape( $m[3] );
		$tokens   = preg_split( '/\s+/', trim( $request ), -1, PREG_SPLIT_NO_EMPTY );
		$method   = (string) array_shift( $tokens );
		$protocol = '';
		if ( count( $tokens ) > 1 && preg_match( self::PROTOCOL_REGEX, end( $tokens ) ) ) {
			$protocol = array_pop( $tokens );
		}
		$path = implode( ' ', $tokens );

		return [
			'domain'     => $domain,
			'ip'         => $ip,
			'ident'      => $ident,
			'user'       => $user,
			'date'       => $m[2],
			'method'     => $method,
			'path'       => $path,
			'protocol'   => $protocol,
			'status'     => (int) $m[4],
			'size'       => ( $m[5] === '-' ) ? 0 : (int) $m[5],
			'referer'    => isset( $m[6] ) ? self::unescape( $m[6] ) : '',
			'user_agent' => isset( $m[7] ) ? self::unescape( $m[7] ) : '',
			'raw'        => $line,
		];
	}

	/** \" → ", \\ → \ ; остальные последовательности (\x16 и т. п.) остаются как есть. */
	private static function unescape( $s ) {
		return strpos( $s, '\\' ) === false ? $s : strtr( $s, [ '\\"' => '"', '\\\\' => '\\' ] );
	}

	/**
	 * Читает новую часть файла лога начиная с offset, с ограничением объёма
	 * за один запуск (чтобы не создавать нагрузку на слабом сервере).
	 *
	 * Возвращает:
	 *   [ 'lines' => [...], 'new_offset' => int, 'rotated' => bool, 'size' => int, 'unparsed' => int,
	 *     'fingerprint' => [ 'hash', 'len' ] ]
	 *   либо [ 'error' => 'not_readable' | 'cannot_open' | 'read_error' ]
	 *
	 * $fingerprint — отпечаток начала файла с прошлого запуска (см. fingerprint()).
	 * Не совпал — файл заменён (ротация), читаем с начала. null — не проверяем.
	 * В ответе — отпечаток текущего файла, его и надо сохранить рядом с offset.
	 *
	 * unparsed — сколько непустых строк парсер не распознал: такие строки
	 * не видны правилам, их долю показывает дашборд.
	 *
	 * $count_unparsed = false — строки не разбираются и unparsed = 0: так
	 * делает run(), чтобы не разбирать каждую строку дважды (analyze() сам
	 * возвращает 'unparsed').
	 *
	 * Файл читается блоками по READ_BLOCK байт, без промежуточной строки на
	 * весь кусок и её копий: в памяти только итоговый массив строк.
	 */
	public static function read_chunk( $path, $offset, $max_bytes, $fingerprint = null, $count_unparsed = true ) {
		clearstatcache();
		$size = @filesize( $path );
		if ( $size === false ) {
			return [ 'error' => 'not_readable' ];
		}

		$fp = @fopen( $path, 'rb' );
		if ( ! $fp ) {
			return [ 'error' => 'cannot_open' ];
		}
		$head    = self::read_head( $fp );
		$current = self::make_fingerprint( $head );

		$rotated = false;
		if ( $offset > $size ) {
			// Файл был ротирован или обрезан — начинаем заново.
			$offset  = 0;
			$rotated = true;
		} elseif ( $offset > 0 && ! self::fingerprint_matches( $fingerprint, $head ) ) {
			// Начало файла другое: на месте старого лога новый, и он уже успел
			// вырасти больше прежней позиции. Без этой проверки его начало пропустили бы.
			$offset  = 0;
			$rotated = true;
		}

		if ( $offset >= $size ) {
			fclose( $fp );
			return [ 'lines' => [], 'new_offset' => $size, 'rotated' => $rotated, 'size' => $size, 'unparsed' => 0, 'fingerprint' => $current ];
		}

		fseek( $fp, $offset );

		// Читаем блоками по 64 КБ; хвост блока без перевода строки ждёт следующего.
		// Не разрезаем последнюю строку: строка без перевода строки в пределах
		// лимита (не дописана или не влезла) откладывается до следующего запуска.
		$remaining = min( $size - $offset, $max_bytes );
		$newOffset = $offset;
		$lines     = [];
		$unparsed  = 0;
		$buf       = '';
		while ( $remaining > 0 ) {
			$block = fread( $fp, min( self::READ_BLOCK, $remaining ) );
			if ( $block === false ) {
				fclose( $fp );
				return [ 'error' => 'read_error' ];
			}
			if ( $block === '' ) break; // файл укоротили после filesize()
			$remaining -= strlen( $block );
			$blockNl    = strrpos( $block, "\n" ); // в $buf перевода строки нет — ищем только в новом блоке
			$buf       .= $block;
			if ( $blockNl === false ) continue;
			$lastNl     = strlen( $buf ) - strlen( $block ) + $blockNl;
			$newOffset += $lastNl + 1;
			foreach ( explode( "\n", substr( $buf, 0, $lastNl ) ) as $line ) {
				$line = trim( $line );
				if ( $line === '' ) continue;
				$lines[] = $line;
				if ( $count_unparsed && self::parse_line( $line ) === null ) $unparsed++;
			}
			$buf = (string) substr( $buf, $lastNl + 1 );
		}
		fclose( $fp );

		return [ 'lines' => $lines, 'new_offset' => $newOffset, 'rotated' => $rotated, 'size' => $size, 'unparsed' => $unparsed, 'fingerprint' => $current ];
	}

	/** Размер блока чтения в read_chunk(). */
	const READ_BLOCK = 65536;

	/** Сколько первых байт файла идёт в отпечаток. */
	const FINGERPRINT_BYTES = 256;

	/**
	 * Отпечаток начала файла: [ 'hash' => sha1, 'len' => сколько байт взято ].
	 * Пока файл меньше 256 байт, берётся сколько есть — len сохраняется, чтобы
	 * сравнивать тот же объём, когда файл подрастёт.
	 *
	 * @return array|null null, если файл не открыть
	 */
	public static function fingerprint( $path ) {
		$fp = @fopen( $path, 'rb' );
		if ( ! $fp ) return null;
		$head = self::read_head( $fp );
		fclose( $fp );
		return self::make_fingerprint( $head );
	}

	/**
	 * Совпадает ли сохранённый отпечаток с началом файла. Отпечатка нет
	 * (старая установка) — считаем, что совпал: run() просто запишет новый.
	 */
	public static function fingerprint_matches( $fingerprint, $head ) {
		if ( ! is_array( $fingerprint ) || ! isset( $fingerprint['hash'], $fingerprint['len'] ) ) return true;
		$len = (int) $fingerprint['len'];
		if ( $len <= 0 ) return true;
		if ( strlen( $head ) < $len ) return false; // файл стал короче прежнего начала
		return hash_equals( (string) $fingerprint['hash'], sha1( substr( $head, 0, $len ) ) );
	}

	private static function read_head( $fp ) {
		rewind( $fp );
		$head = fread( $fp, self::FINGERPRINT_BYTES );
		return $head === false ? '' : $head;
	}

	private static function make_fingerprint( $head ) {
		return [ 'hash' => sha1( $head ), 'len' => strlen( $head ) ];
	}
}
