<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Дашборд «LogShield → Дашборд»: метрики, графики по часам, атакующие адреса,
 * история сканирований и хвост лога (с живым режимом, пока страница открыта).
 *
 * Внешних библиотек и CDN нет: графики рисуются в SVG своим скриптом.
 */
class LogShield_Dashboard {

	// Хвост при открытии вкладки. Фильтр «Скрыть обычное» (по умолчанию) прячет
	// около половины строк, поэтому берём больше, чем раньше (было 32 КБ / 80 строк):
	// на реальном логе в последних 250 строках видимых обычно 150+, в 80 — около 50,
	// а в каждом десятом окне 80 строк — не больше 12. Читается один раз за открытие.
	const TAIL_FIRST_BYTES = 65536;
	const TAIL_MAX_BYTES   = 65536; // максимум нового за один опрос
	const TAIL_LINES       = 250;
	const BACKFILL_OPTION  = 'logshield_backfilled'; // путь лога, по которому уже строили историю

	const SEEN_META = 'logshield_seen_at'; // когда пользователь последний раз открывал дашборд

	/** Тема дашборда у пользователя: system | dark | light. Нет значения — тёмная (как было всегда). */
	const THEME_META    = 'logshield_theme';
	const THEMES        = [ 'system' => 'Как в системе', 'dark' => 'Тёмная', 'light' => 'Светлая' ];
	const DEFAULT_THEME = 'dark';

	/** Подписи тем на языке сайта (ключи — как в THEMES). */
	public static function themes() {
		return [ 'system' => __( 'Как в системе', 'logshield' ), 'dark' => __( 'Тёмная', 'logshield' ), 'light' => __( 'Светлая', 'logshield' ) ];
	}

	/**
	 * Вкладки дашборда: имя (оно же #hash адреса и значение поля ls_tab) => подпись.
	 * Первая — по умолчанию.
	 */
	const TABS = [
		'overview'  => 'Обзор',
		'addresses' => 'Адреса',
		'log'       => 'Лог',
		'health'    => 'Состояние',
	];

	/**
	 * Старые имена вкладок (закладки, ссылки из писем, ls_tab старых форм) => новые.
	 * «Атакующие» стали «Адресами», «Журнал» переехал в «Состояние».
	 */
	const TAB_ALIASES = [
		'attackers' => 'addresses',
		'journal'   => 'health',
	];

	/** Подписи вкладок на языке сайта (ключи и порядок — как в TABS). */
	public static function tabs() {
		return [
			'overview'  => __( 'Обзор', 'logshield' ),
			'addresses' => __( 'Адреса', 'logshield' ),
			'log'       => __( 'Лог', 'logshield' ),
			'health'    => __( 'Состояние', 'logshield' ),
		];
	}

	/**
	 * Счётчик новых атакующих и прежняя отметка просмотра — на момент открытия
	 * дашборда, до сброса (mark_seen() в admin_menu идёт раньше render()).
	 */
	private static $unseen_on_open = 0;
	private static $seen_before    = 0;

	/**
	 * Короткий индекс для кружка в меню: строка «время:n время:n …» по истории
	 * сканирований (от новых к старым), где n — сколько адресов этого
	 * сканирования не встречалось в более новых. Несколько сотен байт вместо
	 * 100+ КБ истории на каждой странице админки.
	 */
	const UNSEEN_INDEX_OPTION = 'logshield_unseen_index';

	/**
	 * Скрытые в таблице атакующих: ip|cidr => когда скрыли (autoload off).
	 * Строка снова видна, если адрес пойман позже. Записи старше
	 * DISMISS_TTL_DAYS удаляются, сверх DISMISS_MAX — самые старые.
	 */
	const DISMISSED_OPTION = 'logshield_dismissed';
	const DISMISS_MAX      = 2000;
	const DISMISS_TTL_DAYS = 30;

	/** Групповое действие: не больше стольких адресов за раз. */
	const BULK_MAX = 200;

	/** Сроки блокировки в панели адреса (дней); «по умолчанию» — из настроек. */
	const BAN_DAYS = [ 1, 7, 30 ];

	/** Последние запросы адреса: сколько байт с конца лога читать и сколько строк отдавать. */
	const IP_REQUESTS_BYTES = 2097152;
	const IP_REQUESTS_MAX   = 50;

	/** Сколько записей истории срабатываний на адрес отдавать панели. */
	const HISTORY_PER_IP = 10;

	/** Вычисленное за запрос: атакующие, список банов, история. */
	private static $memo = [];

	/** Хуки: индекс и кэш запроса обновляются при любой записи истории и банов. */
	public static function init() {
		$scan = LogShield_Detector::SCANLOG_OPTION;
		add_action( "add_option_{$scan}", function ( $name, $value ) { self::refresh_unseen_index( $value ); }, 10, 2 );
		add_action( "update_option_{$scan}", function ( $old, $value ) { self::refresh_unseen_index( $value ); }, 10, 2 );
		add_action( "delete_option_{$scan}", function () { self::refresh_unseen_index( [] ); } );
		$ban = LogShield_Htaccess::BANNED_OPTION;
		foreach ( [ "add_option_{$ban}", "update_option_{$ban}", "delete_option_{$ban}" ] as $hook ) {
			add_action( $hook, [ __CLASS__, 'flush_memo' ] );
		}
		add_action( 'admin_post_logshield_evictions_ack', [ __CLASS__, 'ack_evictions' ] );
		add_action( 'wp_ajax_logshield_theme', [ __CLASS__, 'ajax_theme' ] );
		add_action( 'admin_post_logshield_bulk', [ __CLASS__, 'bulk' ] );
		add_action( 'admin_post_logshield_import_denies', [ __CLASS__, 'import_denies' ] );
		add_action( 'wp_ajax_logshield_ip_requests', [ __CLASS__, 'ajax_ip_requests' ] );
		$dis = self::DISMISSED_OPTION;
		foreach ( [ "add_option_{$dis}", "update_option_{$dis}", "delete_option_{$dis}" ] as $hook ) {
			add_action( $hook, [ __CLASS__, 'flush_memo' ] );
		}
	}

	/** «Понятно» у предупреждения о лимите блокировок: забыть сводку вытеснений. */
	public static function ack_evictions() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_evictions_ack' );
		LogShield_Htaccess::clear_evictions();
		LogShield_Admin::redirect_with_message( __( 'Предупреждение о лимите блокировок скрыто.', 'logshield' ) );
	}

	/** Сбросить вычисленное за запрос (после записи истории или банов; для тестов). */
	public static function flush_memo() {
		self::$memo = [];
	}

	/**
	 * Индекс по истории сканирований. Сканирование без новых адресов (n = 0)
	 * нужно только там, где старое сканирование новее его по времени (часы
	 * переводили): иначе обрыв подсчёта на нём ничего не меняет.
	 */
	public static function build_unseen_index( $scan_log ) {
		$pairs = [];
		$seen  = [];
		foreach ( (array) $scan_log as $run ) {
			$n = 0;
			foreach ( array_keys( (array) ( $run['flagged'] ?? [] ) ) as $ip ) {
				$ip = (string) $ip;
				if ( isset( $seen[ $ip ] ) ) continue;
				$seen[ $ip ] = true;
				$n++;
			}
			$pairs[] = [ (int) ( $run['time'] ?? 0 ), $n ];
		}
		$out       = [];
		$older_max = PHP_INT_MIN; // самое позднее время среди более старых сканирований с n > 0
		for ( $i = count( $pairs ) - 1; $i >= 0; $i-- ) {
			list( $t, $n ) = $pairs[ $i ];
			if ( $n > 0 || $older_max > $t ) $out[] = $t . ':' . $n;
			if ( $n > 0 ) $older_max = max( $older_max, $t );
		}
		return implode( ' ', array_reverse( $out ) );
	}

	public static function refresh_unseen_index( $scan_log ) {
		self::flush_memo();
		update_option( self::UNSEEN_INDEX_OPTION, self::build_unseen_index( $scan_log ), true );
	}

	private static function unseen_index() {
		$index = get_option( self::UNSEEN_INDEX_OPTION, false );
		if ( ! is_string( $index ) ) {
			// Установка до появления индекса: строим один раз по полной истории.
			$index = self::build_unseen_index( self::scan_log() );
			update_option( self::UNSEEN_INDEX_OPTION, $index, true );
		}
		return $index;
	}

	/**
	 * Сколько новых атакующих (IP и подсетей) нашли сканирования с момента,
	 * когда текущий пользователь последний раз открывал дашборд.
	 * Уже забаненные сюда не попадают — их убирает run() до записи в историю.
	 * Считается по короткому индексу, без загрузки истории сканирований.
	 */
	public static function unseen_count( $user_id = 0 ) {
		$user_id = $user_id ?: get_current_user_id();
		$seen    = (int) get_user_meta( $user_id, self::SEEN_META, true );
		if ( ! $seen ) {
			// Первый раз: не пугать всей историей, считать с установки отметки.
			update_user_meta( $user_id, self::SEEN_META, time() );
			return 0;
		}
		$count = 0;
		$index = self::unseen_index();
		if ( $index === '' ) return 0;
		foreach ( explode( ' ', $index ) as $pair ) {
			list( $t, $n ) = array_map( 'intval', explode( ':', $pair ) + [ 1 => 0 ] );
			if ( $t <= $seen ) break; // история — от новых к старым
			$count += $n;
		}
		return $count;
	}

	/** История сканирований — один раз за запрос. */
	private static function scan_log() {
		if ( ! isset( self::$memo['scan_log'] ) ) self::$memo['scan_log'] = (array) LogShield_Detector::get_scan_log();
		return self::$memo['scan_log'];
	}

	/** Список банов — один раз за запрос. */
	public static function banned() {
		if ( ! isset( self::$memo['banned'] ) ) self::$memo['banned'] = (array) LogShield_Htaccess::get_banned();
		return self::$memo['banned'];
	}

	/** Статусы записей ручного списка .htaccess: ключ => [ подпись, класс метки ]. */
	const DENY_STATUSES = [
		'whitelist' => [ 'в белом списке!', 'ls-tag-banned' ],
		'banned'    => [ 'уже в LogShield', 'ls-tag-ok' ],
		'wide'      => [ 'слишком широкая сеть', 'ls-tag-seen' ],
		'scoped'    => [ 'только для части сайта', 'ls-tag-dismissed' ],
		'import'    => [ 'можно перенести', 'ls-tag-import' ],
	];

	/** Подпись статуса записи ручного списка на языке сайта. */
	public static function deny_status_label( $status ) {
		switch ( $status ) {
			case 'whitelist': return __( 'в белом списке!', 'logshield' );
			case 'banned':    return __( 'уже в LogShield', 'logshield' );
			case 'wide':      return __( 'слишком широкая сеть', 'logshield' );
			case 'scoped':    return __( 'только для части сайта', 'logshield' );
			case 'import':    return __( 'можно перенести', 'logshield' );
		}
		return (string) $status;
	}

	/**
	 * Ручной список запретов в .htaccess (вне блока LogShield) со статусом
	 * каждой записи — один раз за запрос (сбрасывается flush_memo()).
	 *
	 * status: whitelist — пересекается с белым списком (сотрудник, сервер, ручной
	 * список: человек блокирует сам себя); banned — уже есть в банах LogShield
	 * (тот же адрес или входит в забаненную сеть); wide — сеть шире, чем
	 * разрешает ручная блокировка; scoped — запрет внутри <Files>/<Location>
	 * и т. п., то есть не на весь сайт; import — можно перенести.
	 *
	 * @return array{exists:bool, path:string, entries:array[], invalid:array[], counts:array}
	 */
	public static function denies() {
		if ( isset( self::$memo['denies'] ) ) return self::$memo['denies'];
		$d      = LogShield_Htaccess::foreign_denies();
		$manual = (array) ( LogShield_Plugin::get_options()['whitelist_ips'] ?? [] );
		$wl     = LogShield_Whitelist::get_full_whitelist( $manual );
		$banned = array_map( 'strval', array_keys( self::banned() ) );
		$counts = array_fill_keys( array_keys( self::DENY_STATUSES ), 0 );
		foreach ( $d['entries'] as &$e ) {
			$e['status'] = 'import';
			$e['note']   = '';
			foreach ( $wl as $w ) {
				if ( ! LogShield_IP::overlaps( $e['entry'], (string) $w ) ) continue;
				$e['status'] = 'whitelist';
				$e['note']   = self::whitelist_note( (string) $w, $manual );
				break;
			}
			if ( $e['status'] === 'import' ) {
				foreach ( $banned as $b ) {
					if ( LogShield_IP::contains( $b, $e['entry'] ) ) {
						$e['status'] = 'banned';
						/* translators: %s: заблокированная сеть. */
						$e['note']   = $b === $e['entry'] ? '' : sprintf( __( 'в сети %s', 'logshield' ), $b );
						break;
					}
				}
			}
			if ( $e['status'] === 'import' && strpos( $e['entry'], '/' ) !== false && ! self::manual_entry( $e['entry'] )['ok'] ) {
				$e['status'] = 'wide';
			}
			if ( $e['status'] === 'import' && $e['scope'] !== '' ) {
				$e['status'] = 'scoped';
				/* translators: %s: секция .htaccess, например <Files wp-login.php>. */
				$e['note']   = sprintf( __( 'внутри %s', 'logshield' ), $e['scope'] );
			}
			$counts[ $e['status'] ]++;
		}
		unset( $e );
		$d['counts'] = $counts;
		return self::$memo['denies'] = $d;
	}

	/** Чем занят адрес белого списка: «сотрудник (admin)», «адрес сервера», «вручную, диапазон …». */
	private static function whitelist_note( $w, array $manual ) {
		if ( strpos( $w, '/' ) === false ) {
			$why = LogShield_Whitelist::whitelist_reason( $w, $manual );
			return $w . ( $why ? ' — ' . $why['text'] : '' );
		}
		return $w . ' — ' . ( in_array( $w, $manual, true ) ? __( 'вручную, диапазон', 'logshield' ) : __( 'доверенный прокси', 'logshield' ) );
	}

	/**
	 * Запись ручного списка .htaccess, которая закрывает адрес или сеть целиком
	 * (запреты для части сайта не считаются), или null.
	 */
	public static function foreign_cover( $entry ) {
		foreach ( self::denies()['entries'] as $e ) {
			if ( $e['scope'] === '' && LogShield_IP::contains( $e['entry'], (string) $entry ) ) return $e;
		}
		return null;
	}

	/** Пояснение к разблокировке: какие из адресов всё равно закрыты строками .htaccess вне LogShield. */
	public static function foreign_note( array $entries ) {
		$hit = [];
		foreach ( $entries as $x ) {
			$e = self::foreign_cover( $x );
			/* translators: 1: адрес или сеть, 2: номер строки .htaccess. */
			if ( $e ) $hit[] = sprintf( __( '%1$s (строка %2$d)', 'logshield' ), $x, $e['line'] );
		}
		if ( ! $hit ) return '';
		return ' ' . sprintf(
			/* translators: %s: адреса с номерами строк через запятую. */
			_n( 'Внимание: %s также заблокирован в .htaccess вручную, вне блока LogShield — пока эти строки там, доступ не откроется.', 'Внимание: %s также заблокированы в .htaccess вручную, вне блока LogShield — пока эти строки там, доступ не откроется.', count( $hit ), 'logshield' ),
			LogShield_Admin::short_list( $hit )
		);
	}

	/** Скрытые адреса без устаревших записей: ip|cidr => когда скрыли. Один раз за запрос. */
	public static function dismissed() {
		if ( isset( self::$memo['dismissed'] ) ) return self::$memo['dismissed'];
		$list = get_option( self::DISMISSED_OPTION, [] );
		return self::$memo['dismissed'] = self::prune_dismissed( is_array( $list ) ? $list : [] );
	}

	/** Убрать старше DISMISS_TTL_DAYS и урезать до DISMISS_MAX (остаются скрытые последними). */
	private static function prune_dismissed( array $list ) {
		$cutoff = time() - self::DISMISS_TTL_DAYS * DAY_IN_SECONDS;
		$out    = [];
		foreach ( $list as $ip => $t ) {
			$t = (int) $t;
			if ( $t >= $cutoff && LogShield_IP::is_valid_entry( (string) $ip ) ) $out[ (string) $ip ] = $t;
		}
		if ( count( $out ) > self::DISMISS_MAX ) {
			arsort( $out );
			$out = array_slice( $out, 0, self::DISMISS_MAX, true );
		}
		return $out;
	}

	/**
	 * Скрыть адреса в таблице атакующих (пока их не поймают снова).
	 *
	 * @param string[] $entries проверенные IP и CIDR
	 * @return int сколько скрыто
	 */
	public static function dismiss( array $entries ) {
		$list = self::dismissed();
		$now  = time();
		$n    = 0;
		foreach ( $entries as $e ) {
			$e = (string) $e;
			if ( ! LogShield_IP::is_valid_entry( $e ) ) continue;
			$list[ $e ] = $now;
			$n++;
		}
		update_option( self::DISMISSED_OPTION, self::prune_dismissed( $list ), false );
		self::flush_memo();
		return $n;
	}

	public static function mark_seen( $user_id = 0 ) {
		update_user_meta( $user_id ?: get_current_user_id(), self::SEEN_META, time() );
	}

	/**
	 * Запомнить счётчик и отметку до сброса: бейдж вкладки «Адреса» показывает,
	 * сколько было новых на момент открытия. Вызывается из admin_menu перед mark_seen().
	 */
	public static function remember_unseen( $user_id = 0 ) {
		$user_id              = $user_id ?: get_current_user_id();
		self::$seen_before    = (int) get_user_meta( $user_id, self::SEEN_META, true );
		self::$unseen_on_open = self::unseen_count( $user_id );
	}

	/** Сколько новых атакующих было на момент открытия дашборда. */
	public static function unseen_on_open() {
		return self::$unseen_on_open;
	}

	/** Имя вкладки из запроса, если оно из белого списка; иначе ''. */
	public static function sanitize_tab( $tab ) {
		$tab = is_string( $tab ) ? $tab : '';
		if ( isset( self::TAB_ALIASES[ $tab ] ) ) $tab = self::TAB_ALIASES[ $tab ];
		return isset( self::TABS[ $tab ] ) ? $tab : '';
	}

	/** Тема пользователя: system | dark | light. */
	public static function get_theme( $user_id = 0 ) {
		$t = get_user_meta( $user_id ?: get_current_user_id(), self::THEME_META, true );
		return is_string( $t ) && isset( self::THEMES[ $t ] ) ? $t : self::DEFAULT_THEME;
	}

	/** Сохранение темы без перезагрузки (admin-ajax, POST: theme, nonce). */
	public static function ajax_theme() {
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden', 403 );
		check_ajax_referer( 'logshield_theme', 'nonce' );
		$theme = isset( $_POST['theme'] ) ? sanitize_key( wp_unslash( $_POST['theme'] ) ) : '';
		if ( ! isset( self::THEMES[ $theme ] ) ) wp_send_json_error( 'bad theme', 400 );
		update_user_meta( get_current_user_id(), self::THEME_META, $theme );
		wp_send_json_success( [ 'theme' => $theme ] );
	}

	/**
	 * Переключатель темы для шапки. Без скрипта не работает, поэтому скрыт:
	 * его показывает dashboard.js.
	 */
	private static function theme_control( $theme ) {
		?>
		<label class="ls-theme" data-theme-control hidden>
			<span class="screen-reader-text"><?php esc_html_e( 'Тема дашборда', 'logshield' ); ?></span>
			<span class="dashicons dashicons-admin-appearance" aria-hidden="true"></span>
			<select class="ls-input ls-input-sm" data-theme-select autocomplete="off">
				<?php foreach ( self::themes() as $k => $label ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $theme, $k ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<?php
	}

	/**
	 * Скрытые поля возврата: ls_back (на дашборд) и ls_tab (на вкладку).
	 * $follow — форма вне панелей (шапка, диалог): скрипт подставляет открытую вкладку.
	 */
	public static function back_fields( $tab, $follow = false ) {
		echo '<input type="hidden" name="ls_back" value="' . esc_attr( LogShield_Admin::SLUG_DASH ) . '">';
		echo '<input type="hidden" name="ls_tab" value="' . esc_attr( $tab ) . '"' . ( $follow ? ' data-ls-tab-follow' : '' ) . '>';
	}

	public static function enqueue() {
		// Версия по самому свежему из двух файлов: правка только CSS тоже сбрасывает кэш браузера.
		$ver = LOGSHIELD_VERSION . '-' . max( (int) @filemtime( LOGSHIELD_DIR . 'assets/dashboard.js' ), (int) @filemtime( LOGSHIELD_DIR . 'assets/dashboard.css' ) );
		wp_enqueue_style( 'logshield-dashboard', LOGSHIELD_URL . 'assets/dashboard.css', [], $ver );
		wp_enqueue_script( 'logshield-dashboard', LOGSHIELD_URL . 'assets/dashboard.js', [], $ver, [ 'in_footer' => true, 'strategy' => 'defer' ] );
		LogShield_IPInfo::enqueue();
		wp_add_inline_script( 'logshield-dashboard', 'window.LogShieldData = ' . wp_json_encode( self::data() ) . ';', 'before' );
		wp_add_inline_script( 'logshield-dashboard', 'window.LogShieldL10n = ' . wp_json_encode( self::js_l10n() ) . ';', 'before' );
	}

	/**
	 * Тексты dashboard.js на языке сайта (window.LogShieldL10n). Подстановки —
	 * %s/%d или %1$s…; множественное число — LogShield_Plugin::js_plural().
	 * Нужен и странице «Доступ по API» (кнопка «Копировать», тема).
	 */
	public static function js_l10n() {
		return [
			// Графики.
			'noData'          => __( 'Нет данных за период', 'logshield' ),
			'chartRole'       => __( 'график', 'logshield' ),
			/* translators: %s: описание графика. */
			'chartLabel'      => __( '%s. Стрелки влево и вправо — значения по периодам.', 'logshield' ),
			/* translators: %s: число сканирований. */
			'tipScans'        => __( 'сканирований: %s', 'logshield' ),
			/* translators: %s: сколько найдено (продолжение подсказки, с запятой в начале). */
			'tipFound'        => __( ', найдено: %s', 'logshield' ),
			/* translators: %s: сколько сканирований с ошибкой (продолжение, с запятой в начале). */
			'tipErrors'       => __( ', с ошибкой: %s', 'logshield' ),
			/* translators: %s: число блокировок. */
			'tipBans'         => __( 'блокировок: %s', 'logshield' ),
			'period'          => __( 'Период', 'logshield' ),
			'events'          => __( 'События', 'logshield' ),
			/* translators: %s: число сканирований (ячейка таблицы, сокращённо). */
			'evScans'         => __( 'скан.: %s', 'logshield' ),
			/* translators: %s: сколько найдено (продолжение, с запятой в начале). */
			'evFound'         => __( ', найдено %s', 'logshield' ),
			/* translators: %s: число ошибок (продолжение, с запятой в начале). */
			'evErrors'        => __( ', ошибок %s', 'logshield' ),
			/* translators: %s: число блокировок (ячейка таблицы, сокращённо). */
			'evBans'          => __( 'блок.: %s', 'logshield' ),
			'period24h'       => __( 'за 24 часа', 'logshield' ),
			'period7d'        => __( 'за 7 дней', 'logshield' ),
			'period30d'       => __( 'за 30 дней', 'logshield' ),
			'seriesReq'       => __( 'запросы', 'logshield' ),
			'seriesErr'       => __( 'ошибки', 'logshield' ),
			'seriesFails'     => __( 'неудачные входы', 'logshield' ),
			/* translators: 1: период («за 24 часа»), 2: число запросов, 3: число ошибок. */
			'traffic'         => __( 'Трафик %1$s: %2$s запросов, %3$s ошибок', 'logshield' ),
			/* translators: 1: период («за 24 часа»), 2: число неудачных входов. */
			'failsChart'      => __( 'Неудачные входы %1$s: %2$s', 'logshield' ),
			// Общее.
			'copied'          => __( 'Скопировано', 'logshield' ),
			'stepDone'        => __( '— выполнено', 'logshield' ),
			'stepCurrent'     => __( '— текущий шаг', 'logshield' ),
			'stepTodo'        => __( '— не выполнено', 'logshield' ),
			/* translators: 1: выполнено шагов, 2: всего шагов. */
			'onboardCount'    => __( 'Готово %1$d из %2$d', 'logshield' ),
			'ipFormat'        => __( 'Нужен IP (203.0.113.5, 2001:db8::1) или сеть CIDR (203.0.113.0/24).', 'logshield' ),
			/* translators: %s: «Как в системе». */
			'themeNowDark'    => __( '%s (сейчас тёмная)', 'logshield' ),
			/* translators: %s: «Как в системе». */
			'themeNowLight'   => __( '%s (сейчас светлая)', 'logshield' ),
			'themeFail'       => __( 'Не удалось сохранить тему.', 'logshield' ),
			'themeFailTitle'  => __( 'Не удалось сохранить тему', 'logshield' ),
			// Таблица атакующих.
			/* translators: %d: число адресов. */
			'addr'            => LogShield_Plugin::js_plural( _n_noop( '%d адрес', '%d адресов', 'logshield' ), '%d адреса' ),
			/* translators: %s: название столбца. */
			'sortAsc'         => __( 'Сортировка: %s, по возрастанию.', 'logshield' ),
			/* translators: %s: название столбца. */
			'sortDesc'        => __( 'Сортировка: %s, по убыванию.', 'logshield' ),
			/* translators: %s: число строк. */
			'total'           => __( 'Всего: %s', 'logshield' ),
			/* translators: 1: показано строк, 2: всего строк. */
			'shown'           => __( 'Показано %1$s из %2$s', 'logshield' ),
			/* translators: %s: число выбранных строк. */
			'selected'        => __( 'Выбрано: %s', 'logshield' ),
			/* translators: 1: сколько выбранных скрыто фильтром, 2: сколько видимых. */
			'selectedHidden'  => __( 'из них скрыто фильтром: %1$s — действия применятся только к видимым (%2$s)', 'logshield' ),
			/* translators: 1: выбрано видимых, 2: выбрано всего. */
			'selectedAll'     => __( 'Выбраны все видимые: %1$s. Всего выбрано: %2$s', 'logshield' ),
			'selCleared'      => __( 'Выделение снято', 'logshield' ),
			'opBan'           => __( 'Заблокировать', 'logshield' ),
			'opUnban'         => __( 'Разблокировать', 'logshield' ),
			'opHide'          => __( 'Скрыть', 'logshield' ),
			'noneBan'         => __( 'Среди выбранных видимых нет незаблокированных адресов', 'logshield' ),
			'noneUnban'       => __( 'Среди выбранных видимых нет заблокированных адресов (адрес внутри заблокированной подсети разблокируется вместе с ней)', 'logshield' ),
			'noneHide'        => __( 'Среди выбранных видимых нет адресов, которые можно скрыть', 'logshield' ),
			/* translators: 1: предел, 2: сколько выбрано. */
			'tooMany'         => __( 'За раз можно не больше %1$s адресов, выбрано %2$s', 'logshield' ),
			/* translators: %d: всегда 1. */
			'restOne'         => __( 'Ещё %d адрес выбран, но скрыто фильтром — его это не затронет.', 'logshield' ),
			'rest'            => LogShield_Plugin::js_plural(
				/* translators: %d: сколько выбранных адресов скрыто фильтром. */
				_n_noop( 'Ещё %d адрес выбран, но скрыто фильтром — их это не затронет.', 'Ещё %d адресов выбрано, но скрыто фильтром — их это не затронет.', 'logshield' ),
				'Ещё %d адреса выбрано, но скрыто фильтром — их это не затронет.'
			),
			/* translators: %s: «3 адреса». */
			'confirmBan'      => __( 'Заблокировать %s? Запись в .htaccess применяется сразу, в тестовом режиме тоже.', 'logshield' ),
			/* translators: 1: адрес или «N адресов», 2: срок, например «30 дней». */
			'confirmBanFor'   => __( 'Заблокировать %1$s на %2$s? Запись в .htaccess применяется сразу, в тестовом режиме тоже.', 'logshield' ),
			/* translators: %s: «1 адрес». */
			'confirmUnbanOne' => __( 'Разблокировать %s? Адрес снова сможет открывать сайт.', 'logshield' ),
			/* translators: %s: «3 адреса». */
			'confirmUnban'    => __( 'Разблокировать %s? Они снова смогут открывать сайт.', 'logshield' ),
			// Панель адреса.
			'reqLoading'      => __( 'Загрузка запросов из лога…', 'logshield' ),
			'reqFail'         => __( 'Не удалось получить запросы.', 'logshield' ),
			'reqWhole'        => __( 'во всём логе', 'logshield' ),
			/* translators: %s: объём в мегабайтах. */
			'reqLastMb'       => __( 'в последних %s МБ лога', 'logshield' ),
			/* translators: %d: число запросов. */
			'reqs'            => LogShield_Plugin::js_plural( _n_noop( '%d запрос', '%d запросов', 'logshield' ), '%d запроса' ),
			/* translators: 1: «12 запросов», 2: «во всём логе» или «в последних 2 МБ лога». */
			'reqFound'        => __( '%1$s %2$s, новые сверху.', 'logshield' ),
			/* translators: 1: «50 запросов», 2: «во всём логе» или «в последних 2 МБ лога». */
			'reqFoundLast'    => __( 'Последние %1$s %2$s, новые сверху.', 'logshield' ),
			'reqNoneWhole'    => __( 'Во всём логе запросов этого адреса нет.', 'logshield' ),
			/* translators: %s: объём в мегабайтах. */
			'reqNoneMb'       => __( 'В последних %s МБ лога запросов этого адреса нет.', 'logshield' ),
			'stNotBanned'     => __( 'Не заблокирован.', 'logshield' ),
			'stInSubnet'      => __( 'Входит в заблокированную подсеть — снимается вместе с ней.', 'logshield' ),
			/* translators: %s: дата окончания блокировки. */
			'stUntil'         => __( 'Заблокирован до %s.', 'logshield' ),
			'stForever'       => __( 'Заблокирован бессрочно.', 'logshield' ),
			'stHidden'        => __( 'Скрыт в таблице, пока его не поймают снова.', 'logshield' ),
			/* translators: %s: номер строки .htaccess. */
			'stForeign'       => __( 'Также заблокирован в .htaccess вручную (строка %s, вне блока LogShield): пока эта строка там, разблокировка в LogShield доступ не откроет — удалите её из .htaccess.', 'logshield' ),
			/* translators: %s: IP-адрес. */
			'confirmWl'       => __( "Добавить %s в белый список?\n\nЭтот адрес больше никогда не будет заблокирован LogShield, а действующая блокировка будет снята.", 'logshield' ),
			/* translators: %s: сеть CIDR. */
			'confirmWlRange'  => __( "Добавить %s в белый список?\n\nНи один адрес этого диапазона больше никогда не будет заблокирован LogShield, а действующая блокировка будет снята.", 'logshield' ),
			// Панель адреса: карточка «Настойчивые адреса».
			/* translators: %s: почему адрес в белом списке, например «сотрудник (admin)». */
			'stWhite'         => __( 'В белом списке (%s): LogShield его не блокирует.', 'logshield' ),
			/* translators: %s: сеть CIDR. */
			'stInNet'         => __( 'Заблокирован в составе сети %s.', 'logshield' ),
			'stFlagged'       => __( 'Помечен правилом — см. историю сканирований на вкладке «Состояние».', 'logshield' ),
			/* translators: %s: имя бота, например Bingbot. */
			'botSays'         => __( 'Называет себя %s.', 'logshield' ),
			'botFake'         => __( 'Сеть не принадлежит владельцу этого бота — возможно, поддельный. Обратный DNS не проверялся; на блокировку это не влияет.', 'logshield' ),
			/* translators: %d: число разных User-Agent. */
			'uas'             => LogShield_Plugin::js_plural( _n_noop( 'За сканирование был %d разный User-Agent.', 'За сканирование было %d разных User-Agent.', 'logshield' ), 'За сканирование было %d разных User-Agent.' ),
			/* translators: %d: сколько разных User-Agent детектор запоминает на адрес. */
			'uasMore'         => __( 'За сканирование было больше %d разных User-Agent.', 'logshield' ),
			'histNoisy'       => __( 'Правила этот адрес не помечали: он только настойчиво получал ошибки.', 'logshield' ),
			/* translators: %s: сеть CIDR, например 192.0.2.0/24. */
			'banNet'          => __( 'Заблокировать сеть %s', 'logshield' ),
			/* translators: 1: сеть CIDR, 2: срок, например «30 дней». */
			'confirmBanNet'   => __( "Заблокировать всю сеть %1\$s на %2\$s?\n\nДоступ потеряют все адреса этой сети, не только этот. Запись в .htaccess применяется сразу, в тестовом режиме тоже.", 'logshield' ),
			// Хвост лога.
			/* translators: %s: число скрытых строк. */
			'tailHidden'      => __( 'обычных скрыто: %s', 'logshield' ),
			'tailEmpty'       => __( 'Записей пока нет.', 'logshield' ),
			'tailOnlyRoutine' => __( 'Только обычные запросы — нажмите «Все», чтобы увидеть их.', 'logshield' ),
			'tailNoMatch'     => __( 'Под этот фильтр записей нет.', 'logshield' ),
			'tailFail'        => __( 'Не удалось прочитать лог.', 'logshield' ),
			'tailNetwork'     => __( 'Ошибка сети при чтении лога.', 'logshield' ),
			'logMissing'      => __( 'Лог недоступен — укажите путь в настройках.', 'logshield' ),
		];
	}

	/** Данные для скрипта: статистика за 30 дней и настройки живого хвоста. */
	private static function data() {
		$stats = [];
		foreach ( LogShield_Stats::get() as $hour => $h ) {
			$stats[] = [ (int) $hour, $h['req'], $h['e4'], $h['e5'], $h['fails'], $h['ips'], (object) $h['flag'] ];
		}
		$suspects = [];
		foreach ( self::attackers() as $a ) $suspects[] = $a['ip'];
		// События для отметок на графиках: сканирования [время, успешно, найдено] и время банов.
		$scans = [];
		foreach ( self::scan_log() as $run ) {
			$scans[] = [ (int) ( $run['time'] ?? 0 ), empty( $run['ok'] ) ? 0 : 1, count( (array) ( $run['flagged'] ?? [] ) ) ];
		}
		$bans = [];
		foreach ( self::banned() as $info ) {
			if ( ! empty( $info['banned_at'] ) ) $bans[] = (int) $info['banned_at'];
		}
		return [
			'events'   => [ 'scans' => $scans, 'bans' => $bans ],
			'now'      => time(),
			'stats'    => $stats,
			'types'    => LogShield_Stats::labels(),
			'banned'   => count( self::banned() ),
			'suspects' => $suspects,
			'tail'     => [
				'url'   => LogShield_Admin::ajax_url( 'logshield_tail' ),
				'nonce' => wp_create_nonce( 'logshield_tail' ),
			],
			'theme'    => [
				'url'   => LogShield_Admin::ajax_url( 'logshield_theme' ),
				'nonce' => wp_create_nonce( 'logshield_theme' ),
			],
			'tabs'     => array_keys( self::TABS ),
			'tabAlias' => (object) self::TAB_ALIASES,
			// Панель адреса: история срабатываний и последние запросы (admin-ajax).
			'history'  => (object) self::history(),
			'ipreq'    => [
				'url'   => LogShield_Admin::ajax_url( 'logshield_ip_requests' ),
				'nonce' => wp_create_nonce( 'logshield_ip_requests' ),
				'mb'    => round( self::ip_requests_bytes() / 1048576, 1 ),
			],
			// Прошлый просмотр дашборда (unix, 0 — первый): атакующие новее него — «новые».
			'seenBefore' => self::$seen_before,
		];
	}

	/**
	 * Атакующие: заблокированные и помеченные в последних сканированиях.
	 *
	 * @return array[] [ ip, reason, types, last, runs, banned, expires ]
	 */
	public static function attackers() {
		if ( isset( self::$memo['attackers'] ) ) return self::$memo['attackers'];
		$banned = self::banned();
		$out    = [];
		foreach ( self::scan_log() as $run ) {
			foreach ( (array) ( $run['flagged'] ?? [] ) as $ip => $reasons ) {
				$ip = (string) $ip;
				if ( isset( $out[ $ip ] ) ) { $out[ $ip ]['runs']++; continue; }
				$out[ $ip ] = [
					'ip'      => $ip,
					'reason'  => implode( '; ', (array) $reasons ),
					'types'   => (array) ( $run['types'][ $ip ] ?? [] ),
					'last'    => (int) $run['time'],
					'runs'    => 1,
					'banned'  => false,
					'expires' => 0,
				];
			}
		}
		foreach ( $banned as $ip => $info ) {
			$ip = (string) $ip;
			if ( ! isset( $out[ $ip ] ) ) {
				$out[ $ip ] = [ 'ip' => $ip, 'reason' => (string) $info['reason'], 'types' => [], 'last' => (int) $info['banned_at'], 'runs' => 0 ];
			}
			$out[ $ip ]['banned']  = true;
			$out[ $ip ]['expires'] = (int) $info['expires_at'];
		}
		// Помеченный IP мог попасть в забаненную потом подсеть.
		$ranges = array_filter( array_keys( $banned ), function ( $b ) { return strpos( (string) $b, '/' ) !== false; } );
		foreach ( $out as $ip => &$a ) {
			if ( ! $a['banned'] && strpos( $ip, '/' ) === false && $ranges && LogShield_IP::matches_any( $ip, $ranges ) ) {
				$a['banned'] = true;
			}
		}
		unset( $a );
		uasort( $out, function ( $x, $y ) { return $y['last'] <=> $x['last']; } );
		// Скрытые — если их не поймали после того, как скрыли. Они не занимают
		// место видимых: 200 видимых и до 100 скрытых (показываются переключателем).
		// Собственные баны показываются все, без лимита: вкладка «Адреса» — это и список блокировок.
		$dismissed = self::dismissed();
		$shown     = [];
		$hidden    = [];
		$n_shown   = 0;
		$n_hidden  = 0;
		foreach ( $out as $ip => $a ) {
			$a['direct'] = isset( $banned[ $ip ] ); // свой бан (а не попал в забаненную подсеть)
			$a['hidden'] = isset( $dismissed[ $ip ] ) && $a['last'] <= $dismissed[ $ip ];
			if ( $a['hidden'] ) {
				if ( ! $a['direct'] && $n_hidden >= 100 ) continue;
				if ( ! $a['direct'] ) $n_hidden++;
			} else {
				if ( ! $a['direct'] && $n_shown >= 200 ) continue;
				if ( ! $a['direct'] ) $n_shown++;
			}
			// Закрыт ещё и строкой .htaccess вне LogShield: «Разблокировать» его не откроет.
			$cover        = self::foreign_cover( $ip );
			$a['foreign'] = $cover ? (int) $cover['line'] : 0;
			if ( $a['hidden'] ) $hidden[] = $a; else $shown[] = $a;
		}
		return self::$memo['attackers'] = array_merge( $shown, $hidden );
	}

	/** Сколько настойчивых адресов (LogShield_IPInfo) добавлять во вкладку «Адреса». */
	const PERSIST_MAX = 200;

	/** Бан истекает меньше чем через столько дней — пометка «скоро истекает». */
	const SOON_DAYS = 3;

	/**
	 * Строки вкладки «Адреса»: атакующие (все баны, помеченные правилами) и
	 * настойчивые адреса (≥ LogShield_IPInfo::MIN_HITS ошибок за сканирование).
	 * Страна, сеть и UA — только для информации, на статус не влияют.
	 *
	 * Поля attackers() плюс:
	 *   status  banned | white | seen; persist — [ e, bot ] или null;
	 *   white   почему в белом списке ('' — нет); net — сеть /24 (/64) для «Заблокировать сеть»;
	 *   cover   заблокированная сеть, в которую входит адрес; flagged — есть в истории сканирований;
	 *   new, manual (ручной бан), forever (свой бан без срока), soon (истекает < SOON_DAYS).
	 *
	 * @return array[]
	 */
	public static function addresses() {
		if ( isset( self::$memo['addresses'] ) ) return self::$memo['addresses'];
		$banned = self::banned();
		$rows   = [];
		foreach ( self::attackers() as $a ) {
			$a += [ 'persist' => null, 'white' => '', 'net' => '', 'cover' => '', 'flagged' => $a['runs'] > 0 ];
			$rows[ $a['ip'] ] = $a;
		}
		$all = LogShield_IPInfo::get_all();
		if ( $all ) {
			$min     = (int) LogShield_IPInfo::MIN_HITS;
			$persist = array_filter( $all, function ( $e ) use ( $min ) { return (int) ( $e['hits'] ?? 0 ) >= $min; } );
			$dismissed = self::dismissed();
			foreach ( $persist ? LogShield_IPInfo::card_rows( $persist, self::PERSIST_MAX ) : [] as $r ) {
				$ip = (string) $r['ip'];
				$p  = [ 'e' => $r['e'], 'bot' => $r['bot'] ];
				if ( isset( $rows[ $ip ] ) ) {
					$rows[ $ip ]['persist'] = $p;
					$rows[ $ip ]['white']   = $rows[ $ip ]['banned'] ? '' : $r['white'];
					$rows[ $ip ]['net']     = $rows[ $ip ]['banned'] ? '' : $r['net'];
					if ( $r['cover'] !== '' ) $rows[ $ip ]['cover'] = $r['cover'];
					continue;
				}
				$last   = (int) ( $r['e']['last'] ?? 0 );
				$cover  = self::foreign_cover( $ip );
				$rows[ $ip ] = [
					'ip'      => $ip,
					/* translators: %d: число ошибок. */
					'reason'  => sprintf( __( 'настойчивые ошибки (%d)', 'logshield' ), (int) ( $r['e']['hits'] ?? 0 ) ),
					'types'   => [],
					'last'    => $last,
					'runs'    => 0,
					'banned'  => $r['status'] === 'banned',
					'expires' => (int) $r['expires'],
					'direct'  => (bool) $r['direct'],
					'hidden'  => isset( $dismissed[ $ip ] ) && $last <= $dismissed[ $ip ],
					'foreign' => $cover ? (int) $cover['line'] : 0,
					'persist' => $p,
					'white'   => $r['white'],
					'net'     => $r['net'],
					'cover'   => $r['cover'],
					'flagged' => (bool) $r['flagged'],
				];
			}
		}
		$now  = time();
		$soon = self::SOON_DAYS * DAY_IN_SECONDS;
		foreach ( $rows as $ip => &$a ) {
			$a['status']  = $a['banned'] ? 'banned' : ( $a['white'] !== '' ? 'white' : 'seen' );
			$a['new']     = self::$seen_before > 0 && $a['last'] > self::$seen_before;
			$a['manual']  = $a['direct'] && LogShield_Htaccess::is_manual( $banned[ $ip ] ?? null );
			$a['forever'] = $a['direct'] && ! $a['expires'];
			$a['soon']    = $a['direct'] && $a['expires'] && $a['expires'] - $now < $soon;
		}
		unset( $a );
		// Новые сверху, скрытые — в конце.
		uasort( $rows, function ( $x, $y ) { return ( $x['hidden'] <=> $y['hidden'] ) ?: ( $y['last'] <=> $x['last'] ); } );
		return self::$memo['addresses'] = array_values( $rows );
	}

	/**
	 * Счётчики переключателя «Адресов» (без скрытых): all, new, banned, seen (не заблокированы), persist.
	 */
	public static function address_counts( array $rows ) {
		$c = [ 'all' => 0, 'new' => 0, 'banned' => 0, 'seen' => 0, 'persist' => 0 ];
		foreach ( $rows as $a ) {
			if ( $a['hidden'] ) continue;
			$c['all']++;
			if ( $a['new'] ) $c['new']++;
			if ( $a['status'] === 'banned' ) $c['banned']++; else $c['seen']++;
			if ( $a['persist'] ) $c['persist']++;
		}
		return $c;
	}

	/**
	 * Срабатывания правил по адресам из таблицы: ip => [ [ время, причина, время для показа ], … ],
	 * от новых к старым, не больше HISTORY_PER_IP на адрес.
	 */
	public static function history() {
		$want = [];
		foreach ( self::attackers() as $a ) $want[ $a['ip'] ] = true;
		$out = [];
		foreach ( self::scan_log() as $run ) {
			foreach ( (array) ( $run['flagged'] ?? [] ) as $ip => $reasons ) {
				$ip = (string) $ip;
				if ( ! isset( $want[ $ip ] ) || count( $out[ $ip ] ?? [] ) >= self::HISTORY_PER_IP ) continue;
				$t = (int) ( $run['time'] ?? 0 );
				// Время уже в часовом поясе сайта, как в таблице: у браузера пояс может быть другим.
				$out[ $ip ][] = [ $t, implode( '; ', (array) $reasons ), wp_date( 'd.m H:i', $t ) ];
			}
		}
		return $out;
	}

	/** Группы фильтра «Тип» в таблице атакующих: ключ => [ подпись, типы LogShield_Stats::TYPES ]. */
	const TYPE_GROUPS = [
		'brute'  => [ 'Подбор пароля', [ 'brute' ] ],
		'subnet' => [ 'Подсети', [ 'subnet' ] ],
		'scan'   => [ 'Сканеры', [ 'scan', 'sensitive' ] ],
		'enum'   => [ 'Перебор пользователей', [ 'enum' ] ],
		'other'  => [ 'Другое', [ 'rate', 'errors' ] ],
	];

	/** Подпись группы фильтра «Тип» на языке сайта. */
	public static function type_group_label( $group ) {
		switch ( $group ) {
			case 'brute':  return __( 'Подбор пароля', 'logshield' );
			case 'subnet': return __( 'Подсети', 'logshield' );
			case 'scan':   return __( 'Сканеры', 'logshield' );
			case 'enum':   return __( 'Перебор пользователей', 'logshield' );
			case 'other':  return __( 'Другое', 'logshield' );
		}
		return (string) $group;
	}

	/** В какие группы фильтра попадает строка; без типов (ручной бан) — «Другое». */
	public static function row_groups( array $types ) {
		$out = [];
		foreach ( self::TYPE_GROUPS as $g => $def ) {
			if ( array_intersect( $types, $def[1] ) ) $out[] = $g;
		}
		$known = array_merge( ...array_column( array_values( self::TYPE_GROUPS ), 1 ) );
		if ( ! $out || array_diff( $types, $known ) ) $out[] = 'other';
		return array_values( array_unique( $out ) );
	}

	/** Сколько байт с конца лога смотреть для «Последних запросов» (фильтр logshield_ip_requests_bytes). */
	private static function ip_requests_bytes() {
		return max( 65536, (int) apply_filters( 'logshield_ip_requests_bytes', self::IP_REQUESTS_BYTES ) );
	}

	/**
	 * Проверки для карточки «Состояние»: расписание, последнее сканирование,
	 * файл лога и сколько лога ещё не прочитано.
	 *
	 * @return array[] [ level => ok|warn|err, title, text ]
	 */
	public static function health( array $opts, array $scan_log, $next_run, array $state ) {
		$now       = time();
		$schedules = wp_get_schedules();
		$interval  = (int) ( $schedules[ $opts['interval'] ]['interval'] ?? 3 * HOUR_IN_SECONDS );
		$no_cron   = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
		$out       = [];

		// Неудачная запись в .htaccess: держится, пока следующая запись не удастся.
		$write_err = LogShield_Detector::get_write_error();
		if ( $write_err ) {
			$out[] = [ 'err', '.htaccess', sprintf(
				/* translators: 1: дата и время первого сбоя, 2: причина. */
				__( 'Блокировка не записана (%1$s): %2$s. Найденные адреса НЕ заблокированы. Проверьте права на запись в .htaccess — предупреждение исчезнет после успешной записи.', 'logshield' ),
				wp_date( 'd.m H:i', (int) $write_err['time'] ),
				$write_err['error']
			) ];
		}

		// Список банов упёрся в лимит: часть блокировок снята. Держится до «Понятно».
		$ev = LogShield_Htaccess::evictions();
		if ( ! empty( $ev['total'] ) ) {
			$manual = (int) ( $ev['manual'] ?? 0 );
			$out[]  = [ 'warn', __( 'Лимит блокировок', 'logshield' ), sprintf(
				/* translators: 1: лимит записей, 2: сколько снято, 3: «, из них ручных: N» или пусто, 4: когда последний раз, 5: сколько снято в последний раз. */
				__( 'Из-за лимита в %1$d записей снято блокировок: %2$d%3$s, последний раз %4$s (%5$d). Первыми снимаются самые старые автоматические — те, что раньше всех истекают; ручные — только если их одних больше лимита.', 'logshield' ),
				LogShield_Htaccess::max_bans(),
				(int) $ev['total'],
				/* translators: %d: число ручных блокировок среди снятых. */
				$manual ? sprintf( __( ', из них ручных: %d', 'logshield' ), $manual ) : '',
				wp_date( 'd.m H:i', (int) ( $ev['last_at'] ?? 0 ) ),
				(int) ( $ev['last_count'] ?? 0 )
			), 'logshield_evictions_ack' ];
		}

		// Telegram: уведомления не доходят (очередь повторов или окончательная неудача).
		if ( LogShield_Notifier::telegram_configured( $opts ) ) {
			$tg_queue = (array) get_option( LogShield_Notifier::RETRY_OPTION, [] );
			$tg_fail  = get_option( LogShield_Notifier::FAIL_OPTION );
			if ( $tg_queue ) {
				$last_q = end( $tg_queue );
				$out[]  = [ 'warn', 'Telegram', sprintf(
					/* translators: 1: число недоставленных сообщений, 2: последняя ошибка. */
					__( 'Не доставлено сообщений: %1$d — %2$s. Плагин повторит отправку сам; подробности — в настройках, раздел «Уведомления».', 'logshield' ),
					count( $tg_queue ),
					is_array( $last_q ) ? (string) ( $last_q['error'] ?? '' ) : ''
				) ];
			} elseif ( is_array( $tg_fail ) && ! empty( $tg_fail['error'] ) ) {
				$out[] = [ 'warn', 'Telegram', sprintf(
					/* translators: 1: дата и время, 2: ошибка. */
					__( 'Уведомление %1$s так и не дошло до Telegram: %2$s. Проверьте токен и chat_id в настройках.', 'logshield' ),
					wp_date( 'd.m H:i', (int) ( $tg_fail['time'] ?? 0 ) ),
					(string) $tg_fail['error']
				) ];
			}
		}

		// Ручной список в .htaccess закрывает адрес из белого списка: сотрудник или
		// сервер получает 403 от самого .htaccess, и LogShield тут ничего не снимет.
		$dn = self::denies();
		if ( $dn['counts']['whitelist'] ) {
			$hit = [];
			foreach ( $dn['entries'] as $e ) {
				/* translators: 1: адрес или сеть, 2: номер строки .htaccess. */
				if ( $e['status'] === 'whitelist' ) $hit[] = sprintf( __( '%1$s (строка %2$d)', 'logshield' ), $e['entry'], $e['line'] );
			}
			$out[] = [ 'warn', __( 'Ручной список в .htaccess', 'logshield' ), sprintf(
				/* translators: %s: адреса с номерами строк через запятую. */
				__( 'Строки вне блока LogShield блокируют адреса из белого списка: %s. Эти адреса получают 403. Удалите строки из .htaccess вручную — подробности в карточке «Ручной список в .htaccess» ниже.', 'logshield' ),
				LogShield_Admin::short_list( $hit )
			) ];
		}

		// Расписание.
		if ( ! $next_run ) {
			$out[] = [ 'err', __( 'Расписание', 'logshield' ), __( 'Сканирование не запланировано. Выключите и снова включите плагин.', 'logshield' ) ];
		} elseif ( $next_run < $now - 15 * MINUTE_IN_SECONDS ) {
			/* translators: %s: на сколько просрочено, например «2 часа». */
			$out[] = [ 'warn', __( 'Расписание', 'logshield' ), sprintf( __( 'Сканирование просрочено на %s.', 'logshield' ), human_time_diff( $next_run, $now ) ) . ' '
				. ( $no_cron ? __( 'WP-Cron отключён (DISABLE_WP_CRON): нужен системный cron на wp-cron.php.', 'logshield' ) : __( 'WP-Cron запускается только при посещениях сайта; на тихом сайте лучше системный cron.', 'logshield' ) ) ];
		} else {
			/* translators: %s: интервал, например «2 часа». */
			$when  = $next_run <= $now ? __( 'вот-вот', 'logshield' ) : sprintf( __( 'через %s', 'logshield' ), human_time_diff( $now, $next_run ) );
			/* translators: 1: «через 2 часа» или «вот-вот», 2: дата и время. */
			$out[] = [ 'ok', __( 'Расписание', 'logshield' ), sprintf( __( 'Следующее сканирование %1$s (%2$s).', 'logshield' ), $when, wp_date( 'd.m H:i', $next_run ) )
				. ( $no_cron ? ' ' . __( 'WP-Cron отключён: проверьте, что системный cron вызывает wp-cron.php.', 'logshield' ) : '' ) ];
		}

		// Последнее сканирование.
		$last = $scan_log[0] ?? null;
		if ( ! $last ) {
			$out[] = [ 'warn', __( 'Сканирование', 'logshield' ), __( 'Ещё не запускалось.', 'logshield' ) ];
		} elseif ( empty( $last['ok'] ) ) {
			/* translators: 1: сколько времени назад, 2: текст ошибки. */
			$out[] = [ 'err', __( 'Сканирование', 'logshield' ), sprintf( __( '%1$s назад с ошибкой: %2$s', 'logshield' ), human_time_diff( $last['time'], $now ), $last['message'] ) ];
		} elseif ( $now - $last['time'] > 2 * $interval + HOUR_IN_SECONDS ) {
			/* translators: %s: сколько времени назад. */
			$out[] = [ 'warn', __( 'Сканирование', 'logshield' ), sprintf( __( 'Последнее было %s назад — дольше двух интервалов.', 'logshield' ), human_time_diff( $last['time'], $now ) ) ];
		} else {
			$n     = count( (array) ( $last['flagged'] ?? [] ) );
			$ago   = human_time_diff( $last['time'], $now );
			$out[] = [ 'ok', __( 'Сканирование', 'logshield' ), $n
				/* translators: 1: сколько времени назад, 2: число нарушителей. */
				? sprintf( __( '%1$s назад, найдено: %2$d.', 'logshield' ), $ago, $n )
				/* translators: %s: сколько времени назад. */
				: sprintf( __( '%s назад, нарушителей нет.', 'logshield' ), $ago ) ];
		}

		// Нераспознанные строки правила не видят: так можно спрятаться от проверки.
		if ( $last ) {
			$read     = (int) ( $last['read_lines'] ?? 0 );
			$unparsed = (int) ( $last['unparsed'] ?? 0 );
			if ( $unparsed >= 20 && $read > 0 && $unparsed > $read * 0.05 ) {
				$out[] = [ 'warn', __( 'Формат лога', 'logshield' ), sprintf(
					/* translators: 1: нераспознанных строк, 2: всего строк, 3: процент. */
					__( 'В последнем сканировании не распознано %1$d из %2$d строк (%3$s%%). Эти строки правила не проверяют. Нужен формат Apache Combined или Common.', 'logshield' ),
					$unparsed,
					$read,
					number_format_i18n( $unparsed / $read * 100, 1 )
				) ];
			}
		}

		// Файл лога.
		$out[] = [ $state['ok'] ? 'ok' : 'err', __( 'Лог', 'logshield' ), ( $opts['log_path'] ?: __( 'путь не указан', 'logshield' ) ) . ' — ' . $state['text'] ];

		// Сколько осталось прочитать: за запуск читается не больше max_read_mb.
		if ( $state['ok'] ) {
			$pos  = (array) get_option( LogShield_Detector::OFFSET_OPTION, [] );
			$size = (int) @filesize( $opts['log_path'] );
			if ( ( $pos['path'] ?? '' ) !== $opts['log_path'] ) {
				$out[] = [ 'ok', __( 'Чтение', 'logshield' ), __( 'Первое сканирование запомнит конец лога, анализ начнётся со следующего.', 'logshield' ) ];
			} else {
				$left  = max( 0, $size - (int) ( $pos['offset'] ?? 0 ) );
				$chunk = max( 1, (int) $opts['max_read_mb'] ) * MB_IN_BYTES;
				$runs  = (int) ceil( $left / $chunk );
				if ( $runs <= 1 ) {
					/* translators: %s: объём новых записей. */
					$out[] = [ 'ok', __( 'Чтение', 'logshield' ), $left ? sprintf( __( 'Новых записей %s — прочитает в следующий раз.', 'logshield' ), size_format( $left ) ) : __( 'Лог прочитан до конца.', 'logshield' ) ];
				} else {
					$out[] = [ 'warn', __( 'Чтение', 'logshield' ), sprintf(
						/* translators: 1: непрочитанный объём, 2: лимит в МБ, 3: число сканирований, 4: примерное время. */
						__( 'Не прочитано %1$s: при лимите %2$d МБ догонит примерно за %3$d сканирований (≈ %4$s).', 'logshield' ),
						size_format( $left ),
						(int) $opts['max_read_mb'],
						$runs,
						human_time_diff( 0, $runs * $interval )
					) ];
				}
			}
		}
		return $out;
	}

	/**
	 * Кого заблокировал бы тестовый режим за последние $days дней:
	 * помеченные сканированиями адреса и подсети, ещё не заблокированные.
	 *
	 * @return array{ips:int, nets:int}
	 */
	public static function would_ban( $days = 7 ) {
		$since = time() - $days * DAY_IN_SECONDS;
		$seen  = [];
		foreach ( self::scan_log() as $run ) {
			if ( (int) ( $run['time'] ?? 0 ) < $since ) break; // история — от новых к старым
			foreach ( array_keys( (array) ( $run['flagged'] ?? [] ) ) as $ip ) $seen[ (string) $ip ] = true;
		}
		$banned = [];
		foreach ( self::attackers() as $a ) {
			if ( $a['banned'] ) $banned[ $a['ip'] ] = true;
		}
		$ips  = 0;
		$nets = 0;
		foreach ( array_keys( $seen ) as $ip ) {
			if ( isset( $banned[ $ip ] ) ) continue;
			if ( strpos( $ip, '/' ) === false ) $ips++; else $nets++;
		}
		return [ 'ips' => $ips, 'nets' => $nets ];
	}

	/**
	 * Чек-лист «Первый запуск» на вкладке «Обзор».
	 *
	 * Шаг «Проверьте список» отмечает браузер (dashboard.js, localStorage), когда
	 * пользователь открыл вкладку «Адреса» после первого сканирования: отдельной
	 * user meta для этого нет. После включения защиты шаг считается пройденным —
	 * решение уже принято.
	 *
	 * @param array $state    LogShield_LogFinder::describe() текущего пути
	 * @param bool  $reviewed список уже проверен (для тестов; на странице — false, отмечает скрипт)
	 * @return array{steps: array[], done: int, current: string, show: bool}
	 *         steps: [ key, title, done, text ]; current — первый невыполненный шаг ('' — всё готово);
	 *         show — показывать карточку (есть невыполненные шаги; пока включён тестовый режим, это всегда так).
	 */
	public static function onboarding( array $opts, array $state, array $scan_log, $reviewed = false ) {
		$dry  = ! empty( $opts['dry_run'] );
		$path = (string) ( $opts['log_path'] ?? '' );
		$ok_run = null;
		foreach ( $scan_log as $run ) {
			if ( ! empty( $run['ok'] ) ) { $ok_run = $run; break; } // история — от новых к старым
		}
		$last = $scan_log[0] ?? null;

		$steps   = [];
		$steps[] = [ 'log', __( 'Лог найден', 'logshield' ), ! empty( $state['ok'] ),
			! empty( $state['ok'] ) ? $path : ( $path === '' ? __( 'Путь к access_log не указан и не найден автоматически.', 'logshield' ) : $path . ' — ' . ( $state['text'] ?? '' ) ) ];
		if ( $ok_run ) {
			/* translators: %s: дата и время последнего успешного сканирования. */
			$scan_text = sprintf( __( 'Последнее успешное — %s.', 'logshield' ), wp_date( 'd.m H:i', (int) $ok_run['time'] ) );
		} elseif ( $last ) {
			/* translators: %s: текст ошибки. */
			$scan_text = sprintf( __( 'Последнее закончилось ошибкой: %s', 'logshield' ), $last['message'] ?? '' );
		} else {
			$scan_text = __( 'Первое сканирование запомнит конец лога; со следующего начнётся анализ. Можно не ждать расписания.', 'logshield' );
		}
		$steps[] = [ 'scan', __( 'Первое сканирование прошло', 'logshield' ), (bool) $ok_run, $scan_text ];
		$steps[] = [ 'review', __( 'Проверьте список атакующих (нет ли своих)', 'logshield' ), $reviewed || ! $dry,
			__( 'Свой адрес, офис или сервис мониторинга в списке — добавьте в белый список, иначе после включения защиты он будет заблокирован.', 'logshield' ) ];
		$steps[] = [ 'protect', __( 'Включите защиту', 'logshield' ), ! $dry,
			$dry ? __( 'Сейчас тестовый режим: нарушители только записываются. После включения новые будут блокироваться в .htaccess.', 'logshield' ) : __( 'Нарушители блокируются в .htaccess.', 'logshield' ) ];

		$current = '';
		$done    = 0;
		foreach ( $steps as $s ) {
			if ( $s[2] ) $done++;
			elseif ( $current === '' ) $current = $s[0];
		}
		return [ 'steps' => $steps, 'done' => $done, 'current' => $current, 'show' => $current !== '' ];
	}

	/** Карточка «Первый запуск»: <ol> шагов, у невыполненных — действие. */
	private static function render_onboarding( array $ob ) {
		if ( ! $ob['show'] ) return;
		$total = count( $ob['steps'] );
		// Ключ отметки «список проверен» в localStorage: свой у сайта и пользователя.
		$key = 'logshield-reviewed:' . get_current_user_id() . '@' . home_url( '/' );
		?>
		<section class="ls-card ls-onboard" aria-labelledby="ls-onboard-title" data-onboard data-review-key="<?php echo esc_attr( $key ); ?>">
			<div class="ls-card-head">
				<h2 id="ls-onboard-title"><?php esc_html_e( 'Первый запуск', 'logshield' ); ?></h2>
				<p class="ls-legend" data-onboard-count><?php
					/* translators: 1: выполнено шагов, 2: всего шагов. */
					echo esc_html( sprintf( __( 'Готово %1$d из %2$d', 'logshield' ), (int) $ob['done'], (int) $total ) );
				?></p>
			</div>
			<ol class="ls-steps">
				<?php foreach ( $ob['steps'] as $i => $s ) :
					list( $key_s, $title, $done, $text ) = $s;
					$cur = $key_s === $ob['current']; ?>
					<li class="ls-step<?php echo $done ? ' ls-step-done' : ''; ?>" data-step="<?php echo esc_attr( $key_s ); ?>" data-done="<?php echo $done ? '1' : '0'; ?>"<?php echo $cur ? ' aria-current="step"' : ''; ?>>
						<span class="ls-step-mark" aria-hidden="true"><span class="ls-step-n"><?php echo (int) $i + 1; ?></span></span>
						<div class="ls-step-body">
							<strong class="ls-step-title"><?php echo esc_html( $title ); ?></strong><span class="screen-reader-text" data-step-state><?php echo ' — ' . esc_html( $done ? __( 'выполнено', 'logshield' ) : ( $cur ? __( 'текущий шаг', 'logshield' ) : __( 'не выполнено', 'logshield' ) ) ); ?></span>
							<span class="ls-step-text"><?php echo esc_html( $text ); ?></span>
							<?php if ( ! $done ) : ?>
								<div class="ls-step-act">
									<?php if ( $key_s === 'log' ) : ?>
										<a class="ls-btn ls-btn-sm<?php echo $cur ? ' ls-btn-accent' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=' . LogShield_Admin::SLUG ) . '#log_path' ); ?>"><?php esc_html_e( 'Указать путь к логу', 'logshield' ); ?></a>
									<?php elseif ( $key_s === 'scan' ) : ?>
										<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_run_now' ) ); ?>">
											<input type="hidden" name="action" value="logshield_run_now">
											<?php self::back_fields( 'overview' ); ?>
											<?php wp_nonce_field( 'logshield_run_now' ); ?>
											<button class="ls-btn ls-btn-sm<?php echo $cur ? ' ls-btn-accent' : ''; ?>"><?php esc_html_e( 'Запустить сканирование', 'logshield' ); ?></button>
										</form>
									<?php elseif ( $key_s === 'review' ) : ?>
										<a class="ls-btn ls-btn-sm<?php echo $cur ? ' ls-btn-accent' : ''; ?>" href="#addresses"><?php esc_html_e( 'Открыть «Адреса»', 'logshield' ); ?></a>
									<?php elseif ( $key_s === 'protect' ) : ?>
										<?php // Диалог #ls-protect есть, пока включён тестовый режим (а шаг не выполнен только тогда). ?>
										<button type="button" class="ls-btn ls-btn-sm<?php echo $cur ? ' ls-btn-accent' : ''; ?>" command="show-modal" commandfor="ls-protect"><?php esc_html_e( 'Включить защиту…', 'logshield' ); ?></button>
									<?php endif; ?>
								</div>
							<?php endif; ?>
						</div>
					</li>
				<?php endforeach; ?>
			</ol>
		</section>
		<?php
	}

	/** Кнопка «Включить защиту» на дашборде: выключает тестовый режим. */
	public static function protect() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_protect' );
		$opts            = LogShield_Plugin::get_options();
		$opts['dry_run'] = false;
		update_option( LOGSHIELD_OPTION, $opts );
		LogShield_Admin::redirect_with_message( __( 'Защита включена: со следующего сканирования нарушители будут блокироваться в .htaccess.', 'logshield' ) );
	}

	/** Худший уровень пунктов «Состояния»: ok | warn | err. */
	public static function health_level( array $health ) {
		$worst = 'ok';
		foreach ( $health as $item ) {
			if ( $item[0] === 'err' ) return 'err';
			if ( $item[0] === 'warn' ) $worst = 'warn';
		}
		return $worst;
	}

	/** «Сканирование 12 минут назад · следующее в 14:20» для шапки. */
	private static function scan_status( array $scan_log, $next_run, $interval_label ) {
		$now  = time();
		$last = (int) ( $scan_log[0]['time'] ?? 0 );
		// Разметка внутри переводимых строк пропускается через kses, значения экранируются.
		$out  = $last
			? sprintf(
				/* translators: 1: время в ISO 8601, 2: дата и время, 3: сколько времени назад. Разметку <time> сохраните. */
				LogShield_Plugin::kses( __( 'Сканирование <time datetime="%1$s" title="%2$s">%3$s назад</time>', 'logshield' ) ),
				esc_attr( gmdate( 'c', $last ) ),
				esc_attr( wp_date( 'd.m.Y H:i', $last ) ),
				esc_html( human_time_diff( $last, $now ) )
			)
			: esc_html__( 'Сканирований ещё не было', 'logshield' );
		if ( ! $next_run ) {
			$out .= ' · <span class="ls-danger">' . esc_html__( 'следующее не запланировано', 'logshield' ) . '</span>';
		} elseif ( $next_run <= $now ) {
			$out .= ' · ' . esc_html__( 'следующее вот-вот', 'logshield' );
		} else {
			$fmt  = wp_date( 'Y-m-d', $next_run ) === wp_date( 'Y-m-d', $now ) ? 'H:i' : 'd.m H:i';
			$out .= ' · ' . sprintf(
				/* translators: 1: время в ISO 8601, 2: время или дата и время. Разметку <time> сохраните. */
				LogShield_Plugin::kses( __( 'следующее в <time datetime="%1$s">%2$s</time>', 'logshield' ) ),
				esc_attr( gmdate( 'c', $next_run ) ),
				esc_html( wp_date( $fmt, $next_run ) )
			);
		}
		/* translators: %s: интервал, например «3 ч». */
		return $out . ' <span class="ls-dim">' . esc_html( sprintf( __( '(анализ лога раз в %s)', 'logshield' ), $interval_label ) ) . '</span>';
	}

	/** Переключатель вкладки «Адреса»: ключ (all — без фильтра) => подпись. */
	public static function address_views() {
		return [
			'all'     => __( 'Все', 'logshield' ),
			'new'     => __( 'Новые', 'logshield' ),
			'banned'  => __( 'Заблокированы', 'logshield' ),
			'seen'    => __( 'Не заблокированы', 'logshield' ),
			'persist' => __( 'Настойчивые', 'logshield' ),
		];
	}

	/** Группы фильтра «Тип» строки «Адресов»: настойчивый адрес без срабатываний правил — ни в одной. */
	public static function addr_groups( array $a ) {
		if ( ! $a['types'] && ! empty( $a['persist'] ) && ! $a['direct'] && ! $a['runs'] ) return [];
		return self::row_groups( $a['types'] );
	}

	/**
	 * data-атрибуты строки «Адресов» (и пункта «Настойчивых» на «Обзоре»): по ним
	 * работают фильтры, выбор и панель адреса. Всё экранировано.
	 */
	public static function row_data_attrs( array $a, array $types, array $ipinfo ) {
		$geo = $a['persist'] ? $a['persist']['e'] : ( $ipinfo[ $a['ip'] ] ?? null );
		// Поиск: адрес, причина, типы, страна, сеть, номер AS и User-Agent.
		$q = $a['ip'] . ' ' . $a['reason'];
		foreach ( $a['types'] as $t ) $q .= ' ' . ( $types[ $t ] ?? $t );
		if ( $geo ) {
			$q .= ' ' . ( $geo['country'] ?? '' ) . ' ' . ( $geo['cc'] ?? '' ) . ' ' . ( $geo['org'] ?? '' ) . ( ! empty( $geo['asn'] ) ? ' AS' . $geo['asn'] : '' ) . ' ' . ( $geo['ua'] ?? '' );
		}
		$out = ' data-ip="' . esc_attr( $a['ip'] ) . '"'
			. ' data-types="' . esc_attr( implode( ' ', $a['types'] ) ) . '"'
			. ' data-groups="' . esc_attr( implode( ' ', self::addr_groups( $a ) ) ) . '"'
			. ' data-status="' . esc_attr( $a['status'] ) . '"'
			. ' data-direct="' . ( $a['direct'] ? '1' : '0' ) . '"'
			. ' data-expires="' . ( $a['expires'] ? esc_attr( wp_date( 'd.m.Y', (int) $a['expires'] ) ) : '' ) . '"'
			. ' data-q="' . esc_attr( mb_strtolower( $q ) ) . '"';
		if ( $a['hidden'] ) $out .= ' data-dismissed';
		if ( $a['new'] ) $out .= ' data-new';
		if ( $a['foreign'] ) $out .= ' data-foreign="' . (int) $a['foreign'] . '"';
		if ( $a['soon'] ) $out .= ' data-soon';
		if ( $a['manual'] ) $out .= ' data-manual';
		if ( $a['cover'] !== '' ) $out .= ' data-cover="' . esc_attr( $a['cover'] ) . '"';
		if ( $a['white'] !== '' ) $out .= ' data-white="' . esc_attr( $a['white'] ) . '"';
		if ( $a['net'] !== '' ) $out .= ' data-net="' . esc_attr( $a['net'] ) . '"';
		if ( $a['persist'] ) {
			$out .= ' data-persist="' . (int) ( $a['persist']['e']['hits'] ?? 0 ) . '"';
			if ( $a['flagged'] ) $out .= ' data-flagged="1"';
			// Настойчивый адрес без срабатываний правил блокируется на BAN_DAYS (дата-центры меняют владельцев).
			if ( ! $a['runs'] && $a['status'] === 'seen' ) $out .= ' data-ban-days="' . (int) LogShield_IPInfo::BAN_DAYS . '"';
		}
		if ( $geo ) $out .= LogShield_IPInfo::row_attrs( $geo );
		return $out;
	}

	/** Ячейка «Статус» строки «Адресов». */
	private static function render_status_cell( array $a ) {
		if ( $a['status'] === 'banned' ) {
			echo '<span class="ls-tag ls-tag-banned">' . esc_html__( 'Заблокирован', 'logshield' ) . '</span>';
			if ( ! $a['direct'] ) {
				/* translators: %s: сеть CIDR. */
				echo '<br><span class="ls-dim">' . esc_html( $a['cover'] !== '' ? sprintf( __( 'в сети %s', 'logshield' ), $a['cover'] ) : __( 'в подсети', 'logshield' ) ) . '</span>';
			} elseif ( $a['forever'] ) {
				echo '<br><span class="ls-dim">' . esc_html__( 'бессрочно', 'logshield' ) . '</span>';
			} else {
				/* translators: %s: дата окончания блокировки. */
				echo '<br><span class="ls-dim ls-nowrap">' . esc_html( sprintf( __( 'до %s', 'logshield' ), wp_date( 'd.m.Y', (int) $a['expires'] ) ) ) . '</span>';
			}
			if ( $a['soon'] ) echo ' <span class="ls-tag ls-tag-soon">' . esc_html__( 'скоро истекает', 'logshield' ) . '</span>';
			if ( $a['manual'] ) echo ' <span class="ls-tag ls-tag-manual">' . esc_html__( 'вручную', 'logshield' ) . '</span>';
		} elseif ( $a['status'] === 'white' ) {
			echo '<span class="ls-tag ls-tag-white" title="' . esc_attr( $a['white'] ) . '">' . esc_html__( 'в белом списке', 'logshield' ) . '</span>';
		} elseif ( $a['flagged'] ) {
			echo '<span class="ls-tag ls-tag-seen">' . esc_html__( 'Обнаружен', 'logshield' ) . '</span>';
		} else {
			echo '<span class="ls-tag ls-tag-seen">' . esc_html__( 'Не заблокирован', 'logshield' ) . '</span>';
		}
		if ( $a['foreign'] ) {
			/* translators: %d: номер строки .htaccess. */
			echo '<br><span class="ls-tag ls-tag-foreign" title="' . esc_attr( sprintf( __( 'Строка %d в .htaccess, вне блока LogShield', 'logshield' ), (int) $a['foreign'] ) ) . '">' . esc_html__( 'также в .htaccess вручную', 'logshield' ) . '</span>';
		}
	}

	/** Кнопка строки «Адресов»: разблокировать свой бан или заблокировать обнаруженный. */
	private static function render_row_action( array $a ) {
		$ip = $a['ip'];
		if ( $a['status'] === 'banned' && $a['direct'] ) : ?>
			<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_unban' ) ); ?>">
				<input type="hidden" name="action" value="logshield_unban">
				<input type="hidden" name="ip" value="<?php echo esc_attr( $ip ); ?>">
				<?php self::back_fields( 'addresses' ); ?>
				<?php wp_nonce_field( 'logshield_unban' ); ?>
				<button class="ls-btn ls-btn-sm"><?php esc_html_e( 'Разблокировать', 'logshield' ); ?><span class="screen-reader-text"> <?php echo esc_html( $ip ); ?></span></button>
			</form>
		<?php elseif ( $a['status'] === 'seen' ) :
			// Настойчивый адрес без срабатываний правил — на BAN_DAYS с подтверждением, как в прежней карточке.
			$persist_only = $a['persist'] && ! $a['runs'];
			$days_text    = self::days_text( LogShield_IPInfo::BAN_DAYS );
			$confirm      = $persist_only
				/* translators: 1: IP-адрес, 2: срок, например «30 дней». */
				? sprintf( __( 'Заблокировать %1$s на %2$s? Запись в .htaccess применяется сразу, в тестовом режиме тоже.', 'logshield' ), $ip, $days_text )
				: ''; ?>
			<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_ban' ) ); ?>"<?php echo $confirm !== '' ? ' data-confirm="' . esc_attr( $confirm ) . '"' : ''; ?>>
				<input type="hidden" name="action" value="logshield_ban">
				<input type="hidden" name="ip" value="<?php echo esc_attr( $ip ); ?>">
				<?php if ( $persist_only ) : ?>
					<input type="hidden" name="days" value="<?php echo (int) LogShield_IPInfo::BAN_DAYS; ?>">
					<input type="hidden" name="reason" value="<?php echo esc_attr( $a['reason'] ); ?>">
				<?php endif; ?>
				<?php self::back_fields( 'addresses' ); ?>
				<?php wp_nonce_field( 'logshield_ban' ); ?>
				<button class="ls-btn ls-btn-sm ls-btn-danger"><?php esc_html_e( 'Заблокировать', 'logshield' ); ?><span class="screen-reader-text"> <?php echo esc_html( $ip ); ?></span></button>
			</form>
		<?php endif;
	}

	/** Список проверок «Состояния» (на «Обзоре» — только предупреждения и ошибки). */
	private static function render_health_list( array $items, $back, array $levels ) {
		?>
		<ul class="ls-health">
			<?php foreach ( $items as $item ) :
				list( $lvl, $title, $text ) = $item;
				$ack = $item[3] ?? ''; ?>
				<li class="ls-h-<?php echo esc_attr( $lvl ); ?>">
					<span class="ls-h-icon" aria-hidden="true"><?php echo esc_html( $levels[ $lvl ][0] ); ?></span>
					<?php // div, а не span: внутри бывает форма «Понятно» (форма в строчном элементе — неверная разметка). Пункт списка — flex, так что вид тот же. ?>
					<div><strong><?php echo esc_html( $title ); ?></strong><span class="screen-reader-text"> (<?php echo esc_html( $levels[ $lvl ][1] ); ?>)</span><br><?php echo esc_html( $text ); ?>
						<?php if ( $ack ) : ?>
							<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( $ack ) ); ?>">
								<input type="hidden" name="action" value="<?php echo esc_attr( $ack ); ?>">
								<?php self::back_fields( $back ); ?>
								<?php wp_nonce_field( $ack ); ?>
								<button class="ls-btn ls-btn-sm"><?php esc_html_e( 'Понятно', 'logshield' ); ?><span class="screen-reader-text">: <?php echo esc_html( $title ); ?></span></button>
							</form>
						<?php endif; ?>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	}

	/** Сколько настойчивых адресов показывать на «Обзоре». */
	const TOP_PERSIST = 5;

	/**
	 * «Настойчивые адреса» на «Обзоре»: пять с наибольшим числом ошибок, по щелчку —
	 * панель адреса; полный список — во вкладке «Адреса» с фильтром «Настойчивые».
	 */
	private static function render_top_persist( array $addr, array $ipinfo ) {
		if ( ! LogShield_IPInfo::enabled() && ! $ipinfo ) return;
		$top = array_values( array_filter( $addr, function ( $a ) { return $a['persist'] && ! $a['hidden']; } ) );
		usort( $top, function ( $x, $y ) { return ( (int) $y['persist']['e']['hits'] <=> (int) $x['persist']['e']['hits'] ) ?: ( $y['last'] <=> $x['last'] ); } );
		$total = count( $top );
		$top   = array_slice( $top, 0, self::TOP_PERSIST );
		$types = LogShield_Stats::labels();
		?>
		<section class="ls-card ls-top-card" aria-labelledby="ls-top-title">
			<div class="ls-card-head">
				<h2 id="ls-top-title"><?php esc_html_e( 'Настойчивые адреса', 'logshield' ); ?></h2>
				<p class="ls-legend"><?php
					/* translators: %d: порог ошибок или неудачных входов за одно сканирование. */
					echo esc_html( sprintf( __( 'за 30 дней: %d+ ошибок или неудачных входов за сканирование · только для информации', 'logshield' ), (int) LogShield_IPInfo::MIN_HITS ) );
				?></p>
			</div>
			<?php if ( ! is_file( LogShield_IPInfo::dir() . 'country.mmdb' ) && LogShield_IPInfo::enabled() ) : ?>
				<p class="ls-pad ls-dim"><?php
					/* translators: %s: адрес страницы настроек. */
					echo LogShield_Plugin::kses( sprintf( __( 'Базы стран ещё не скачаны — это сделает ежедневная задача, или нажмите «Обновить базы сейчас» в <a href="%s">настройках</a>.', 'logshield' ), esc_url( admin_url( 'admin.php?page=' . LogShield_Admin::SLUG ) ) ) ); // phpcs:ignore
				?></p>
			<?php endif; ?>
			<?php if ( ! $top ) : ?>
				<p class="ls-pad ls-dim"><?php esc_html_e( 'Пока никого. Появятся после сканирования, если кто-то настойчиво получает ошибки.', 'logshield' ); ?></p>
			<?php else : ?>
				<ol class="ls-top">
					<?php foreach ( $top as $a ) : ?>
						<li<?php echo self::row_data_attrs( $a, $types, $ipinfo ); // phpcs:ignore -- экранировано внутри ?>>
							<div class="ls-top-main">
								<button type="button" class="ls-ip-btn" data-ip-open aria-haspopup="dialog" title="<?php esc_attr_e( 'Подробнее об адресе', 'logshield' ); ?>"><code><?php echo esc_html( $a['ip'] ); ?></code><span class="screen-reader-text"><?php esc_html_e( ', подробнее', 'logshield' ); ?></span></button>
								<?php echo LogShield_IPInfo::badge( $a['ip'], $ipinfo ); // phpcs:ignore -- экранировано внутри ?>
							</div>
							<span class="ls-top-hits"><?php
								/* translators: %d: число ошибок. */
								echo esc_html( sprintf( __( 'ошибок: %d', 'logshield' ), (int) $a['persist']['e']['hits'] ) );
							?></span>
							<span class="ls-top-status"><?php
								if ( $a['status'] === 'banned' ) echo '<span class="ls-tag ls-tag-banned">' . esc_html__( 'Заблокирован', 'logshield' ) . '</span>';
								elseif ( $a['status'] === 'white' ) echo '<span class="ls-tag ls-tag-white">' . esc_html__( 'в белом списке', 'logshield' ) . '</span>';
								else echo '<span class="ls-tag ls-tag-seen">' . esc_html__( 'Не заблокирован', 'logshield' ) . '</span>';
							?></span>
						</li>
					<?php endforeach; ?>
				</ol>
			<?php endif; ?>
			<p class="ls-pad ls-top-foot">
				<?php if ( $total ) : ?>
					<a href="#addresses" data-goto-view="persist"><?php
						/* translators: %d: число настойчивых адресов. */
						echo esc_html( sprintf( __( 'Все настойчивые (%d) →', 'logshield' ), (int) $total ) );
					?></a>
				<?php endif; ?>
				<span class="ls-dim ls-geo-credit"><?php LogShield_IPInfo::credit(); ?></span>
			</p>
		</section>
		<?php
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$opts     = LogShield_Plugin::get_options();
		$scan_log = self::scan_log();
		$banned   = self::banned();
		$next_run = wp_next_scheduled( LOGSHIELD_CRON_HOOK );
		$state    = LogShield_LogFinder::describe( $opts['log_path'] );
		$addr     = self::addresses();
		$counts   = self::address_counts( $addr );
		$types    = LogShield_Stats::labels();
		$can_fill = $state['ok'] && get_option( self::BACKFILL_OPTION ) !== $opts['log_path'];
		$health   = self::health( $opts, $scan_log, $next_run, $state );
		$h_level  = self::health_level( $health );
		$unseen   = self::unseen_on_open();
		$theme    = self::get_theme();
		$levels   = [ 'ok' => [ '✓', __( 'в порядке', 'logshield' ) ], 'warn' => [ '⚠', __( 'внимание', 'logshield' ) ], 'err' => [ '✕', __( 'ошибка', 'logshield' ) ] ];
		$first    = array_key_first( self::TABS );
		$def_days = (int) $opts['ban_expiry_days'];
		$onboard  = self::onboarding( $opts, $state, $scan_log, false );
		// Группы для фильтра по типу: сколько строк в каждой (без скрытых).
		$groups   = array_fill_keys( array_keys( self::TYPE_GROUPS ), 0 );
		$n_hidden = 0;
		$ipinfo   = LogShield_IPInfo::get_all();
		foreach ( $addr as $a ) {
			if ( $a['hidden'] ) { $n_hidden++; continue; }
			foreach ( self::addr_groups( $a ) as $g ) $groups[ $g ]++;
		}
		?>
		<div class="wrap ls-wrap">
		<h1 class="screen-reader-text"><?php esc_html_e( 'LogShield — дашборд', 'logshield' ); ?></h1>
		<?php // Уведомления WordPress вставляет после первого заголовка, до панели. ?>
		<?php // data-theme ставит сервер — без мигания; тему меняет dashboard.js. ?>
		<div class="ls-dash" data-theme="<?php echo esc_attr( $theme ); ?>">

			<header class="ls-head">
				<p class="ls-brand">
					<span class="ls-logo dashicons dashicons-shield" aria-hidden="true"></span>
					<span class="ls-title">LogShield</span>
				</p>
				<?php if ( $opts['dry_run'] ) : ?>
					<span class="ls-badge ls-badge-warn"><span class="ls-dot" aria-hidden="true"></span><?php esc_html_e( 'Тестовый режим', 'logshield' ); ?></span>
				<?php else : ?>
					<span class="ls-badge ls-badge-ok"><span class="ls-dot" aria-hidden="true"></span><?php esc_html_e( 'Защита включена', 'logshield' ); ?></span>
				<?php endif; ?>
				<p class="ls-head-status"><?php echo self::scan_status( $scan_log, $next_run, LogShield_Plugin::interval_label( $opts['interval'] ) ); // phpcs:ignore -- экранировано внутри ?></p>
				<div class="ls-head-actions">
					<?php self::theme_control( $theme ); ?>
					<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_run_now' ) ); ?>">
						<input type="hidden" name="action" value="logshield_run_now">
						<?php self::back_fields( $first, true ); ?>
						<?php wp_nonce_field( 'logshield_run_now' ); ?>
						<button class="ls-btn ls-btn-accent"><span class="dashicons dashicons-update" aria-hidden="true"></span> <?php esc_html_e( 'Запустить', 'logshield' ); ?><span class="screen-reader-text"> <?php esc_html_e( 'сканирование сейчас', 'logshield' ); ?></span></button>
					</form>
					<a class="ls-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=' . LogShield_Admin::SLUG ) ); ?>"><span class="dashicons dashicons-admin-generic" aria-hidden="true"></span> <?php esc_html_e( 'Настройки', 'logshield' ); ?></a>
				</div>
			</header>

			<?php if ( $opts['dry_run'] ) :
				$would = self::would_ban( 7 );
				$my_ip = LogShield_Whitelist::get_client_ip();
				$my_why = $my_ip ? LogShield_Whitelist::whitelist_reason( $my_ip, (array) $opts['whitelist_ips'] ) : null; ?>
				<section class="ls-dry" aria-label="<?php esc_attr_e( 'Тестовый режим', 'logshield' ); ?>">
					<p>
						<span aria-hidden="true">⚠</span> <strong class="ls-dry-title"><?php esc_html_e( 'Тестовый режим: никого не блокирует.', 'logshield' ); ?></strong>
						<?php if ( $would['ips'] || $would['nets'] ) : ?>
							<?php
							if ( $would['nets'] ) {
								/* translators: 1: число адресов, 2: число подсетей. */
								$would_fmt = __( 'За 7 дней заблокировал бы адресов: <strong>%1$d</strong>, подсетей: <strong>%2$d</strong> — проверьте, нет ли своих, во вкладке <a href="#addresses">«Адреса»</a>.', 'logshield' );
							} else {
								/* translators: %1$d: число адресов. */
								$would_fmt = __( 'За 7 дней заблокировал бы адресов: <strong>%1$d</strong> — проверьте, нет ли своих, во вкладке <a href="#addresses">«Адреса»</a>.', 'logshield' );
							}
							echo sprintf( LogShield_Plugin::kses( $would_fmt ), (int) $would['ips'], (int) $would['nets'] ) . "\n";
							?>
						<?php else : ?>
							<?php echo esc_html__( 'За 7 дней блокировать было бы некого.', 'logshield' ) . "\n"; ?>
						<?php endif; ?>
					</p>
					<?php // Где нет command/commandfor, диалог открывает dashboard.js. ?>
					<button type="button" class="ls-btn ls-btn-accent ls-btn-sm" command="show-modal" commandfor="ls-protect"><?php esc_html_e( 'Включить защиту…', 'logshield' ); ?></button>
				</section>
				<dialog id="ls-protect" class="ls-dialog" aria-labelledby="ls-protect-title" aria-describedby="ls-protect-desc">
					<h2 id="ls-protect-title"><?php esc_html_e( 'Включить защиту?', 'logshield' ); ?></h2>
					<div id="ls-protect-desc">
						<p><?php echo LogShield_Plugin::kses( __( 'Со следующего сканирования новые нарушители будут блокироваться в <code>.htaccess</code>. Уже найденных можно заблокировать вручную в таблице.', 'logshield' ) ); ?></p>
						<?php if ( $my_why ) : ?>
							<p><span aria-hidden="true">✓</span> <?php
								/* translators: 1: IP-адрес в теге <code>, 2: почему адрес в белом списке. */
								echo LogShield_Plugin::kses( sprintf( __( 'Ваш адрес %1$s в белом списке: %2$s.', 'logshield' ), '<code>' . esc_html( $my_ip ) . '</code>', esc_html( $my_why['text'] ) ) );
							?></p>
						<?php else : ?>
							<p class="ls-warn-text"><span aria-hidden="true">⚠</span> <?php
								/* translators: %s: IP-адрес в теге <code>. */
								echo LogShield_Plugin::kses( sprintf( __( 'Ваш адрес %s не найден в белом списке.', 'logshield' ), '<code>' . esc_html( $my_ip ?: __( 'не определён', 'logshield' ) ) . '</code>' ) );
							?> <?php esc_html_e( 'Добавьте его в настройках, прежде чем включать.', 'logshield' ); ?></p>
						<?php endif; ?>
						<p class="ls-dim"><?php esc_html_e( 'Вернуть тестовый режим можно в настройках.', 'logshield' ); ?></p>
					</div>
					<div class="ls-dialog-actions">
						<form method="dialog">
							<button class="ls-btn" autofocus><?php esc_html_e( 'Отмена', 'logshield' ); ?></button>
						</form>
						<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_protect' ) ); ?>">
							<input type="hidden" name="action" value="logshield_protect">
							<?php self::back_fields( $first, true ); ?>
							<?php wp_nonce_field( 'logshield_protect' ); ?>
							<button class="ls-btn ls-btn-accent"><?php esc_html_e( 'Включить защиту', 'logshield' ); ?></button>
						</form>
					</div>
				</dialog>
			<?php endif; ?>

			<?php
			// Вкладки. Без скрипта список вкладок скрыт и все панели идут подряд.
			// Выбор — по нажатию (Enter/пробел/щелчок), а не по фокусу: выбор меняет адрес (#hash).
			?>
			<div class="ls-tablist" role="tablist" aria-label="<?php esc_attr_e( 'Разделы дашборда', 'logshield' ); ?>" data-tablist hidden>
				<?php foreach ( self::tabs() as $k => $label ) : $on = $k === $first; ?>
					<button type="button" role="tab" class="ls-tab" id="ls-tab-<?php echo esc_attr( $k ); ?>" data-tab="<?php echo esc_attr( $k ); ?>" aria-selected="<?php echo $on ? 'true' : 'false'; ?>" tabindex="<?php echo $on ? '0' : '-1'; ?>">
						<?php echo esc_html( $label ); ?>
						<?php if ( $k === 'addresses' && $unseen ) : ?>
							<span class="ls-tab-count" data-tab-badge><span aria-hidden="true"><?php echo (int) $unseen; ?></span><span class="screen-reader-text">, <?php
								/* translators: %d: число новых атакующих. */
								echo esc_html( sprintf( __( 'новых: %d', 'logshield' ), (int) $unseen ) );
							?></span></span>
						<?php elseif ( $k === 'health' && $h_level !== 'ok' ) : ?>
							<span class="ls-tab-alert ls-tab-alert-<?php echo esc_attr( $h_level ); ?>" data-tab-badge><span aria-hidden="true"><?php echo esc_html( $levels[ $h_level ][0] ); ?></span><span class="screen-reader-text">, <?php echo esc_html( $h_level === 'err' ? __( 'есть ошибки', 'logshield' ) : __( 'есть предупреждения', 'logshield' ) ); ?></span></span>
						<?php endif; ?>
					</button>
				<?php endforeach; ?>
			</div>
			<?php
			// До загрузки dashboard.js (он с defer) — сразу показать вкладку из #hash,
			// чтобы не мелькали все панели подряд. Всё остальное делает dashboard.js.
			// Старые имена (#attackers, #journal) заменяются в адресе на новые.
			wp_print_inline_script_tag(
				'(function(s,a){var r=s.parentNode,l=r.querySelector("[data-tablist]"),t=location.hash.slice(1);'
				. 'if(!l)return;if(Object.prototype.hasOwnProperty.call(a,t)){t=a[t];history.replaceState(history.state,"","#"+t);}'
				. 'if(!/^[a-z]+$/.test(t)||!l.querySelector("#ls-tab-"+t))t=l.querySelector("[role=tab]").dataset.tab;'
				. 'r.setAttribute("data-boot-tab",t);l.hidden=false;'
				. 'l.querySelectorAll("[role=tab]").forEach(function(b){var on=b.dataset.tab===t;b.setAttribute("aria-selected",on);b.tabIndex=on?0:-1;});'
				. '})(document.currentScript,' . wp_json_encode( (object) self::TAB_ALIASES ) . ');'
			);
			?>

			<div class="ls-panels">

			<div class="ls-panel" id="ls-panel-overview" role="tabpanel" aria-labelledby="ls-tab-overview" data-panel="overview">
				<?php self::render_onboarding( $onboard ); ?>
				<?php
				// «Требует внимания»: только предупреждения и ошибки из «Состояния»; нет проблем — нет блока.
				$issues = array_values( array_filter( $health, function ( $h ) { return $h[0] !== 'ok'; } ) );
				if ( $issues ) : ?>
					<section class="ls-card ls-attn ls-attn-<?php echo esc_attr( $h_level ); ?>" aria-labelledby="ls-attn-title">
						<div class="ls-card-head">
							<h2 id="ls-attn-title"><span class="ls-attn-icon" aria-hidden="true"><?php echo esc_html( $levels[ $h_level ][0] ); ?></span> <?php esc_html_e( 'Требует внимания', 'logshield' ); ?></h2>
							<p class="ls-legend"><a href="#health"><?php esc_html_e( 'Все проверки', 'logshield' ); ?></a></p>
						</div>
						<?php self::render_health_list( $issues, 'overview', $levels ); ?>
					</section>
				<?php endif; ?>
				<div class="ls-range" role="group" aria-label="<?php esc_attr_e( 'Период графиков', 'logshield' ); ?>">
					<button type="button" class="ls-btn ls-btn-sm" data-range="24" aria-pressed="true"><?php esc_html_e( '24 часа', 'logshield' ); ?></button>
					<button type="button" class="ls-btn ls-btn-sm" data-range="168" aria-pressed="false"><?php esc_html_e( '7 дней', 'logshield' ); ?></button>
					<button type="button" class="ls-btn ls-btn-sm" data-range="720" aria-pressed="false"><?php esc_html_e( '30 дней', 'logshield' ); ?></button>
				</div>

				<section class="ls-metrics" aria-label="<?php esc_attr_e( 'Итоги за период', 'logshield' ); ?>">
					<div class="ls-card"><p class="ls-label"><?php esc_html_e( 'Запросов', 'logshield' ); ?></p><p class="ls-value ls-accent" data-metric="req">—</p></div>
					<div class="ls-card"><p class="ls-label"><?php esc_html_e( 'Ошибки 4xx/5xx', 'logshield' ); ?></p><p class="ls-value ls-danger" data-metric="err">—</p></div>
					<div class="ls-card"><p class="ls-label"><?php esc_html_e( 'Неудачных входов', 'logshield' ); ?></p><p class="ls-value ls-warn" data-metric="fails">—</p></div>
					<div class="ls-card"><p class="ls-label"><?php esc_html_e( 'Атакующих найдено', 'logshield' ); ?></p><p class="ls-value ls-danger" data-metric="flag">—</p></div>
					<div class="ls-card"><p class="ls-label"><?php esc_html_e( 'Заблокировано сейчас', 'logshield' ); ?></p><p class="ls-value" data-metric="banned">—</p></div>
				</section>

				<div class="ls-empty ls-card" hidden>
					<p><strong><?php esc_html_e( 'Графиков пока нет.', 'logshield' ); ?></strong> <?php esc_html_e( 'Статистика копится при каждом сканировании; первое сканирование только запоминает позицию в логе.', 'logshield' ); ?></p>
					<?php if ( $can_fill ) : ?>
						<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_backfill' ) ); ?>">
							<input type="hidden" name="action" value="logshield_backfill">
							<?php self::back_fields( 'overview' ); ?>
							<?php wp_nonce_field( 'logshield_backfill' ); ?>
							<button class="ls-btn ls-btn-accent"><?php esc_html_e( 'Построить графики по уже записанному логу', 'logshield' ); ?></button>
							<span class="ls-dim"><?php
								/* translators: %d: лимит чтения в мегабайтах. */
								echo esc_html( sprintf( __( '— прочитает до %d МБ, ничего не блокирует', 'logshield' ), (int) $opts['max_read_mb'] ) );
							?></span>
						</form>
					<?php endif; ?>
				</div>

				<section class="ls-card ls-chart-card">
					<div class="ls-card-head">
						<h2><?php esc_html_e( 'Трафик', 'logshield' ); ?></h2>
						<p class="ls-legend"><span class="ls-key ls-key-accent"></span><?php esc_html_e( 'Запросы', 'logshield' ); ?> <span class="ls-key ls-key-danger"></span><?php esc_html_e( 'Ошибки 4xx/5xx', 'logshield' ); ?> <span class="ls-legend-ev" aria-hidden="true"><svg class="ls-mk-key" viewBox="0 0 10 10"><circle class="ls-mk-scan" cx="5" cy="5" r="3"/></svg><?php esc_html_e( 'сканирование', 'logshield' ); ?> <svg class="ls-mk-key" viewBox="0 0 10 10"><path class="ls-mk-hit" d="M0 1h10L5 9z"/></svg><?php esc_html_e( 'нашло атакующих', 'logshield' ); ?> <svg class="ls-mk-key" viewBox="0 0 10 10"><rect class="ls-mk-ban" x="1" y="1" width="8" height="8"/></svg><?php esc_html_e( 'блокировка', 'logshield' ); ?></span></p>
					</div>
					<div class="ls-chart" data-chart="traffic"></div>
					<details class="ls-chart-data">
						<summary><?php esc_html_e( 'Данные графика таблицей', 'logshield' ); ?></summary>
						<div class="ls-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Трафик по периодам', 'logshield' ); ?>">
							<table class="ls-table" data-chart-table="traffic"></table>
						</div>
					</details>
				</section>

				<div class="ls-grid-2">
					<section class="ls-card ls-chart-card">
						<div class="ls-card-head">
							<h2><?php esc_html_e( 'Неудачные входы', 'logshield' ); ?></h2>
							<p class="ls-legend"><span class="ls-key ls-key-warn"></span><?php esc_html_e( 'POST на wp-login.php без входа', 'logshield' ); ?> <span class="ls-legend-ev" aria-hidden="true"><svg class="ls-mk-key" viewBox="0 0 10 10"><circle class="ls-mk-scan" cx="5" cy="5" r="3"/></svg><?php esc_html_e( 'сканирование', 'logshield' ); ?> <svg class="ls-mk-key" viewBox="0 0 10 10"><path class="ls-mk-hit" d="M0 1h10L5 9z"/></svg><?php esc_html_e( 'нашло атакующих', 'logshield' ); ?> <svg class="ls-mk-key" viewBox="0 0 10 10"><rect class="ls-mk-ban" x="1" y="1" width="8" height="8"/></svg><?php esc_html_e( 'блокировка', 'logshield' ); ?></span></p>
						</div>
						<div class="ls-chart" data-chart="fails"></div>
						<details class="ls-chart-data">
							<summary><?php esc_html_e( 'Данные графика таблицей', 'logshield' ); ?></summary>
							<div class="ls-table-wrap" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Неудачные входы по периодам', 'logshield' ); ?>">
								<table class="ls-table" data-chart-table="fails"></table>
							</div>
						</details>
					</section>
					<section class="ls-card">
						<div class="ls-card-head"><h2><?php esc_html_e( 'Типы атак', 'logshield' ); ?></h2><p class="ls-legend"><?php esc_html_e( 'адресов за период', 'logshield' ); ?></p></div>
						<ul class="ls-types" data-types></ul>
					</section>
				</div>

				<?php self::render_top_persist( $addr, $ipinfo ); ?>

				<p class="ls-dim ls-foot"><?php esc_html_e( 'Графики строятся по данным сканирований и нагрузки не добавляют.', 'logshield' ); ?></p>
			</div>

			<?php // Адреса: атакующие, все блокировки и настойчивые адреса в одной таблице; формы строк возвращают на эту вкладку (ls_tab). ?>
			<div class="ls-panel" id="ls-panel-addresses" role="tabpanel" aria-labelledby="ls-tab-addresses" data-panel="addresses">
				<?php // Ручная блокировка адреса или сети: тот же admin_post_logshield_ban, что у кнопки в строке. ?>
				<section class="ls-card ls-mban" aria-labelledby="ls-mban-title">
					<h2 id="ls-mban-title" class="ls-mban-title"><?php esc_html_e( 'Заблокировать адрес или сеть', 'logshield' ); ?></h2>
					<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_ban' ) ); ?>" class="ls-mban-form" aria-labelledby="ls-mban-title" data-mban>
						<input type="hidden" name="action" value="logshield_ban">
						<?php self::back_fields( 'addresses' ); ?>
						<?php wp_nonce_field( 'logshield_ban' ); ?>
						<div class="ls-mban-field ls-mban-ip">
							<label for="ls-mban-ip"><?php esc_html_e( 'IP или сеть', 'logshield' ); ?></label>
							<?php // inputmode="url": на телефоне клавиатура с «.», «/» и буквами (IPv6), а не только цифры. ?>
							<input type="text" id="ls-mban-ip" name="ip" required maxlength="64"
								inputmode="url" autocomplete="off" autocapitalize="none" autocorrect="off" spellcheck="false" enterkeyhint="go"
								pattern="[0-9A-Fa-f:.\/]+" placeholder="<?php esc_attr_e( '203.0.113.5 или 203.0.113.0/24', 'logshield' ); ?>"
								aria-describedby="ls-mban-hint" data-mban-ip>
						</div>
						<div class="ls-mban-field">
							<label for="ls-mban-days"><?php esc_html_e( 'Срок', 'logshield' ); ?></label>
							<?php self::days_select( $def_days, 'ls-mban-days' ); ?>
						</div>
						<div class="ls-mban-field ls-mban-reason">
							<label for="ls-mban-reason"><?php esc_html_e( 'Причина', 'logshield' ); ?> <span class="ls-dim"><?php esc_html_e( '(необязательно)', 'logshield' ); ?></span></label>
							<input type="text" id="ls-mban-reason" name="reason" maxlength="<?php echo (int) self::MANUAL_REASON_MAX; ?>" autocomplete="off" enterkeyhint="go">
						</div>
						<button class="ls-btn ls-btn-danger"><?php esc_html_e( 'Заблокировать', 'logshield' ); ?></button>
						<p id="ls-mban-hint" class="ls-dim ls-mban-hint"><?php
							/* translators: 1: наименьший префикс для IPv4, 2: для IPv6. */
							echo LogShield_Plugin::kses( sprintf( __( 'IPv4 или IPv6, сеть — в виде CIDR: не шире /%1$d для IPv4 и /%2$d для IPv6. Записывается в <code>.htaccess</code> сразу, и в тестовом режиме тоже. Адрес из белого списка не заблокируется.', 'logshield' ), (int) self::MANUAL_MIN_BITS_V4, (int) self::MANUAL_MIN_BITS_V6 ) );
						?></p>
					</form>
				</section>

				<section class="ls-card ls-addr-card" data-sel-scope>
					<div class="ls-card-head">
						<h2 id="ls-addr-title"><?php esc_html_e( 'Адреса', 'logshield' ); ?></h2>
						<p class="ls-legend"><?php esc_html_e( 'атакующие, блокировки и настойчивые адреса · страна, сеть и User-Agent только для информации', 'logshield' ); ?></p>
					</div>
					<?php if ( ! $addr ) : ?>
						<p class="ls-dim ls-pad"><?php esc_html_e( 'Пока никого: нет ни пойманных, ни заблокированных, ни настойчивых адресов.', 'logshield' ); ?></p>
					<?php else : ?>
						<?php // Фильтры, выбор строк и панель адреса работают только со скриптом — он их и показывает. ?>
						<div class="ls-filters" data-attack-filters hidden>
							<div class="ls-seg" role="group" aria-label="<?php esc_attr_e( 'Какие адреса показать', 'logshield' ); ?>" data-f-view>
								<?php foreach ( self::address_views() as $v => $label ) : ?>
									<button type="button" class="ls-seg-btn" aria-pressed="<?php echo $v === 'all' ? 'true' : 'false'; ?>" data-v="<?php echo esc_attr( $v === 'all' ? '' : $v ); ?>"><?php echo esc_html( $label ); ?> <span class="ls-chip-n"><?php echo (int) $counts[ $v ]; ?></span></button>
								<?php endforeach; ?>
							</div>
							<label class="ls-f-search">
								<span><?php esc_html_e( 'Поиск', 'logshield' ); ?></span>
								<input type="search" class="ls-input" data-f-q placeholder="<?php esc_attr_e( 'IP, причина, страна, сеть или User-Agent', 'logshield' ); ?>" autocomplete="off" spellcheck="false">
							</label>
							<?php if ( array_sum( $groups ) ) : ?>
								<div class="ls-chips" role="group" aria-labelledby="ls-f-type-label" data-f-type>
									<span class="ls-chips-label" id="ls-f-type-label"><?php esc_html_e( 'Тип', 'logshield' ); ?></span>
									<button type="button" class="ls-chip" aria-pressed="true" data-v=""><?php esc_html_e( 'Все', 'logshield' ); ?></button>
									<?php foreach ( self::TYPE_GROUPS as $g => $def ) : if ( ! $groups[ $g ] ) continue; ?>
										<button type="button" class="ls-chip" aria-pressed="false" data-v="<?php echo esc_attr( $g ); ?>"><?php echo esc_html( self::type_group_label( $g ) ); ?> <span class="ls-chip-n"><?php echo (int) $groups[ $g ]; ?></span></button>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
							<?php if ( $n_hidden ) : ?>
								<button type="button" class="ls-chip" aria-pressed="false" data-f-hidden><?php
									/* translators: %d: число скрытых строк. */
									echo esc_html( sprintf( __( 'Показать скрытые (%d)', 'logshield' ), (int) $n_hidden ) );
								?></button>
							<?php endif; ?>
							<p class="ls-dim ls-f-count" role="status" data-f-count></p>
						</div>

						<?php // Панель действий с выбранными: видна, когда выбрана хотя бы одна строка. ?>
						<div class="ls-bulk" data-bulk hidden>
							<p class="ls-bulk-count" data-bulk-count></p>
							<div class="ls-bulk-bar" role="toolbar" focusgroup="toolbar wrap" aria-label="<?php esc_attr_e( 'Действия с выбранными адресами', 'logshield' ); ?>" aria-controls="ls-addresses">
								<button type="button" class="ls-btn ls-btn-sm ls-btn-danger" data-bulk-op="ban"><?php esc_html_e( 'Заблокировать', 'logshield' ); ?></button>
								<button type="button" class="ls-btn ls-btn-sm" data-bulk-op="unban"><?php esc_html_e( 'Разблокировать', 'logshield' ); ?></button>
								<button type="button" class="ls-btn ls-btn-sm" data-bulk-op="hide"><?php esc_html_e( 'Скрыть', 'logshield' ); ?></button>
								<button type="button" class="ls-btn ls-btn-sm" data-bulk-op="clear"><?php esc_html_e( 'Снять выделение', 'logshield' ); ?></button>
							</div>
						</div>
						<?php // Объявления о выборе и результатах — вне панели, всегда в DOM. ?>
						<p class="screen-reader-text" role="status" data-bulk-live></p>
						<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_bulk' ) ); ?>" data-bulk-form hidden>
							<input type="hidden" name="action" value="logshield_bulk">
							<input type="hidden" name="op" value="" data-bulk-input-op>
							<?php self::back_fields( 'addresses' ); ?>
							<?php wp_nonce_field( 'logshield_bulk' ); ?>
						</form>

						<div class="ls-table-wrap" tabindex="0" role="region" aria-labelledby="ls-addr-title">
							<table class="ls-table ls-table-stack ls-addr-table" id="ls-addresses" data-attackers>
								<thead><tr>
									<th scope="col" class="ls-sel-col"><label class="ls-sel-all"><input type="checkbox" class="ls-check" data-sel-all aria-label="<?php esc_attr_e( 'Выбрать все видимые', 'logshield' ); ?>"><span class="ls-sel-all-text" aria-hidden="true"><?php esc_html_e( 'Выбрать все видимые', 'logshield' ); ?></span></label></th>
									<th scope="col" data-type="ip"><button type="button" class="ls-sort" commandfor="ls-addresses" command="--sort"><?php esc_html_e( 'Адрес', 'logshield' ); ?><span class="ls-sort-icon" aria-hidden="true"></span></button></th>
									<th scope="col"><?php esc_html_e( 'Что делал', 'logshield' ); ?></th>
									<th scope="col" data-type="number" aria-sort="descending"><button type="button" class="ls-sort" commandfor="ls-addresses" command="--sort"><?php esc_html_e( 'Когда', 'logshield' ); ?><span class="ls-sort-icon" aria-hidden="true"></span></button></th>
									<th scope="col"><?php esc_html_e( 'Статус', 'logshield' ); ?></th>
									<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Действие', 'logshield' ); ?></span></th>
								</tr></thead>
								<tbody>
								<?php foreach ( $addr as $a ) :
									$pe = $a['persist'] ? $a['persist']['e'] : null; ?>
									<tr<?php echo self::row_data_attrs( $a, $types, $ipinfo ); // phpcs:ignore -- экранировано внутри ?><?php echo $a['hidden'] ? ' hidden' : ''; ?>>
										<?php // label вокруг флажка — область касания больше самого флажка (на сенсорном экране 44 px). ?>
										<td class="ls-sel-col"><label class="ls-sel"><input type="checkbox" class="ls-check" data-sel value="<?php echo esc_attr( $a['ip'] ); ?>" aria-label="<?php /* translators: %s: IP-адрес. */ echo esc_attr( sprintf( __( 'Выбрать %s', 'logshield' ), $a['ip'] ) ); ?>"></label></td>
										<th scope="row" data-value="<?php echo esc_attr( $a['ip'] ); ?>">
											<button type="button" class="ls-ip-btn" data-ip-open aria-haspopup="dialog" title="<?php esc_attr_e( 'Подробнее об адресе', 'logshield' ); ?>"><code><?php echo esc_html( $a['ip'] ); ?></code><span class="screen-reader-text"><?php esc_html_e( ', подробнее', 'logshield' ); ?></span></button>
											<?php if ( $a['new'] ) : ?><span class="ls-tag ls-tag-new"><?php esc_html_e( 'новый', 'logshield' ); ?></span><?php endif; ?>
											<?php if ( $a['hidden'] ) : ?><span class="ls-tag ls-tag-dismissed"><?php esc_html_e( 'скрыт', 'logshield' ); ?></span><?php endif; ?>
											<?php echo LogShield_IPInfo::badge( $a['ip'], $ipinfo ); // phpcs:ignore -- экранировано внутри ?>
										</th>
										<td class="ls-who" data-label="<?php esc_attr_e( 'Что делал', 'logshield' ); ?>">
											<?php foreach ( $a['types'] as $t ) : ?>
												<span class="ls-tag ls-tag-<?php echo esc_attr( $t ); ?>"><?php echo esc_html( $types[ $t ] ?? $t ); ?></span>
											<?php endforeach; ?>
											<span class="ls-reason"><?php echo esc_html( $a['reason'] ); ?></span>
											<?php if ( $pe ) echo LogShield_IPInfo::hints_html( $pe, $a['persist']['bot'] ); // phpcs:ignore -- экранировано внутри ?>
										</td>
										<td class="ls-nowrap" data-label="<?php esc_attr_e( 'Когда', 'logshield' ); ?>" data-value="<?php echo (int) $a['last']; ?>"><?php echo esc_html( wp_date( 'd.m H:i', $a['last'] ) ); ?><?php if ( $a['runs'] > 1 ) : ?><br><span class="ls-dim"><?php /* translators: %d: в скольких сканированиях пойман. */ echo esc_html( sprintf( __( '%d скан.', 'logshield' ), (int) $a['runs'] ) ); ?></span><?php endif; ?></td>
										<td class="ls-addr-status" data-label="<?php esc_attr_e( 'Статус', 'logshield' ); ?>">
											<?php self::render_status_cell( $a ); ?>
										</td>
										<td class="ls-addr-act">
											<?php self::render_row_action( $a ); ?>
										</td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>
						<p class="ls-dim ls-pad" data-f-empty hidden><?php esc_html_e( 'Под фильтр ничего не попало.', 'logshield' ); ?></p>
					<?php endif; ?>

					<?php $banned_count = count( $banned ); ?>
					<div class="ls-pad ls-addr-foot">
						<?php if ( $banned_count ) : ?>
							<?php // Где нет command/commandfor, диалог открывает dashboard.js. ?>
							<button type="button" class="ls-btn ls-btn-sm" command="show-modal" commandfor="ls-unban-all"><?php
								/* translators: %d: число блокировок. */
								echo esc_html( sprintf( __( 'Снять все блокировки (%d)…', 'logshield' ), (int) $banned_count ) );
							?></button>
						<?php endif; ?>
						<?php if ( $ipinfo || LogShield_IPInfo::enabled() ) : ?>
							<p class="ls-dim ls-geo-credit"><?php LogShield_IPInfo::credit(); ?></p>
						<?php endif; ?>
					</div>
					<?php if ( $banned_count ) : ?>
						<dialog id="ls-unban-all" class="ls-dialog" aria-labelledby="ls-unban-all-title" aria-describedby="ls-unban-all-desc" closedby="any">
							<h2 id="ls-unban-all-title"><?php esc_html_e( 'Снять все блокировки?', 'logshield' ); ?></h2>
							<div id="ls-unban-all-desc">
								<p><?php
									/* translators: %d: число блокировок. */
									echo LogShield_Plugin::kses( sprintf( __( 'Из блока LogShield в <code>.htaccess</code> будут удалены все заблокированные адреса и подсети (%d): автоматические, ручные и перенесённые. Вернуть их можно только новой блокировкой.', 'logshield' ), (int) $banned_count ) );
								?></p>
								<p class="ls-dim"><?php esc_html_e( 'Строки .htaccess вне блока LogShield (ручной список) не меняются.', 'logshield' ); ?></p>
							</div>
							<div class="ls-dialog-actions">
								<form method="dialog">
									<button class="ls-btn" autofocus><?php esc_html_e( 'Отмена', 'logshield' ); ?></button>
								</form>
								<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_unban_all' ) ); ?>">
									<input type="hidden" name="action" value="logshield_unban_all">
									<?php self::back_fields( 'addresses' ); ?>
									<?php wp_nonce_field( 'logshield_unban_all' ); ?>
									<button class="ls-btn ls-btn-danger"><?php esc_html_e( 'Снять все блокировки', 'logshield' ); ?></button>
								</form>
							</div>
						</dialog>
					<?php endif; ?>
				</section>
			</div>

			<div class="ls-panel" id="ls-panel-log" role="tabpanel" aria-labelledby="ls-tab-log" data-panel="log">
				<section class="ls-card">
					<div class="ls-card-head">
						<h2><?php esc_html_e( 'Последние записи лога', 'logshield' ); ?></h2>
						<div class="ls-tail-tools">
							<div role="group" aria-label="<?php esc_attr_e( 'Фильтр записей', 'logshield' ); ?>">
								<button type="button" class="ls-btn ls-btn-sm" data-filter="quiet" aria-pressed="true" title="<?php esc_attr_e( 'Прячет ответы 1xx–3xx без признаков атаки и запросы адресов из белого списка (кроме 5xx)', 'logshield' ); ?>"><?php esc_html_e( 'Скрыть обычное', 'logshield' ); ?></button>
								<button type="button" class="ls-btn ls-btn-sm" data-filter="all" aria-pressed="false"><?php esc_html_e( 'Все', 'logshield' ); ?></button>
								<button type="button" class="ls-btn ls-btn-sm" data-filter="4xx" aria-pressed="false">4xx</button>
								<button type="button" class="ls-btn ls-btn-sm" data-filter="5xx" aria-pressed="false">5xx</button>
								<button type="button" class="ls-btn ls-btn-sm" data-filter="bad" aria-pressed="false"><?php esc_html_e( 'Атакующие', 'logshield' ); ?></button>
							</div>
							<span class="ls-dim ls-tail-hidden" data-tail-hidden></span>
							<button type="button" class="ls-btn ls-btn-sm" data-ua aria-pressed="false">User-Agent</button>
							<button type="button" class="ls-btn ls-btn-sm" data-live aria-pressed="false"><span class="ls-dot" aria-hidden="true"></span> <?php esc_html_e( 'Живой режим', 'logshield' ); ?></button>
						</div>
					</div>
					<p class="ls-dim ls-pad ls-tail-note" data-tail-status role="status"><?php echo esc_html( $state['ok'] ? __( 'Загрузка…', 'logshield' ) : __( 'Лог недоступен — укажите путь в настройках.', 'logshield' ) ); ?></p>
					<div class="ls-tail" data-tail tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Последние записи лога', 'logshield' ); ?>"></div>
				</section>
				<p class="ls-dim ls-foot"><?php esc_html_e( 'Лог читается, только пока открыта эта вкладка. Живой режим опрашивает его раз в 5 секунд, а пока новых записей нет — всё реже, до раза в 30 секунд; на скрытой вкладке браузера опросов нет. «Скрыть обычное» прячет успешные ответы (1xx–3xx) без признаков атаки и запросы адресов из белого списка; входы, xmlrpc.php, перебор пользователей, чувствительные пути, запросы атакующих, ошибки 4xx и 5xx остаются видны.', 'logshield' ); ?></p>
			</div>

			<div class="ls-panel" id="ls-panel-health" role="tabpanel" aria-labelledby="ls-tab-health" data-panel="health">
				<section class="ls-card" aria-labelledby="ls-health-title">
					<div class="ls-card-head"><h2 id="ls-health-title"><?php esc_html_e( 'Состояние', 'logshield' ); ?></h2></div>
					<?php self::render_health_list( $health, 'health', $levels ); ?>
				</section>
				<section class="ls-card">
					<div class="ls-card-head"><h2 id="ls-runs-title"><?php esc_html_e( 'Сканирования', 'logshield' ); ?></h2><p class="ls-legend"><?php esc_html_e( 'последние 20', 'logshield' ); ?></p></div>
					<?php if ( ! $scan_log ) : ?>
						<p class="ls-dim ls-pad"><?php esc_html_e( 'Сканирование ещё не запускалось.', 'logshield' ); ?></p>
					<?php else : ?>
						<div class="ls-runs-wrap" tabindex="0" role="region" aria-labelledby="ls-runs-title">
						<ol class="ls-runs">
							<?php foreach ( array_slice( $scan_log, 0, 20 ) as $run ) :
								$n = count( (array) ( $run['flagged'] ?? [] ) );
								// Итог словом и значком, а не только цветом полосы.
								if ( empty( $run['ok'] ) ) {
									$cls = 'ls-run-err'; $icon = '⚠'; $word = __( 'ошибка', 'logshield' );
								} elseif ( $n ) {
									/* translators: %d: число найденных адресов. */
									$cls = 'ls-run-hit'; $icon = '●'; $word = sprintf( __( 'найдено: %d', 'logshield' ), $n );
								} else {
									$cls = 'ls-run-ok'; $icon = '✓'; $word = __( 'чисто', 'logshield' );
								} ?>
								<li class="<?php echo esc_attr( $cls ); ?>">
									<span class="ls-run-time"><?php echo esc_html( wp_date( 'd.m H:i', $run['time'] ) ); ?> · <span class="ls-run-state"><span aria-hidden="true"><?php echo esc_html( $icon ); ?></span> <?php echo esc_html( $word ); ?></span></span>
									<span><?php echo esc_html( $run['message'] ); ?></span>
								</li>
							<?php endforeach; ?>
						</ol>
						</div>
					<?php endif; ?>
				</section>
				<?php self::render_denies(); ?>
			</div>

			</div>
		<?php
		// Панель адреса: одна на дашборд (таблица «Адреса» и пять настойчивых на «Обзоре»),
		// содержимое подставляет dashboard.js.
			// Нативный модальный <dialog>: фокус, Esc, inert страницы и возврат фокуса даёт браузер.
			?>
			<dialog id="ls-ip-panel" class="ls-dialog ls-side" aria-labelledby="ls-ip-title" closedby="any" data-ip-panel>
				<div class="ls-side-head">
					<h2 id="ls-ip-title"><code data-p-ip></code></h2>
					<form method="dialog"><button class="ls-btn ls-btn-sm" autofocus><?php esc_html_e( 'Закрыть', 'logshield' ); ?></button></form>
				</div>
				<div class="ls-side-body">
					<div data-p-geo></div>
					<section class="ls-side-sec" aria-labelledby="ls-ip-ua-h" data-p-ua-sec hidden>
						<h3 id="ls-ip-ua-h"><?php esc_html_e( 'Кто это', 'logshield' ); ?></h3>
						<p class="ls-side-ua"><span class="ls-dim"><?php esc_html_e( 'Частый User-Agent:', 'logshield' ); ?></span> <code data-p-ua></code></p>
						<p data-p-bot hidden></p>
						<p class="ls-dim" data-p-uas hidden></p>
					</section>
					<section class="ls-side-sec" aria-labelledby="ls-ip-status-h">
						<h3 id="ls-ip-status-h"><?php esc_html_e( 'Статус', 'logshield' ); ?></h3>
						<p data-p-status></p>
					</section>
					<section class="ls-side-sec" aria-labelledby="ls-ip-act-h">
						<h3 id="ls-ip-act-h"><?php esc_html_e( 'Действия', 'logshield' ); ?></h3>
						<div class="ls-side-actions">
							<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_bulk' ) ); ?>" class="ls-side-ban" data-p-form="ban">
								<input type="hidden" name="action" value="logshield_bulk">
								<input type="hidden" name="op" value="ban">
								<input type="hidden" name="items[]" value="" data-p-item>
								<?php self::back_fields( 'addresses' ); ?>
								<?php wp_nonce_field( 'logshield_bulk' ); ?>
								<label><span><?php esc_html_e( 'Заблокировать на', 'logshield' ); ?></span>
									<?php self::days_select( $def_days ); ?>
								</label>
								<button class="ls-btn ls-btn-sm ls-btn-danger"><?php esc_html_e( 'Заблокировать', 'logshield' ); ?></button>
							</form>
							<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_bulk' ) ); ?>" data-p-form="unban">
								<input type="hidden" name="action" value="logshield_bulk">
								<input type="hidden" name="op" value="unban">
								<input type="hidden" name="items[]" value="" data-p-item>
								<?php self::back_fields( 'addresses' ); ?>
								<?php wp_nonce_field( 'logshield_bulk' ); ?>
								<button class="ls-btn ls-btn-sm"><?php esc_html_e( 'Разблокировать', 'logshield' ); ?></button>
							</form>
							<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_bulk' ) ); ?>" class="ls-side-ban" data-p-form="bannet" data-confirm="" data-days-text="<?php echo esc_attr( self::days_text( LogShield_IPInfo::BAN_DAYS ) ); ?>" hidden>
								<input type="hidden" name="action" value="logshield_bulk">
								<input type="hidden" name="op" value="ban">
								<input type="hidden" name="items[]" value="" data-p-net>
								<input type="hidden" name="days" value="<?php echo (int) LogShield_IPInfo::BAN_DAYS; ?>">
								<?php self::back_fields( 'addresses' ); ?>
								<?php wp_nonce_field( 'logshield_bulk' ); ?>
								<button class="ls-btn ls-btn-sm ls-btn-danger" data-p-net-label></button>
							</form>
							<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_bulk' ) ); ?>" data-p-form="whitelist" data-confirm="">
								<input type="hidden" name="action" value="logshield_bulk">
								<input type="hidden" name="op" value="whitelist">
								<input type="hidden" name="items[]" value="" data-p-item>
								<?php self::back_fields( 'addresses' ); ?>
								<?php wp_nonce_field( 'logshield_bulk' ); ?>
								<button class="ls-btn ls-btn-sm"><?php esc_html_e( 'В белый список', 'logshield' ); ?></button>
							</form>
							<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_bulk' ) ); ?>" data-p-form="hide">
								<input type="hidden" name="action" value="logshield_bulk">
								<input type="hidden" name="op" value="hide">
								<input type="hidden" name="items[]" value="" data-p-item>
								<?php self::back_fields( 'addresses' ); ?>
								<?php wp_nonce_field( 'logshield_bulk' ); ?>
								<button class="ls-btn ls-btn-sm"><?php esc_html_e( 'Скрыть', 'logshield' ); ?></button>
							</form>
						</div>
					</section>
					<section class="ls-side-sec" aria-labelledby="ls-ip-hist-h">
						<h3 id="ls-ip-hist-h"><?php esc_html_e( 'Срабатывания правил', 'logshield' ); ?></h3>
						<p class="ls-dim" data-p-hist-empty hidden><?php esc_html_e( 'В истории сканирований этого адреса нет (заблокирован вручную или запись устарела).', 'logshield' ); ?></p>
						<ol class="ls-side-list" data-p-hist></ol>
					</section>
					<section class="ls-side-sec" aria-labelledby="ls-ip-req-h">
						<h3 id="ls-ip-req-h"><?php esc_html_e( 'Последние запросы', 'logshield' ); ?></h3>
						<p class="ls-dim" role="status" data-p-req-status></p>
						<ol class="ls-reqs" data-p-reqs></ol>
					</section>
				</div>
			</dialog>
		</div><!-- .ls-dash -->
		</div>
		<?php
	}

	/** Подписи источника записи ручного списка. */
	const DENY_SOURCES = [ 'aiowps' => 'All In One WP Security', 'own' => 'свои строки' ];

	/** Подпись источника строки ручного списка на языке сайта. */
	public static function deny_source_label( $source ) {
		if ( $source === 'own' ) return __( 'свои строки', 'logshield' );
		return self::DENY_SOURCES[ $source ] ?? (string) $source;
	}

	/**
	 * Карточка «Ручной список в .htaccess» на вкладке «Состояние»: строки
	 * Require not ip / Deny from вне блока LogShield, их статус и перенос.
	 */
	private static function render_denies() {
		$d = self::denies();
		$c = $d['counts'];
		$n = count( $d['entries'] );
		?>
		<section class="ls-card ls-denies" aria-labelledby="ls-denies-title">
			<div class="ls-card-head">
				<h2 id="ls-denies-title"><?php esc_html_e( 'Ручной список в .htaccess', 'logshield' ); ?></h2>
				<p class="ls-legend"><?php echo LogShield_Plugin::kses( __( '<code>Require not ip</code> и <code>Deny from</code> вне блока LogShield', 'logshield' ) ); ?></p>
			</div>
			<?php if ( ! $n && ! $d['invalid'] ) : ?>
				<p class="ls-dim ls-pad"><?php echo esc_html( $d['exists'] ? __( 'Своих блокировок по адресу в .htaccess нет.', 'logshield' ) : __( 'Файл .htaccess не найден или не читается.', 'logshield' ) ); ?></p>
			<?php else : ?>
				<div class="ls-pad ls-denies-body">
					<ul class="ls-denies-sum">
						<li><?php /* Разметка <strong> — внутри переводимых строк, они проходят через kses. */ /* translators: %d: число записей. */ echo LogShield_Plugin::kses( sprintf( LogShield_Plugin::plural( $n, _n_noop( '<strong>%d</strong> запись', '<strong>%d</strong> записей', 'logshield' ), '<strong>%d</strong> записи' ), (int) $n ) ); ?></li>
						<li><?php /* translators: %d: число записей. */ echo LogShield_Plugin::kses( sprintf( __( '<strong>%d</strong> уже в LogShield', 'logshield' ), (int) $c['banned'] ) ); ?></li>
						<li><?php
							if ( $c['import'] && $c['import'] !== $n - $c['banned'] ) {
								/* translators: 1: сколько записей ещё не в LogShield, 2: сколько из них можно перенести. */
								echo LogShield_Plugin::kses( sprintf( __( '<strong>%1$d</strong> ещё нет, из них можно перенести <strong>%2$d</strong>', 'logshield' ), (int) ( $n - $c['banned'] ), (int) $c['import'] ) );
							} else {
								/* translators: %d: сколько записей ещё не в LogShield. */
								echo LogShield_Plugin::kses( sprintf( __( '<strong>%d</strong> ещё нет', 'logshield' ), (int) ( $n - $c['banned'] ) ) );
							}
						?></li>
						<?php if ( $d['invalid'] ) : ?><li><?php /* translators: %d: число нераспознанных записей. */ echo LogShield_Plugin::kses( sprintf( __( '<strong>%d</strong> не распознано', 'logshield' ), count( $d['invalid'] ) ) ); ?></li><?php endif; ?>
					</ul>
					<?php if ( $c['whitelist'] ) : ?>
						<p class="ls-warn-text"><span aria-hidden="true">⚠</span> <?php
							echo LogShield_Plugin::kses( sprintf( LogShield_Plugin::plural(
								$c['whitelist'],
								/* translators: %d: число записей. */
								_n_noop( '<strong>%d</strong> запись блокирует адреса из белого списка — сотрудников, сервера или ваш ручной список. Эти строки нужно удалить из <code>.htaccess</code> вручную: LogShield их не переносит и не трогает.', '<strong>%d</strong> записей блокируют адреса из белого списка — сотрудников, сервера или ваш ручной список. Эти строки нужно удалить из <code>.htaccess</code> вручную: LogShield их не переносит и не трогает.', 'logshield' ),
								'<strong>%d</strong> записи блокируют адреса из белого списка — сотрудников, сервера или ваш ручной список. Эти строки нужно удалить из <code>.htaccess</code> вручную: LogShield их не переносит и не трогает.'
							), (int) $c['whitelist'] ) );
						?></p>
					<?php endif; ?>
					<?php if ( $c['import'] ) : ?>
						<form method="post" action="<?php echo esc_url( LogShield_Admin::post_url( 'logshield_import_denies' ) ); ?>" class="ls-denies-form" data-confirm="<?php /* translators: %d: число записей. */ echo esc_attr( sprintf( __( 'Перенести в LogShield записей: %d? Они станут ручными блокировками без срока; .htaccess будет записан сразу, и в тестовом режиме тоже. Исходные строки останутся на месте.', 'logshield' ), $c['import'] ) ); ?>">
							<input type="hidden" name="action" value="logshield_import_denies">
							<?php self::back_fields( 'health' ); ?>
							<?php wp_nonce_field( 'logshield_import_denies' ); ?>
							<button class="ls-btn ls-btn-accent ls-btn-sm"><?php /* translators: %d: число записей. */ echo esc_html( sprintf( __( 'Перенести в LogShield (%d)', 'logshield' ), (int) $c['import'] ) ); ?></button>
						</form>
					<?php endif; ?>
					<p class="ls-dim"><?php echo LogShield_Plugin::kses( __( 'После переноса строки в <code>.htaccess</code> остаются — удалить их можно вручную; пока они там, снятие бана в LogShield адрес не разблокирует.', 'logshield' ) ); ?></p>
					<?php if ( $n ) : ?>
						<details class="ls-denies-list"<?php echo $c['whitelist'] ? ' open' : ''; ?>>
							<summary><?php /* translators: %d: число записей. */ echo esc_html( sprintf( __( 'Список записей (%d)', 'logshield' ), (int) $n ) ); ?></summary>
							<div class="ls-table-wrap" tabindex="0" role="region" aria-labelledby="ls-denies-title">
								<table class="ls-table ls-table-stack">
									<thead><tr>
										<th scope="col"><?php esc_html_e( 'Адрес', 'logshield' ); ?></th>
										<th scope="col"><?php esc_html_e( 'Строка', 'logshield' ); ?></th>
										<th scope="col"><?php esc_html_e( 'Источник', 'logshield' ); ?></th>
										<th scope="col"><?php esc_html_e( 'Статус', 'logshield' ); ?></th>
									</tr></thead>
									<tbody>
									<?php foreach ( $d['entries'] as $e ) :
										$st = self::DENY_STATUSES[ $e['status'] ]; ?>
										<tr data-deny-status="<?php echo esc_attr( $e['status'] ); ?>">
											<th scope="row"><code><?php echo esc_html( $e['entry'] ); ?></code><?php if ( $e['raw'] !== $e['entry'] ) : ?> <span class="ls-dim"><?php /* translators: %s: запись, как она написана в .htaccess. */ echo esc_html( sprintf( __( '(в файле: %s)', 'logshield' ), $e['raw'] ) ); ?></span><?php endif; ?></th>
											<td data-label="<?php esc_attr_e( 'Строка', 'logshield' ); ?>"><?php echo esc_html( implode( ', ', $e['lines'] ) ); ?></td>
											<td data-label="<?php esc_attr_e( 'Источник', 'logshield' ); ?>"><?php echo esc_html( self::deny_source_label( $e['source'] ) ); ?></td>
											<td data-label="<?php esc_attr_e( 'Статус', 'logshield' ); ?>">
												<span class="ls-tag <?php echo esc_attr( $st[1] ); ?>"><?php echo esc_html( self::deny_status_label( $e['status'] ) ); ?></span>
												<?php if ( $e['note'] !== '' ) : ?><span class="ls-reason"><?php echo esc_html( $e['note'] ); ?></span><?php endif; ?>
											</td>
										</tr>
									<?php endforeach; ?>
									</tbody>
								</table>
							</div>
						</details>
					<?php endif; ?>
					<?php if ( $d['invalid'] ) : ?>
						<details class="ls-denies-list">
							<summary><?php /* translators: %d: число записей. */ echo esc_html( sprintf( __( 'Не распознано (%d)', 'logshield' ), count( $d['invalid'] ) ) ); ?></summary>
							<ul class="ls-denies-bad">
								<?php foreach ( $d['invalid'] as $bad ) : ?>
									<li><code><?php echo esc_html( $bad['token'] ); ?></code> — <?php /* translators: 1: номер строки, 2: источник, 3: ошибка разбора. */ echo esc_html( sprintf( __( 'строка %1$d, %2$s: %3$s', 'logshield' ), (int) $bad['line'], self::deny_source_label( $bad['source'] ), $bad['error'] ) ); ?></li>
								<?php endforeach; ?>
							</ul>
						</details>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</section>
		<?php
	}


	/**
	 * «Перенести в LogShield»: записи ручного списка .htaccess со статусом import
	 * становятся ручными банами без срока — одним вызовом ban_ips() (одна запись
	 * .htaccess, один бэкап). Пропускаются пересечения с белым списком, слишком
	 * широкие сети, запреты для части сайта и уже забаненные. Исходные строки
	 * пользователя не меняются. Работает и в тестовом режиме, как ручной бан.
	 */
	public static function import_denies() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ), 403 );
		check_admin_referer( 'logshield_import_denies' );
		self::flush_memo();
		$d  = self::denies();
		$to = [];
		foreach ( $d['entries'] as $e ) {
			// Причина хранится в списке банов на языке сайта в момент переноса.
			/* translators: %d: номер строки .htaccess. */
			if ( $e['status'] === 'import' ) $to[ $e['entry'] ] = sprintf( __( 'перенесено из .htaccess (строка %d)', 'logshield' ), $e['line'] );
		}
		$c     = $d['counts'];
		$parts = [];
		/* translators: %d: число записей. */
		if ( $c['whitelist'] ) $parts[] = sprintf( __( 'пересекаются с белым списком — %d', 'logshield' ), $c['whitelist'] );
		/* translators: %d: число записей. */
		if ( $c['wide'] ) $parts[] = sprintf( __( 'слишком широкая сеть — %d', 'logshield' ), $c['wide'] );
		/* translators: %d: число записей. */
		if ( $c['scoped'] ) $parts[] = sprintf( __( 'действуют только для части сайта — %d', 'logshield' ), $c['scoped'] );
		/* translators: %d: число записей. */
		if ( $c['banned'] ) $parts[] = sprintf( __( 'уже в LogShield — %d', 'logshield' ), $c['banned'] );
		/* translators: %d: число записей. */
		if ( $d['invalid'] ) $parts[] = sprintf( __( 'не распознаны — %d', 'logshield' ), count( $d['invalid'] ) );
		/* translators: %s: пропущенные группы через точку с запятой. */
		$notes = $parts ? ' ' . sprintf( __( 'Пропущено: %s.', 'logshield' ), implode( '; ', $parts ) ) : '';
		if ( ! $to ) {
			LogShield_Admin::redirect_with_message( __( 'Переносить нечего.', 'logshield' ) . $notes, 'error' );
		}
		$ok = LogShield_Htaccess::ban_ips( $to, 0, true );
		if ( $ok ) LogShield_Detector::clear_write_error();
		$evicted = count( LogShield_Htaccess::last_evicted() );
		/* translators: %d: сколько старых блокировок снято. */
		$ev_note = $evicted ? ' ' . sprintf( __( 'Из-за лимита блокировок снято старых: %d.', 'logshield' ), $evicted ) : '';
		LogShield_Admin::redirect_with_message(
			$ok
				/* translators: 1: число записей, 2: адреса через запятую. */
				? sprintf( __( 'Перенесено в LogShield: %1$d (%2$s), бессрочно. Строки в .htaccess остались на месте — их можно удалить вручную.', 'logshield' ), count( $to ), LogShield_Admin::short_list( array_keys( $to ) ) ) . $notes . $ev_note
				/* translators: 1: причина ошибки записи, 2: число записей. */
				: sprintf( __( 'Не удалось записать .htaccess: %1$s. Записи (%2$d) остались в списке банов — запись повторится при следующем изменении списка.', 'logshield' ), LogShield_Htaccess::last_error(), count( $to ) ) . $notes . $ev_note,
			$ok && ! $c['whitelist'] ? 'success' : 'error'
		);
	}

	/** Самая широкая сеть для ручной блокировки: IPv4 /16 (65 536 адресов), IPv6 /32. */
	const MANUAL_MIN_BITS_V4 = 16;
	const MANUAL_MIN_BITS_V6 = 32;
	/** Длина своей причины ручной блокировки, символов. */
	const MANUAL_REASON_MAX = 200;

	/**
	 * Адрес из формы ручной блокировки: IP или CIDR.
	 * IP — в каноническом виде (IPv6 сжат), сеть — адрес сети и маска (203.0.113.77/24 → 203.0.113.0/24),
	 * /32 у IPv4 и /128 у IPv6 — просто адрес. Сеть шире /16 (IPv4) или /32 (IPv6) не принимается:
	 * такой бан закрыл бы сайт для целого провайдера.
	 *
	 * @return array{ok:bool, entry:string, error:string, changed:bool} changed — вид отличается от введённого
	 */
	public static function manual_entry( $raw ) {
		$raw = trim( (string) $raw );
		$bad = [ 'ok' => false, 'entry' => '', 'changed' => false ];
		if ( $raw === '' ) return $bad + [ 'error' => __( 'Укажите IP-адрес или сеть.', 'logshield' ) ];
		if ( strlen( $raw ) > 64 ) return $bad + [ 'error' => __( 'Неверный адрес.', 'logshield' ) ];
		if ( filter_var( $raw, FILTER_VALIDATE_IP ) ) {
			$ip = inet_ntop( inet_pton( $raw ) );
			return [ 'ok' => true, 'entry' => $ip, 'error' => '', 'changed' => $ip !== $raw ];
		}
		$c = LogShield_IP::parse_cidr( $raw );
		if ( ! $c ) {
			/* translators: %s: введённый адрес. */
			return $bad + [ 'error' => sprintf( __( 'Неверный адрес: «%s». Нужен IP (203.0.113.5, 2001:db8::1) или сеть CIDR (203.0.113.0/24).', 'logshield' ), $raw ) ];
		}
		$v6  = strlen( $c['net'] ) === 16;
		$min = $v6 ? self::MANUAL_MIN_BITS_V6 : self::MANUAL_MIN_BITS_V4;
		if ( $c['bits'] < $min ) {
			return $bad + [ 'error' => sprintf(
				/* translators: 1: сеть, 2: наименьший префикс, 3: IPv4 или IPv6, 4: пример префикса. */
				__( 'Сеть %1$s слишком широкая: вручную можно заблокировать не больше /%2$d для %3$s. Укажите сеть уже (например, /%4$d) или несколько сетей по очереди.', 'logshield' ),
				$c['canonical'], $min, $v6 ? 'IPv6' : 'IPv4', $v6 ? 48 : 24
			) ];
		}
		$entry = $c['bits'] === strlen( $c['net'] ) * 8 ? inet_ntop( $c['net'] ) : $c['canonical'];
		return [ 'ok' => true, 'entry' => $entry, 'error' => '', 'changed' => $entry !== $raw ];
	}

	/**
	 * Срок блокировки из формы: default или одно из BAN_DAYS; null — неверный.
	 */
	private static function parse_days( $raw, $default ) {
		$d = is_string( $raw ) ? sanitize_text_field( $raw ) : 'default';
		if ( $d === '' || $d === 'default' ) return (int) $default;
		if ( ctype_digit( $d ) && in_array( (int) $d, self::BAN_DAYS, true ) ) return (int) $d;
		return null;
	}

	/** Выбор срока блокировки: «по умолчанию (N дней)» и BAN_DAYS. */
	private static function days_select( $def_days, $id = '' ) {
		?>
		<select name="days" class="ls-input ls-input-sm"<?php echo $id ? ' id="' . esc_attr( $id ) . '"' : ''; ?>>
			<option value="default"><?php /* translators: %s: срок, например «30 дней». */ echo esc_html( $def_days > 0 ? sprintf( __( 'по умолчанию (%s)', 'logshield' ), self::days_text( $def_days ) ) : __( 'по умолчанию (бессрочно)', 'logshield' ) ); ?></option>
			<?php foreach ( self::BAN_DAYS as $d ) : ?>
				<option value="<?php echo (int) $d; ?>"><?php echo esc_html( self::days_text( $d ) ); ?></option>
			<?php endforeach; ?>
		</select>
		<?php
	}

	/**
	 * Ручной бан с дашборда: кнопка в строке таблицы (поле ip) и форма
	 * «Заблокировать адрес или сеть» (ip — IP или CIDR, days, reason — необязательно).
	 * Применяется сразу, и в тестовом режиме тоже.
	 */
	public static function ban() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_ban' );
		$raw = isset( $_POST['ip'] ) && is_string( $_POST['ip'] ) ? sanitize_text_field( wp_unslash( $_POST['ip'] ) ) : '';
		$e   = self::manual_entry( $raw );
		if ( ! $e['ok'] ) LogShield_Admin::redirect_with_message( $e['error'], 'error' );
		$ip   = $e['entry'];
		$opts = LogShield_Plugin::get_options();
		$days = self::parse_days( isset( $_POST['days'] ) ? wp_unslash( $_POST['days'] ) : 'default', $opts['ban_expiry_days'] );
		if ( $days === null ) LogShield_Admin::redirect_with_message( __( 'Неверный срок блокировки.', 'logshield' ), 'error' );

		$whitelist = LogShield_Whitelist::get_full_whitelist( (array) $opts['whitelist_ips'] );
		foreach ( $whitelist as $w ) {
			if ( LogShield_IP::overlaps( $w, $ip ) ) {
				LogShield_Admin::redirect_with_message( sprintf( strpos( $ip, '/' ) !== false
					/* translators: 1: сеть, 2: запись белого списка. */
					? __( 'Сеть %1$s пересекается с белым списком (%2$s) — не блокирую.', 'logshield' )
					/* translators: 1: адрес, 2: запись белого списка. */
					: __( 'Адрес %1$s пересекается с белым списком (%2$s) — не блокирую.', 'logshield' ), $ip, $w ), 'error' );
			}
		}
		$banned = self::banned();
		if ( isset( $banned[ $ip ] ) ) {
			/* translators: %s: адрес или сеть. */
			LogShield_Admin::redirect_with_message( sprintf( __( '%s уже заблокирован.', 'logshield' ), $ip ), 'error' );
		}
		// Уже внутри заблокированной сети (она не уже нашей): новая запись ничего не добавит.
		$bits = function ( $x ) { $p = explode( '/', $x ); return isset( $p[1] ) ? (int) $p[1] : ( strpos( $x, ':' ) !== false ? 128 : 32 ); };
		foreach ( array_keys( $banned ) as $b ) {
			$b = (string) $b;
			if ( strpos( $b, '/' ) !== false && LogShield_IP::overlaps( $b, $ip ) && $bits( $ip ) >= $bits( $b ) ) {
				/* translators: 1: адрес или сеть, 2: заблокированная сеть. */
				LogShield_Admin::redirect_with_message( sprintf( __( '%1$s уже входит в заблокированную сеть %2$s.', 'logshield' ), $ip, $b ), 'error' );
			}
		}

		$own = isset( $_POST['reason'] ) && is_string( $_POST['reason'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['reason'] ) ) ) : '';
		// Причина хранится в списке банов на языке сайта в момент блокировки.
		if ( $own !== '' ) {
			$reason = self::manual_reason( mb_substr( $own, 0, self::MANUAL_REASON_MAX ) );
		} else {
			$reason = __( 'вручную с дашборда', 'logshield' );
			foreach ( self::addresses() as $a ) {
				if ( $a['ip'] === $ip ) { $reason = self::manual_reason( $a['reason'] ); break; }
			}
		}
		// Ручная блокировка применяется сразу, и в тестовом режиме тоже:
		// тестовый режим касается только автоматических банов по расписанию.
		$ok = LogShield_Htaccess::ban_ips( [ $ip => $reason ], $days, true );
		// Записывается весь список банов: удачная запись догнала и прошлые неудачные.
		if ( $ok ) LogShield_Detector::clear_write_error();
		/* translators: %s: введённый адрес. */
		$note = $e['changed'] ? ' ' . sprintf( __( '(введено «%s», записано в каноническом виде)', 'logshield' ), trim( $raw ) ) : '';
		LogShield_Admin::redirect_with_message(
			$ok
				/* translators: 1: срок («на 30 дней» или «бессрочно»), 2: адрес или сеть, 3: пояснение о каноническом виде или пусто, 4: путь к .htaccess. */
				? sprintf( __( 'Заблокирован %1$s: %2$s%3$s — записано в %4$s.', 'logshield' ), self::term_text( $days ), $ip, $note, LogShield_Htaccess::get_htaccess_path() )
				/* translators: 1: адрес или сеть, 2: причина ошибки записи. */
				: sprintf( __( 'Не удалось заблокировать %1$s: %2$s. Адрес остался в списке банов — запись повторится при следующем изменении списка.', 'logshield' ), $ip, LogShield_Htaccess::last_error() ),
			$ok ? 'success' : 'error'
		);
	}

	/**
	 * Графики по уже записанному логу: читает до max_read_mb перед текущей
	 * позицией сканера (чтобы не посчитать одно и то же дважды). Только
	 * статистика — никого не банит и не уведомляет. Один раз на путь.
	 */
	public static function backfill() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ) );
		check_admin_referer( 'logshield_backfill' );
		$opts = LogShield_Plugin::get_options();
		$path = $opts['log_path'];
		if ( ! LogShield_LogFinder::describe( $path )['ok'] ) {
			LogShield_Admin::redirect_with_message( __( 'Лог недоступен — укажите путь в настройках.', 'logshield' ), 'error' );
		}
		if ( get_option( self::BACKFILL_OPTION ) === $path ) {
			LogShield_Admin::redirect_with_message( __( 'Графики по этому логу уже построены.', 'logshield' ), 'error' );
		}
		clearstatcache();
		$size  = (int) @filesize( $path );
		$state = get_option( LogShield_Detector::OFFSET_OPTION, [ 'path' => '', 'offset' => 0 ] );
		$end   = ( $state['path'] === $path ) ? min( (int) $state['offset'], $size ) : $size;
		$start = max( 0, $end - max( 1, (int) $opts['max_read_mb'] ) * 1024 * 1024 );
		$lines = self::read_range( $path, $start, $end - $start );

		$whitelist = LogShield_Whitelist::get_full_whitelist( (array) $opts['whitelist_ips'] );
		$result    = LogShield_Detector::analyze( $lines, $opts, $whitelist );
		LogShield_Stats::record( $result['hourly'], [] );
		update_option( self::BACKFILL_OPTION, $path, false );
		if ( $state['path'] !== $path ) {
			// Сканер ещё не запускался на этом логе: дальше он начнёт с конца файла.
			update_option( LogShield_Detector::OFFSET_OPTION, [ 'path' => $path, 'offset' => $end ], false );
		}
		/* translators: 1: число строк, 2: число часов. */
		LogShield_Admin::redirect_with_message( sprintf( __( 'Графики построены: %1$d строк, %2$d часов.', 'logshield' ), count( $lines ), count( $result['hourly'] ) ) );
	}

	/** IP как есть, CIDR — в каноническом виде; мусор — null. */
	private static function entry( $raw ) {
		$raw = trim( (string) $raw );
		if ( filter_var( $raw, FILTER_VALIDATE_IP ) ) return $raw;
		$c = LogShield_IP::parse_cidr( $raw );
		return $c ? $c['canonical'] : null;
	}

	/**
	 * Действия таблицы атакующих и панели адреса (admin-post):
	 * op = ban | unban | hide | whitelist, items[] — до BULK_MAX адресов (IP или CIDR),
	 * days — срок блокировки для ban: default или одно из BAN_DAYS.
	 * Блокировка применяется сразу и в тестовом режиме (как ручной бан);
	 * файл .htaccess пишется один раз на всё действие.
	 */
	public static function bulk() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Недостаточно прав', 'logshield' ), 403 );
		check_admin_referer( 'logshield_bulk' );
		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		if ( ! in_array( $op, [ 'ban', 'unban', 'hide', 'whitelist' ], true ) ) {
			LogShield_Admin::redirect_with_message( __( 'Неизвестное действие.', 'logshield' ), 'error' );
		}
		$raw = isset( $_POST['items'] ) ? wp_unslash( $_POST['items'] ) : [];
		if ( ! is_array( $raw ) ) $raw = [ $raw ];
		if ( count( $raw ) > self::BULK_MAX ) {
			/* translators: 1: сколько адресов выбрано, 2: предел. */
			LogShield_Admin::redirect_with_message( sprintf( __( 'Слишком много адресов за раз: %1$d. Можно не больше %2$d — выделите меньше.', 'logshield' ), count( $raw ), self::BULK_MAX ), 'error' );
		}
		$items = [];
		$bad   = 0;
		foreach ( $raw as $r ) {
			$c = is_string( $r ) ? self::entry( sanitize_text_field( $r ) ) : null;
			if ( $c === null ) { $bad++; continue; }
			$items[ $c ] = true;
		}
		$items    = array_keys( $items );
		/* translators: %d: число отброшенных адресов. */
		$bad_note = $bad ? ' ' . sprintf( __( 'Отброшено неверных адресов: %d.', 'logshield' ), $bad ) : '';
		if ( ! $items ) {
			LogShield_Admin::redirect_with_message( __( 'Не выбрано ни одного верного адреса.', 'logshield' ) . $bad_note, 'error' );
		}
		$opts = LogShield_Plugin::get_options();
		$list = function ( array $a ) { return LogShield_Admin::short_list( $a ); };

		if ( $op === 'ban' ) {
			$days = self::parse_days( isset( $_POST['days'] ) ? wp_unslash( $_POST['days'] ) : 'default', $opts['ban_expiry_days'] );
			if ( $days === null ) {
				LogShield_Admin::redirect_with_message( __( 'Неверный срок блокировки.', 'logshield' ), 'error' );
			}
			$whitelist = LogShield_Whitelist::get_full_whitelist( (array) $opts['whitelist_ips'] );
			$banned    = self::banned();
			$reasons   = [];
			foreach ( self::addresses() as $a ) $reasons[ $a['ip'] ] = $a['reason'];
			$skip = [];
			$have = [];
			$to   = [];
			foreach ( $items as $ip ) {
				foreach ( $whitelist as $w ) {
					if ( LogShield_IP::overlaps( $w, $ip ) ) { $skip[] = $w === $ip ? $ip : $ip . ' (' . $w . ')'; continue 2; }
				}
				if ( isset( $banned[ $ip ] ) ) { $have[] = $ip; continue; }
				$to[ $ip ] = isset( $reasons[ $ip ] ) && $reasons[ $ip ] !== '' ? self::manual_reason( $reasons[ $ip ] ) : __( 'вручную с дашборда', 'logshield' );
			}
			/* translators: %s: адреса через запятую. */
			$notes = ( $skip ? ' ' . sprintf( __( 'Пропущены — пересекаются с белым списком: %s.', 'logshield' ), $list( $skip ) ) : '' )
				/* translators: %s: адреса через запятую. */
				. ( $have ? ' ' . sprintf( __( 'Уже заблокированы: %s.', 'logshield' ), $list( $have ) ) : '' ) . $bad_note;
			if ( ! $to ) {
				LogShield_Admin::redirect_with_message( __( 'Никто не заблокирован.', 'logshield' ) . $notes, 'error' );
			}
			// Один вызов — одна запись .htaccess и один бэкап на всю группу.
			$ok = LogShield_Htaccess::ban_ips( $to, $days, true );
			if ( $ok ) LogShield_Detector::clear_write_error();
			LogShield_Admin::redirect_with_message(
				$ok
					/* translators: 1: срок («на 30 дней» или «бессрочно»), 2: число адресов, 3: адреса через запятую. */
					? sprintf( __( 'Заблокировано %1$s: %2$d (%3$s).', 'logshield' ), self::term_text( $days ), count( $to ), $list( array_keys( $to ) ) ) . $notes
					/* translators: 1: причина ошибки записи, 2: число адресов. */
					: sprintf( __( 'Не удалось записать .htaccess: %1$s. Адреса (%2$d) остались в списке банов — запись повторится при следующем изменении списка.', 'logshield' ), LogShield_Htaccess::last_error(), count( $to ) ) . $notes,
				$ok && ! $skip ? 'success' : 'error'
			);
		}

		if ( $op === 'unban' ) {
			$removed = LogShield_Htaccess::unban_ips( $items );
			if ( $removed === false ) {
				/* translators: %s: причина ошибки записи. */
				LogShield_Admin::redirect_with_message( sprintf( __( 'Не удалось записать .htaccess: %s. Блокировки не сняты.', 'logshield' ), LogShield_Htaccess::last_error() ) . $bad_note, 'error' );
			}
			if ( ! $removed ) {
				LogShield_Admin::redirect_with_message( __( 'Среди выбранных нет заблокированных адресов (адрес внутри заблокированной подсети разблокируется вместе с подсетью).', 'logshield' ) . $bad_note, 'error' );
			}
			LogShield_Detector::clear_write_error();
			$rest = count( $items ) - count( $removed );
			$foreign = self::foreign_note( $removed );
			/* translators: 1: число адресов, 2: адреса через запятую. */
			LogShield_Admin::redirect_with_message( sprintf( __( 'Разблокировано: %1$d (%2$s).', 'logshield' ), count( $removed ), $list( $removed ) )
				/* translators: %d: число адресов. */
				. ( $rest > 0 ? ' ' . sprintf( __( 'Не были заблокированы: %d.', 'logshield' ), $rest ) : '' ) . $bad_note . $foreign, $foreign ? 'error' : 'success' );
		}

		if ( $op === 'hide' ) {
			$n = self::dismiss( $items );
			/* translators: %d: число скрытых строк. */
			LogShield_Admin::redirect_with_message( sprintf( __( 'Скрыто: %d. Строка вернётся, если адрес поймают снова.', 'logshield' ), $n ) . $bad_note );
		}

		// whitelist: в ручной белый список, затем снять баны, которые он теперь задевает.
		$parsed = LogShield_Whitelist::parse_entries( implode( "\n", $items ) );
		$old    = array_values( (array) ( $opts['whitelist_ips'] ?? [] ) );
		$new    = array_values( array_diff( $parsed['valid'], $old ) );
		if ( $new ) {
			$opts['whitelist_ips'] = array_merge( $old, $new );
			update_option( LOGSHIELD_OPTION, $opts );
		}
		$released = LogShield_Whitelist::release_bans();
		LogShield_Admin::redirect_with_message(
			/* translators: %s: адреса через запятую. */
			( $new ? sprintf( __( 'В белый список добавлено: %s. Эти адреса больше не будут блокироваться.', 'logshield' ), $list( $new ) ) : __( 'Адреса уже были в белом списке.', 'logshield' ) )
				. LogShield_Admin::released_note( $released ) . $bad_note,
			$released === false ? 'error' : 'success'
		);
	}

	/** Срок блокировки для сообщений: «на 30 дней» или «бессрочно». */
	private static function term_text( $days ) {
		/* translators: %s: срок, например «30 дней». */
		return $days > 0 ? sprintf( __( 'на %s', 'logshield' ), self::days_text( $days ) ) : __( 'бессрочно', 'logshield' );
	}

	/** Причина ручной блокировки: «… (вручную)». */
	private static function manual_reason( $reason ) {
		/* translators: %s: причина блокировки. */
		return sprintf( __( '%s (вручную)', 'logshield' ), $reason );
	}

	/** «1 день», «2 дня», «5 дней» (LogShield_Plugin::plural()). */
	public static function days_text( $n ) {
		$n = (int) $n;
		/* translators: %d: число дней. */
		return sprintf( LogShield_Plugin::plural( $n, _n_noop( '%d день', '%d дней', 'logshield' ), '%d дня' ), $n );
	}

	/**
	 * Последние запросы адреса для панели: до IP_REQUESTS_MAX строк из последних
	 * ip_requests_bytes() байт лога, новые сверху. Для диапазона — все адреса внутри.
	 */
	public static function ajax_ip_requests() {
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden', 403 );
		check_ajax_referer( 'logshield_ip_requests', 'nonce' );
		$ip = self::entry( isset( $_POST['ip'] ) && is_string( $_POST['ip'] ) ? sanitize_text_field( wp_unslash( $_POST['ip'] ) ) : '' );
		if ( $ip === null ) wp_send_json_error( __( 'Неверный адрес.', 'logshield' ) );
		$path = LogShield_Plugin::get_options()['log_path'];
		if ( $path === '' || ! @is_readable( $path ) || @is_dir( $path ) ) {
			wp_send_json_error( __( 'Лог недоступен — укажите путь в настройках.', 'logshield' ) );
		}
		clearstatcache();
		$size  = (int) @filesize( $path );
		$bytes = self::ip_requests_bytes();
		$start = max( 0, $size - $bytes );
		$lines = self::read_range( $path, $start, $size - $start );
		$range = strpos( $ip, '/' ) !== false;
		$bin   = $range ? false : @inet_pton( $ip );
		$out   = [];
		$more  = false;
		for ( $i = count( $lines ) - 1; $i >= 0; $i-- ) {
			// Быстрая отсечка для одиночного IPv4: адреса нет в строке — не разбираем.
			if ( ! $range && strpos( $ip, ':' ) === false && strpos( $lines[ $i ], $ip ) === false ) continue;
			$e = LogShield_Parser::parse_line( $lines[ $i ] );
			if ( ! $e ) continue;
			$hit = $range ? LogShield_IP::matches( $e['ip'], $ip ) : ( $e['ip'] === $ip || ( $bin !== false && @inet_pton( $e['ip'] ) === $bin ) );
			if ( ! $hit || LogShield_Whitelist::is_own_request( $e ) ) continue;
			if ( count( $out ) >= self::IP_REQUESTS_MAX ) { $more = true; break; }
			$out[] = [
				't'  => substr( $e['date'], 0, 20 ),
				'ip' => $e['ip'],
				'm'  => substr( $e['method'], 0, 10 ),
				'p'  => mb_substr( $e['path'], 0, 200 ),
				's'  => (int) $e['status'],
				'ua' => mb_substr( $e['user_agent'], 0, 140 ),
			];
		}
		wp_send_json_success( [
			'items' => $out,
			'more'  => $more,
			'whole' => $start === 0,
			'mb'    => round( ( $size - $start ) / 1048576, 1 ),
		] );
	}

	/** Хвост лога для дашборда. offset < 0 — последние строки; иначе новое с offset. */
	public static function ajax_tail() {
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden', 403 );
		check_ajax_referer( 'logshield_tail', 'nonce' );
		$path   = LogShield_Plugin::get_options()['log_path'];
		$offset = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : -1;
		$size   = $path === '' ? false : @filesize( $path );
		// Частый случай живого режима: файл не вырос — ответ без проверок и чтения.
		if ( $size !== false && $offset >= 0 && $offset === (int) $size ) {
			wp_send_json_success( [ 'offset' => $offset, 'lines' => [], 'reset' => false ] );
		}
		if ( $path === '' || ! @is_readable( $path ) || @is_dir( $path ) ) {
			wp_send_json_error( __( 'Лог недоступен — укажите путь в настройках.', 'logshield' ) );
		}
		$size   = (int) $size;
		$reset  = false;
		if ( $offset < 0 || $offset > $size ) {
			// Первый запрос или лог ротировали — показываем хвост заново.
			$reset  = $offset > $size;
			$start  = max( 0, $size - self::TAIL_FIRST_BYTES );
			$lines  = self::read_range( $path, $start, $size - $start );
			$lines  = array_slice( $lines, -self::TAIL_LINES );
		} else {
			// Отстали слишком сильно — пропускаем середину.
			$start = max( $offset, $size - self::TAIL_MAX_BYTES );
			$lines = self::read_range( $path, $start, $size - $start, $start === $offset );
		}
		$out = [];
		$ctx = null; // контекст «обычных» строк собирается, только если есть что разбирать
		foreach ( $lines as $line ) {
			$e = LogShield_Parser::parse_line( $line );
			if ( ! $e || LogShield_Whitelist::is_own_request( $e ) ) continue;
			if ( $ctx === null ) $ctx = self::tail_context();
			$row = [
				't'  => substr( $e['date'], 12, 8 ),
				'd'  => substr( $e['date'], 0, 6 ),
				'ip' => $e['ip'],
				'm'  => substr( $e['method'], 0, 10 ),
				'p'  => mb_substr( $e['path'], 0, 200 ),
				's'  => $e['status'],
				'ua' => mb_substr( $e['user_agent'], 0, 140 ),
			];
			if ( self::is_routine( $e, $ctx ) ) $row['n'] = 1;
			$out[] = $row;
		}
		wp_send_json_success( [ 'offset' => $size, 'lines' => $out, 'reset' => $reset ] );
	}

	/**
	 * Данные для is_routine(), один раз на запрос хвоста: белый список (тот же,
	 * что у детектора) и атакующие — помеченные в истории сканирований и
	 * заблокированные (адреса и подсети, как у чипа «Атакующие»).
	 *
	 * @param string[]|null $whitelist IP/CIDR; null — полный белый список из настроек
	 * @param string[]|null $suspects  IP/CIDR; null — из attackers() и списка банов
	 */
	public static function tail_context( $whitelist = null, $suspects = null ) {
		if ( $whitelist === null ) {
			$whitelist = LogShield_Whitelist::get_full_whitelist( (array) ( LogShield_Plugin::get_options()['whitelist_ips'] ?? [] ) );
		}
		if ( $suspects === null ) {
			$suspects = array_keys( self::banned() );
			foreach ( self::attackers() as $a ) $suspects[] = $a['ip'];
		}
		$split = function ( $list ) {
			$exact  = [];
			$ranges = [];
			foreach ( (array) $list as $x ) {
				$x = (string) $x;
				if ( strpos( $x, '/' ) !== false ) { $ranges[] = $x; continue; }
				// Ключ — двоичный вид: «2001:db8::1» и «2001:0db8:0:0::1» совпадут.
				$bin = @inet_pton( $x );
				if ( $bin !== false ) $exact[ $bin ] = true;
			}
			return [ $exact, $ranges ];
		};
		list( $wl_exact, $wl_ranges ) = $split( $whitelist );
		list( $su_exact, $su_ranges ) = $split( $suspects );
		return [
			'wl_exact'  => $wl_exact,
			'wl_ranges' => $wl_ranges,
			'su_exact'  => $su_exact,
			'su_ranges' => $su_ranges,
			'cache'     => [], // ip => [ в белом списке, атакующий ]
		];
	}

	/**
	 * «Обычная» строка хвоста — фильтр «Скрыть обычное» её прячет:
	 *  - адреса из белого списка — всё, кроме 5xx;
	 *  - остальные — ответы 1xx–3xx, кроме POST на формы входа и xmlrpc.php,
	 *    перебора пользователей, чувствительных путей и запросов атакующих.
	 * 4xx и 5xx не от белого списка видны всегда: неудачный вход, перебор
	 * пользователей через REST и флуд отвечают 200, поэтому 200 целиком не прячем.
	 * Проверки — те же методы, что у детектора; дорогие — только после дешёвых.
	 *
	 * @param array $e   строка из LogShield_Parser::parse_line()
	 * @param array $ctx результат tail_context() (кэш адресов пополняется)
	 */
	public static function is_routine( array $e, array &$ctx ) {
		$status = (int) $e['status'];
		if ( $status >= 500 ) return false;
		$ip = (string) $e['ip'];
		if ( ! isset( $ctx['cache'][ $ip ] ) ) {
			$bin = @inet_pton( $ip );
			$ctx['cache'][ $ip ] = [
				( $bin !== false && isset( $ctx['wl_exact'][ $bin ] ) ) || ( $ctx['wl_ranges'] && LogShield_IP::matches_any( $ip, $ctx['wl_ranges'] ) ),
				( $bin !== false && isset( $ctx['su_exact'][ $bin ] ) ) || ( $ctx['su_ranges'] && LogShield_IP::matches_any( $ip, $ctx['su_ranges'] ) ),
			];
		}
		list( $white, $suspect ) = $ctx['cache'][ $ip ];
		if ( $white ) return true;
		if ( $status >= 400 || $suspect ) return false;

		$norm = LogShield_Detector::normalize_path( $e['path'] );
		if ( strtoupper( (string) $e['method'] ) === 'POST' ) {
			if ( substr( $norm, -13 ) === '/wp-login.php' || substr( $norm, -11 ) === '/xmlrpc.php' ) return false;
			foreach ( LogShield_Detector::OTHER_LOGIN_PATHS as $lp ) {
				if ( strpos( $norm, $lp ) !== false ) return false;
			}
		}
		if ( LogShield_Detector::enum_target( $e['path'], $norm ) !== null ) return false;
		if ( LogShield_Detector::match_sensitive( $norm ) !== null ) return false;
		return true;
	}

	/**
	 * Строки из куска файла [start, start+len). Если start не на границе
	 * строки, первая (обрезанная) строка отбрасывается; хвост без перевода
	 * строки — тоже (допишется к следующему опросу).
	 */
	private static function read_range( $path, $start, $len, $at_line_start = false ) {
		if ( $len <= 0 ) return [];
		$fp = @fopen( $path, 'rb' );
		if ( ! $fp ) return [];
		fseek( $fp, $start );
		$data = (string) fread( $fp, $len );
		fclose( $fp );
		$lines = explode( "\n", $data );
		if ( $start > 0 && ! $at_line_start ) array_shift( $lines );
		array_pop( $lines ); // после последнего \n — пусто или неполная строка
		return array_values( array_filter( array_map( 'rtrim', $lines ), 'strlen' ) );
	}
}

// Индекс кружка в меню обновляется при каждой записи истории сканирований
// (в том числе из WP-Cron), поэтому хуки ставятся при подключении файла.
LogShield_Dashboard::init();
