<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LogShield_Htaccess {

	const BANNED_OPTION = 'logshield_banned_ips';
	const MARK_START    = '# BEGIN LogShield';
	const MARK_END      = '# END LogShield';

	/** Почему не удалась последняя запись — для сообщения в админке. */
	private static $last_error = '';

	/** Записи, которые снял (или пытался снять) последний release_whitelisted(). */
	private static $last_released = [];

	public static function last_error() {
		return self::$last_error;
	}

	public static function get_banned() {
		// ip => [ 'reason' => .., 'banned_at' => .., 'expires_at' => .. ]
		return get_option( self::BANNED_OPTION, [] );
	}

	/**
	 * Сколько записей (IP и подсетей) держать в бане. Apache разбирает блок на
	 * каждый запрос, включая статику. Замер на стенде (XAMPP, статический файл,
	 * ab -c 4, база 1,27 мс): 500 одиночных IPv4 добавляли 0,19 мс (−13 % запросов
	 * в секунду), 1000 — 0,35 мс (−22 %), 2000 — 0,67 мс (−35 %). На слабом
	 * сервере это в разы больше. 500 — около 4 суток при 15 банах за сканирование
	 * и 8 сканированиях в сутки; дольше атакующие с одного адреса обычно и не ходят.
	 * 0 или меньше — без ограничения.
	 */
	const DEFAULT_MAX_BANS = 500;

	/** Сводка вытеснений по лимиту: [ 'total', 'manual', 'last_count', 'last_at', 'last' ]. */
	const EVICTIONS_OPTION = 'logshield_ban_evictions';

	/** Записи, вытесненные лимитом при последнем ban_ips() / cleanup_expired(): ip => данные бана. */
	private static $last_evicted = [];

	public static function max_bans() {
		$n = (int) apply_filters( 'logshield_max_bans', self::DEFAULT_MAX_BANS );
		return $n > 0 ? $n : 0;
	}

	/**
	 * @param bool|null $manual бан поставлен человеком (null — определить по причине:
	 *                          дашборд пишет «вручную»). Ручные вытесняются последними.
	 */
	public static function ban_ip( $ip, $reason, $expiry_days = 0, $manual = null ) {
		if ( ! LogShield_IP::is_valid_entry( $ip ) ) return false;
		return self::ban_ips( [ $ip => $reason ], $expiry_days, $manual );
	}

	/**
	 * Банит сразу несколько IP одной записью в .htaccess (и одним бэкапом).
	 * Ключ может быть одиночным IP или диапазоном CIDR (216.73.160.0/24).
	 *
	 * Если записей больше max_bans(), лишние снимаются (см. enforce_cap());
	 * это не ошибка: метод вернёт результат записи, а снятые — в last_evicted()
	 * и в сводке evictions().
	 *
	 * @param array     $ips    ip или cidr => причина
	 * @param bool|null $manual см. ban_ip()
	 */
	public static function ban_ips( array $ips, $expiry_days = 0, $manual = null ) {
		self::$last_evicted = [];
		$banned = self::get_banned();
		if ( ! is_array( $banned ) ) $banned = [];
		$added  = false;
		foreach ( $ips as $ip => $reason ) {
			$ip = self::canonical( $ip );
			if ( $ip === null ) continue;
			if ( isset( $banned[ $ip ] ) ) continue; // уже забанен
			$banned[ $ip ] = [
				'reason'     => $reason,
				'banned_at'  => time(),
				'expires_at' => $expiry_days > 0 ? time() + ( $expiry_days * DAY_IN_SECONDS ) : 0,
				'manual'     => $manual === null ? self::looks_manual( $reason ) : (bool) $manual,
			];
			$added = true;
		}
		$evicted = self::enforce_cap( $banned );
		if ( $added || $evicted ) update_option( self::BANNED_OPTION, $banned, false );
		// Пишем и когда новых адресов нет: адрес мог остаться в списке после
		// неудачной записи, тогда файл нужно догнать до списка.
		return self::write_block( array_keys( $banned ) );
	}

	/** Что вытеснил лимит при последнем вызове: ip => [ reason, banned_at, expires_at, manual ]. */
	public static function last_evicted() {
		return self::$last_evicted;
	}

	/**
	 * Сводка вытеснений для показа в админке (хранится до clear_evictions()):
	 * total — всего снято лимитом, manual — из них ручных, last_count/last_at —
	 * последний раз, last — до 20 последних снятых адресов.
	 */
	public static function evictions() {
		$e = get_option( self::EVICTIONS_OPTION, [] );
		return is_array( $e ) ? $e : [];
	}

	public static function clear_evictions() {
		delete_option( self::EVICTIONS_OPTION );
	}

	/** Ручной ли бан. У старых записей флага нет — смотрим на причину. */
	private static function is_manual( $info ) {
		if ( ! is_array( $info ) ) return false;
		if ( isset( $info['manual'] ) ) return (bool) $info['manual'];
		return self::looks_manual( $info['reason'] ?? '' );
	}

	private static function looks_manual( $reason ) {
		return is_string( $reason ) && strpos( $reason, 'вручную' ) !== false;
	}

	/**
	 * Урезает список до max_bans(). Первыми снимаются автоматические баны, ближе
	 * всего к истечению (бессрочные — последними, среди равных — более старые);
	 * ручные — только если их одних больше лимита, в том же порядке.
	 *
	 * @return int сколько снято
	 */
	private static function enforce_cap( array &$banned ) {
		$max = self::max_bans();
		if ( $max === 0 || count( $banned ) <= $max ) return 0;

		$order = [];
		$pos   = 0;
		foreach ( $banned as $ip => $info ) {
			$exp     = is_array( $info ) ? (int) ( $info['expires_at'] ?? 0 ) : 0;
			$order[] = [
				(string) $ip,
				self::is_manual( $info ) ? 1 : 0,
				$exp > 0 ? $exp : PHP_INT_MAX,
				is_array( $info ) ? (int) ( $info['banned_at'] ?? 0 ) : 0,
				$pos++, // при равенстве — порядок добавления (usort в PHP 7 нестабилен)
			];
		}
		usort( $order, function ( $a, $b ) {
			return [ $a[1], $a[2], $a[3], $a[4] ] <=> [ $b[1], $b[2], $b[3], $b[4] ];
		} );
		$drop    = array_slice( $order, 0, count( $banned ) - $max );
		$evicted = [];
		$manual  = 0;
		foreach ( $drop as $d ) {
			$key = $d[0];
			$evicted[ $key ] = $banned[ $key ];
			$manual         += $d[1];
			unset( $banned[ $key ] );
		}
		self::$last_evicted = $evicted;

		$e = self::evictions();
		$e['total']      = (int) ( $e['total'] ?? 0 ) + count( $evicted );
		$e['manual']     = (int) ( $e['manual'] ?? 0 ) + $manual;
		$e['last_count'] = count( $evicted );
		$e['last_at']    = time();
		$e['last']       = array_slice( array_keys( $evicted ), -20 );
		update_option( self::EVICTIONS_OPTION, $e, false );
		return count( $evicted );
	}

	public static function unban_ip( $ip ) {
		$banned = self::get_banned();
		unset( $banned[ $ip ] );
		update_option( self::BANNED_OPTION, $banned, false );
		return self::write_block( array_keys( $banned ) );
	}

	public static function unban_all() {
		update_option( self::BANNED_OPTION, [], false );
		return self::write_block( [] );
	}

	/**
	 * Снимает баны, которые задевают белый список: одиночный адрес, совпадающий
	 * с записью белого списка или входящий в его диапазон, и диапазон, в который
	 * попадает адрес (или пересекается диапазон) из белого списка. Иначе
	 * сотрудник, чей новый адрес оказался в забаненной /24, получал бы 403.
	 *
	 * Блок переписывается один раз и только если что-то снято. Список банов
	 * меняется только после удачной записи: при неудаче бан остаётся и в файле,
	 * и в списке, а следующий вызов (ежедневная проверка) попробует снова.
	 *
	 * @param array $whitelist IP и CIDR
	 * @return array|false снятые записи ([] — снимать нечего, файл не трогается);
	 *                     false — запись не удалась, причина в last_error(),
	 *                     что пытались снять — в last_released().
	 */
	public static function release_whitelisted( array $whitelist ) {
		self::$last_released = [];
		$entries = [];
		foreach ( $whitelist as $w ) {
			if ( ! is_string( $w ) ) continue;
			$w = trim( $w );
			if ( $w !== '' && LogShield_IP::is_valid_entry( $w ) ) $entries[] = $w;
		}
		if ( ! $entries ) return [];
		$banned = self::get_banned();
		if ( ! is_array( $banned ) || ! $banned ) return [];

		$released = [];
		foreach ( array_keys( $banned ) as $ban ) {
			$ban = (string) $ban;
			foreach ( $entries as $w ) {
				// overlaps: IP = IP, IP внутри диапазона, диапазоны вложены друг в друга.
				if ( LogShield_IP::overlaps( $ban, $w ) ) {
					$released[] = $ban;
					break;
				}
			}
		}
		if ( ! $released ) return [];
		self::$last_released = $released;

		$rest = array_diff_key( $banned, array_flip( $released ) );
		if ( ! self::write_block( array_keys( $rest ) ) ) return false;
		update_option( self::BANNED_OPTION, $rest, false );
		return $released;
	}

	/** Что пытался снять последний вызов release_whitelisted() (и при неудачной записи тоже). */
	public static function last_released() {
		return self::$last_released;
	}

	public static function cleanup_expired() {
		self::$last_evicted = [];
		$banned = self::get_banned();
		if ( ! is_array( $banned ) ) $banned = [];
		$now     = time();
		$changed = false;
		foreach ( $banned as $ip => $info ) {
			if ( ! empty( $info['expires_at'] ) && $info['expires_at'] < $now ) {
				unset( $banned[ $ip ] );
				$changed = true;
			}
		}
		// Лимит могли уменьшить фильтром — догоняем раз в сутки.
		if ( self::enforce_cap( $banned ) ) $changed = true;
		if ( $changed ) {
			update_option( self::BANNED_OPTION, $banned, false );
			self::write_block( array_keys( $banned ) );
		}
	}

	/**
	 * Полностью пересобирает управляемый блок LogShield в .htaccess на основе
	 * актуального списка забаненных IP. Используется mod_rewrite (а не
	 * Require/Deny), чтобы блок не конфликтовал с другими правилами доступа
	 * в файле (например, с блоком All In One WP Security).
	 */
	private static function write_block( array $ips ) {
		self::$last_error = '';
		$htaccess_path    = self::get_htaccess_path();
		if ( ! $htaccess_path ) {
			self::$last_error = 'не удалось определить путь к .htaccess';
			return false;
		}
		$block = self::build_block( $ips );
		$ok    = self::write_into( $htaccess_path, $block );

		// WordPress в подпапке: старые версии писали блок в .htaccess папки
		// WordPress. Если он там есть — держим его таким же, иначе разбан его не снимет.
		$legacy = trailingslashit( wp_normalize_path( ABSPATH ) ) . '.htaccess';
		if ( wp_normalize_path( $htaccess_path ) !== $legacy ) {
			$old = self::read_file( $legacy );
			if ( $old !== false && strpos( $old, self::MARK_START ) !== false ) {
				$err = self::$last_error;
				self::write_into( $legacy, $block );
				self::$last_error = $err;
			}
		}
		return $ok;
	}

	private static function write_into( $htaccess_path, $block ) {
		$existed = file_exists( $htaccess_path );
		$content = self::read_file( $htaccess_path );
		if ( $content === false ) $content = '';

		// «# BEGIN LogShield» без «# END LogShield» (обрыв записи, ручная правка):
		// иначе новый блок встанет в начало, а осиротевший маркер останется навсегда.
		$work = self::remove_orphans( $content );

		$start_pos = strpos( $work, self::MARK_START );
		$end_pos   = $start_pos === false ? false : strpos( $work, self::MARK_END, $start_pos );

		if ( $start_pos !== false && $end_pos !== false ) {
			$end_pos_full = $end_pos + strlen( self::MARK_END );
			$before       = substr( $work, 0, $start_pos );
			$after        = substr( $work, $end_pos_full );
		} else {
			// Вставляем блок в самое начало файла, чтобы блокировка
			// срабатывала как можно раньше — до правил WordPress.
			$before = '';
			$after  = $work;
		}
		// Срезаем переводы строк в начале хвоста и ставим ровно одну пустую
		// строку-разделитель — иначе при каждой записи пустые строки копятся.
		$after = ltrim( $after, "\r\n" );
		$eol   = ( strpos( $content, "\r\n" ) !== false ) ? "\r\n" : "\n";
		if ( $eol !== "\n" ) $block = str_replace( "\n", $eol, $block );
		$new_content = $before . $block . ( $after !== '' ? $eol . $after : '' );

		if ( $new_content === $content ) return true; // уже в файле — бэкап и запись не нужны
		if ( ! self::write_file( $htaccess_path, $new_content ) ) {
			self::$last_error = 'нет прав на запись в ' . $htaccess_path;
			return false;
		}
		// Перечитываем: запись могла «пройти», но не дойти до файла (кэш ФС,
		// подмена файла другим плагином, ошибка прав без исключения).
		clearstatcache( true, $htaccess_path );
		$check = self::read_file( $htaccess_path );
		if ( $check === false || strpos( $check, $block ) === false ) {
			self::$last_error = 'после записи в ' . $htaccess_path . ' нет блока LogShield';
			return false;
		}

		// Самопроверка: сайт после записи отвечает 500 — значит, новый .htaccess
		// сломал его. Возвращаем прежнее содержимое тем же атомарным способом.
		if ( self::selfcheck_broken( $htaccess_path ) ) {
			if ( $existed ) {
				$restored = self::write_file( $htaccess_path, $content, false );
				clearstatcache( true, $htaccess_path );
				$restored = $restored && self::read_file( $htaccess_path ) === $content;
			} else {
				$restored = @unlink( $htaccess_path );
			}
			self::$last_error = $restored
				? 'после записи блока LogShield в ' . $htaccess_path . ' сайт ответил ошибкой 500; прежний .htaccess возвращён, блокировка не применена'
				: 'после записи блока LogShield в ' . $htaccess_path . ' сайт ответил ошибкой 500, а вернуть прежний .htaccess не удалось — восстановите его из wp-content/logshield-backups/';
			return false;
		}
		return true;
	}

	/**
	 * Один запрос к своему сайту после записи. true — только если ответ 500.
	 * Сетевая ошибка, таймаут и любой другой код — не повод откатывать: на
	 * хостинге запросы сайта к самому себе часто закрыты.
	 */
	private static function selfcheck_broken( $htaccess_path ) {
		if ( ! apply_filters( 'logshield_htaccess_selfcheck', true, $htaccess_path ) ) return false;
		$url = '';
		if ( class_exists( 'LogShield_Ping' ) && get_option( LogShield_Ping::OPTION, '' ) !== '' ) {
			$url = LogShield_Ping::url( false ); // секретный адрес: не кэшируется и не попадает в правила
		}
		if ( $url === '' ) $url = home_url( '/' );
		$res = wp_remote_get( $url, [
			'timeout'     => 5,
			'sslverify'   => false,
			'redirection' => 0,
			'headers'     => [ 'Cache-Control' => 'no-cache' ],
		] );
		if ( is_wp_error( $res ) ) return false;
		return (int) wp_remote_retrieve_response_code( $res ) === 500;
	}

	/**
	 * Убирает осиротевшие маркеры «# BEGIN LogShield» (после них нет «# END LogShield»
	 * раньше следующего BEGIN). Удаляются только идущие подряд строки, которые
	 * build_block() сам генерирует, в его порядке; на первой чужой строке — стоп.
	 * Открывающий <IfModule> без своего </IfModule> не удаляется: он может быть
	 * началом чужого блока, и файл остался бы с непарным тегом.
	 */
	private static function remove_orphans( $content ) {
		if ( strpos( $content, self::MARK_START ) === false ) return $content;
		$lines = preg_split( '/(?<=\n)/', $content );
		$n     = count( $lines );
		$drop  = [];
		for ( $i = 0; $i < $n; $i++ ) {
			if ( trim( $lines[ $i ] ) !== self::MARK_START ) continue;
			// Есть ли END до следующего BEGIN?
			$closed = false;
			for ( $j = $i + 1; $j < $n; $j++ ) {
				$t = trim( $lines[ $j ] );
				if ( $t === self::MARK_END ) { $closed = true; break; }
				if ( $t === self::MARK_START ) break;
			}
			if ( $closed ) { $i = $j; continue; }

			// Порядок строк build_block(): IfModule, RewriteEngine, условия, правило, /IfModule.
			$stage  = 0;     // сколько ступеней пройдено
			$open   = null;  // индекс строки <IfModule>
			$last   = $i;    // последняя строка, которую можно удалить
			$closed = false; // встретился </IfModule>
			for ( $j = $i + 1; $j < $n; $j++ ) {
				$s = self::orphan_stage( trim( $lines[ $j ] ) );
				if ( $s === 0 || $s < $stage || ( $s === $stage && $s !== 3 ) ) break;
				if ( $s === 1 ) $open = $j;
				if ( $s === 5 ) {
					if ( $open === null ) break;
					$closed = true;
				}
				$stage = $s;
				$last  = $j;
				if ( $closed ) break;
			}
			if ( $open !== null && ! $closed ) $last = $open - 1;
			for ( $k = $i; $k <= $last; $k++ ) $drop[ $k ] = true;
			$i = $last;
		}
		if ( ! $drop ) return $content;
		foreach ( $drop as $k => $_ ) unset( $lines[ $k ] );
		return implode( '', $lines );
	}

	/** Ступень строки блока LogShield (1–5) или 0, если строка не наша. */
	private static function orphan_stage( $t ) {
		if ( $t === '<IfModule mod_rewrite.c>' ) return 1;
		if ( $t === 'RewriteEngine On' ) return 2;
		if ( preg_match( '/^RewriteCond %\{REMOTE_ADDR\} \^[0-9A-Fa-f:\\\\.]+\$( \[OR\])?$/', $t ) ) return 3;
		// Прежний формат (по условию на адрес) и нынешний (списки).
		if ( preg_match( '#^RewriteCond expr "-R \'[0-9A-Fa-f:./]+\'( \|\| -R \'[0-9A-Fa-f:./]+\')*"( \[OR\])?$#', $t ) ) return 3;
		if ( preg_match( '#^RewriteCond expr "%\{REMOTE_ADDR\} -in \{\'[0-9.]+\'(, \'[0-9.]+\')*\}"( \[OR\])?$#', $t ) ) return 3;
		if ( $t === 'RewriteRule ^ - [F,L]' ) return 4;
		if ( $t === '</IfModule>' ) return 5;
		return 0;
	}

	/**
	 * Блок пишется компактно: Apache перечитывает и разбирает .htaccess на каждый
	 * запрос, включая статику. Замер на стенде (статический файл, ab, 2000 IPv4):
	 * по регулярке на адрес — 854 запроса в секунду вместо 3150 без банов, одной
	 * регуляркой-альтернативой — 1642, списком через -in — 2057.
	 *
	 * - одиночные IPv4 — списком: RewriteCond expr "%{REMOTE_ADDR} -in {'a', 'b'}".
	 *   Это точное сравнение строк, без регулярок; REMOTE_ADDR у Apache — обычная
	 *   запись IPv4 (без ведущих нулей, IPv4-mapped отдаётся как IPv4), а
	 *   FILTER_VALIDATE_IP ведущие нули не пропускает;
	 * - IPv6 и диапазоны — через -R (ipmatch): сравнение по числу, а не по
	 *   тексту, поэтому любая запись IPv6 совпадёт. Несколько через «||».
	 *
	 * Строки режутся до COND_MAX_LEN байт: предел строки конфигурации Apache — 8 КБ.
	 */
	const COND_MAX_LEN = 4000;

	private static function build_block( array $ips ) {
		if ( empty( $ips ) ) {
			return self::MARK_START . "\n" . self::MARK_END . "\n";
		}
		$lines = [ self::MARK_START, '<IfModule mod_rewrite.c>', 'RewriteEngine On' ];
		$v4    = [];
		$other = [];
		foreach ( $ips as $ip ) {
			$ip = self::canonical( $ip );
			if ( $ip === null ) continue;
			// Адрес проверен filter_var / parse_cidr: кавычек и пробелов в нём быть не может.
			if ( strpos( $ip, '/' ) === false && filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
				$v4[ $ip ] = "'{$ip}'";
			} else {
				$other[ $ip ] = "-R '{$ip}'";
			}
		}
		$conds = [];
		foreach ( self::chunk_join( array_values( $v4 ), ', ' ) as $list ) {
			$conds[] = 'RewriteCond expr "%{REMOTE_ADDR} -in {' . $list . '}"';
		}
		foreach ( self::chunk_join( array_values( $other ), ' || ' ) as $expr ) {
			$conds[] = 'RewriteCond expr "' . $expr . '"';
		}
		// RewriteRule без единого условия закрыл бы сайт для всех.
		if ( empty( $conds ) ) {
			return self::MARK_START . "\n" . self::MARK_END . "\n";
		}
		foreach ( $conds as $i => $cond ) {
			$isLast  = ( $i === count( $conds ) - 1 );
			$lines[] = $isLast ? $cond : ( $cond . ' [OR]' );
		}
		$lines[] = 'RewriteRule ^ - [F,L]';
		$lines[] = '</IfModule>';
		$lines[] = self::MARK_END;
		return implode( "\n", $lines ) . "\n";
	}

	/** Склеивает элементы через $sep в строки не длиннее COND_MAX_LEN байт. */
	private static function chunk_join( array $items, $sep ) {
		$out = [];
		$cur = '';
		foreach ( $items as $it ) {
			if ( $cur !== '' && strlen( $cur ) + strlen( $sep ) + strlen( $it ) > self::COND_MAX_LEN ) {
				$out[] = $cur;
				$cur   = '';
			}
			$cur .= ( $cur === '' ? '' : $sep ) . $it;
		}
		if ( $cur !== '' ) $out[] = $cur;
		return $out;
	}

	/** IP как есть, CIDR — в каноническом виде (биты хоста обнулены); мусор — null. */
	private static function canonical( $entry ) {
		$entry = trim( (string) $entry );
		if ( filter_var( $entry, FILTER_VALIDATE_IP ) ) return $entry;
		$c = LogShield_IP::parse_cidr( $entry );
		return $c ? $c['canonical'] : null;
	}

	/**
	 * .htaccess, который читает Apache для сайта: в корне сайта, а не обязательно
	 * в папке WordPress. Если WordPress стоит в подпапке (site_url …/wp, home …/),
	 * корень — на уровень выше ABSPATH; так же считает WordPress (get_home_path),
	 * но та функция зависит от SCRIPT_FILENAME и в cron ошибается.
	 */
	public static function get_htaccess_path() {
		return (string) apply_filters( 'logshield_htaccess_path', trailingslashit( self::site_root() ) . '.htaccess' );
	}

	public static function site_root() {
		$abs  = untrailingslashit( wp_normalize_path( ABSPATH ) );
		$home = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		$site = trim( (string) wp_parse_url( site_url(), PHP_URL_PATH ), '/' );
		if ( $home === $site ) return $abs;
		if ( $home === '' ) {
			$diff = $site;
		} elseif ( strpos( $site . '/', $home . '/' ) === 0 ) {
			$diff = substr( $site, strlen( $home ) + 1 );
		} else {
			return $abs; // нестандартная схема — оставляем папку WordPress
		}
		$suffix = '/' . $diff;
		if ( $diff !== '' && strtolower( substr( $abs, -strlen( $suffix ) ) ) === strtolower( $suffix ) ) {
			$root = substr( $abs, 0, -strlen( $suffix ) );
			if ( $root !== '' && is_dir( $root ) ) return $root;
		}
		return $abs;
	}

	/**
	 * Возвращает WP_Filesystem только если он работает напрямую (direct).
	 * В cron нет учётных данных FTP/SSH: WP_Filesystem() для ftpext/ssh2 не
	 * подключится, но оставит в $wp_filesystem объект без соединения, и любой
	 * вызов на нём падает с TypeError. В этом случае работаем через PHP напрямую.
	 */
	private static function get_wp_filesystem() {
		global $wp_filesystem;
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		if ( $wp_filesystem instanceof WP_Filesystem_Direct ) {
			return $wp_filesystem;
		}
		if ( get_filesystem_method() !== 'direct' ) {
			return null;
		}
		if ( ! WP_Filesystem() || ! ( $wp_filesystem instanceof WP_Filesystem_Direct ) ) {
			return null;
		}
		return $wp_filesystem;
	}

	private static function read_file( $path ) {
		$fs = self::get_wp_filesystem();
		if ( $fs && $fs->exists( $path ) ) {
			return $fs->get_contents( $path );
		}
		if ( file_exists( $path ) && is_readable( $path ) ) {
			return file_get_contents( $path );
		}
		return false;
	}

	/** Временный файл записи: <имя>.logshield-tmp-<случайное> рядом с целью (Apache не отдаёт .ht*). */
	const TMP_INFIX = '.logshield-tmp-';

	/**
	 * Запись .htaccess без окна, в котором файл обрезан: новое содержимое пишется
	 * во временный файл в той же папке, сверяется и переименовывается поверх цели
	 * (rename в пределах одной ФС атомарен). Если временный файл создать нельзя
	 * (папка только для чтения, сам файл — для записи), владелец сменился бы или
	 * цель — символическая ссылка, пишем на месте под LOCK_EX.
	 */
	private static function write_file( $path, $content, $backup = true ) {
		// Бэкап перед каждой записью — на случай, если что-то пойдёт не так.
		if ( $backup ) self::backup( $path );
		self::cleanup_stale_temps( $path );

		clearstatcache( true, $path );
		$exists = file_exists( $path );
		// Файл, закрытый от записи, не подменяем переименованием.
		if ( $exists && ! is_writable( $path ) ) return false;

		if ( apply_filters( 'logshield_htaccess_atomic', true, $path ) && ! ( $exists && is_link( $path ) ) ) {
			$r = self::write_atomic( $path, $content, $exists );
			if ( $r !== null ) return $r;
		}
		return self::write_in_place( $path, $content, $exists );
	}

	/** true/false — результат; null — атомарно нельзя, нужна запись на месте. */
	private static function write_atomic( $path, $content, $exists ) {
		try {
			$suffix = bin2hex( random_bytes( 6 ) );
		} catch ( Exception $e ) {
			$suffix = uniqid( '', true );
		}
		$tmp = dirname( $path ) . '/' . basename( $path ) . self::TMP_INFIX . $suffix;
		$h   = @fopen( $tmp, 'xb' );
		if ( ! $h ) return null;
		try {
			// Если PHP работает от другого пользователя, после rename файл сменил бы
			// владельца, и хозяин сайта не смог бы править его по FTP.
			if ( $exists && function_exists( 'fileowner' ) && @fileowner( $path ) !== @fileowner( $tmp ) ) {
				fclose( $h );
				$h = null;
				return null;
			}
			$ok = self::write_all( $h, $content );
			$ok = fflush( $h ) && $ok;
			fclose( $h );
			$h = null;
			// Запись во временный файл не удалась (например, кончилось место) — на
			// месте тоже не выйдет, а живой файл при этом обрезался бы.
			if ( ! $ok ) return false;
			clearstatcache( true, $tmp );
			if ( filesize( $tmp ) !== strlen( $content ) || file_get_contents( $tmp ) !== $content ) return false;

			$mode = $exists ? ( @fileperms( $path ) & 0777 ) : ( defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : 0644 );
			if ( $mode ) @chmod( $tmp, $mode );

			// В Windows rename заменяет существующий файл; может не пройти, если
			// файл в этот момент открыт, — тогда запись на месте.
			if ( ! @rename( $tmp, $path ) ) return null;
			return true;
		} finally {
			if ( $h ) fclose( $h );
			if ( file_exists( $tmp ) ) @unlink( $tmp );
		}
	}

	private static function write_in_place( $path, $content, $exists ) {
		if ( $exists ? ! is_writable( $path ) : ! is_writable( dirname( $path ) ) ) return false;
		// «c» не обрезает файл при открытии: обрезаем только под блокировкой.
		$h = @fopen( $path, 'cb' );
		if ( ! $h ) return false;
		if ( ! flock( $h, LOCK_EX ) ) {
			fclose( $h );
			return false;
		}
		$ok = ftruncate( $h, 0 ) && rewind( $h ) && self::write_all( $h, $content );
		$ok = fflush( $h ) && $ok;
		flock( $h, LOCK_UN );
		fclose( $h );
		if ( ! $exists ) @chmod( $path, defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : 0644 );
		return $ok;
	}

	private static function write_all( $h, $content ) {
		$len = strlen( $content );
		for ( $done = 0; $done < $len; $done += $w ) {
			$w = fwrite( $h, substr( $content, $done ) );
			if ( $w === false || $w === 0 ) return false;
		}
		return true;
	}

	/** Временные файлы, оставшиеся от прерванной записи (старше часа). */
	private static function cleanup_stale_temps( $path ) {
		// scandir, а не glob: в пути папки могут быть [ ] и другие символы шаблона.
		$dir    = dirname( $path );
		$prefix = basename( $path ) . self::TMP_INFIX;
		$names  = @scandir( $dir );
		if ( ! $names ) return;
		foreach ( $names as $name ) {
			if ( strpos( $name, $prefix ) !== 0 ) continue;
			$f = $dir . '/' . $name;
			if ( is_file( $f ) && @filemtime( $f ) < time() - HOUR_IN_SECONDS ) @unlink( $f );
		}
	}

	private static function backup( $path ) {
		if ( ! file_exists( $path ) ) return;
		$backup_dir = trailingslashit( WP_CONTENT_DIR ) . 'logshield-backups/';
		if ( ! file_exists( $backup_dir ) ) {
			@mkdir( $backup_dir, 0755, true );
			// Закрываем папку с бэкапами от прямого веб-доступа.
			@file_put_contents( $backup_dir . '.htaccess', "Require all denied\n" );
			@file_put_contents( $backup_dir . 'index.php', "<?php // silence\n" );
		}
		// Несколько записей в одну секунду не должны затирать друг друга.
		$base        = $backup_dir . 'htaccess-' . gmdate( 'Y-m-d-His' );
		$backup_file = $base . '.bak';
		for ( $n = 2; file_exists( $backup_file ); $n++ ) {
			$backup_file = $base . '-' . $n . '.bak';
		}
		@copy( $path, $backup_file );

		// Оставляем только последние 10 бэкапов.
		$files = glob( $backup_dir . 'htaccess-*.bak' );
		if ( $files && count( $files ) > 10 ) {
			usort( $files, function ( $a, $b ) { return filemtime( $a ) <=> filemtime( $b ); } );
			$to_delete = array_slice( $files, 0, count( $files ) - 10 );
			foreach ( $to_delete as $f ) @unlink( $f );
		}
	}
}
