<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LogShield_Whitelist {

	// IP сотрудников: ip => [ 't' => время последнего визита, 'u' => [ логин => время ] ]
	// (в старых версиях значением было просто время — читается тоже).
	const ADMIN_IPS_OPTION  = 'logshield_admin_ips';
	const MAX_LOGINS_PER_IP = 5;
	const SERVER_IPS_OPTION = 'logshield_server_ips'; // IP самого сервера: ip => время
	const ADMIN_IP_TTL_DAYS = 30;
	// Как часто обновлять отметку времени для уже известного IP (не писать в БД на каждый запрос).
	const TOUCH_INTERVAL    = HOUR_IN_SECONDS;

	/**
	 * Кого считать сотрудником: по умолчанию всех, кто может писать записи
	 * (автор, редактор, администратор). Их обращения к admin-ajax.php
	 * (heartbeat, редактор блоков) легко набирают сотни запросов.
	 */
	public static function trusted_capability() {
		return apply_filters( 'logshield_trusted_capability', 'edit_posts' );
	}

	/**
	 * Определяет IP текущего посетителя (используется только в контексте
	 * админки WP — для авто-добавления в белый список, а не для анализа лога).
	 */
	public static function get_client_ip() {
		foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ] as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$ip = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) )[0] );
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) return $ip;
			}
		}
		return '';
	}

	/**
	 * При успешном входе сотрудника запоминаем его IP как доверенный.
	 */
	public static function on_login( $user_login, $user ) {
		if ( $user instanceof WP_User && user_can( $user, self::trusted_capability() ) ) {
			$ip = self::get_client_ip();
			if ( $ip ) self::add_admin_ip( $ip, false, $user->user_login );
		}
	}

	/**
	 * На каждом запросе (дёшево: опции автозагружаются, запись — не чаще раза в час):
	 * - сотрудник, вошедший по cookie «запомнить меня», тоже попадает в whitelist —
	 *   события wp_login у него не бывает, а IP мог смениться;
	 * - IP самого сервера: SERVER_ADDR и адрес, с которого WordPress стучится
	 *   сам к себе в wp-cron.php (за NAT это может быть другой адрес).
	 */
	public static function on_init() {
		if ( ! empty( $_SERVER['SERVER_ADDR'] ) ) {
			self::add_server_ip( sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) ) );
		}
		if ( self::is_verified_cron_loopback() && ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			self::add_server_ip( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) );
		}
		if ( is_user_logged_in() && current_user_can( self::trusted_capability() ) ) {
			$ip = self::get_client_ip();
			if ( $ip ) self::add_admin_ip( $ip, true, wp_get_current_user()->user_login );
		}
	}

	/**
	 * Запрос — это настоящий вызов wp-cron.php, запущенный самим WordPress:
	 * в адресе передан ключ doing_wp_cron, совпадающий с транзиентом doing_cron,
	 * который WordPress только что выставил. Угадать ключ снаружи нельзя
	 * (это microtime с 22 знаками), поэтому подделать «сервер» не получится.
	 * User-Agent «WordPress/…» намеренно не используется — его подделать легко.
	 */
	private static function is_verified_cron_loopback() {
		if ( ! function_exists( 'wp_doing_cron' ) || ! wp_doing_cron() ) return false;
		if ( empty( $_GET['doing_wp_cron'] ) ) return false;
		$key       = sanitize_text_field( wp_unslash( $_GET['doing_wp_cron'] ) );
		$transient = get_transient( 'doing_cron' );
		return is_string( $transient ) && $transient !== '' && hash_equals( $transient, $key );
	}

	/**
	 * Запоминает IP сотрудника и его логин. С $throttle запись в БД не чаще
	 * раза в час на IP — но новый логин с того же адреса пишется сразу.
	 */
	public static function add_admin_ip( $ip, $throttle = false, $login = '' ) {
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) return;
		$login = (string) $login;
		$list  = get_option( self::ADMIN_IPS_OPTION, [] );
		if ( ! is_array( $list ) ) $list = [];
		$entry = self::admin_entry( $list[ $ip ] ?? null );
		if ( $throttle && $entry['t'] > time() - self::TOUCH_INTERVAL && ( $login === '' || isset( $entry['u'][ $login ] ) ) ) return;
		$entry['t'] = time();
		if ( $login !== '' ) {
			$entry['u'][ $login ] = time();
			arsort( $entry['u'] );
			$entry['u'] = array_slice( $entry['u'], 0, self::MAX_LOGINS_PER_IP, true );
		}
		$list[ $ip ] = $entry;
		update_option( self::ADMIN_IPS_OPTION, $list );
	}

	/** Запись об IP сотрудника в текущем формате (старый формат — просто время). */
	private static function admin_entry( $v ) {
		if ( is_array( $v ) ) return [ 't' => (int) ( $v['t'] ?? 0 ), 'u' => (array) ( $v['u'] ?? [] ) ];
		return [ 't' => (int) $v, 'u' => [] ];
	}

	/**
	 * Активные IP сотрудников с логинами: ip => [ логины, свежие первыми ].
	 * Пустой список логинов — адрес записан до того, как плагин стал их хранить.
	 */
	public static function get_admin_users() {
		$cutoff = time() - ( self::ADMIN_IP_TTL_DAYS * DAY_IN_SECONDS );
		$out    = [];
		foreach ( (array) get_option( self::ADMIN_IPS_OPTION, [] ) as $ip => $v ) {
			$e = self::admin_entry( $v );
			if ( $e['t'] < $cutoff ) continue;
			arsort( $e['u'] );
			$out[ (string) $ip ] = array_map( 'strval', array_keys( $e['u'] ) );
		}
		return $out;
	}

	public static function add_server_ip( $ip ) {
		self::touch( self::SERVER_IPS_OPTION, $ip, true );
	}

	private static function touch( $option, $ip, $throttle ) {
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) return;
		$list = get_option( $option, [] );
		if ( ! is_array( $list ) ) $list = [];
		if ( $throttle && isset( $list[ $ip ] ) && $list[ $ip ] > time() - self::TOUCH_INTERVAL ) return;
		$list[ $ip ] = time();
		update_option( $option, $list );
	}

	public static function get_admin_ips() {
		return self::active( self::ADMIN_IPS_OPTION );
	}

	public static function get_server_ips() {
		return self::active( self::SERVER_IPS_OPTION );
	}

	private static function active( $option ) {
		$list   = (array) get_option( $option, [] );
		$cutoff = time() - ( self::ADMIN_IP_TTL_DAYS * DAY_IN_SECONDS );
		$active = [];
		foreach ( $list as $ip => $v ) {
			if ( self::admin_entry( $v )['t'] >= $cutoff ) $active[] = (string) $ip;
		}
		return $active;
	}

	/**
	 * Полный список IP и диапазонов CIDR, которые никогда не должны попасть в бан:
	 * сотрудники WP (по факту входа), сам сервер, ручной whitelist из настроек, localhost.
	 */
	public static function get_full_whitelist( $manual_whitelist = [] ) {
		$list = array_merge(
			[ '127.0.0.1', '::1' ],
			self::get_server_ips(),
			self::get_admin_ips(),
			(array) $manual_whitelist
		);
		return array_values( array_unique( array_filter( $list ) ) );
	}

	/**
	 * Фильтрация "собственных" запросов плагина, чтобы они не попадали
	 * под анализ и не искажали статистику (например, ручной запуск
	 * сканирования из админки или сама страница настроек).
	 */
	public static function is_own_request( array $entry ) {
		$path = isset( $entry['path'] ) ? $entry['path'] : '';
		if ( $path === '' ) return false;
		if ( stripos( $path, 'admin-post.php' ) !== false && stripos( $path, 'logshield' ) !== false ) return true;
		if ( stripos( $path, 'page=logshield' ) !== false ) return true;
		// Опрос хвоста лога с дашборда (живой режим).
		if ( stripos( $path, 'admin-ajax.php' ) !== false && stripos( $path, 'action=logshield_' ) !== false ) return true;
		return false;
	}
}
