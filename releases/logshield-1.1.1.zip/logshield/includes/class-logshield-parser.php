<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LogShield_Parser {

	// Формат: [домен] IP ident user [date] "METHOD path proto" status size "referer" "ua"
	// Ведущая часть до "[date]" разбирается отдельно, т.к. количество полей
	// перед датой отличается: 3 поля (IP ident user) в стандартном Apache
	// Combined Log Format, либо 4 поля (domain IP ident user), если лог
	// объединяет несколько виртуальных хостов (частый вариант на shared-хостингах).
	const LOG_PREFIX_REGEX = '/^(.+?)\s+\[([^\]]+)\]\s+"(\S*)\s*(\S*)\s*(\S*)"\s+(\d{3})\s+(\d+|-)\s*"([^"]*)"\s+"([^"]*)"/';

	public static function parse_line( $line ) {
		$line = trim( $line );
		if ( $line === '' ) return null;
		if ( ! preg_match( self::LOG_PREFIX_REGEX, $line, $m ) ) return null;

		$prefix_tokens = preg_split( '/\s+/', trim( $m[1] ) );
		if ( count( $prefix_tokens ) < 3 ) return null;

		// Последние 3 поля перед [date] — это всегда IP, ident, user.
		// Всё, что осталось перед ними (обычно ничего или одно слово) — домен.
		$user   = array_pop( $prefix_tokens );
		$ident  = array_pop( $prefix_tokens );
		$ip     = array_pop( $prefix_tokens );
		$domain = implode( ' ', $prefix_tokens );

		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) return null;

		return [
			'domain'     => $domain,
			'ip'         => $ip,
			'ident'      => $ident,
			'user'       => $user,
			'date'       => $m[2],
			'method'     => $m[3],
			'path'       => $m[4],
			'protocol'   => $m[5],
			'status'     => (int) $m[6],
			'size'       => ( $m[7] === '-' ) ? 0 : (int) $m[7],
			'referer'    => $m[8],
			'user_agent' => $m[9],
			'raw'        => $line,
		];
	}

	/**
	 * Читает новую часть файла лога начиная с offset, с ограничением объёма
	 * за один запуск (чтобы не создавать нагрузку на слабом сервере).
	 *
	 * Возвращает:
	 *   [ 'lines' => [...], 'new_offset' => int, 'rotated' => bool, 'size' => int ]
	 *   либо [ 'error' => 'not_readable' | 'cannot_open' | 'read_error' ]
	 */
	public static function read_chunk( $path, $offset, $max_bytes ) {
		clearstatcache();
		$size = @filesize( $path );
		if ( $size === false ) {
			return [ 'error' => 'not_readable' ];
		}

		$rotated = false;
		if ( $offset > $size ) {
			// Файл был ротирован или обрезан — начинаем заново.
			$offset  = 0;
			$rotated = true;
		}

		if ( $offset >= $size ) {
			return [ 'lines' => [], 'new_offset' => $size, 'rotated' => $rotated, 'size' => $size ];
		}

		$fp = @fopen( $path, 'rb' );
		if ( ! $fp ) {
			return [ 'error' => 'cannot_open' ];
		}
		fseek( $fp, $offset );

		$toRead = min( $size - $offset, $max_bytes );
		$data   = fread( $fp, $toRead );
		fclose( $fp );

		if ( $data === false ) {
			return [ 'error' => 'read_error' ];
		}

		// Не разрезаем последнюю строку: если в прочитанном куске нет ни одного
		// завершённого перевода строки, откладываем анализ до следующего запуска
		// (к тому моменту строка, скорее всего, будет дописана).
		$lastNl = strrpos( $data, "\n" );
		if ( $lastNl === false ) {
			return [ 'lines' => [], 'new_offset' => $offset, 'rotated' => $rotated, 'size' => $size ];
		}

		$newOffset = $offset + $lastNl + 1;
		$data      = substr( $data, 0, $lastNl );

		$lines = explode( "\n", $data );
		$lines = array_filter( array_map( 'trim', $lines ), function ( $l ) { return $l !== ''; } );

		return [ 'lines' => array_values( $lines ), 'new_offset' => $newOffset, 'rotated' => $rotated, 'size' => $size ];
	}
}
