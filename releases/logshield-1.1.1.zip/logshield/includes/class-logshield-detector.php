<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LogShield_Detector {

	const OFFSET_OPTION  = 'logshield_offset_state'; // [ 'path' => .., 'offset' => .. ]
	const SCANLOG_OPTION = 'logshield_scan_log';

	/**
	 * Чувствительные пути: метка => регулярка по нормализованному пути
	 * (без query string, URL-декодирован, в нижнем регистре).
	 * Регулярки привязаны к сегментам пути, а не к подстроке: '/catalog/actuators'
	 * или '/.github/' не совпадут. xmlrpc.php сюда намеренно не входит — к нему
	 * легально ходят Jetpack, мобильное приложение WP и пингбеки; подбор пароля
	 * через xmlrpc ловится правилом brute-force.
	 */
	const SENSITIVE_PATTERNS = [
		'.env'           => '~(^|/)\.env([._-][^/]*)?$~',
		'.git/.svn'      => '~(^|/)\.(git|svn|hg)(/|$)~',
		'wp-config'      => '~(^|/)wp-config(\.php)?[^/]*$~',
		'.htpasswd'      => '~(^|/)\.ht(passwd|access)$~',
		'phpmyadmin'     => '~(^|/)(phpmyadmin[^/]*|myadmin|pma)(/|$)~',
		'дамп БД'        => '~(^|/)[^/]+\.sql(\.(gz|zip|bz2|tar))?$~',
		'config.php'     => '~^/(config|configuration)\.php$~',
		'server-status'  => '~^/server-(status|info)(/|$)~',
		'actuator'       => '~^/actuator(/|$)~',
		'веб-шелл'       => '~(^|/)(shell|c99|r57|wso|alfa)\.php$~',
		'.aws'           => '~(^|/)\.aws(/|$)~',
	];

	/**
	 * Входы не на WordPress (самописные формы): неудача — только 401/403.
	 * xmlrpc.php сюда не входит: Jetpack и приложение WP ходят к нему постоянно,
	 * а по ответу (всегда 200 или 403 от .htaccess) неудачу не отличить.
	 */
	const OTHER_LOGIN_PATHS = [ '/login', 'admin/login', 'auth/login', 'signin' ];

	/**
	 * Фоновые запросы WordPress: heartbeat и редактор (admin-ajax.php), планировщик
	 * (wp-cron.php). У сотрудника в админке их сотни — в частоту не считаются,
	 * если ответ успешный (атака на admin-ajax обычно получает 400).
	 */
	const BACKGROUND_PATHS_RE = '~/(wp-admin/admin-ajax|wp-cron)\.php$~';

	/**
	 * Служебные файлы в корне сайта, которые браузеры и легальные краулеры
	 * (рекламные, WebPageTest, Safari, поисковики) запрашивают «на всякий случай».
	 * 404 на них — не признак сканирования и не считается ошибкой.
	 */
	const SERVICE_PATHS_RE = '~^/(\.well-known/.*|ads\.txt|app-ads\.txt|sellers\.json|llms(-full)?\.txt|robots\.txt|humans\.txt|security\.txt|dsrdelete\.json|favicon\.ico|apple-touch-icon[^/]*\.png|browserconfig\.xml|site\.webmanifest|manifest\.json)$~';

	/**
	 * Перебор пользователей: REST-список пользователей WordPress. Вместе с ?author=N
	 * (см. enum_target()) сканеры так узнают логины перед подбором пароля.
	 */
	const USERS_REST_RE = '~^/wp/v2/users(/\d+)?/?$~';

	public static function run() {
		$opts     = LogShield_Plugin::get_options();
		$log_path = $opts['log_path'];

		$summary = [
			'time'    => time(),
			'ok'      => false,
			'lines'   => 0,
			'ips_seen'=> 0,
			'flagged' => [],
			'applied' => [],
			'dry_run' => (bool) $opts['dry_run'],
			'message' => '',
		];

		$found_note = '';
		if ( empty( $log_path ) ) {
			// Путь не указан — ищем сами (только если лог явно относится к сайту).
			$auto = LogShield_LogFinder::best_confident();
			if ( $auto ) {
				$log_path         = $auto;
				$opts['log_path'] = $auto;
				update_option( LOGSHIELD_OPTION, $opts );
				$found_note = 'Путь к логу найден автоматически: ' . $auto . '. ';
			}
		}

		if ( empty( $log_path ) || ! is_readable( $log_path ) ) {
			$summary['message'] = empty( $log_path )
				? 'Путь к логу не указан, и найти лог автоматически не удалось. Укажите путь в настройках.'
				: 'Файл лога недоступен для чтения: ' . $log_path;
			self::log_run( $summary );
			return $summary;
		}

		$offset_state = get_option( self::OFFSET_OPTION, [ 'path' => '', 'offset' => 0 ] );

		if ( $offset_state['path'] !== $log_path ) {
			// Новый (или первый) путь к логу: фиксируем текущий конец файла
			// и НЕ анализируем всю историю разом — только новые записи начиная
			// со следующего запуска. Это важно для слабого сервера с большими логами.
			clearstatcache();
			$size = @filesize( $log_path );
			update_option( self::OFFSET_OPTION, [ 'path' => $log_path, 'offset' => $size ], false );

			$summary['ok']      = true;
			$summary['message'] = $found_note . sprintf(
				'Путь к логу зафиксирован. Стартовая позиция: %d байт. Анализ новых записей начнётся со следующего запуска.',
				$size
			);
			self::log_run( $summary );
			return $summary;
		}

		$offset    = (int) $offset_state['offset'];
		$max_bytes = max( 1, (int) $opts['max_read_mb'] ) * 1024 * 1024;
		$chunk     = LogShield_Parser::read_chunk( $log_path, $offset, $max_bytes );

		if ( isset( $chunk['error'] ) ) {
			$summary['message'] = 'Ошибка чтения лога: ' . $chunk['error'];
			self::log_run( $summary );
			return $summary;
		}

		update_option( self::OFFSET_OPTION, [ 'path' => $log_path, 'offset' => $chunk['new_offset'] ], false );

		if ( empty( $chunk['lines'] ) ) {
			$summary['ok']      = true;
			$summary['message'] = $found_note . ( $chunk['rotated']
				? 'Лог был ротирован — позиция сброшена, новые записи будут проанализированы в следующий раз.'
				: 'Новых записей в логе не найдено.' );
			self::log_run( $summary );
			return $summary;
		}

		$whitelist = LogShield_Whitelist::get_full_whitelist( (array) $opts['whitelist_ips'] );
		$summary   = self::analyze( $chunk['lines'], $opts, $whitelist ) + $summary;
		// Уже забаненные адреса продолжают стучаться и получают 403 — в логе
		// они снова выглядят как атака. Повторно не помечаем и не уведомляем.
		$summary['flagged'] = self::without_banned( $summary['flagged'], array_keys( LogShield_Htaccess::get_banned() ) );
		$flagged            = $summary['flagged'];
		$summary['types']   = array_intersect_key( $summary['types'], $flagged );
		LogShield_Stats::record( $summary['hourly'], $summary['types'] );
		// Страна и сеть: только для информации, на баны не влияет.
		LogShield_IPInfo::remember( $summary['noisy'], array_keys( $flagged ) );
		unset( $summary['hourly'], $summary['noisy'] ); // в историю сканирований не нужно

		$applied = [];
		if ( ! $opts['dry_run'] && ! empty( $flagged ) ) {
			$to_ban = [];
			foreach ( $flagged as $ip => $reasons ) {
				$to_ban[ $ip ] = implode( '; ', $reasons );
			}
			// Одна запись в .htaccess на всё сканирование.
			LogShield_Htaccess::ban_ips( $to_ban, (int) $opts['ban_expiry_days'] );
			$applied = array_keys( $to_ban );
		}

		$summary['ok']       = true;
		$summary['applied']  = $applied;
		$summary['message']  = $found_note . sprintf(
			'Обработано %d строк, %d IP, обнаружено подозрительных: %d%s',
			$summary['lines'],
			$summary['ips_seen'],
			count( $flagged ),
			$opts['dry_run'] ? ' (тестовый режим — блокировка не применена)' : ''
		);

		self::log_run( $summary );
		LogShield_Notifier::notify( $summary, $opts );

		return $summary;
	}

	/**
	 * Применяет правила к строкам лога. Ничего не пишет и не банит.
	 *
	 * @param string[] $lines     строки access_log
	 * @param array    $opts      настройки плагина
	 * @param string[] $whitelist IP и диапазоны CIDR, которые не трогаем
	 * @return array [ 'lines' => int, 'ips_seen' => int, 'flagged' => [ ip|cidr => [причины] ] ]
	 */
	public static function analyze( array $lines, array $opts, array $whitelist ) {
		$wl_exact  = [];
		$wl_ranges = [];
		foreach ( $whitelist as $w ) {
			if ( strpos( $w, '/' ) !== false ) $wl_ranges[] = $w; else $wl_exact[ $w ] = true;
		}
		$wl_cache = [];

		$ip_records = [];
		$processed  = 0;
		$hourly     = [];  // час => счётчики для графиков (весь трафик, и whitelist тоже)
		$hour_ips   = [];
		$hour_cache = [];

		foreach ( $lines as $line ) {
			$entry = LogShield_Parser::parse_line( $line );
			if ( ! $entry ) continue;
			if ( LogShield_Whitelist::is_own_request( $entry ) ) continue;

			$ip     = $entry['ip'];
			$status = $entry['status'];
			$norm   = self::normalize_path( $entry['path'] );
			$failed = self::is_failed_login( $entry, $norm );

			$hour = self::hour_of( $entry['date'], $hour_cache );
			if ( $hour !== null ) {
				if ( ! isset( $hourly[ $hour ] ) ) $hourly[ $hour ] = [ 'req' => 0, 'e4' => 0, 'e5' => 0, 'fails' => 0, 'ips' => 0 ];
				$hourly[ $hour ]['req']++;
				if ( $status >= 500 ) $hourly[ $hour ]['e5']++;
				elseif ( $status >= 400 ) $hourly[ $hour ]['e4']++;
				if ( $failed ) $hourly[ $hour ]['fails']++;
				$hour_ips[ $hour ][ $ip ] = true;
			}

			if ( ! isset( $wl_cache[ $ip ] ) ) {
				$wl_cache[ $ip ] = isset( $wl_exact[ $ip ] ) || ( $wl_ranges && LogShield_IP::matches_any( $ip, $wl_ranges ) );
			}
			if ( $wl_cache[ $ip ] ) continue;

			$processed++;

			if ( ! isset( $ip_records[ $ip ] ) ) {
				$ip_records[ $ip ] = [ 'total' => 0, 'rate' => 0, 'errors' => 0, 'error_paths' => [], 'login_fails' => 0, 'sensitive' => [], 'enum' => [], 'bad' => 0 ];
			}
			$r =& $ip_records[ $ip ];

			$r['total']++;
			if ( $status >= 400 || ! preg_match( self::BACKGROUND_PATHS_RE, $norm ) ) {
				$r['rate']++;
			}
			$is_error = $status >= 400 && ! ( $status < 500 && preg_match( self::SERVICE_PATHS_RE, $norm ) );
			if ( $is_error ) $r['errors']++;
			// Сканер перебирает несуществующие пути; обычный посетитель и
			// поисковый бот ходят по живым страницам и ошибок почти не получают.
			if ( $is_error && $status < 500 ) $r['error_paths'][ $norm ] = true;

			$label = self::match_sensitive( $norm );
			if ( $label !== null ) {
				$r['sensitive'][ $norm ] = $label; // считаем разные пути, не повторы
			}

			$enum = self::enum_target( $entry['path'], $norm );
			if ( $enum !== null ) $r['enum'][ $enum ] = true; // разные ID, не повторы

			if ( $failed ) $r['login_fails']++;
			if ( $failed || $is_error ) $r['bad']++;
			unset( $r );
		}

		$flagged = [];
		$types   = [];
		foreach ( $ip_records as $ip => $r ) {
			$reasons = [];
			$t       = [];

			if ( $r['rate'] >= $opts['rpm_threshold'] ) {
				$reasons[] = sprintf( 'высокая частота запросов (%d за период сканирования)', $r['rate'] );
				$t[]       = 'rate';
			}
			if ( $r['login_fails'] >= $opts['brute_attempts'] ) {
				$reasons[] = sprintf( 'подбор пароля (%d неудачных входов)', $r['login_fails'] );
				$t[]       = 'brute';
			}
			$error_paths = count( $r['error_paths'] );
			if ( $error_paths >= $opts['scan_unique_paths'] && $r['total'] >= $opts['scan_min_requests'] ) {
				$reasons[] = sprintf( 'сканирование (%d несуществующих или закрытых путей)', $error_paths );
				$t[]       = 'scan';
			}
			if ( $r['total'] >= $opts['error_rate_min_requests'] ) {
				$err_pct = ( $r['errors'] / $r['total'] ) * 100;
				if ( $err_pct >= $opts['error_rate_pct'] ) {
					$reasons[] = sprintf( 'высокий процент ошибок (%.0f%%)', $err_pct );
					$t[]       = 'errors';
				}
			}
			// Одно случайное обращение — не повод для бана: сканеры перебирают
			// много разных чувствительных путей за раз.
			$sensitive_count = count( $r['sensitive'] );
			if ( $sensitive_count >= max( 1, (int) $opts['sensitive_min_hits'] ) ) {
				$examples  = array_slice( array_keys( $r['sensitive'] ), 0, 3 );
				$reasons[] = sprintf(
					'обращения к чувствительным путям (%d: %s%s)',
					$sensitive_count,
					implode( ', ', $examples ),
					$sensitive_count > 3 ? ', …' : ''
				);
				$t[]       = 'sensitive';
			}

			// Перебор авторов (?author=1, 2, 3…) и REST-списка пользователей —
			// разведка логинов перед подбором пароля. Посетитель открывает
			// автора по ссылке /author/имя/, а не по номерам подряд.
			$enum_count = count( $r['enum'] );
			if ( $enum_count >= max( 1, (int) $opts['enum_min_hits'] ) ) {
				$reasons[] = sprintf( 'перебор пользователей (%d: %s%s)', $enum_count, implode( ', ', array_slice( array_keys( $r['enum'] ), 0, 3 ) ), $enum_count > 3 ? ', …' : '' );
				$t[]       = 'enum';
			}

			if ( ! empty( $reasons ) ) {
				$flagged[ $ip ] = $reasons;
				$types[ $ip ]   = $t;
			}
		}

		// Распределённый подбор пароля: каждый адрес подсети делает немного
		// попыток (меньше порога на один IP), но вместе их много.
		$subnets = [];
		foreach ( $ip_records as $ip => $r ) {
			if ( $r['login_fails'] < 1 ) continue;
			$net = LogShield_IP::subnet_of( $ip );
			if ( $net === null ) continue;
			if ( ! isset( $subnets[ $net ] ) ) $subnets[ $net ] = [ 'ips' => [], 'fails' => 0 ];
			$subnets[ $net ]['ips'][] = $ip;
			$subnets[ $net ]['fails'] += $r['login_fails'];
		}
		$min_ips      = max( 2, (int) $opts['subnet_min_ips'] );
		$min_attempts = max( 1, (int) $opts['subnet_min_attempts'] );
		foreach ( $subnets as $net => $sn ) {
			if ( count( $sn['ips'] ) < $min_ips || $sn['fails'] < $min_attempts ) continue;
			// В подсети сотрудник или сервер — диапазон не баним (отдельные IP — по своим правилам).
			$protected = false;
			foreach ( $whitelist as $w ) {
				if ( LogShield_IP::overlaps( $w, $net ) ) { $protected = true; break; }
			}
			if ( $protected ) continue;

			$flagged[ $net ] = [ sprintf(
				'распределённый подбор пароля (%d IP из подсети, %d неудачных входов)',
				count( $sn['ips'] ),
				$sn['fails']
			) ];
			$types[ $net ] = [ 'subnet' ];
			// Адреса внутри диапазона отдельно банить не нужно.
			foreach ( $sn['ips'] as $ip ) unset( $flagged[ $ip ], $types[ $ip ] );
		}

		foreach ( $hour_ips as $hour => $set ) $hourly[ $hour ]['ips'] = count( $set );

		// Настойчивые адреса: много ошибок или неудачных входов. Для них (и для
		// пойманных) определяются страна и сеть — только для информации.
		$noisy    = [];
		$min_hits = max( 1, (int) apply_filters( 'logshield_ipinfo_min_hits', LogShield_IPInfo::MIN_HITS ) );
		foreach ( $ip_records as $ip => $r ) {
			if ( $r['bad'] >= $min_hits ) $noisy[ $ip ] = $r['bad'];
		}

		return [
			'lines'    => $processed,
			'ips_seen' => count( $ip_records ),
			'flagged'  => $flagged,
			'types'    => $types,   // ip|cidr => [ ключ из LogShield_Stats::TYPES ]
			'hourly'   => $hourly,  // час (unix) => [ req, e4, e5, fails, ips ]
			'noisy'    => $noisy,   // ip => ошибок и неудачных входов (≥ порога)
		];
	}

	/**
	 * «12/Nov/2026:00:03:12 +0300» → начало часа (unix). Кэш по часу и поясу:
	 * DateTime на каждую строку дорог.
	 */
	private static function hour_of( $date, array &$cache ) {
		$key = substr( $date, 0, 14 ) . substr( $date, 20 );
		if ( ! array_key_exists( $key, $cache ) ) {
			$dt            = DateTime::createFromFormat( 'd/M/Y:H:i:s O', substr( $date, 0, 14 ) . ':00:00' . substr( $date, 20 ) );
			$cache[ $key ] = $dt ? $dt->getTimestamp() : null;
		}
		return $cache[ $key ];
	}

	/**
	 * Неудачная попытка входа.
	 *
	 * WordPress на неверный пароль отвечает 200 (форма с ошибкой), на успешный
	 * вход — 302. Поэтому для POST на wp-login.php в любом каталоге
	 * (/wp-login.php, /wp/wp-login.php, /wordpress/… — пробы получают 404)
	 * неудача — любой ответ, кроме перенаправления. Остальные действия формы
	 * (lostpassword, register, postpass) не считаются.
	 */
	public static function is_failed_login( array $entry, $norm ) {
		$status = (int) $entry['status'];
		if ( strtoupper( $entry['method'] ) === 'POST' && substr( $norm, -13 ) === '/wp-login.php' ) {
			$query = (string) parse_url( 'http://x' . $entry['path'], PHP_URL_QUERY );
			parse_str( $query, $q );
			$action = isset( $q['action'] ) && is_string( $q['action'] ) ? strtolower( $q['action'] ) : 'login';
			if ( $action !== 'login' ) return false;
			return $status < 300 || $status >= 400;
		}
		if ( $status === 401 || $status === 403 ) {
			foreach ( self::OTHER_LOGIN_PATHS as $lp ) {
				if ( strpos( $norm, $lp ) !== false ) return true;
			}
		}
		return false;
	}

	/**
	 * Путь из лога → вид для сравнения: без query string и фрагмента,
	 * URL-декодирован (сканеры шлют %2e вместо точки), нижний регистр,
	 * повторные слэши схлопнуты.
	 */
	public static function normalize_path( $path ) {
		$path = (string) $path;
		$cut  = strcspn( $path, '?#' );
		$path = substr( $path, 0, $cut );
		$path = strtolower( rawurldecode( $path ) );
		$path = preg_replace( '~/{2,}~', '/', $path );
		if ( $path === '' || $path[0] !== '/' ) $path = '/' . $path;
		return $path;
	}

	/**
	 * Цель перебора пользователей или null: «author=7» для ?author=7 на любой
	 * странице, «users», «users/3» для REST (/wp-json/wp/v2/users и ?rest_route=).
	 * /author/имя/ не считается — это обычная ссылка с сайта.
	 */
	public static function enum_target( $path, $norm ) {
		$query = (string) parse_url( 'http://x' . $path, PHP_URL_QUERY );
		$q     = [];
		if ( $query !== '' ) parse_str( $query, $q );
		if ( isset( $q['author'] ) && is_string( $q['author'] ) && preg_match( '~^\d+$~', $q['author'] ) ) {
			return 'author=' . (int) $q['author'];
		}
		$route = null;
		if ( strpos( $norm, '/wp-json/' ) !== false ) {
			$route = substr( $norm, strpos( $norm, '/wp-json/' ) + 8 );
		} elseif ( isset( $q['rest_route'] ) && is_string( $q['rest_route'] ) ) {
			$route = strtolower( $q['rest_route'] );
		}
		if ( $route !== null && preg_match( self::USERS_REST_RE, $route, $m ) ) {
			// /users/me — свой профиль в редакторе; у сотрудников он в whitelist, но на всякий случай.
			return 'users' . ( isset( $m[1] ) ? $m[1] : '' );
		}
		return null;
	}

	/** Метка чувствительного пути или null. Ожидает результат normalize_path(). */
	public static function match_sensitive( $norm_path ) {
		foreach ( self::SENSITIVE_PATTERNS as $label => $re ) {
			if ( preg_match( $re, $norm_path ) ) return $label;
		}
		return null;
	}

	private static function log_run( $summary ) {
		$log = get_option( self::SCANLOG_OPTION, [] );
		array_unshift( $log, $summary );
		$log = array_slice( $log, 0, 50 );
		update_option( self::SCANLOG_OPTION, $log, false );
	}

	/** Убирает из найденных то, что уже покрыто банами (IP или диапазоном). */
	public static function without_banned( array $flagged, array $banned ) {
		if ( empty( $banned ) ) return $flagged;
		$exact  = array_flip( $banned );
		$ranges = array_values( array_filter( $banned, function ( $b ) { return strpos( $b, '/' ) !== false; } ) );
		foreach ( array_keys( $flagged ) as $key ) {
			$key = (string) $key;
			if ( isset( $exact[ $key ] ) ) { unset( $flagged[ $key ] ); continue; }
			if ( ! $ranges ) continue;
			// Одиночный IP внутри забаненной сети или подсеть внутри более широкой.
			foreach ( $ranges as $r ) {
				$inside = strpos( $key, '/' ) === false
					? LogShield_IP::matches( $key, $r )
					: ( LogShield_IP::overlaps( $key, $r ) && LogShield_IP::parse_cidr( $key )['bits'] >= LogShield_IP::parse_cidr( $r )['bits'] );
				if ( $inside ) { unset( $flagged[ $key ] ); break; }
			}
		}
		return $flagged;
	}

	public static function get_scan_log() {
		return get_option( self::SCANLOG_OPTION, [] );
	}
}
