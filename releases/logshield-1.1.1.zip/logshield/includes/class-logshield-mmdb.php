<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Минимальный читатель баз MaxMind DB (.mmdb) на чистом PHP — без расширений
 * и Composer. Файл не грузится в память целиком: дерево и данные читаются
 * через fseek, поэтому поиск одного IP — несколько десятков чтений по 6–8 байт.
 *
 * Формат: https://maxmind.github.io/MaxMind-DB/
 */
class LogShield_MMDB {

	const META_MARKER = "\xAB\xCD\xEFMaxMind.com";

	private $fp;
	private $node_count;
	private $record_size;
	private $node_bytes;
	private $ip_version;
	private $data_start;
	private $ipv4_start = null;
	public  $metadata = [];

	/** @return self|null null, если файла нет или это не mmdb */
	public static function open( $path ) {
		if ( ! is_readable( $path ) ) return null;
		try {
			return new self( $path );
		} catch ( Exception $e ) {
			return null;
		}
	}

	private function __construct( $path ) {
		$this->fp = fopen( $path, 'rb' );
		if ( ! $this->fp ) throw new Exception( 'open' );
		$size = filesize( $path );
		$tail = min( $size, 128 * 1024 );
		fseek( $this->fp, $size - $tail );
		$buf = fread( $this->fp, $tail );
		$pos = strrpos( $buf, self::META_MARKER );
		if ( $pos === false ) throw new Exception( 'no metadata' );
		$meta_start = $size - $tail + $pos + strlen( self::META_MARKER );
		// Метаданные — обычная структура формата; указатели в них не используются.
		$this->data_start = $meta_start;
		list( $meta ) = $this->decode( $meta_start );
		$this->metadata    = is_array( $meta ) ? $meta : [];
		$this->node_count  = (int) ( $meta['node_count'] ?? 0 );
		$this->record_size = (int) ( $meta['record_size'] ?? 0 );
		$this->ip_version  = (int) ( $meta['ip_version'] ?? 0 );
		if ( ! $this->node_count || ! in_array( $this->record_size, [ 24, 28, 32 ], true ) ) throw new Exception( 'bad metadata' );
		$this->node_bytes = $this->record_size / 4; // две записи на узел
		$this->data_start = $this->node_count * $this->node_bytes + 16;
	}

	public function __destruct() {
		if ( $this->fp ) fclose( $this->fp );
	}

	/** Запись для IP или null, если адреса в базе нет. */
	public function get( $ip ) {
		$packed = @inet_pton( $ip );
		if ( $packed === false ) return null;
		$bits = strlen( $packed ) * 8;
		if ( $bits === 128 && $this->ip_version === 4 ) return null;

		$node = 0;
		$i    = 0;
		if ( $bits === 32 && $this->ip_version === 6 ) {
			$node = $this->ipv4_start();
		}
		for ( ; $i < $bits && $node < $this->node_count; $i++ ) {
			$bit  = ( ord( $packed[ $i >> 3 ] ) >> ( 7 - ( $i & 7 ) ) ) & 1;
			$node = $this->record( $node, $bit );
		}
		if ( $node === $this->node_count ) return null; // нет данных
		if ( $node < $this->node_count ) return null;   // дерево короче адреса — битая база
		$offset = $this->data_start + ( $node - $this->node_count - 16 );
		list( $value ) = $this->decode( $offset );
		return $value;
	}

	/** Узел, с которого начинаются IPv4-адреса в дереве IPv6 (96 нулевых бит). */
	private function ipv4_start() {
		if ( $this->ipv4_start !== null ) return $this->ipv4_start;
		$node = 0;
		for ( $i = 0; $i < 96 && $node < $this->node_count; $i++ ) $node = $this->record( $node, 0 );
		return $this->ipv4_start = $node;
	}

	private function record( $node, $bit ) {
		fseek( $this->fp, $node * $this->node_bytes );
		$b = fread( $this->fp, $this->node_bytes );
		switch ( $this->record_size ) {
			case 24:
				return self::uint( substr( $b, $bit ? 3 : 0, 3 ) );
			case 28:
				$mid = ord( $b[3] );
				return $bit
					? ( ( $mid & 0x0F ) << 24 ) | self::uint( substr( $b, 4, 3 ) )
					: ( ( $mid & 0xF0 ) << 20 ) | self::uint( substr( $b, 0, 3 ) );
			default:
				return self::uint( substr( $b, $bit ? 4 : 0, 4 ) );
		}
	}

	private static function uint( $bytes ) {
		$n = 0;
		for ( $i = 0, $l = strlen( $bytes ); $i < $l; $i++ ) $n = ( $n << 8 ) | ord( $bytes[ $i ] );
		return $n;
	}

	private function read( $offset, $len ) {
		if ( $len <= 0 ) return '';
		fseek( $this->fp, $offset );
		return (string) fread( $this->fp, $len );
	}

	/** @return array [ значение, смещение после него ] */
	private function decode( $offset ) {
		$ctrl = ord( $this->read( $offset++, 1 ) );
		$type = $ctrl >> 5;

		if ( $type === 1 ) { // указатель
			$ss  = ( $ctrl >> 3 ) & 3;
			$vvv = $ctrl & 7;
			$b   = $this->read( $offset, $ss + 1 );
			$offset += $ss + 1;
			switch ( $ss ) {
				case 0: $p = ( $vvv << 8 ) | ord( $b[0] ); break;
				case 1: $p = ( ( $vvv << 16 ) | self::uint( $b ) ) + 2048; break;
				case 2: $p = ( ( $vvv << 24 ) | self::uint( $b ) ) + 526336; break;
				default: $p = self::uint( $b );
			}
			list( $value ) = $this->decode( $this->data_start + $p );
			return [ $value, $offset ];
		}

		if ( $type === 0 ) { // расширенный тип
			$type = 7 + ord( $this->read( $offset++, 1 ) );
		}

		$size = $ctrl & 0x1F;
		if ( $size >= 29 ) {
			$extra = $size - 28;
			$n     = self::uint( $this->read( $offset, $extra ) );
			$offset += $extra;
			$size = [ 1 => 29, 2 => 285, 3 => 65821 ][ $extra ] + $n;
		}

		switch ( $type ) {
			case 2: // строка
				return [ $this->read( $offset, $size ), $offset + $size ];
			case 3: // double
				$v = unpack( 'E', $this->read( $offset, 8 ) );
				return [ $v[1], $offset + 8 ];
			case 4: // байты
				return [ $this->read( $offset, $size ), $offset + $size ];
			case 5: case 6: case 8: case 9: case 10: // целые
				$n = self::uint( $this->read( $offset, $size ) );
				if ( $type === 8 && $size === 4 && $n >= 0x80000000 ) $n -= 0x100000000;
				return [ $n, $offset + $size ];
			case 7: // map
				$map = [];
				for ( $i = 0; $i < $size; $i++ ) {
					list( $k, $offset ) = $this->decode( $offset );
					list( $v, $offset ) = $this->decode( $offset );
					$map[ (string) $k ] = $v;
				}
				return [ $map, $offset ];
			case 11: // массив
				$arr = [];
				for ( $i = 0; $i < $size; $i++ ) {
					list( $arr[], $offset ) = $this->decode( $offset );
				}
				return [ $arr, $offset ];
			case 14: // boolean: значение — сам размер
				return [ $size !== 0, $offset ];
			case 15: // float
				$v = unpack( 'G', $this->read( $offset, 4 ) );
				return [ $v[1], $offset + 4 ];
			default: // 12 — контейнер кэша, 13 — маркер конца: в данных не встречаются
				return [ null, $offset + $size ];
		}
	}
}
