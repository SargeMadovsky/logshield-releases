<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Работа с IP и диапазонами CIDR (IPv4 и IPv6).
 */
class LogShield_IP {

	/** Одиночный IP или диапазон вида 1.2.3.0/24, 2001:db8::/48. */
	public static function is_valid_entry( $entry ) {
		$entry = (string) $entry;
		if ( filter_var( $entry, FILTER_VALIDATE_IP ) ) return true;
		return self::parse_cidr( $entry ) !== null;
	}

	public static function is_cidr( $entry ) {
		return strpos( (string) $entry, '/' ) !== false && self::parse_cidr( $entry ) !== null;
	}

	/**
	 * Разбирает CIDR и приводит адрес сети к каноническому виду
	 * (биты хоста обнуляются: 1.2.3.77/24 → 1.2.3.0/24).
	 *
	 * @return array|null [ 'net' => binary, 'bits' => int, 'canonical' => string ]
	 */
	public static function parse_cidr( $cidr ) {
		$parts = explode( '/', (string) $cidr );
		if ( count( $parts ) !== 2 || ! ctype_digit( $parts[1] ) ) return null;
		$bin = @inet_pton( $parts[0] );
		if ( $bin === false ) return null;
		$max  = strlen( $bin ) * 8;
		$bits = (int) $parts[1];
		if ( $bits < 1 || $bits > $max ) return null;
		$net = self::mask( $bin, $bits );
		return [ 'net' => $net, 'bits' => $bits, 'canonical' => inet_ntop( $net ) . '/' . $bits ];
	}

	/** Входит ли IP в диапазон (или совпадает с одиночным IP). */
	public static function matches( $ip, $entry ) {
		if ( $ip === $entry ) return true;
		if ( strpos( $entry, '/' ) === false ) {
			// Разные записи одного IPv6-адреса (2001:db8::1 и 2001:0db8:0:0:0:0:0:1).
			$a = @inet_pton( $ip );
			$b = @inet_pton( $entry );
			return $a !== false && $a === $b;
		}
		$c   = self::parse_cidr( $entry );
		$bin = @inet_pton( $ip );
		if ( ! $c || $bin === false || strlen( $bin ) !== strlen( $c['net'] ) ) return false;
		return self::mask( $bin, $c['bits'] ) === $c['net'];
	}

	public static function matches_any( $ip, array $entries ) {
		foreach ( $entries as $e ) {
			if ( self::matches( $ip, $e ) ) return true;
		}
		return false;
	}

	/** Пересекаются ли две записи (IP или CIDR): одна содержит другую. */
	public static function overlaps( $a, $b ) {
		$pa = self::as_range( $a );
		$pb = self::as_range( $b );
		if ( ! $pa || ! $pb || strlen( $pa['net'] ) !== strlen( $pb['net'] ) ) return false;
		$bits = min( $pa['bits'], $pb['bits'] );
		return self::mask( $pa['net'], $bits ) === self::mask( $pb['net'], $bits );
	}

	private static function as_range( $entry ) {
		if ( strpos( (string) $entry, '/' ) !== false ) return self::parse_cidr( $entry );
		$bin = @inet_pton( (string) $entry );
		return $bin === false ? null : [ 'net' => $bin, 'bits' => strlen( $bin ) * 8 ];
	}

	/** Подсеть, к которой относится IP: /24 для IPv4, /64 для IPv6. */
	public static function subnet_of( $ip ) {
		$bin = @inet_pton( $ip );
		if ( $bin === false ) return null;
		$bits = strlen( $bin ) === 4 ? 24 : 64;
		return inet_ntop( self::mask( $bin, $bits ) ) . '/' . $bits;
	}

	private static function mask( $bin, $bits ) {
		$out = '';
		$len = strlen( $bin );
		for ( $i = 0; $i < $len; $i++ ) {
			$b    = max( 0, min( 8, $bits - $i * 8 ) );
			$m    = $b === 0 ? 0 : ( 0xFF << ( 8 - $b ) ) & 0xFF;
			$out .= chr( ord( $bin[ $i ] ) & $m );
		}
		return $out;
	}
}
