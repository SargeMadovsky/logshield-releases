<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Обновления из публичного репозитория сборок на GitHub
 * (SargeMadovsky/logshield-releases), а не с wordpress.org.
 *
 * В заголовке плагина указан Update URI с хостом github.com, поэтому WordPress
 * не спрашивает о нём wordpress.org, а вызывает фильтр update_plugins_github.com.
 * Отвечаем данными из update.json. Дальше всё штатно: кнопка «Обновить»,
 * автообновление, окно «Подробнее» (plugins_api).
 *
 * Сборки кладёт GitHub Actions по тегу v* (.github/workflows/release.yml).
 */
class LogShield_Updater {

	const MANIFEST  = 'https://raw.githubusercontent.com/SargeMadovsky/logshield-releases/main/update.json';
	const CACHE     = 'logshield_update_manifest';
	const SLUG      = 'logshield';
	const CACHE_TTL = 6 * HOUR_IN_SECONDS;
	const FAIL_TTL  = HOUR_IN_SECONDS; // GitHub не ответил — не долбим его на каждой странице

	public static function init() {
		add_filter( 'update_plugins_github.com', [ __CLASS__, 'check' ], 10, 3 );
		add_filter( 'plugins_api', [ __CLASS__, 'info' ], 20, 3 );
		add_filter( 'upgrader_source_selection', [ __CLASS__, 'fix_folder' ], 10, 4 );
		// «Проверить снова» на странице обновлений — читаем update.json заново.
		add_action( 'load-update-core.php', [ __CLASS__, 'maybe_flush' ] );
	}

	public static function basename() {
		// Фильтр — для тестов (плагин в папке с другим именем).
		return (string) apply_filters( 'logshield_plugin_basename', plugin_basename( LOGSHIELD_FILE ) );
	}

	/**
	 * Рабочая копия из git (как на стенде: плагин подключён ссылкой на репозиторий).
	 * Обновление стёрло бы её и заменило архивом — такие копии не обновляем.
	 */
	public static function is_dev_checkout() {
		$dev = file_exists( LOGSHIELD_DIR . '.git' );
		return (bool) apply_filters( 'logshield_is_dev_checkout', $dev );
	}

	/** Фильтр update_plugins_github.com: данные о последней версии или false. */
	public static function check( $update, $plugin_data, $plugin_file ) {
		if ( $plugin_file !== self::basename() ) return $update;
		if ( self::is_dev_checkout() ) return $update;

		$m = self::manifest();
		if ( ! $m ) return $update;

		return [
			'slug'         => self::SLUG,
			'version'      => $m['version'],
			'url'          => 'https://github.com/SargeMadovsky/logshield-releases',
			'package'      => $m['download_url'],
			'tested'       => $m['tested'] ?? '',
			'requires_php' => $m['requires_php'] ?? '',
			'icons'        => [],
		];
	}

	/** Окно «Подробнее» / «Посмотреть детали версии». */
	public static function info( $result, $action, $args ) {
		if ( $action !== 'plugin_information' || ! isset( $args->slug ) || $args->slug !== self::SLUG ) return $result;
		$m = self::manifest();
		if ( ! $m ) return $result;

		$data = get_plugin_data( LOGSHIELD_FILE, false, false );
		return (object) [
			'name'          => 'LogShield',
			'slug'          => self::SLUG,
			'version'       => $m['version'],
			'author'        => 'LogShield',
			'homepage'      => 'https://github.com/SargeMadovsky/logshield-releases',
			'requires'      => $m['requires'] ?? '',
			'requires_php'  => $m['requires_php'] ?? '',
			'tested'        => $m['tested'] ?? '',
			'last_updated'  => $m['released'] ?? '',
			'download_link' => $m['download_url'],
			'sections'      => [
				'description' => '<p>' . esc_html( $data['Description'] ?? '' ) . '</p>',
				'changelog'   => self::changelog_html( $m['changelog'] ?? '' ),
			],
		];
	}

	/**
	 * Архив распаковывается в папку «logshield». Если плагин стоит в папке с другим
	 * именем (например, «logshield-main»), WordPress поставил бы новую версию рядом,
	 * а старая осталась бы. Переименовываем распакованное под текущую папку.
	 */
	public static function fix_folder( $source, $remote_source, $upgrader, $hook_extra = [] ) {
		if ( empty( $hook_extra['plugin'] ) || $hook_extra['plugin'] !== self::basename() ) return $source;
		global $wp_filesystem;
		$want = trailingslashit( $remote_source ) . dirname( self::basename() ) . '/';
		if ( untrailingslashit( $source ) === untrailingslashit( $want ) ) return $source;
		if ( ! $wp_filesystem || ! $wp_filesystem->move( $source, $want, true ) ) {
			return new WP_Error( 'logshield_rename', 'Не удалось переименовать папку обновления LogShield.' );
		}
		return $want;
	}

	public static function maybe_flush() {
		if ( isset( $_GET['force-check'] ) && current_user_can( 'update_plugins' ) ) delete_site_transient( self::CACHE );
	}

	/**
	 * update.json из репозитория сборок, с кэшем.
	 *
	 * @return array|null [ version, download_url, requires, requires_php, tested, released, changelog ]
	 */
	public static function manifest() {
		$cached = get_site_transient( self::CACHE );
		if ( is_array( $cached ) ) return $cached['ok'] ? $cached['data'] : null;

		$url  = (string) apply_filters( 'logshield_update_manifest_url', self::MANIFEST );
		$res  = wp_remote_get( $url, [ 'timeout' => 10, 'headers' => [ 'Accept' => 'application/json' ] ] );
		$data = null;
		if ( ! is_wp_error( $res ) && (int) wp_remote_retrieve_response_code( $res ) === 200 ) {
			$data = self::validate( json_decode( wp_remote_retrieve_body( $res ), true ) );
		}
		set_site_transient( self::CACHE, [ 'ok' => (bool) $data, 'data' => $data ], $data ? self::CACHE_TTL : self::FAIL_TTL );
		return $data;
	}

	/** Проверяет update.json: версия вида 1.2.3 и ссылка на zip в репозитории сборок по https. */
	public static function validate( $m ) {
		if ( ! is_array( $m ) || ! isset( $m['version'], $m['download_url'] ) ) return null;
		if ( ! is_string( $m['version'] ) || ! preg_match( '~^\d+(\.\d+){1,3}$~', $m['version'] ) ) return null;
		$prefix = (string) apply_filters( 'logshield_update_package_prefix', 'https://raw.githubusercontent.com/SargeMadovsky/logshield-releases/' );
		if ( ! is_string( $m['download_url'] ) || strpos( $m['download_url'], $prefix ) !== 0 || substr( $m['download_url'], -4 ) !== '.zip' ) return null;
		$out = [ 'version' => $m['version'], 'download_url' => $m['download_url'] ];
		foreach ( [ 'requires', 'requires_php', 'tested', 'released', 'changelog' ] as $k ) {
			if ( isset( $m[ $k ] ) && is_string( $m[ $k ] ) ) $out[ $k ] = $m[ $k ];
		}
		return $out;
	}

	/** Список изменений: строки «- текст» → <ul>, остальное — абзацы. Всё экранируется. */
	public static function changelog_html( $text ) {
		$html = '';
		$list = false;
		foreach ( preg_split( '~\R~', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( $line === '' ) continue;
			if ( preg_match( '~^[-*]\s+(.*)$~', $line, $mm ) ) {
				if ( ! $list ) { $html .= '<ul>'; $list = true; }
				$html .= '<li>' . esc_html( $mm[1] ) . '</li>';
				continue;
			}
			if ( $list ) { $html .= '</ul>'; $list = false; }
			$html .= '<h4>' . esc_html( $line ) . '</h4>';
		}
		if ( $list ) $html .= '</ul>';
		return $html !== '' ? $html : '<p>Нет описания изменений.</p>';
	}
}
