<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Поиск access_log на сервере.
 *
 * Перебирает типичные места (папка над сайтом, как в старом log_proxy.php,
 * cPanel, ISPmanager, Plesk, /var/log/…) и проверяет каждый файл: читает
 * хвост и считает, сколько строк распознаёт парсер. Ничего не пишет.
 */
class LogShield_LogFinder {

	const SAMPLE_BYTES = 32768; // сколько байт с конца файла читать для проверки
	const MAX_GLOB     = 40;    // не больше стольких файлов из одной маски

	/**
	 * Найденные логи, лучший первым.
	 *
	 * @return array[] [ path, size, mtime, sampled, parsed, own_domain, near_site ]
	 */
	public static function find() {
		$found = [];
		foreach ( self::candidates() as $path => $near_site ) {
			$info = self::inspect( $path );
			if ( ! $info || ! $info['looks_like_log'] ) continue;
			$info['near_site'] = $near_site;
			$found[]           = $info;
		}
		usort( $found, function ( $a, $b ) {
			// Свой домен в строках лога, затем рядом с сайтом, затем свежее, затем больше.
			return [ $b['own_domain'], $b['near_site'], $b['mtime'], $b['size'] ]
				<=> [ $a['own_domain'], $a['near_site'], $a['mtime'], $a['size'] ];
		} );
		return $found;
	}

	/**
	 * Лучший кандидат, если в нём можно быть уверенным: в строках есть домен
	 * сайта или файл лежит рядом с сайтом. Общий лог сервера без признаков
	 * сайта сам не выбирается — там чужие посетители.
	 */
	public static function best_confident() {
		foreach ( self::find() as $f ) {
			if ( $f['own_domain'] || $f['near_site'] ) return $f['path'];
		}
		return null;
	}

	/**
	 * Проверка одного файла. null — файла нет или он не читается.
	 */
	public static function inspect( $path ) {
		$path = (string) $path;
		if ( $path === '' || ! @is_file( $path ) || ! @is_readable( $path ) ) return null;
		$size  = (int) @filesize( $path );
		$mtime = (int) @filemtime( $path );

		$sampled = 0;
		$parsed  = 0;
		$domain  = 0;
		$host    = self::host();
		if ( $size > 0 ) {
			$fp = @fopen( $path, 'rb' );
			if ( ! $fp ) return null;
			$from = max( 0, $size - self::SAMPLE_BYTES );
			fseek( $fp, $from );
			$data = (string) fread( $fp, self::SAMPLE_BYTES );
			fclose( $fp );
			$lines = preg_split( '/\r?\n/', $data );
			if ( $from > 0 ) array_shift( $lines ); // первая строка обрезана
			foreach ( $lines as $line ) {
				if ( trim( $line ) === '' ) continue;
				$sampled++;
				$e = LogShield_Parser::parse_line( $line );
				if ( ! $e ) continue;
				$parsed++;
				if ( $host !== '' && ( self::same_host( $e['domain'], $host ) || stripos( $e['referer'], '//' . $host ) !== false ) ) {
					$domain++;
				}
			}
		}

		return [
			'path'           => $path,
			'size'           => $size,
			'mtime'          => $mtime,
			'sampled'        => $sampled,
			'parsed'         => $parsed,
			'own_domain'     => $domain > 0,
			// Пустой файл тоже годится: лог могли только что ротировать.
			'looks_like_log' => $sampled === 0 ? self::log_like_name( $path ) : ( $parsed >= 1 && $parsed * 2 >= $sampled ),
			'near_site'      => false,
		];
	}

	/**
	 * Пути для проверки: path => лежит ли рядом с сайтом (в папке сайта,
	 * над ней или в домашнем каталоге).
	 */
	public static function candidates() {
		$host  = self::host();
		$hosts = array_unique( array_filter( [ $host, preg_replace( '/^www\./', '', $host ), 'www.' . preg_replace( '/^www\./', '', $host ) ] ) );

		$near = [];
		$site = self::norm( ABSPATH );
		$near[] = $site;
		$near[] = dirname( $site );
		$near[] = dirname( $site, 2 );
		if ( ! empty( $_SERVER['DOCUMENT_ROOT'] ) ) {
			$doc    = self::norm( $_SERVER['DOCUMENT_ROOT'] );
			$near[] = $doc;
			$near[] = dirname( $doc );
		}
		$home = self::home_dir();
		if ( $home ) $near[] = $home;
		$near = array_values( array_unique( array_filter( $near, function ( $d ) {
			// Корень диска и /home целиком не перебираем.
			return $d !== '' && $d !== '/' && $d !== '.' && ! preg_match( '~^[A-Za-z]:/?$~', $d ) && $d !== '/home';
		} ) ) );

		$out = [];
		$add = function ( $p, $is_near ) use ( &$out ) {
			$p = self::norm( $p );
			if ( ! isset( $out[ $p ] ) || $is_near ) $out[ $p ] = $is_near;
		};

		$names = [ 'access_log', 'access.log', 'access-log', 'logs/access_log', 'logs/access.log', 'log/access_log', 'log/access.log', 'apache/logs/access.log' ];
		foreach ( $hosts as $h ) {
			foreach ( [ "logs/$h.access.log", "logs/$h-access.log", "logs/$h.log", "logs/{$h}_access.log", "access-logs/$h", "access-logs/$h-ssl_log", "log/$h.access.log" ] as $n ) {
				$names[] = $n;
			}
		}
		foreach ( $near as $dir ) {
			foreach ( $names as $n ) $add( "$dir/$n", true );
			// Как в старом log_proxy.php: всё, что похоже на лог, прямо в папке.
			foreach ( [ "$dir/*access*log*", "$dir/*access*", "$dir/logs/*", "$dir/log/*", "$dir/access-logs/*" ] as $mask ) {
				foreach ( self::glob( $mask ) as $p ) $add( $p, true );
			}
		}

		// Системные места панелей и дистрибутивов.
		$system = [
			'/var/log/apache2/access.log', '/var/log/apache2/access_log', '/var/log/httpd/access_log', '/var/log/httpd/access.log',
			'/var/log/nginx/access.log', '/usr/local/apache/logs/access_log',
		];
		foreach ( $hosts as $h ) {
			$system[] = "/var/www/httpd-logs/$h.access.log";          // ISPmanager
			$system[] = "/var/www/vhosts/$h/logs/access_log";         // Plesk
			$system[] = "/var/www/vhosts/$h/logs/access_ssl_log";
			$system[] = "/var/www/vhosts/system/$h/logs/access_log";
			$system[] = "/var/www/vhosts/system/$h/logs/access_ssl_log";
			$system[] = "/usr/local/apache/domlogs/$h";               // cPanel (root)
			$system[] = "/usr/local/apache/domlogs/$h-ssl_log";
			$system[] = "/var/log/apache2/$h-access.log";
			$system[] = "/var/log/apache2/$h.access.log";
			$system[] = "/var/log/httpd/$h-access_log";
			$system[] = "/var/log/nginx/$h.access.log";
			$system[] = "/var/log/nginx/$h-access.log";
		}
		foreach ( $system as $p ) $add( $p, false );

		// Свои места можно добавить фильтром: path => true (рядом с сайтом) / false.
		$out = (array) apply_filters( 'logshield_log_candidates', $out );

		// Убираем архивы и старые ротации: access_log.1, .gz и т.п.
		foreach ( array_keys( $out ) as $p ) {
			if ( preg_match( '~\.(gz|bz2|xz|zip|zst|tar|\d+)$~i', $p ) || preg_match( '~\.(php|html?|js|css|json|txt|bak|old)$~i', $p ) ) {
				unset( $out[ $p ] );
			}
		}
		return $out;
	}

	/** Состояние текущего пути для страницы настроек. */
	public static function describe( $path ) {
		if ( $path === '' ) return [ 'ok' => false, 'text' => 'Путь не указан.' ];
		if ( ! @file_exists( $path ) ) {
			return [ 'ok' => false, 'text' => 'Файл не найден (или закрыт ограничением open_basedir).' ];
		}
		if ( ! @is_readable( $path ) ) return [ 'ok' => false, 'text' => 'Файл есть, но PHP не может его читать (права доступа).' ];
		if ( @is_dir( $path ) ) return [ 'ok' => false, 'text' => 'Это папка, а не файл.' ];
		$i = self::inspect( $path );
		if ( ! $i ) return [ 'ok' => false, 'text' => 'Файл не открывается.' ];
		$text = size_format( $i['size'] ) . ', изменён ' . wp_date( 'd.m.Y H:i', $i['mtime'] );
		if ( $i['sampled'] === 0 ) return [ 'ok' => true, 'text' => $text . '. Файл пуст — возможно, лог только что ротировали.' ];
		if ( ! $i['looks_like_log'] ) {
			return [ 'ok' => false, 'text' => $text . '. Строки не похожи на access_log в формате Apache Combined (распознано ' . $i['parsed'] . ' из ' . $i['sampled'] . ').' ];
		}
		return [ 'ok' => true, 'text' => $text . '. Строки распознаются (' . $i['parsed'] . ' из ' . $i['sampled'] . ' в конце файла).' ];
	}

	private static function glob( $mask ) {
		$r = @glob( $mask, GLOB_NOSORT );
		if ( ! is_array( $r ) ) return [];
		$r = array_filter( $r, function ( $p ) { return @is_file( $p ); } );
		return array_slice( array_values( $r ), 0, self::MAX_GLOB );
	}

	private static function home_dir() {
		$h = getenv( 'HOME' );
		if ( ! $h && function_exists( 'posix_getpwuid' ) && function_exists( 'posix_geteuid' ) ) {
			$pw = @posix_getpwuid( posix_geteuid() );
			$h  = $pw['dir'] ?? '';
		}
		if ( ! $h && preg_match( '~^(/home\d*/[^/]+(?:/[^/]+)?)/~', self::norm( ABSPATH ) . '/', $m ) ) {
			// /home/c/cXXXX/… (Timeweb) или /home/user/…: берём первые уровни.
			$h = $m[1];
		}
		return $h ? self::norm( $h ) : '';
	}

	private static function host() {
		return strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	}

	private static function same_host( $a, $host ) {
		$a = strtolower( preg_replace( '/:\d+$/', '', (string) $a ) );
		return $a !== '' && preg_replace( '/^www\./', '', $a ) === preg_replace( '/^www\./', '', $host );
	}

	private static function log_like_name( $path ) {
		return (bool) preg_match( '~access~i', basename( $path ) );
	}

	private static function norm( $p ) {
		$p = str_replace( '\\', '/', (string) $p );
		return $p === '/' ? $p : rtrim( $p, '/' );
	}
}
