<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Дашборд «LogShield → Дашборд»: метрики, графики по часам, атакующие адреса,
 * история сканирований и хвост лога (с живым режимом, пока страница открыта).
 *
 * Внешних библиотек и CDN нет: графики рисуются в SVG своим скриптом.
 */
class LogShield_Dashboard {

	const TAIL_FIRST_BYTES = 32768; // хвост при открытии страницы
	const TAIL_MAX_BYTES   = 65536; // максимум нового за один опрос
	const TAIL_LINES       = 80;
	const BACKFILL_OPTION  = 'logshield_backfilled'; // путь лога, по которому уже строили историю

	const SEEN_META = 'logshield_seen_at'; // когда пользователь последний раз открывал дашборд

	/**
	 * Сколько новых атакующих (IP и подсетей) нашли сканирования с момента,
	 * когда текущий пользователь последний раз открывал дашборд.
	 * Уже забаненные сюда не попадают — их убирает run() до записи в историю.
	 */
	public static function unseen_count( $user_id = 0 ) {
		$user_id = $user_id ?: get_current_user_id();
		$seen    = (int) get_user_meta( $user_id, self::SEEN_META, true );
		if ( ! $seen ) {
			// Первый раз: не пугать всей историей, считать с установки отметки.
			update_user_meta( $user_id, self::SEEN_META, time() );
			return 0;
		}
		$new = [];
		foreach ( LogShield_Detector::get_scan_log() as $run ) {
			if ( (int) ( $run['time'] ?? 0 ) <= $seen ) break; // история — от новых к старым
			foreach ( array_keys( (array) ( $run['flagged'] ?? [] ) ) as $ip ) $new[ (string) $ip ] = true;
		}
		return count( $new );
	}

	public static function mark_seen( $user_id = 0 ) {
		update_user_meta( $user_id ?: get_current_user_id(), self::SEEN_META, time() );
	}

	public static function enqueue() {
		$ver = LOGSHIELD_VERSION . '-' . @filemtime( LOGSHIELD_DIR . 'assets/dashboard.js' );
		wp_enqueue_style( 'logshield-dashboard', LOGSHIELD_URL . 'assets/dashboard.css', [], $ver );
		wp_enqueue_script( 'logshield-dashboard', LOGSHIELD_URL . 'assets/dashboard.js', [], $ver, [ 'in_footer' => true, 'strategy' => 'defer' ] );
		LogShield_IPInfo::enqueue();
		wp_add_inline_script( 'logshield-dashboard', 'window.LogShieldData = ' . wp_json_encode( self::data() ) . ';', 'before' );
	}

	/** Данные для скрипта: статистика за 30 дней и настройки живого хвоста. */
	private static function data() {
		$stats = [];
		foreach ( LogShield_Stats::get() as $hour => $h ) {
			$stats[] = [ (int) $hour, $h['req'], $h['e4'], $h['e5'], $h['fails'], $h['ips'], (object) $h['flag'] ];
		}
		$suspects = [];
		foreach ( self::attackers() as $a ) $suspects[] = $a['ip'];
		return [
			'now'      => time(),
			'stats'    => $stats,
			'types'    => LogShield_Stats::TYPES,
			'banned'   => count( LogShield_Htaccess::get_banned() ),
			'suspects' => $suspects,
			'tail'     => [
				'url'   => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'logshield_tail' ),
			],
		];
	}

	/**
	 * Атакующие: заблокированные и помеченные в последних сканированиях.
	 *
	 * @return array[] [ ip, reason, types, last, runs, banned, expires ]
	 */
	public static function attackers() {
		$banned = LogShield_Htaccess::get_banned();
		$out    = [];
		foreach ( LogShield_Detector::get_scan_log() as $run ) {
			foreach ( (array) ( $run['flagged'] ?? [] ) as $ip => $reasons ) {
				$ip = (string) $ip;
				if ( isset( $out[ $ip ] ) ) { $out[ $ip ]['runs']++; continue; }
				$out[ $ip ] = [
					'ip'      => $ip,
					'reason'  => implode( '; ', (array) $reasons ),
					'types'   => (array) ( $run['types'][ $ip ] ?? [] ),
					'last'    => (int) $run['time'],
					'runs'    => 1,
					'banned'  => false,
					'expires' => 0,
				];
			}
		}
		foreach ( $banned as $ip => $info ) {
			$ip = (string) $ip;
			if ( ! isset( $out[ $ip ] ) ) {
				$out[ $ip ] = [ 'ip' => $ip, 'reason' => (string) $info['reason'], 'types' => [], 'last' => (int) $info['banned_at'], 'runs' => 0 ];
			}
			$out[ $ip ]['banned']  = true;
			$out[ $ip ]['expires'] = (int) $info['expires_at'];
		}
		// Помеченный IP мог попасть в забаненную потом подсеть.
		$ranges = array_filter( array_keys( $banned ), function ( $b ) { return strpos( (string) $b, '/' ) !== false; } );
		foreach ( $out as $ip => &$a ) {
			if ( ! $a['banned'] && strpos( $ip, '/' ) === false && $ranges && LogShield_IP::matches_any( $ip, $ranges ) ) {
				$a['banned'] = true;
			}
		}
		unset( $a );
		uasort( $out, function ( $x, $y ) { return $y['last'] <=> $x['last']; } );
		return array_slice( array_values( $out ), 0, 200 );
	}

	/**
	 * Проверки для карточки «Состояние»: расписание, последнее сканирование,
	 * файл лога и сколько лога ещё не прочитано.
	 *
	 * @return array[] [ level => ok|warn|err, title, text ]
	 */
	public static function health( array $opts, array $scan_log, $next_run, array $state ) {
		$now       = time();
		$schedules = wp_get_schedules();
		$interval  = (int) ( $schedules[ $opts['interval'] ]['interval'] ?? 3 * HOUR_IN_SECONDS );
		$no_cron   = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
		$out       = [];

		// Расписание.
		if ( ! $next_run ) {
			$out[] = [ 'err', 'Расписание', 'Сканирование не запланировано. Выключите и снова включите плагин.' ];
		} elseif ( $next_run < $now - 15 * MINUTE_IN_SECONDS ) {
			$out[] = [ 'warn', 'Расписание', 'Сканирование просрочено на ' . human_time_diff( $next_run, $now ) . '. '
				. ( $no_cron ? 'WP-Cron отключён (DISABLE_WP_CRON): нужен системный cron на wp-cron.php.' : 'WP-Cron запускается только при посещениях сайта; на тихом сайте лучше системный cron.' ) ];
		} else {
			$when  = $next_run <= $now ? 'вот-вот' : 'через ' . human_time_diff( $now, $next_run );
			$out[] = [ 'ok', 'Расписание', 'Следующее сканирование ' . $when . ' (' . wp_date( 'd.m H:i', $next_run ) . ').'
				. ( $no_cron ? ' WP-Cron отключён: проверьте, что системный cron вызывает wp-cron.php.' : '' ) ];
		}

		// Последнее сканирование.
		$last = $scan_log[0] ?? null;
		if ( ! $last ) {
			$out[] = [ 'warn', 'Сканирование', 'Ещё не запускалось.' ];
		} elseif ( empty( $last['ok'] ) ) {
			$out[] = [ 'err', 'Сканирование', human_time_diff( $last['time'], $now ) . ' назад с ошибкой: ' . $last['message'] ];
		} elseif ( $now - $last['time'] > 2 * $interval + HOUR_IN_SECONDS ) {
			$out[] = [ 'warn', 'Сканирование', 'Последнее было ' . human_time_diff( $last['time'], $now ) . ' назад — дольше двух интервалов.' ];
		} else {
			$n     = count( (array) ( $last['flagged'] ?? [] ) );
			$out[] = [ 'ok', 'Сканирование', human_time_diff( $last['time'], $now ) . ' назад, ' . ( $n ? 'найдено: ' . $n : 'нарушителей нет' ) . '.' ];
		}

		// Файл лога.
		$out[] = [ $state['ok'] ? 'ok' : 'err', 'Лог', ( $opts['log_path'] ?: 'путь не указан' ) . ' — ' . $state['text'] ];

		// Сколько осталось прочитать: за запуск читается не больше max_read_mb.
		if ( $state['ok'] ) {
			$pos  = (array) get_option( LogShield_Detector::OFFSET_OPTION, [] );
			$size = (int) @filesize( $opts['log_path'] );
			if ( ( $pos['path'] ?? '' ) !== $opts['log_path'] ) {
				$out[] = [ 'ok', 'Чтение', 'Первое сканирование запомнит конец лога, анализ начнётся со следующего.' ];
			} else {
				$left  = max( 0, $size - (int) ( $pos['offset'] ?? 0 ) );
				$chunk = max( 1, (int) $opts['max_read_mb'] ) * MB_IN_BYTES;
				$runs  = (int) ceil( $left / $chunk );
				if ( $runs <= 1 ) {
					$out[] = [ 'ok', 'Чтение', $left ? 'Новых записей ' . size_format( $left ) . ' — прочитает в следующий раз.' : 'Лог прочитан до конца.' ];
				} else {
					$out[] = [ 'warn', 'Чтение', 'Не прочитано ' . size_format( $left ) . ': при лимите ' . (int) $opts['max_read_mb'] . ' МБ догонит примерно за '
						. $runs . ' сканирований (≈ ' . human_time_diff( 0, $runs * $interval ) . ').' ];
				}
			}
		}
		return $out;
	}

	/**
	 * Кого заблокировал бы тестовый режим за последние $days дней:
	 * помеченные сканированиями адреса и подсети, ещё не заблокированные.
	 *
	 * @return array{ips:int, nets:int}
	 */
	public static function would_ban( $days = 7 ) {
		$since = time() - $days * DAY_IN_SECONDS;
		$seen  = [];
		foreach ( LogShield_Detector::get_scan_log() as $run ) {
			if ( (int) ( $run['time'] ?? 0 ) < $since ) break; // история — от новых к старым
			foreach ( array_keys( (array) ( $run['flagged'] ?? [] ) ) as $ip ) $seen[ (string) $ip ] = true;
		}
		$banned = [];
		foreach ( self::attackers() as $a ) {
			if ( $a['banned'] ) $banned[ $a['ip'] ] = true;
		}
		$ips  = 0;
		$nets = 0;
		foreach ( array_keys( $seen ) as $ip ) {
			if ( isset( $banned[ $ip ] ) ) continue;
			if ( strpos( $ip, '/' ) === false ) $ips++; else $nets++;
		}
		return [ 'ips' => $ips, 'nets' => $nets ];
	}

	/** Кнопка «Включить защиту» на дашборде: выключает тестовый режим. */
	public static function protect() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_protect' );
		$opts            = LogShield_Plugin::get_options();
		$opts['dry_run'] = false;
		update_option( LOGSHIELD_OPTION, $opts );
		LogShield_Admin::redirect_with_message( 'Защита включена: со следующего сканирования нарушители будут блокироваться в .htaccess.' );
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$opts     = LogShield_Plugin::get_options();
		$scan_log = LogShield_Detector::get_scan_log();
		$last     = $scan_log[0] ?? null;
		$next_run = wp_next_scheduled( LOGSHIELD_CRON_HOOK );
		$state    = LogShield_LogFinder::describe( $opts['log_path'] );
		$attack   = self::attackers();
		$types    = LogShield_Stats::TYPES;
		$host     = wp_parse_url( home_url(), PHP_URL_HOST );
		$post_url = admin_url( 'admin-post.php' );
		$can_fill = $state['ok'] && get_option( self::BACKFILL_OPTION ) !== $opts['log_path'];
		$health   = self::health( $opts, $scan_log, $next_run, $state );
		$levels   = [ 'ok' => [ '✓', 'в порядке' ], 'warn' => [ '⚠', 'внимание' ], 'err' => [ '✕', 'ошибка' ] ];
		$attack_types = [];
		foreach ( $attack as $a ) {
			foreach ( $a['types'] as $t ) $attack_types[ $t ] = true;
		}
		?>
		<div class="wrap ls-wrap">
		<h1 class="screen-reader-text">LogShield — дашборд</h1>
		<?php // Уведомления WordPress вставляет после первого заголовка, до тёмной панели. ?>
		<div class="ls-dash">

			<header class="ls-head">
				<div class="ls-brand">
					<span class="ls-logo dashicons dashicons-shield" aria-hidden="true"></span>
					<div>
						<p class="ls-title">LogShield</p>
						<p class="ls-dim"><?php echo esc_html( $host ); ?> · анализ лога раз в <?php echo esc_html( (int) substr( $opts['interval'], -2, 1 ) ); ?> ч</p>
					</div>
				</div>
				<div class="ls-head-actions">
					<?php if ( $opts['dry_run'] ) : ?>
						<span class="ls-badge ls-badge-warn"><span class="ls-dot" aria-hidden="true"></span>Тестовый режим — не блокирует</span>
					<?php else : ?>
						<span class="ls-badge ls-badge-ok"><span class="ls-dot" aria-hidden="true"></span>Защита включена</span>
					<?php endif; ?>
					<form method="post" action="<?php echo esc_url( $post_url ); ?>">
						<input type="hidden" name="action" value="logshield_run_now">
						<input type="hidden" name="ls_back" value="<?php echo esc_attr( LogShield_Admin::SLUG_DASH ); ?>">
						<?php wp_nonce_field( 'logshield_run_now' ); ?>
						<button class="ls-btn ls-btn-accent"><span class="dashicons dashicons-update" aria-hidden="true"></span> Сканировать сейчас</button>
					</form>
					<a class="ls-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=' . LogShield_Admin::SLUG ) ); ?>"><span class="dashicons dashicons-admin-generic" aria-hidden="true"></span> Настройки</a>
				</div>
			</header>

			<?php if ( $opts['dry_run'] ) :
				$would = self::would_ban( 7 );
				$my_ip = LogShield_Whitelist::get_client_ip();
				$my_ok = $my_ip && LogShield_IP::matches_any( $my_ip, LogShield_Whitelist::get_full_whitelist( (array) $opts['whitelist_ips'] ) ); ?>
				<section class="ls-dry" aria-labelledby="ls-dry-title">
					<div>
						<h2 id="ls-dry-title"><span aria-hidden="true">⚠</span> Тестовый режим: LogShield никого не блокирует</h2>
						<p>
							<?php if ( $would['ips'] || $would['nets'] ) : ?>
								За 7 дней он заблокировал бы адресов: <strong><?php echo (int) $would['ips']; ?></strong><?php if ( $would['nets'] ) : ?>, подсетей: <strong><?php echo (int) $would['nets']; ?></strong><?php endif; ?>.
							<?php else : ?>
								За 7 дней блокировать было бы некого.
							<?php endif; ?>
							Проверьте список атакующих ниже: если своих там нет, защиту можно включать.
						</p>
					</div>
					<?php // Где нет command/commandfor, диалог открывает dashboard.js. ?>
					<button type="button" class="ls-btn ls-btn-accent" command="show-modal" commandfor="ls-protect">Включить защиту…</button>
				</section>
				<dialog id="ls-protect" class="ls-dialog" aria-labelledby="ls-protect-title" aria-describedby="ls-protect-desc">
					<h2 id="ls-protect-title">Включить защиту?</h2>
					<div id="ls-protect-desc">
						<p>Со следующего сканирования новые нарушители будут блокироваться в <code>.htaccess</code>. Уже найденных можно заблокировать вручную в таблице.</p>
						<?php if ( $my_ok ) : ?>
							<p><span aria-hidden="true">✓</span> Ваш адрес <code><?php echo esc_html( $my_ip ); ?></code> в белом списке.</p>
						<?php else : ?>
							<p class="ls-warn-text"><span aria-hidden="true">⚠</span> Ваш адрес <code><?php echo esc_html( $my_ip ?: 'не определён' ); ?></code> не найден в белом списке. Добавьте его в настройках, прежде чем включать.</p>
						<?php endif; ?>
						<p class="ls-dim">Вернуть тестовый режим можно в настройках.</p>
					</div>
					<div class="ls-dialog-actions">
						<form method="dialog">
							<button class="ls-btn" autofocus>Отмена</button>
						</form>
						<form method="post" action="<?php echo esc_url( $post_url ); ?>">
							<input type="hidden" name="action" value="logshield_protect">
							<input type="hidden" name="ls_back" value="<?php echo esc_attr( LogShield_Admin::SLUG_DASH ); ?>">
							<?php wp_nonce_field( 'logshield_protect' ); ?>
							<button class="ls-btn ls-btn-accent">Включить защиту</button>
						</form>
					</div>
				</dialog>
			<?php endif; ?>

			<section class="ls-card" aria-labelledby="ls-health-title">
				<div class="ls-card-head"><h2 id="ls-health-title">Состояние</h2></div>
				<ul class="ls-health">
					<?php foreach ( $health as list( $lvl, $title, $text ) ) : ?>
						<li class="ls-h-<?php echo esc_attr( $lvl ); ?>">
							<span class="ls-h-icon" aria-hidden="true"><?php echo esc_html( $levels[ $lvl ][0] ); ?></span>
							<span><strong><?php echo esc_html( $title ); ?></strong><span class="screen-reader-text"> (<?php echo esc_html( $levels[ $lvl ][1] ); ?>)</span><br><?php echo esc_html( $text ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>

			<div class="ls-range" role="group" aria-label="Период графиков">
				<button type="button" class="ls-btn ls-btn-sm" data-range="24" aria-pressed="true">24 часа</button>
				<button type="button" class="ls-btn ls-btn-sm" data-range="168" aria-pressed="false">7 дней</button>
				<button type="button" class="ls-btn ls-btn-sm" data-range="720" aria-pressed="false">30 дней</button>
			</div>

			<section class="ls-metrics" aria-label="Итоги за период">
				<div class="ls-card"><p class="ls-label">Запросов</p><p class="ls-value ls-accent" data-metric="req">—</p></div>
				<div class="ls-card"><p class="ls-label">Ошибки 4xx/5xx</p><p class="ls-value ls-danger" data-metric="err">—</p></div>
				<div class="ls-card"><p class="ls-label">Неудачных входов</p><p class="ls-value ls-warn" data-metric="fails">—</p></div>
				<div class="ls-card"><p class="ls-label">Атакующих найдено</p><p class="ls-value ls-danger" data-metric="flag">—</p></div>
				<div class="ls-card"><p class="ls-label">Заблокировано сейчас</p><p class="ls-value" data-metric="banned">—</p></div>
			</section>

			<div class="ls-empty ls-card" hidden>
				<p><strong>Графиков пока нет.</strong> Статистика копится при каждом сканировании; первое сканирование только запоминает позицию в логе.</p>
				<?php if ( $can_fill ) : ?>
					<form method="post" action="<?php echo esc_url( $post_url ); ?>">
						<input type="hidden" name="action" value="logshield_backfill">
						<input type="hidden" name="ls_back" value="<?php echo esc_attr( LogShield_Admin::SLUG_DASH ); ?>">
						<?php wp_nonce_field( 'logshield_backfill' ); ?>
						<button class="ls-btn ls-btn-accent">Построить графики по уже записанному логу</button>
						<span class="ls-dim">— прочитает до <?php echo (int) $opts['max_read_mb']; ?> МБ, ничего не блокирует</span>
					</form>
				<?php endif; ?>
			</div>

			<section class="ls-card ls-chart-card">
				<div class="ls-card-head">
					<h2>Трафик</h2>
					<p class="ls-legend"><span class="ls-key ls-key-accent"></span>Запросы <span class="ls-key ls-key-danger"></span>Ошибки 4xx/5xx</p>
				</div>
				<div class="ls-chart" data-chart="traffic"></div>
				<details class="ls-chart-data">
					<summary>Данные графика таблицей</summary>
					<div class="ls-table-wrap" tabindex="0" role="region" aria-label="Трафик по периодам">
						<table class="ls-table" data-chart-table="traffic"></table>
					</div>
				</details>
			</section>

			<div class="ls-grid-2">
				<section class="ls-card ls-chart-card">
					<div class="ls-card-head">
						<h2>Неудачные входы</h2>
						<p class="ls-legend"><span class="ls-key ls-key-warn"></span>POST на wp-login.php без входа</p>
					</div>
					<div class="ls-chart" data-chart="fails"></div>
					<details class="ls-chart-data">
						<summary>Данные графика таблицей</summary>
						<div class="ls-table-wrap" tabindex="0" role="region" aria-label="Неудачные входы по периодам">
							<table class="ls-table" data-chart-table="fails"></table>
						</div>
					</details>
				</section>
				<section class="ls-card">
					<div class="ls-card-head"><h2>Типы атак</h2><p class="ls-legend">адресов за период</p></div>
					<ul class="ls-types" data-types></ul>
				</section>
			</div>

			<div class="ls-grid-3">
				<section class="ls-card ls-span-2">
					<div class="ls-card-head">
						<h2 id="ls-attackers-title">Атакующие адреса</h2>
						<p class="ls-legend"><?php echo count( $attack ); ?></p>
					</div>
					<?php if ( ! $attack ) : ?>
						<p class="ls-dim ls-pad">Пока никого не поймали.</p>
					<?php else : ?>
						<?php // Панель работает только со скриптом — он её и показывает. ?>
						<div class="ls-filters" data-attack-filters hidden>
							<label>
								<span>Поиск</span>
								<input type="search" class="ls-input" data-f-q placeholder="IP или причина" autocomplete="off" spellcheck="false">
							</label>
							<label>
								<span>Тип</span>
								<select class="ls-input" data-f-type>
									<option value="">Все</option>
									<?php foreach ( array_keys( $attack_types ) as $t ) : ?>
										<option value="<?php echo esc_attr( $t ); ?>"><?php echo esc_html( $types[ $t ] ?? $t ); ?></option>
									<?php endforeach; ?>
								</select>
							</label>
							<label>
								<span>Статус</span>
								<select class="ls-input" data-f-status>
									<option value="">Все</option>
									<option value="seen">Обнаружен</option>
									<option value="banned">Заблокирован</option>
								</select>
							</label>
							<p class="ls-dim ls-f-count" role="status" data-f-count></p>
						</div>
						<div class="ls-table-wrap" tabindex="0" role="region" aria-labelledby="ls-attackers-title">
							<table class="ls-table ls-table-stack" id="ls-attackers" data-attackers>
								<thead><tr>
									<th scope="col" data-type="ip"><button type="button" class="ls-sort" commandfor="ls-attackers" command="--sort">Адрес<span class="ls-sort-icon" aria-hidden="true"></span></button></th>
									<th scope="col">Что делал</th>
									<th scope="col" data-type="number" aria-sort="descending"><button type="button" class="ls-sort" commandfor="ls-attackers" command="--sort">Когда<span class="ls-sort-icon" aria-hidden="true"></span></button></th>
									<th scope="col">Статус</th>
									<th scope="col"><span class="screen-reader-text">Действие</span></th>
								</tr></thead>
								<tbody>
								<?php foreach ( $attack as $a ) : ?>
									<tr data-types="<?php echo esc_attr( implode( ' ', $a['types'] ) ); ?>" data-status="<?php echo $a['banned'] ? 'banned' : 'seen'; ?>">
										<th scope="row" data-value="<?php echo esc_attr( $a['ip'] ); ?>"><code><?php echo esc_html( $a['ip'] ); ?></code><?php echo LogShield_IPInfo::badge( $a['ip'] ); // phpcs:ignore -- экранировано внутри ?></th>
										<td data-label="Что делал">
											<?php foreach ( $a['types'] as $t ) : ?>
												<span class="ls-tag ls-tag-<?php echo esc_attr( $t ); ?>"><?php echo esc_html( $types[ $t ] ?? $t ); ?></span>
											<?php endforeach; ?>
											<span class="ls-reason"><?php echo esc_html( $a['reason'] ); ?></span>
										</td>
										<td class="ls-nowrap" data-label="Когда" data-value="<?php echo (int) $a['last']; ?>"><?php echo esc_html( wp_date( 'd.m H:i', $a['last'] ) ); ?><?php if ( $a['runs'] > 1 ) : ?><br><span class="ls-dim"><?php echo (int) $a['runs']; ?> скан.</span><?php endif; ?></td>
										<td class="ls-nowrap" data-label="Статус">
											<?php if ( $a['banned'] ) : ?>
												<span class="ls-tag ls-tag-banned">Заблокирован</span>
												<?php if ( $a['expires'] ) : ?><br><span class="ls-dim">до <?php echo esc_html( wp_date( 'd.m.Y', $a['expires'] ) ); ?></span><?php endif; ?>
											<?php else : ?>
												<span class="ls-tag ls-tag-seen">Обнаружен</span>
											<?php endif; ?>
										</td>
										<td>
											<form method="post" action="<?php echo esc_url( $post_url ); ?>">
												<input type="hidden" name="ls_back" value="<?php echo esc_attr( LogShield_Admin::SLUG_DASH ); ?>">
												<input type="hidden" name="ip" value="<?php echo esc_attr( $a['ip'] ); ?>">
												<?php if ( $a['banned'] && isset( LogShield_Htaccess::get_banned()[ $a['ip'] ] ) ) : ?>
													<input type="hidden" name="action" value="logshield_unban">
													<?php wp_nonce_field( 'logshield_unban' ); ?>
													<button class="ls-btn ls-btn-sm">Разблокировать<span class="screen-reader-text"> <?php echo esc_html( $a['ip'] ); ?></span></button>
												<?php elseif ( ! $a['banned'] ) : ?>
													<input type="hidden" name="action" value="logshield_ban">
													<?php wp_nonce_field( 'logshield_ban' ); ?>
													<button class="ls-btn ls-btn-sm ls-btn-danger">Заблокировать<span class="screen-reader-text"> <?php echo esc_html( $a['ip'] ); ?></span></button>
												<?php endif; ?>
											</form>
										</td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>
						<?php $banned_count = count( LogShield_Htaccess::get_banned() ); ?>
						<?php if ( $banned_count ) : ?>
							<p class="ls-pad">
								<?php // Где нет command/commandfor, диалог открывает dashboard.js. ?>
								<button type="button" class="ls-btn ls-btn-sm" command="show-modal" commandfor="ls-unban-all">Разблокировать все…</button>
							</p>
							<dialog id="ls-unban-all" class="ls-dialog" aria-labelledby="ls-unban-all-title" aria-describedby="ls-unban-all-desc">
								<h2 id="ls-unban-all-title">Снять все блокировки?</h2>
								<p id="ls-unban-all-desc">Из <code>.htaccess</code> будут удалены все заблокированные адреса и подсети (<?php echo (int) $banned_count; ?>). Вернуть их можно только новой блокировкой.</p>
								<div class="ls-dialog-actions">
									<form method="dialog">
										<button class="ls-btn" autofocus>Отмена</button>
									</form>
									<form method="post" action="<?php echo esc_url( $post_url ); ?>">
										<input type="hidden" name="action" value="logshield_unban_all">
										<input type="hidden" name="ls_back" value="<?php echo esc_attr( LogShield_Admin::SLUG_DASH ); ?>">
										<?php wp_nonce_field( 'logshield_unban_all' ); ?>
										<button class="ls-btn ls-btn-danger">Снять все блокировки</button>
									</form>
								</div>
							</dialog>
						<?php endif; ?>
					<?php endif; ?>
				</section>

				<section class="ls-card">
					<div class="ls-card-head"><h2 id="ls-runs-title">Сканирования</h2></div>
					<?php if ( ! $scan_log ) : ?>
						<p class="ls-dim ls-pad">Сканирование ещё не запускалось.</p>
					<?php else : ?>
						<div class="ls-runs-wrap" tabindex="0" role="region" aria-labelledby="ls-runs-title">
						<ol class="ls-runs">
							<?php foreach ( array_slice( $scan_log, 0, 20 ) as $run ) :
								$n = count( (array) ( $run['flagged'] ?? [] ) );
								// Итог словом и значком, а не только цветом полосы.
								if ( empty( $run['ok'] ) ) {
									$cls = 'ls-run-err'; $icon = '⚠'; $word = 'ошибка';
								} elseif ( $n ) {
									$cls = 'ls-run-hit'; $icon = '●'; $word = 'найдено: ' . $n;
								} else {
									$cls = 'ls-run-ok'; $icon = '✓'; $word = 'чисто';
								} ?>
								<li class="<?php echo esc_attr( $cls ); ?>">
									<span class="ls-run-time"><?php echo esc_html( wp_date( 'd.m H:i', $run['time'] ) ); ?> · <span class="ls-run-state"><span aria-hidden="true"><?php echo esc_html( $icon ); ?></span> <?php echo esc_html( $word ); ?></span></span>
									<span><?php echo esc_html( $run['message'] ); ?></span>
								</li>
							<?php endforeach; ?>
						</ol>
						</div>
					<?php endif; ?>
				</section>
			</div>

			<section class="ls-card">
				<div class="ls-card-head">
					<h2>Последние записи лога</h2>
					<div class="ls-tail-tools">
						<div role="group" aria-label="Фильтр записей">
							<button type="button" class="ls-btn ls-btn-sm" data-filter="all" aria-pressed="true">Все</button>
							<button type="button" class="ls-btn ls-btn-sm" data-filter="4xx" aria-pressed="false">4xx</button>
							<button type="button" class="ls-btn ls-btn-sm" data-filter="5xx" aria-pressed="false">5xx</button>
							<button type="button" class="ls-btn ls-btn-sm" data-filter="bad" aria-pressed="false">Атакующие</button>
						</div>
						<button type="button" class="ls-btn ls-btn-sm" data-ua aria-pressed="false">User-Agent</button>
						<button type="button" class="ls-btn ls-btn-sm" data-live aria-pressed="false"><span class="ls-dot" aria-hidden="true"></span> Живой режим</button>
					</div>
				</div>
				<p class="ls-dim ls-pad ls-tail-note" data-tail-status role="status"><?php echo $state['ok'] ? 'Загрузка…' : 'Лог недоступен — укажите путь в настройках.'; ?></p>
				<div class="ls-tail" data-tail tabindex="0" role="region" aria-label="Последние записи лога"></div>
			</section>

			<?php LogShield_IPInfo::render_card(); ?>

			<p class="ls-dim ls-foot">Живой режим опрашивает лог раз в 5 секунд, только пока эта страница открыта и видна. Графики строятся по данным сканирований и нагрузки не добавляют.</p>
		</div>
		</div>
		<?php
	}

	/** Ручной бан с дашборда (например, адреса, найденного в тестовом режиме). */
	public static function ban() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_ban' );
		$ip = isset( $_POST['ip'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['ip'] ) ) ) : '';
		if ( ! LogShield_IP::is_valid_entry( $ip ) ) {
			LogShield_Admin::redirect_with_message( 'Неверный адрес.', 'error' );
		}
		$whitelist = LogShield_Whitelist::get_full_whitelist( (array) LogShield_Plugin::get_options()['whitelist_ips'] );
		foreach ( $whitelist as $w ) {
			if ( LogShield_IP::overlaps( $w, $ip ) ) {
				LogShield_Admin::redirect_with_message( 'Адрес ' . $ip . ' пересекается с белым списком (' . $w . ') — не блокирую.', 'error' );
			}
		}
		$reason = 'вручную с дашборда';
		foreach ( self::attackers() as $a ) {
			if ( $a['ip'] === $ip ) { $reason = $a['reason'] . ' (вручную)'; break; }
		}
		$opts = LogShield_Plugin::get_options();
		// Ручная блокировка применяется сразу, и в тестовом режиме тоже:
		// тестовый режим касается только автоматических банов по расписанию.
		$ok   = LogShield_Htaccess::ban_ip( $ip, $reason, (int) $opts['ban_expiry_days'] );
		LogShield_Admin::redirect_with_message(
			$ok
				? 'Заблокирован: ' . $ip . ' (записано в ' . LogShield_Htaccess::get_htaccess_path() . ')'
				: 'Не удалось заблокировать ' . $ip . ': ' . LogShield_Htaccess::last_error() . '. Адрес остался в списке банов — запись повторится при следующем изменении списка.',
			$ok ? 'success' : 'error'
		);
	}

	/**
	 * Графики по уже записанному логу: читает до max_read_mb перед текущей
	 * позицией сканера (чтобы не посчитать одно и то же дважды). Только
	 * статистика — никого не банит и не уведомляет. Один раз на путь.
	 */
	public static function backfill() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_backfill' );
		$opts = LogShield_Plugin::get_options();
		$path = $opts['log_path'];
		if ( ! LogShield_LogFinder::describe( $path )['ok'] ) {
			LogShield_Admin::redirect_with_message( 'Лог недоступен — укажите путь в настройках.', 'error' );
		}
		if ( get_option( self::BACKFILL_OPTION ) === $path ) {
			LogShield_Admin::redirect_with_message( 'Графики по этому логу уже построены.', 'error' );
		}
		clearstatcache();
		$size  = (int) @filesize( $path );
		$state = get_option( LogShield_Detector::OFFSET_OPTION, [ 'path' => '', 'offset' => 0 ] );
		$end   = ( $state['path'] === $path ) ? min( (int) $state['offset'], $size ) : $size;
		$start = max( 0, $end - max( 1, (int) $opts['max_read_mb'] ) * 1024 * 1024 );
		$lines = self::read_range( $path, $start, $end - $start );

		$whitelist = LogShield_Whitelist::get_full_whitelist( (array) $opts['whitelist_ips'] );
		$result    = LogShield_Detector::analyze( $lines, $opts, $whitelist );
		LogShield_Stats::record( $result['hourly'], [] );
		update_option( self::BACKFILL_OPTION, $path, false );
		if ( $state['path'] !== $path ) {
			// Сканер ещё не запускался на этом логе: дальше он начнёт с конца файла.
			update_option( LogShield_Detector::OFFSET_OPTION, [ 'path' => $path, 'offset' => $end ], false );
		}
		LogShield_Admin::redirect_with_message( sprintf( 'Графики построены: %d строк, %d часов.', count( $lines ), count( $result['hourly'] ) ) );
	}

	/** Хвост лога для дашборда. offset < 0 — последние строки; иначе новое с offset. */
	public static function ajax_tail() {
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden', 403 );
		check_ajax_referer( 'logshield_tail', 'nonce' );
		$path = LogShield_Plugin::get_options()['log_path'];
		if ( $path === '' || ! @is_readable( $path ) || @is_dir( $path ) ) {
			wp_send_json_error( 'Лог недоступен — укажите путь в настройках.' );
		}
		clearstatcache();
		$size   = (int) @filesize( $path );
		$offset = isset( $_GET['offset'] ) ? (int) $_GET['offset'] : -1;
		$reset  = false;
		if ( $offset < 0 || $offset > $size ) {
			// Первый запрос или лог ротировали — показываем хвост заново.
			$reset  = $offset > $size;
			$start  = max( 0, $size - self::TAIL_FIRST_BYTES );
			$lines  = self::read_range( $path, $start, $size - $start );
			$lines  = array_slice( $lines, -self::TAIL_LINES );
		} else {
			// Отстали слишком сильно — пропускаем середину.
			$start = max( $offset, $size - self::TAIL_MAX_BYTES );
			$lines = self::read_range( $path, $start, $size - $start, $start === $offset );
		}
		$out = [];
		foreach ( $lines as $line ) {
			$e = LogShield_Parser::parse_line( $line );
			if ( ! $e || LogShield_Whitelist::is_own_request( $e ) ) continue;
			$out[] = [
				't'  => substr( $e['date'], 12, 8 ),
				'd'  => substr( $e['date'], 0, 6 ),
				'ip' => $e['ip'],
				'm'  => substr( $e['method'], 0, 10 ),
				'p'  => mb_substr( $e['path'], 0, 200 ),
				's'  => $e['status'],
				'ua' => mb_substr( $e['user_agent'], 0, 140 ),
			];
		}
		wp_send_json_success( [ 'offset' => $size, 'lines' => $out, 'reset' => $reset ] );
	}

	/**
	 * Строки из куска файла [start, start+len). Если start не на границе
	 * строки, первая (обрезанная) строка отбрасывается; хвост без перевода
	 * строки — тоже (допишется к следующему опросу).
	 */
	private static function read_range( $path, $start, $len, $at_line_start = false ) {
		if ( $len <= 0 ) return [];
		$fp = @fopen( $path, 'rb' );
		if ( ! $fp ) return [];
		fseek( $fp, $start );
		$data = (string) fread( $fp, $len );
		fclose( $fp );
		$lines = explode( "\n", $data );
		if ( $start > 0 && ! $at_line_start ) array_shift( $lines );
		array_pop( $lines ); // после последнего \n — пусто или неполная строка
		return array_values( array_filter( array_map( 'rtrim', $lines ), 'strlen' ) );
	}
}
