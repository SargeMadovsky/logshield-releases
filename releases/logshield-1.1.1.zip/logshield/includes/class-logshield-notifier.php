<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Уведомления о результатах сканирования: e-mail и Telegram.
 * Отправляются только если кого-то поймали — одно сообщение на запуск.
 */
class LogShield_Notifier {

	const TELEGRAM_LIMIT = 4096; // максимум символов в сообщении Telegram

	// Повтор при сбое сети или временной ошибке Telegram (таймаут, 429, 5xx).
	const ATTEMPTS     = 2;                      // попыток сразу, с паузой между ними
	const RETRY_OPTION = 'logshield_tg_queue';   // недоставленные: [ [ text, try, error, time ] ]
	const FAIL_OPTION  = 'logshield_tg_failed';  // последняя окончательная неудача: [ error, time ]
	const RETRY_HOOK   = 'logshield_telegram_retry';
	const RETRY_DELAYS = [ 300, 900, 3600 ];     // потом ещё раз через 5 мин, 15 мин, час
	const QUEUE_MAX    = 5;

	/** Временная ли была последняя ошибка (стоит повторить) — для очереди. */
	private static $transient = false;

	public static function notify( array $summary, array $opts ) {
		if ( empty( $summary['flagged'] ) ) return;
		$info = LogShield_IPInfo::get_all();

		if ( ! empty( $opts['notify_email'] ) ) {
			$lines = [];
			foreach ( $summary['flagged'] as $ip => $reasons ) {
				$where   = isset( $info[ $ip ] ) ? LogShield_IPInfo::describe( $info[ $ip ], false ) : '';
				$lines[] = $ip . ( $where !== '' ? ' (' . $where . ')' : '' ) . ' — ' . implode( '; ', $reasons );
			}
			$subject = '[LogShield] Обнаружены подозрительные IP (' . count( $summary['flagged'] ) . ')';
			$body    = implode( "\n", $lines );
			if ( $opts['dry_run'] ) {
				$body .= "\n\n(Тестовый режим: блокировка НЕ применена)";
			}
			wp_mail( $opts['notify_email'], $subject, $body );
		}

		if ( self::telegram_configured( $opts ) ) {
			$text = self::format_telegram( $summary );
			$res  = self::send_telegram( $opts['telegram_token'], $opts['telegram_chat_id'], $text );
			if ( $res !== true && self::$transient ) self::queue( $text, $res );
		}
	}

	public static function telegram_configured( array $opts ) {
		return ! empty( $opts['telegram_token'] ) && ! empty( $opts['telegram_chat_id'] );
	}

	/** Токен бота от @BotFather: «123456789:AA…». */
	public static function is_valid_token( $token ) {
		return (bool) preg_match( '~^\d{5,15}:[A-Za-z0-9_-]{30,50}$~D', (string) $token );
	}

	/** chat_id: число (у групп — отрицательное) или @имя_канала. */
	public static function is_valid_chat_id( $chat_id ) {
		return (bool) preg_match( '~^(-?\d{1,20}|@[A-Za-z][A-Za-z0-9_]{4,31})$~D', (string) $chat_id );
	}

	/** Текст сообщения в разметке HTML (Telegram понимает <b>, <code>, <i>). */
	public static function format_telegram( array $summary ) {
		$host  = wp_parse_url( home_url(), PHP_URL_HOST );
		$count = count( $summary['flagged'] );
		$head  = '🛡 <b>LogShield</b> · ' . self::h( $host ) . "\n";
		if ( ! empty( $summary['dry_run'] ) ) {
			$head .= 'Обнаружено: ' . $count . " <i>(тестовый режим — не заблокированы)</i>\n";
		} else {
			$head .= 'Заблокировано: ' . $count . "\n";
		}

		$text  = $head;
		$shown = 0;
		$info  = LogShield_IPInfo::get_all();
		foreach ( $summary['flagged'] as $ip => $reasons ) {
			$item  = "\n<code>" . self::h( $ip ) . '</code> — ' . self::h( implode( '; ', $reasons ) );
			$where = isset( $info[ $ip ] ) ? LogShield_IPInfo::describe( $info[ $ip ] ) : '';
			if ( $where !== '' ) $item .= "\n    <i>" . self::h( $where ) . '</i>';
			// Хвост «…и ещё N» должен тоже поместиться.
			if ( mb_strlen( $text . $item ) > self::TELEGRAM_LIMIT - 60 ) break;
			$text .= $item;
			$shown++;
		}
		if ( $shown < $count ) {
			$text .= "\n\n…и ещё " . ( $count - $shown ) . ' — полный список в «Настройки → LogShield».';
		}
		return $text;
	}

	/**
	 * Отправляет сообщение через Bot API.
	 *
	 * @return true|string true или текст ошибки (без токена)
	 */
	public static function send_telegram( $token, $chat_id, $text ) {
		self::$transient = false;
		if ( ! self::is_valid_token( $token ) ) return 'Неверный формат токена бота.';
		if ( ! self::is_valid_chat_id( $chat_id ) ) return 'Неверный формат chat_id.';

		$attempts = max( 1, (int) apply_filters( 'logshield_telegram_attempts', self::ATTEMPTS ) );
		for ( $try = 1; ; $try++ ) {
			$res = self::send_once( $token, $chat_id, $text );
			if ( $res === true || ! self::$transient || $try >= $attempts ) return $res;
			// Короткая пауза: сбой сети обычно проходит за секунды. Фильтр — для тестов.
			$pause = (int) apply_filters( 'logshield_telegram_retry_pause', 2 * $try );
			if ( $pause > 0 ) sleep( $pause );
		}
	}

	private static function send_once( $token, $chat_id, $text ) {
		self::$transient = false;
		$response = wp_remote_post(
			'https://api.telegram.org/bot' . $token . '/sendMessage',
			[
				'timeout' => 8,
				'body'    => [
					'chat_id'                  => $chat_id,
					'text'                     => $text,
					'parse_mode'               => 'HTML',
					'disable_web_page_preview' => 'true',
				],
			]
		);
		if ( is_wp_error( $response ) ) {
			self::$transient = true;
			// В сообщении WP_Error может оказаться URL с токеном — вырезаем.
			return 'Ошибка соединения с Telegram: ' . str_replace( $token, '***', $response->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code === 200 && ! empty( $data['ok'] ) ) return true;

		self::$transient = $code === 429 || $code >= 500 || $code === 0;
		$desc = is_array( $data ) && isset( $data['description'] ) ? (string) $data['description'] : 'HTTP ' . $code;
		return 'Telegram ответил ошибкой: ' . str_replace( $token, '***', $desc ) . self::hint( $code );
	}

	/** Не доставлено из-за сети — пробуем ещё раз позже через WP-Cron. */
	private static function queue( $text, $error ) {
		$q   = (array) get_option( self::RETRY_OPTION, [] );
		$q[] = [ 'text' => $text, 'try' => 0, 'error' => $error, 'time' => time() ];
		update_option( self::RETRY_OPTION, array_slice( $q, -self::QUEUE_MAX ), false );
		self::schedule_retry( 0 );
	}

	private static function schedule_retry( $step ) {
		if ( wp_next_scheduled( self::RETRY_HOOK ) ) return;
		wp_schedule_single_event( time() + self::RETRY_DELAYS[ min( $step, count( self::RETRY_DELAYS ) - 1 ) ], self::RETRY_HOOK );
	}

	/** Обработчик отложенного повтора. */
	public static function retry_queue() {
		$q    = (array) get_option( self::RETRY_OPTION, [] );
		$opts = LogShield_Plugin::get_options();
		if ( ! $q ) return;
		if ( ! self::telegram_configured( $opts ) ) { delete_option( self::RETRY_OPTION ); return; }

		$left      = [];
		$delivered = false;
		$failed    = false;
		foreach ( $q as $item ) {
			$res = self::send_telegram( $opts['telegram_token'], $opts['telegram_chat_id'], $item['text'] );
			if ( $res === true ) { $delivered = true; continue; }
			$item['try']++;
			$item['error'] = $res;
			if ( self::$transient && $item['try'] < count( self::RETRY_DELAYS ) ) {
				$left[] = $item;
			} else {
				update_option( self::FAIL_OPTION, [ 'error' => $res, 'time' => (int) $item['time'] ], false );
				$failed = true;
			}
		}
		if ( $left ) {
			update_option( self::RETRY_OPTION, $left, false );
			self::schedule_retry( min( array_column( $left, 'try' ) ) );
		} else {
			delete_option( self::RETRY_OPTION );
		}
		// Дошло — значит, связь есть: старое предупреждение в настройках больше не нужно.
		if ( $delivered && ! $failed ) delete_option( self::FAIL_OPTION );
	}

	private static function hint( $code ) {
		if ( $code === 401 ) return ' (проверьте токен бота)';
		if ( $code === 400 || $code === 403 ) return ' (проверьте chat_id и что вы написали боту /start или добавили его в группу)';
		return '';
	}

	private static function h( $s ) {
		return htmlspecialchars( (string) $s, ENT_NOQUOTES, 'UTF-8' );
	}
}
