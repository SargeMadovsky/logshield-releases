<?php
/**
 * Plugin Name: LogShield
 * Description: Периодический анализ access_log, обнаружение атакующих IP и автоматическая блокировка через .htaccess. Работает не в реальном времени, а по расписанию (раз в 2–4 часа), чтобы не нагружать сервер.
 * Version: 1.2.3
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: LogShield
 * License: GPL v2 or later
 * Text Domain: logshield
 * Update URI: https://github.com/SargeMadovsky/logshield-releases
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LOGSHIELD_VERSION', '1.2.3' );
define( 'LOGSHIELD_FILE', __FILE__ );
define( 'LOGSHIELD_DIR', plugin_dir_path( __FILE__ ) );
define( 'LOGSHIELD_URL', plugin_dir_url( __FILE__ ) );
define( 'LOGSHIELD_OPTION', 'logshield_options' );
define( 'LOGSHIELD_CRON_HOOK', 'logshield_scan_event' );
define( 'LOGSHIELD_CLEANUP_HOOK', 'logshield_cleanup_event' );

require_once LOGSHIELD_DIR . 'includes/class-logshield-ip.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-parser.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-logfinder.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-whitelist.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-ping.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-htaccess.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-stats.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-mmdb.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-ipinfo.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-detector.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-notifier.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-admin.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-dashboard.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-api.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-updater.php';

// REST-эндпоинт статистики для внешней сводной панели и страница выпуска токена.
LogShield_API::init();

// Обновления из публичного репозитория сборок на GitHub (не с wordpress.org).
LogShield_Updater::init();

class LogShield_Plugin {

	public static function default_options() {
		return [
			'log_path'                => '',
			'interval'                 => 'logshield_3h',
			'dry_run'                  => true,
			'rpm_threshold'            => 300,
			'brute_attempts'           => 10,
			'scan_unique_paths'        => 15,
			'scan_min_requests'        => 20,
			'error_rate_pct'           => 50,
			'error_rate_min_requests'  => 20,
			'sensitive_min_hits'       => 3,
			'enum_min_hits'            => 3,
			'subnet_min_ips'           => 5,
			'subnet_min_attempts'      => 30,
			'max_read_mb'              => 5,
			'ban_expiry_days'          => 7,
			'whitelist_ips'            => [],
			'notify_email'             => '',
			'telegram_token'           => '',
			'telegram_chat_id'         => '',
			'ipinfo_enabled'           => true,
		];
	}

	public static function get_options() {
		$opts = get_option( LOGSHIELD_OPTION, [] );
		return wp_parse_args( $opts, self::default_options() );
	}

	public static function activate() {
		$opts = self::get_options();
		if ( $opts['log_path'] === '' ) {
			$opts['log_path'] = (string) LogShield_LogFinder::best_confident();
		}
		update_option( LOGSHIELD_OPTION, $opts );

		// Защита от блокировки самого себя: сразу добавляем IP текущего администратора.
		$ip = LogShield_Whitelist::get_client_ip();
		if ( $ip ) {
			LogShield_Whitelist::add_admin_ip( $ip, false, wp_get_current_user()->user_login );
		}

		if ( ! wp_next_scheduled( LOGSHIELD_CRON_HOOK ) ) {
			wp_schedule_event( time() + 300, $opts['interval'], LOGSHIELD_CRON_HOOK );
		}
		if ( ! wp_next_scheduled( LOGSHIELD_CLEANUP_HOOK ) ) {
			wp_schedule_event( time() + 60, 'daily', LOGSHIELD_CLEANUP_HOOK );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( LOGSHIELD_CRON_HOOK );
		wp_clear_scheduled_hook( LOGSHIELD_CLEANUP_HOOK );
		wp_clear_scheduled_hook( LOGSHIELD_CLEANUP_HOOK, [ 'geo' ] );
		wp_clear_scheduled_hook( LogShield_Notifier::RETRY_HOOK );
		wp_clear_scheduled_hook( LogShield_Updater::FETCH_HOOK );
	}

	public static function cron_schedules( $schedules ) {
		$schedules['logshield_2h'] = [ 'interval' => 2 * HOUR_IN_SECONDS, 'display' => __( 'Каждые 2 часа (LogShield)', 'logshield' ) ];
		$schedules['logshield_3h'] = [ 'interval' => 3 * HOUR_IN_SECONDS, 'display' => __( 'Каждые 3 часа (LogShield)', 'logshield' ) ];
		$schedules['logshield_4h'] = [ 'interval' => 4 * HOUR_IN_SECONDS, 'display' => __( 'Каждые 4 часа (LogShield)', 'logshield' ) ];
		return $schedules;
	}

	public static function reschedule( $new_interval ) {
		wp_clear_scheduled_hook( LOGSHIELD_CRON_HOOK );
		wp_schedule_event( time() + 60, $new_interval, LOGSHIELD_CRON_HOOK );
	}

	public static function run_scan() {
		LogShield_Detector::run();
	}

	public static function run_cleanup() {
		LogShield_Htaccess::cleanup_expired();
		if ( LogShield_IPInfo::enabled() ) LogShield_IPInfo::update();
	}
}

register_activation_hook( __FILE__, [ 'LogShield_Plugin', 'activate' ] );
register_deactivation_hook( __FILE__, [ 'LogShield_Plugin', 'deactivate' ] );

add_filter( 'cron_schedules', [ 'LogShield_Plugin', 'cron_schedules' ] );
add_action( LOGSHIELD_CRON_HOOK, [ 'LogShield_Plugin', 'run_scan' ] );
add_action( LOGSHIELD_CLEANUP_HOOK, [ 'LogShield_Plugin', 'run_cleanup' ] );
add_action( LogShield_Notifier::RETRY_HOOK, [ 'LogShield_Notifier', 'retry_queue' ] );

// Авто-whitelist: IP сотрудников при входе и при работе по cookie, IP самого сервера.
add_action( 'wp_login', [ 'LogShield_Whitelist', 'on_login' ], 10, 2 );
add_action( 'init', [ 'LogShield_Whitelist', 'on_init' ] );
// Адрес проверки доступности: отвечаем, когда WordPress загружен полностью.
add_action( 'wp_loaded', [ 'LogShield_Ping', 'maybe_respond' ], PHP_INT_MAX );

// Админка.
add_action( 'admin_menu', [ 'LogShield_Admin', 'add_menu' ] );
add_action( 'admin_post_logshield_save_settings', [ 'LogShield_Admin', 'save_settings' ] );
add_action( 'admin_post_logshield_run_now', [ 'LogShield_Admin', 'run_now' ] );
add_action( 'admin_post_logshield_unban', [ 'LogShield_Admin', 'unban_ip' ] );
add_action( 'admin_post_logshield_unban_all', [ 'LogShield_Admin', 'unban_all' ] );
add_action( 'admin_post_logshield_add_my_ip', [ 'LogShield_Admin', 'add_my_ip' ] );
add_action( 'admin_post_logshield_telegram_test', [ 'LogShield_Admin', 'telegram_test' ] );
add_action( 'admin_post_logshield_detect_log', [ 'LogShield_Admin', 'detect_log' ] );
add_action( 'admin_post_logshield_use_log', [ 'LogShield_Admin', 'use_log' ] );
add_action( 'admin_post_logshield_geo_update', [ 'LogShield_Admin', 'geo_update' ] );
add_action( 'admin_post_logshield_ping_rotate', [ 'LogShield_Admin', 'ping_rotate' ] );
add_action( 'admin_post_logshield_ban', [ 'LogShield_Dashboard', 'ban' ] );
add_action( 'admin_post_logshield_backfill', [ 'LogShield_Dashboard', 'backfill' ] );
add_action( 'admin_post_logshield_protect', [ 'LogShield_Dashboard', 'protect' ] );
add_action( 'wp_ajax_logshield_tail', [ 'LogShield_Dashboard', 'ajax_tail' ] );
add_action( 'admin_init', [ 'LogShield_Admin', 'legacy_redirect' ] );
add_action( 'admin_notices', [ 'LogShield_Admin', 'notices' ] );
