<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Обновления из публичного репозитория сборок на GitHub
 * (SargeMadovsky/logshield-releases), а не с wordpress.org.
 *
 * В заголовке плагина указан Update URI с хостом github.com, поэтому WordPress
 * не спрашивает о нём wordpress.org, а вызывает фильтр update_plugins_github.com.
 * Отвечаем данными из update.json. Дальше всё штатно: кнопка «Обновить»,
 * автообновление, окно «Подробнее» (plugins_api).
 *
 * Сборки кладёт GitHub Actions по тегу v* (.github/workflows/release.yml).
 */
class LogShield_Updater {

	const MANIFEST  = 'https://raw.githubusercontent.com/SargeMadovsky/logshield-releases/main/update.json';
	const CACHE     = 'logshield_update_manifest';
	const SLUG      = 'logshield';
	const LAST      = 'logshield_update_last'; // [ time, ms, ok, error ] — для диагностики в настройках
	const TIMEOUT   = 5;
	// WordPress сам спрашивает об обновлениях не чаще раза в 12 часов (на странице
	// плагинов — раз в час), так что долгий кэш только задерживал бы новую версию.
	const CACHE_TTL = HOUR_IN_SECONDS;
	const FAIL_TTL  = 30 * MINUTE_IN_SECONDS; // GitHub не ответил — повтор через полчаса
	const KEEP      = 30 * DAY_IN_SECONDS;    // сколько хранить последнюю удачную копию
	const FETCH_HOOK = 'logshield_update_fetch';
	const UPDATE_URI = 'https://github.com/SargeMadovsky/logshield-releases';

	public static function init() {
		add_filter( 'update_plugins_github.com', [ __CLASS__, 'check' ], 10, 3 );
		add_filter( 'plugins_api', [ __CLASS__, 'info' ], 20, 3 );
		add_filter( 'upgrader_source_selection', [ __CLASS__, 'fix_folder' ], 10, 4 );
		// Проверка sha256 архива до распаковки (см. pre_download()).
		add_filter( 'upgrader_pre_download', [ __CLASS__, 'pre_download' ], 10, 4 );
		// «Проверить снова» на странице обновлений — читаем update.json заново (в фоне).
		add_action( 'load-update-core.php', [ __CLASS__, 'maybe_flush' ] );
		add_action( self::FETCH_HOOK, [ __CLASS__, 'fetch_cron' ] );
	}

	public static function basename() {
		// Фильтр — для тестов (плагин в папке с другим именем).
		return (string) apply_filters( 'logshield_plugin_basename', plugin_basename( LOGSHIELD_FILE ) );
	}

	/**
	 * Рабочая копия из git (как на стенде: плагин подключён ссылкой на репозиторий).
	 * Обновление стёрло бы её и заменило архивом — такие копии не обновляем.
	 */
	public static function is_dev_checkout() {
		$dev = file_exists( LOGSHIELD_DIR . '.git' );
		return (bool) apply_filters( 'logshield_is_dev_checkout', $dev );
	}

	/** Фильтр update_plugins_github.com: данные о последней версии или false. */
	public static function check( $update, $plugin_data, $plugin_file ) {
		if ( $plugin_file !== self::basename() ) return $update;
		if ( self::is_dev_checkout() ) return $update;

		$m = self::manifest();
		if ( ! $m ) return $update;

		return array_merge( self::item( $m ), [ 'version' => $m['version'] ] );
	}

	/** Поля записи об обновлении (как у WordPress в update_plugins). */
	private static function item( array $m ) {
		return [
			'slug'         => self::SLUG,
			'url'          => self::UPDATE_URI,
			'package'      => $m['download_url'],
			'tested'       => $m['tested'] ?? '',
			'requires_php' => $m['requires_php'] ?? '',
			'icons'        => [],
		];
	}

	/** Окно «Подробнее» / «Посмотреть детали версии». */
	public static function info( $result, $action, $args ) {
		if ( $action !== 'plugin_information' || ! isset( $args->slug ) || $args->slug !== self::SLUG ) return $result;
		$m = self::manifest();
		if ( ! $m ) return $result;

		$data = get_plugin_data( LOGSHIELD_FILE, false, false );
		return (object) [
			'name'          => 'LogShield',
			'slug'          => self::SLUG,
			'version'       => $m['version'],
			'author'        => 'LogShield',
			'homepage'      => 'https://github.com/SargeMadovsky/logshield-releases',
			'requires'      => $m['requires'] ?? '',
			'requires_php'  => $m['requires_php'] ?? '',
			'tested'        => $m['tested'] ?? '',
			'last_updated'  => $m['released'] ?? '',
			'download_link' => $m['download_url'],
			'sections'      => [
				'description' => '<p>' . esc_html( $data['Description'] ?? '' ) . '</p>',
				'changelog'   => self::changelog_html( $m['changelog'] ?? '' ),
			],
		];
	}

	/**
	 * Архив распаковывается в папку «logshield». Если плагин стоит в папке с другим
	 * именем (например, «logshield-main»), WordPress поставил бы новую версию рядом,
	 * а старая осталась бы. Переименовываем распакованное под текущую папку.
	 */
	public static function fix_folder( $source, $remote_source, $upgrader, $hook_extra = [] ) {
		if ( empty( $hook_extra['plugin'] ) || $hook_extra['plugin'] !== self::basename() ) return $source;
		global $wp_filesystem;
		$want = trailingslashit( $remote_source ) . dirname( self::basename() ) . '/';
		if ( untrailingslashit( $source ) === untrailingslashit( $want ) ) return $source;
		if ( ! $wp_filesystem || ! $wp_filesystem->move( $source, $want, true ) ) {
			return new WP_Error( 'logshield_rename', 'Не удалось переименовать папку обновления LogShield.' );
		}
		return $want;
	}

	/**
	 * Фильтр upgrader_pre_download: скачиваем архив сами и сверяем sha256 из update.json
	 * ДО распаковки.
	 *
	 * Почему этот хук: только здесь есть и URL пакета, и момент до unzip, а файл ещё не
	 * удалён. В upgrader_package_options файла ещё нет, в upgrader_source_selection архив
	 * уже распакован и удалён (WP_Upgrader::unpack_package), так что хэшировать нечего.
	 * Через этот же путь идут ручное, массовое и автоматическое обновление.
	 * Возвращённый путь WordPress сам удалит после распаковки (файл не совпадает с $package).
	 *
	 * Наш пакет узнаём по точному совпадению URL с download_url сохранённого манифеста;
	 * всё остальное (другие плагины, темы, ядро, переводы) возвращается как пришло.
	 * Манифест берётся только из сохранённой копии — GitHub здесь не спрашивается.
	 *
	 * Обратная совместимость: в update.json версий 1.2.5 и старше sha256 нет — тогда
	 * возвращаем $reply, и WordPress качает и ставит как раньше, без проверки.
	 *
	 * @return false|string|WP_Error
	 */
	public static function pre_download( $reply, $package, $upgrader = null, $hook_extra = [] ) {
		if ( $reply !== false || ! is_string( $package ) || $package === '' ) return $reply;
		$m = self::manifest( false );
		if ( ! $m || empty( $m['sha256'] ) || $package !== $m['download_url'] ) return $reply;

		if ( ! function_exists( 'download_url' ) ) require_once ABSPATH . 'wp-admin/includes/file.php';
		if ( is_object( $upgrader ) && isset( $upgrader->skin ) && is_object( $upgrader->skin ) ) {
			$upgrader->skin->feedback( 'downloading_package', $package );
		}
		$file = download_url( $package, 300, false );
		if ( is_wp_error( $file ) ) {
			return new WP_Error( 'download_failed', 'Не удалось скачать обновление LogShield.', $file->get_error_message() );
		}

		$error = '';
		$size  = @filesize( $file );
		if ( isset( $m['size'] ) && $size !== $m['size'] ) {
			$error = sprintf( 'размер %s байт, а в update.json — %s', (int) $size, (int) $m['size'] );
		} else {
			$hash = hash_file( 'sha256', $file );
			if ( ! is_string( $hash ) || ! hash_equals( $m['sha256'], $hash ) ) {
				$error = 'контрольная сумма sha256 не совпадает с update.json';
			}
		}
		if ( $error !== '' ) {
			@unlink( $file );
			return new WP_Error(
				'logshield_checksum',
				'Архив обновления LogShield повреждён или подменён (' . $error . '). Обновление не установлено, текущая версия не тронута. Попробуйте позже.'
			);
		}
		return $file;
	}

	/** Строка для настроек: когда и как прошла последняя проверка обновлений. */
	public static function last_check_text() {
		$l = get_option( self::LAST );
		if ( ! is_array( $l ) ) return 'GitHub ещё не опрашивался.';
		$s = wp_date( 'd.m H:i', $l['time'] ) . ', ' . number_format( $l['ms'] / 1000, 1, ',', '' ) . ' с — ';
		return $s . ( $l['ok'] ? 'ответ получен' : 'ошибка: ' . $l['error'] );
	}

	/** «Проверить снова» на странице «Обновления»: запросить update.json в фоне. */
	public static function maybe_flush() {
		if ( ! isset( $_GET['force-check'] ) || ! current_user_can( 'update_plugins' ) ) return;
		$c = get_site_transient( self::CACHE );
		if ( is_array( $c ) ) {
			$c['next'] = 0;
			set_site_transient( self::CACHE, $c, self::KEEP );
		}
		self::schedule();
		spawn_cron(); // фоновый запрос к wp-cron.php, страницу не задерживает
	}

	/**
	 * update.json из репозитория сборок.
	 *
	 * В обычном запросе (страница админки) GitHub НЕ спрашивается: только сохранённая
	 * копия, а если она устарела — фоновая задача WP-Cron. С российских хостингов
	 * GitHub бывает недоступен или отвечает десятками секунд; синхронный запрос на
	 * странице «Обновления» обрывал соединение и ронял связь с БД.
	 *
	 * @param bool $allow_fetch Можно ли спросить GitHub прямо сейчас (в WP-Cron — да).
	 * @return array|null [ version, download_url, requires, requires_php, tested, released, changelog ]
	 */
	public static function manifest( $allow_fetch = null ) {
		if ( $allow_fetch === null ) $allow_fetch = wp_doing_cron();
		$c     = get_site_transient( self::CACHE );
		$data  = is_array( $c ) && isset( $c['data'] ) && is_array( $c['data'] ) ? $c['data'] : null;
		$stale = ! is_array( $c ) || (int) ( $c['next'] ?? 0 ) <= time();
		if ( ! $stale ) return $data;
		if ( $allow_fetch ) return self::refresh();
		self::schedule();
		return $data; // пока — что есть (старая копия лучше, чем ничего)
	}

	/** Запрос к GitHub. Неудача не стирает прошлую удачную копию. */
	public static function refresh() {
		$url   = (string) apply_filters( 'logshield_update_manifest_url', self::MANIFEST );
		$start = microtime( true );
		$res   = wp_remote_get( $url, [ 'timeout' => self::TIMEOUT, 'headers' => [ 'Accept' => 'application/json' ] ] );
		$ms    = (int) round( ( microtime( true ) - $start ) * 1000 );
		$data  = null;
		$error = '';
		if ( is_wp_error( $res ) ) {
			$error = $res->get_error_message();
		} elseif ( (int) wp_remote_retrieve_response_code( $res ) !== 200 ) {
			$error = 'HTTP ' . (int) wp_remote_retrieve_response_code( $res );
		} else {
			$data = self::validate( json_decode( wp_remote_retrieve_body( $res ), true ) );
			if ( ! $data ) $error = 'update.json не прошёл проверку';
		}
		update_option( self::LAST, [ 'time' => time(), 'ms' => $ms, 'ok' => (bool) $data, 'error' => mb_substr( $error, 0, 300 ) ], false );

		$old = get_site_transient( self::CACHE );
		$keep = is_array( $old ) && isset( $old['data'] ) && is_array( $old['data'] ) ? $old['data'] : null;
		set_site_transient( self::CACHE, [
			'data' => $data ?: $keep,
			'next' => time() + ( $data ? self::CACHE_TTL : self::FAIL_TTL ),
		], self::KEEP );
		return $data ?: $keep;
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::FETCH_HOOK ) ) wp_schedule_single_event( time(), self::FETCH_HOOK );
	}

	/**
	 * Фоновая задача: обновить update.json и, если вышла новая версия, сразу
	 * показать её в списке обновлений (иначе WordPress заметил бы её только
	 * при своей следующей проверке, раз в 12 часов).
	 */
	public static function fetch_cron() {
		if ( self::is_dev_checkout() ) return;
		$m = self::refresh();
		if ( ! $m ) return;
		$t = get_site_transient( 'update_plugins' );
		if ( ! is_object( $t ) ) return; // WordPress ещё ни разу не проверял — проверит сам и спросит check()
		$file = self::basename();
		$cur  = isset( $t->checked[ $file ] ) ? $t->checked[ $file ] : LOGSHIELD_VERSION;
		$item = (object) array_merge( self::item( $m ), [ 'id' => self::UPDATE_URI, 'plugin' => $file, 'new_version' => $m['version'] ] );
		if ( version_compare( $m['version'], $cur, '>' ) ) {
			if ( isset( $t->response[ $file ] ) && $t->response[ $file ]->new_version === $m['version'] ) return;
			$t->response[ $file ] = $item;
			unset( $t->no_update[ $file ] );
		} else {
			if ( ! isset( $t->response[ $file ] ) ) return;
			unset( $t->response[ $file ] );
			$t->no_update[ $file ] = $item;
		}
		set_site_transient( 'update_plugins', $t );
	}

	/** Проверяет update.json: версия вида 1.2.3 и ссылка на zip в репозитории сборок по https. */
	public static function validate( $m ) {
		if ( ! is_array( $m ) || ! isset( $m['version'], $m['download_url'] ) ) return null;
		if ( ! is_string( $m['version'] ) || ! preg_match( '~^\d+(\.\d+){1,3}$~', $m['version'] ) ) return null;
		$prefix = (string) apply_filters( 'logshield_update_package_prefix', 'https://raw.githubusercontent.com/SargeMadovsky/logshield-releases/' );
		if ( ! is_string( $m['download_url'] ) || strpos( $m['download_url'], $prefix ) !== 0 || substr( $m['download_url'], -4 ) !== '.zip' ) return null;
		$out = [ 'version' => $m['version'], 'download_url' => $m['download_url'] ];
		// sha256 — только 64 hex в нижнем регистре (так пишет build.sh); иное поле игнорируется,
		// и архив ставится без проверки, как до 1.2.6.
		if ( isset( $m['sha256'] ) && is_string( $m['sha256'] ) && preg_match( '~^[0-9a-f]{64}$~D', $m['sha256'] ) ) $out['sha256'] = $m['sha256'];
		if ( isset( $m['size'] ) && is_int( $m['size'] ) && $m['size'] > 0 ) $out['size'] = $m['size'];
		foreach ( [ 'requires', 'requires_php', 'tested', 'released', 'changelog' ] as $k ) {
			if ( isset( $m[ $k ] ) && is_string( $m[ $k ] ) ) $out[ $k ] = $m[ $k ];
		}
		return $out;
	}

	/** Список изменений: строки «- текст» → <ul>, остальное — абзацы. Всё экранируется. */
	public static function changelog_html( $text ) {
		$html = '';
		$list = false;
		// Флаг u обязателен: без него \R считает переводом строки байт 0x85,
		// а он есть внутри русских букв в UTF-8 («х» = D1 85) — строки рвались посередине.
		foreach ( preg_split( '~\R~u', (string) $text ) ?: [] as $line ) {
			$line = trim( $line );
			if ( $line === '' ) continue;
			if ( preg_match( '~^[-*]\s+(.*)$~u', $line, $mm ) ) {
				if ( ! $list ) { $html .= '<ul>'; $list = true; }
				$html .= '<li>' . esc_html( $mm[1] ) . '</li>';
				continue;
			}
			if ( $list ) { $html .= '</ul>'; $list = false; }
			$html .= '<h4>' . esc_html( $line ) . '</h4>';
		}
		if ( $list ) $html .= '</ul>';
		return $html !== '' ? $html : '<p>Нет описания изменений.</p>';
	}
}
