<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LogShield_Whitelist {

	// IP сотрудников: ip => [ 't' => время последнего визита, 'u' => [ логин => время ] ]
	// (в старых версиях значением было просто время — читается тоже).
	const ADMIN_IPS_OPTION  = 'logshield_admin_ips';
	const MAX_LOGINS_PER_IP = 5;
	const SERVER_IPS_OPTION = 'logshield_server_ips'; // IP самого сервера: ip => время
	const ADMIN_IP_TTL_DAYS = 30;
	// Как часто обновлять отметку времени для уже известного IP (не писать в БД на каждый запрос).
	const TOUCH_INTERVAL    = HOUR_IN_SECONDS;

	/**
	 * Диапазоны Cloudflare для кнопки «Вставить диапазоны Cloudflare» в настройках.
	 * Зашиты в код намеренно: при сохранении настроек сеть не запрашивается.
	 * Источник: https://www.cloudflare.com/ips-v4 и https://www.cloudflare.com/ips-v6
	 * (страница https://www.cloudflare.com/ips/). Список меняется редко, но при
	 * выпуске новой версии плагина его стоит сверить с источником.
	 */
	const CLOUDFLARE_RANGES = [
		'173.245.48.0/20',
		'103.21.244.0/22',
		'103.22.200.0/22',
		'103.31.4.0/22',
		'141.101.64.0/18',
		'108.162.192.0/18',
		'190.93.240.0/20',
		'188.114.96.0/20',
		'197.234.240.0/22',
		'198.41.128.0/17',
		'162.158.0.0/15',
		'104.16.0.0/13',
		'104.24.0.0/14',
		'172.64.0.0/13',
		'131.0.72.0/22',
		'2400:cb00::/32',
		'2606:4700::/32',
		'2803:f800::/32',
		'2405:b500::/32',
		'2405:8100::/32',
		'2a06:98c0::/29',
		'2c0f:f248::/32',
	];

	/**
	 * Кого считать сотрудником: по умолчанию всех, кто может писать записи
	 * (автор, редактор, администратор). Их обращения к admin-ajax.php
	 * (heartbeat, редактор блоков) легко набирают сотни запросов.
	 */
	public static function trusted_capability() {
		return apply_filters( 'logshield_trusted_capability', 'edit_posts' );
	}

	/**
	 * Доверенные прокси (IP и CIDR), от которых принимаются заголовки
	 * CF-Connecting-IP, X-Real-IP и X-Forwarded-For. По умолчанию — никто:
	 * эти заголовки может прислать кто угодно, и без проверки любой сотрудник
	 * внёс бы в белый список произвольный адрес.
	 */
	public static function trusted_proxies() {
		// Список из настроек («Доверенные прокси»); фильтр получает его на вход
		// и может дополнить или заменить.
		$opts = LogShield_Plugin::get_options();
		$list = apply_filters( 'logshield_trusted_proxies', (array) ( $opts['trusted_proxies'] ?? [] ) );
		return array_values( array_filter( (array) $list, [ 'LogShield_IP', 'is_valid_entry' ] ) );
	}

	/**
	 * Разбирает текст из поля настроек (по строке или через запятую) на
	 * корректные IP/CIDR и отброшенные строки.
	 *
	 * @return array [ 'valid' => [...], 'invalid' => [...] ]
	 */
	public static function parse_entries( $raw ) {
		$valid   = [];
		$invalid = [];
		foreach ( preg_split( '/[\r\n,]+/', (string) $raw ) as $line ) {
			$line = trim( $line );
			if ( $line === '' ) continue;
			if ( LogShield_IP::is_valid_entry( $line ) ) {
				if ( ! in_array( $line, $valid, true ) ) $valid[] = $line;
			} else {
				$invalid[] = $line;
			}
		}
		return [ 'valid' => $valid, 'invalid' => $invalid ];
	}

	/**
	 * Почему адрес в белом списке — по тем же источникам, что и
	 * get_full_whitelist(), с учётом диапазонов CIDR и разной записи IPv6.
	 *
	 * @param string     $ip     адрес
	 * @param array|null $manual ручной список (null — из настроек)
	 * @return array|null [ 'type' => staff|manual|server|proxy|localhost, 'entry' => запись списка, 'text' => пояснение ]
	 *                    или null — адреса в белом списке нет
	 */
	public static function whitelist_reason( $ip, $manual = null ) {
		$ip = (string) $ip;
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) return null;
		if ( $manual === null ) $manual = (array) ( LogShield_Plugin::get_options()['whitelist_ips'] ?? [] );

		foreach ( [ '127.0.0.1', '::1' ] as $e ) {
			if ( LogShield_IP::matches( $ip, $e ) ) return [ 'type' => 'localhost', 'entry' => $e, 'text' => 'локальный адрес' ];
		}
		foreach ( self::get_admin_users() as $e => $logins ) {
			if ( LogShield_IP::matches( $ip, (string) $e ) ) {
				return [ 'type' => 'staff', 'entry' => (string) $e, 'text' => 'сотрудник' . ( $logins ? ' (' . implode( ', ', $logins ) . ')' : '' ) ];
			}
		}
		foreach ( (array) $manual as $e ) {
			$e = (string) $e;
			if ( LogShield_IP::matches( $ip, $e ) ) {
				return [ 'type' => 'manual', 'entry' => $e, 'text' => strpos( $e, '/' ) !== false ? 'вручную, диапазон ' . $e : 'вручную' ];
			}
		}
		foreach ( self::get_server_ips() as $e ) {
			if ( LogShield_IP::matches( $ip, $e ) ) return [ 'type' => 'server', 'entry' => $e, 'text' => 'адрес сервера' ];
		}
		foreach ( self::trusted_proxies() as $e ) {
			if ( LogShield_IP::matches( $ip, $e ) ) {
				return [ 'type' => 'proxy', 'entry' => $e, 'text' => 'доверенный прокси' . ( strpos( $e, '/' ) !== false ? ', диапазон ' . $e : '' ) ];
			}
		}
		return null;
	}

	/** Адрес в полном белом списке (см. whitelist_reason()). */
	public static function is_whitelisted( $ip, $manual = null ) {
		return self::whitelist_reason( $ip, $manual ) !== null;
	}

	/**
	 * Определяет IP текущего посетителя (используется только в контексте
	 * админки WP — для авто-добавления в белый список, а не для анализа лога).
	 *
	 * По умолчанию это REMOTE_ADDR — тот же адрес, который Apache пишет в
	 * access_log (%h) и по которому срабатывают баны в .htaccess
	 * (%{REMOTE_ADDR}). Поэтому в белый список попадает ровно то, что видит
	 * детектор. Если на сервере стоит mod_remoteip, REMOTE_ADDR уже
	 * содержит адрес клиента и в логе, и здесь — всё сходится само.
	 *
	 * Заголовки прокси читаются, только если REMOTE_ADDR — доверенный прокси
	 * из настроек («Доверенные прокси», фильтр logshield_trusted_proxies). Тогда возвращается адрес клиента
	 * (так его видит лог с LogFormat по X-Forwarded-For, и его показываем
	 * сотруднику), а сами доверенные прокси добавляются в общий белый список
	 * в get_full_whitelist(): если Apache пишет в лог адрес прокси, детектор
	 * увидит именно его, и бан прокси закрыл бы сайт для всех. Так белый
	 * список совпадает с логом при любой из двух схем записи.
	 */
	public static function get_client_ip() {
		$remote = self::server_ip_value( 'REMOTE_ADDR' );
		if ( $remote === '' ) return '';
		$proxies = self::trusted_proxies();
		if ( ! $proxies || ! LogShield_IP::matches_any( $remote, $proxies ) ) return $remote;

		foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP' ] as $key ) {
			$ip = self::server_ip_value( $key );
			if ( $ip !== '' ) return $ip;
		}
		// X-Forwarded-For дописывается каждым прокси справа: идём с конца и
		// берём первый адрес, который не является доверенным прокси. Левые
		// значения мог подставить сам клиент, поэтому им не верим.
		if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$chain = array_reverse( explode( ',', sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) ) );
			foreach ( $chain as $ip ) {
				$ip = trim( $ip );
				if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) break;
				if ( ! LogShield_IP::matches_any( $ip, $proxies ) ) return $ip;
			}
		}
		return $remote;
	}

	/** Значение $_SERVER[$key], если это один корректный IP, иначе ''. */
	private static function server_ip_value( $key ) {
		if ( empty( $_SERVER[ $key ] ) ) return '';
		$ip = trim( sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) );
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}

	/**
	 * При успешном входе сотрудника запоминаем его IP как доверенный.
	 */
	public static function on_login( $user_login, $user ) {
		if ( $user instanceof WP_User && user_can( $user, self::trusted_capability() ) ) {
			$ip = self::get_client_ip();
			if ( $ip ) self::add_admin_ip( $ip, false, $user->user_login );
		}
	}

	/**
	 * На каждом запросе (дёшево: опции автозагружаются, запись — не чаще раза в час):
	 * - сотрудник, вошедший по cookie «запомнить меня», тоже попадает в whitelist —
	 *   события wp_login у него не бывает, а IP мог смениться;
	 * - IP самого сервера: SERVER_ADDR и адрес, с которого WordPress стучится
	 *   сам к себе в wp-cron.php (за NAT это может быть другой адрес).
	 */
	public static function on_init() {
		if ( ! empty( $_SERVER['SERVER_ADDR'] ) ) {
			self::add_server_ip( sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) ) );
		}
		if ( self::is_verified_cron_loopback() && ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			self::add_server_ip( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) );
		}
		if ( is_user_logged_in() && current_user_can( self::trusted_capability() ) ) {
			$ip = self::get_client_ip();
			if ( $ip ) self::add_admin_ip( $ip, true, wp_get_current_user()->user_login );
		}
	}

	/**
	 * Запрос — это настоящий вызов wp-cron.php, запущенный самим WordPress:
	 * в адресе передан ключ doing_wp_cron, совпадающий с транзиентом doing_cron,
	 * который WordPress только что выставил. Угадать ключ снаружи нельзя
	 * (это microtime с 22 знаками), поэтому подделать «сервер» не получится.
	 * User-Agent «WordPress/…» намеренно не используется — его подделать легко.
	 */
	private static function is_verified_cron_loopback() {
		if ( ! function_exists( 'wp_doing_cron' ) || ! wp_doing_cron() ) return false;
		if ( empty( $_GET['doing_wp_cron'] ) ) return false;
		$key       = sanitize_text_field( wp_unslash( $_GET['doing_wp_cron'] ) );
		$transient = get_transient( 'doing_cron' );
		return is_string( $transient ) && $transient !== '' && hash_equals( $transient, $key );
	}

	/**
	 * Запоминает IP сотрудника и его логин. С $throttle запись в БД не чаще
	 * раза в час на IP — но новый логин с того же адреса пишется сразу.
	 *
	 * @return array|false снятые баны (только для нового адреса, иначе []);
	 *                     false — снять пытались, но .htaccess не записан
	 */
	public static function add_admin_ip( $ip, $throttle = false, $login = '' ) {
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) return [];
		$login = (string) $login;
		$list  = get_option( self::ADMIN_IPS_OPTION, [] );
		if ( ! is_array( $list ) ) $list = [];
		$entry = self::admin_entry( $list[ $ip ] ?? null );
		if ( $throttle && $entry['t'] > time() - self::TOUCH_INTERVAL && ( $login === '' || isset( $entry['u'][ $login ] ) ) ) return [];
		// Нового адреса (или просроченного) в белом списке не было: после записи
		// снимаем баны, которые его задевают. Для известного адреса — ничего лишнего.
		$is_new     = ! self::is_fresh( $entry['t'] );
		$entry['t'] = time();
		if ( $login !== '' ) {
			$entry['u'][ $login ] = time();
			arsort( $entry['u'] );
			$entry['u'] = array_slice( $entry['u'], 0, self::MAX_LOGINS_PER_IP, true );
		}
		$list[ $ip ] = $entry;
		update_option( self::ADMIN_IPS_OPTION, self::prune( $list ) );
		return $is_new ? self::release_bans( [ $ip ] ) : [];
	}

	/** Отметка времени ещё не просрочена (адрес активен в белом списке). */
	private static function is_fresh( $t ) {
		return (int) $t >= time() - ( self::ADMIN_IP_TTL_DAYS * DAY_IN_SECONDS );
	}

	/**
	 * Снимает баны, которые задевают белый список (см.
	 * LogShield_Htaccess::release_whitelisted()). Без аргумента — полный белый
	 * список: сотрудники, сервер, прокси, ручной список из настроек, localhost.
	 * Неудачная запись запоминается как ошибка записи .htaccess (видна на
	 * дашборде), удачная — снимает прошлое предупреждение: блок переписан
	 * целиком по списку.
	 *
	 * @return array|false снятые записи; false — .htaccess записать не удалось
	 */
	public static function release_bans( $entries = null ) {
		if ( $entries === null ) {
			$opts    = LogShield_Plugin::get_options();
			$entries = self::get_full_whitelist( $opts['whitelist_ips'] ?? [] );
		}
		$released = LogShield_Htaccess::release_whitelisted( (array) $entries );
		if ( $released === false ) {
			$err = (string) LogShield_Htaccess::last_error();
			LogShield_Detector::remember_write_error( $err !== '' ? $err : 'неизвестная ошибка записи' );
		} elseif ( $released ) {
			LogShield_Detector::clear_write_error();
		}
		return $released;
	}

	/**
	 * Убирает записи старше ADMIN_IP_TTL_DAYS. Вызывается при каждой записи,
	 * иначе автозагружаемая опция росла бы бесконечно (при чтении устаревшие
	 * адреса и так отбрасываются). Формат оставшихся записей не меняется:
	 * и ip => время, и ip => [ 't' => …, 'u' => … ].
	 */
	private static function prune( array $list ) {
		$cutoff = time() - ( self::ADMIN_IP_TTL_DAYS * DAY_IN_SECONDS );
		foreach ( $list as $ip => $v ) {
			if ( self::admin_entry( $v )['t'] < $cutoff ) unset( $list[ $ip ] );
		}
		return $list;
	}

	/** Запись об IP сотрудника в текущем формате (старый формат — просто время). */
	private static function admin_entry( $v ) {
		if ( is_array( $v ) ) return [ 't' => (int) ( $v['t'] ?? 0 ), 'u' => (array) ( $v['u'] ?? [] ) ];
		return [ 't' => (int) $v, 'u' => [] ];
	}

	/**
	 * Активные IP сотрудников с логинами: ip => [ логины, свежие первыми ].
	 * Пустой список логинов — адрес записан до того, как плагин стал их хранить.
	 */
	public static function get_admin_users() {
		$cutoff = time() - ( self::ADMIN_IP_TTL_DAYS * DAY_IN_SECONDS );
		$out    = [];
		foreach ( (array) get_option( self::ADMIN_IPS_OPTION, [] ) as $ip => $v ) {
			$e = self::admin_entry( $v );
			if ( $e['t'] < $cutoff ) continue;
			arsort( $e['u'] );
			$out[ (string) $ip ] = array_map( 'strval', array_keys( $e['u'] ) );
		}
		return $out;
	}

	public static function add_server_ip( $ip ) {
		// Новый адрес сервера (например, сменился IP за NAT): снимаем баны,
		// которые его задевают, — иначе WP-Cron стучался бы в 403.
		if ( self::touch( self::SERVER_IPS_OPTION, $ip, true ) ) self::release_bans( [ $ip ] );
	}

	/** @return bool адрес новый (его не было или запись просрочена) и записан */
	private static function touch( $option, $ip, $throttle ) {
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) return false;
		$list = get_option( $option, [] );
		if ( ! is_array( $list ) ) $list = [];
		if ( $throttle && isset( $list[ $ip ] ) && $list[ $ip ] > time() - self::TOUCH_INTERVAL ) return false;
		$is_new      = ! isset( $list[ $ip ] ) || ! self::is_fresh( self::admin_entry( $list[ $ip ] )['t'] );
		$list[ $ip ] = time();
		update_option( $option, self::prune( $list ) );
		return $is_new;
	}

	public static function get_admin_ips() {
		return self::active( self::ADMIN_IPS_OPTION );
	}

	public static function get_server_ips() {
		return self::active( self::SERVER_IPS_OPTION );
	}

	private static function active( $option ) {
		$list   = (array) get_option( $option, [] );
		$cutoff = time() - ( self::ADMIN_IP_TTL_DAYS * DAY_IN_SECONDS );
		$active = [];
		foreach ( $list as $ip => $v ) {
			if ( self::admin_entry( $v )['t'] >= $cutoff ) $active[] = (string) $ip;
		}
		return $active;
	}

	/**
	 * Полный список IP и диапазонов CIDR, которые никогда не должны попасть в бан:
	 * сотрудники WP (по факту входа), сам сервер, доверенные прокси
	 * (см. get_client_ip()), ручной whitelist из настроек, localhost.
	 */
	public static function get_full_whitelist( $manual_whitelist = [] ) {
		$list = array_merge(
			[ '127.0.0.1', '::1' ],
			self::get_server_ips(),
			self::trusted_proxies(),
			self::get_admin_ips(),
			(array) $manual_whitelist
		);
		return array_values( array_unique( array_filter( $list ) ) );
	}

	/**
	 * Фильтрация "собственных" запросов плагина, чтобы они не попадали
	 * под анализ и не искажали статистику (например, ручной запуск
	 * сканирования из админки или сама страница настроек).
	 */
	public static function is_own_request( array $entry ) {
		$path = isset( $entry['path'] ) ? $entry['path'] : '';
		if ( $path === '' ) return false;
		// Вызывается на каждую строку лога. Все проверки ниже требуют «logshield»
		// в пути (is_ping — «logshield_ping» с учётом регистра), так что без этого
		// слова ответ всегда false — выходим сразу.
		if ( stripos( $path, 'logshield' ) === false ) return false;
		// Проверка доступности от воркера (tools/uptime-worker) с верным ключом.
		if ( LogShield_Ping::is_ping( $entry ) ) return true;
		if ( stripos( $path, 'admin-post.php' ) !== false && stripos( $path, 'logshield' ) !== false ) return true;
		if ( stripos( $path, 'page=logshield' ) !== false ) return true;
		// Опрос хвоста лога с дашборда (живой режим).
		if ( stripos( $path, 'admin-ajax.php' ) !== false && stripos( $path, 'action=logshield_' ) !== false ) return true;
		return false;
	}
}
