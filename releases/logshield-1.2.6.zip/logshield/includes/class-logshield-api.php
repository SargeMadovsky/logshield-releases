<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * REST-эндпоинт для центральной панели (хаба):
 *
 *   GET /wp-json/logshield/v1/stats?since=<unix>
 *   Authorization: Bearer <токен>     (или X-LogShield-Token: <токен>)
 *
 * Только чтение. Токен выпускается на странице «LogShield → Доступ по API»,
 * показывается один раз и хранится только хэшем (sha256) в опции
 * logshield_api_token_hash. Без верного токена — 401. Сводная панель по
 * нескольким сайтам — отдельный проект, в этом плагине её нет.
 *
 * Наружу уходят только агрегаты и адреса атакующих. Путь к логу, белый список,
 * IP сотрудников и сервера не отдаются.
 */
class LogShield_API {

	const SLUG          = 'logshield-api';
	const NS            = 'logshield/v1';
	const HASH_OPTION   = 'logshield_api_token_hash';
	const TOKEN_PREFIX  = 'lsk_';
	const MAX_ATTACKERS = 100;
	const FORMAT        = 1; // версия формата ответа

	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
		add_action( 'admin_menu', [ __CLASS__, 'add_menu' ], 20 );
		add_action( 'admin_post_logshield_api_token', [ __CLASS__, 'handle_token' ] );
		add_action( 'admin_notices', [ __CLASS__, 'notices' ] );
	}

	public static function register_routes() {
		register_rest_route( self::NS, '/stats', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'get_stats' ],
			'permission_callback' => [ __CLASS__, 'check_token' ],
			'args'                => [
				'since' => [
					'type'              => 'integer',
					'minimum'           => 0,
					'default'           => 0,
					'validate_callback' => 'rest_validate_request_arg',
					'sanitize_callback' => 'rest_sanitize_request_arg',
				],
			],
		] );
	}

	/** Новый токен: возвращается один раз, сохраняется только хэш. */
	public static function generate_token() {
		$token = self::TOKEN_PREFIX . wp_generate_password( 40, false, false );
		update_option( self::HASH_OPTION, hash( 'sha256', $token ), false );
		return $token;
	}

	public static function revoke_token() {
		delete_option( self::HASH_OPTION );
	}

	public static function has_token() {
		return (string) get_option( self::HASH_OPTION, '' ) !== '';
	}

	public static function is_valid_token_format( $token ) {
		return is_string( $token ) && (bool) preg_match( '/^' . self::TOKEN_PREFIX . '[A-Za-z0-9]{40}$/', $token );
	}

	/** Токен из запроса: Bearer или запасной заголовок (некоторые хостинги режут Authorization). */
	public static function token_from_request( WP_REST_Request $request ) {
		$auth = (string) $request->get_header( 'authorization' );
		if ( $auth === '' ) {
			// PHP-FPM/CGI без проброса заголовка: WordPress в .htaccess кладёт его в переменную окружения.
			foreach ( [ 'HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION' ] as $k ) {
				if ( ! empty( $_SERVER[ $k ] ) ) { $auth = (string) $_SERVER[ $k ]; break; }
			}
		}
		if ( $auth === '' && function_exists( 'getallheaders' ) ) {
			// mod_php не кладёт Authorization: Bearer в $_SERVER, а REST API WordPress читает только оттуда.
			foreach ( (array) getallheaders() as $name => $value ) {
				if ( strcasecmp( (string) $name, 'Authorization' ) === 0 ) { $auth = (string) $value; break; }
			}
		}
		if ( preg_match( '/^\s*Bearer\s+(\S+)\s*$/i', $auth, $m ) ) return $m[1];
		return trim( (string) $request->get_header( 'x_logshield_token' ) );
	}

	/** @return true|WP_Error */
	public static function check_token( WP_REST_Request $request ) {
		$hash  = (string) get_option( self::HASH_OPTION, '' );
		$token = self::token_from_request( $request );
		// hash_equals вызывается всегда — время ответа не зависит от того, задан ли токен.
		$given = hash( 'sha256', $token );
		$ok    = hash_equals( $hash !== '' ? $hash : str_repeat( '0', 64 ), $given );
		if ( $ok && $hash !== '' && $token !== '' ) return true;
		return new WP_Error( 'logshield_unauthorized', 'Нужен верный токен LogShield.', [ 'status' => 401 ] );
	}

	public static function get_stats( WP_REST_Request $request ) {
		$response = rest_ensure_response( self::payload( (int) $request->get_param( 'since' ) ) );
		$response->header( 'Cache-Control', 'no-store' );
		return $response;
	}

	/**
	 * Данные для хаба. since — отдать только часы, начиная с часа, в который
	 * попадает since (час мог дополниться следующим сканированием, поэтому хаб
	 * запрашивает с запасом и перезаписывает полученные часы целиком).
	 */
	public static function payload( $since = 0 ) {
		$since = max( 0, (int) $since );
		$from  = $since - ( $since % HOUR_IN_SECONDS );
		$stats = [];
		foreach ( LogShield_Stats::get() as $hour => $h ) {
			if ( (int) $hour < $from ) continue;
			$stats[] = [
				(int) $hour,
				(int) ( $h['req'] ?? 0 ),
				(int) ( $h['e4'] ?? 0 ),
				(int) ( $h['e5'] ?? 0 ),
				(int) ( $h['fails'] ?? 0 ),
				(int) ( $h['ips'] ?? 0 ),
				(object) array_map( 'intval', (array) ( $h['flag'] ?? [] ) ),
			];
		}

		$attackers = [];
		foreach ( array_slice( LogShield_Dashboard::attackers(), 0, self::MAX_ATTACKERS ) as $a ) {
			$attackers[] = [
				'ip'      => (string) $a['ip'],
				'types'   => array_values( array_map( 'strval', (array) $a['types'] ) ),
				'reason'  => mb_substr( (string) $a['reason'], 0, 300 ),
				'last'    => (int) $a['last'],
				'runs'    => (int) $a['runs'],
				'banned'  => (bool) $a['banned'],
				'expires' => (int) ( $a['expires'] ?? 0 ),
			];
		}

		$opts = LogShield_Plugin::get_options();
		$last = LogShield_Detector::get_scan_log()[0] ?? null;
		return [
			'format'    => self::FORMAT,
			'version'   => LOGSHIELD_VERSION,
			'name'      => get_bloginfo( 'name' ),
			'home'      => home_url(),
			'now'       => time(),
			'dry_run'   => (bool) $opts['dry_run'],
			'interval'  => (string) $opts['interval'],
			'last_scan' => $last ? (int) $last['time'] : 0,
			'last_ok'   => $last ? ! empty( $last['ok'] ) : null,
			'next_scan' => (int) wp_next_scheduled( LOGSHIELD_CRON_HOOK ),
			'banned'    => count( LogShield_Htaccess::get_banned() ),
			'types'     => LogShield_Stats::TYPES,
			'stats'     => $stats,
			'attackers' => $attackers,
		];
	}

	/* ---------- Страница «Доступ по API» ---------- */

	public static function add_menu() {
		$hook = add_submenu_page( LogShield_Admin::SLUG_DASH, 'LogShield — доступ по API', 'Доступ по API', 'manage_options', self::SLUG, [ __CLASS__, 'render' ] );
		add_action( 'admin_enqueue_scripts', function ( $h ) use ( $hook ) {
			if ( $h !== $hook ) return;
			$ver = LOGSHIELD_VERSION . '-' . @filemtime( LOGSHIELD_DIR . 'assets/dashboard.js' );
			wp_enqueue_style( 'logshield-dashboard', LOGSHIELD_URL . 'assets/dashboard.css', [], $ver );
			wp_enqueue_script( 'logshield-dashboard', LOGSHIELD_URL . 'assets/dashboard.js', [], $ver, [ 'in_footer' => true, 'strategy' => 'defer' ] );
		} );
	}

	private static function back( $msg, $type = 'success' ) {
		wp_safe_redirect( add_query_arg(
			[ 'page' => self::SLUG, 'logshield_msg' => rawurlencode( $msg ), 'logshield_type' => $type ],
			admin_url( 'admin.php' )
		) );
		exit;
	}

	public static function notices() {
		if ( ( $_GET['page'] ?? '' ) !== self::SLUG || ! isset( $_GET['logshield_msg'] ) ) return;
		$msg  = sanitize_text_field( wp_unslash( $_GET['logshield_msg'] ) );
		$type = ( $_GET['logshield_type'] ?? '' ) === 'error' ? 'error' : 'success';
		printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $type ), esc_html( $msg ) );
	}

	/** Выпуск / отзыв токена. */
	public static function handle_token() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_api_token' );
		if ( ( $_POST['do'] ?? '' ) === 'revoke' ) {
			self::revoke_token();
			self::back( 'Токен отозван: статистика этого сайта больше не отдаётся.' );
		}
		$token = self::generate_token();
		// Показать один раз: короткий транзиент на пользователя, удаляется при показе.
		set_transient( 'logshield_new_token_' . get_current_user_id(), $token, 5 * MINUTE_IN_SECONDS );
		self::back( 'Новый токен выпущен. Скопируйте его сейчас — позже он показан не будет.' );
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$post_url  = admin_url( 'admin-post.php' );
		$has       = self::has_token();
		$new_token = get_transient( 'logshield_new_token_' . get_current_user_id() );
		if ( $new_token ) delete_transient( 'logshield_new_token_' . get_current_user_id() );
		?>
		<div class="wrap ls-wrap">
		<h1 class="screen-reader-text">LogShield — доступ по API</h1>
		<div class="ls-dash" data-theme="<?php echo esc_attr( LogShield_Dashboard::get_theme() ); ?>">
			<header class="ls-head">
				<div class="ls-brand">
					<span class="ls-logo dashicons dashicons-rest-api" aria-hidden="true"></span>
					<div>
						<p class="ls-title">LogShield · доступ по API</p>
						<p class="ls-dim">Статистика этого сайта для внешней сводной панели</p>
					</div>
				</div>
			</header>

			<section class="ls-card" aria-labelledby="ls-api-title">
				<div class="ls-card-head"><h2 id="ls-api-title">Токен доступа</h2></div>
				<div class="ls-pad ls-form">
					<p class="ls-dim">Сводная панель забирает статистику по адресу ниже, передавая токен в заголовке <code>Authorization: Bearer …</code> (или <code>X-LogShield-Token</code>). Отдаются только почасовая статистика, число банов и адреса атакующих — без пути к логу, белого списка и адресов сотрудников.</p>
					<?php if ( $new_token ) : ?>
						<div class="ls-field ls-token-new">
							<label for="ls-new-token">Новый токен — скопируйте сейчас, больше он показан не будет</label>
							<div class="ls-actions">
								<input type="text" id="ls-new-token" readonly value="<?php echo esc_attr( $new_token ); ?>" autocomplete="off" spellcheck="false">
								<button type="button" class="ls-btn" data-copy="ls-new-token">Копировать</button>
							</div>
						</div>
					<?php endif; ?>
					<p><?php echo $has ? '✅ Токен выпущен (хранится только его хэш).' : 'Токен не выпущен — статистика наружу не отдаётся.'; ?></p>
					<div class="ls-actions">
						<form method="post" action="<?php echo esc_url( $post_url ); ?>"<?php if ( $has ) : ?> data-confirm="Выпустить новый токен? Старый перестанет работать, и его надо будет заменить в сводной панели."<?php endif; ?>>
							<input type="hidden" name="action" value="logshield_api_token">
							<input type="hidden" name="do" value="new">
							<?php wp_nonce_field( 'logshield_api_token' ); ?>
							<button class="ls-btn ls-btn-accent"><?php echo $has ? 'Выпустить новый токен' : 'Выпустить токен'; ?></button>
						</form>
						<?php if ( $has ) : ?>
							<form method="post" action="<?php echo esc_url( $post_url ); ?>" data-confirm="Отозвать токен? Сводная панель перестанет получать статистику этого сайта.">
								<input type="hidden" name="action" value="logshield_api_token">
								<input type="hidden" name="do" value="revoke">
								<?php wp_nonce_field( 'logshield_api_token' ); ?>
								<button class="ls-btn ls-btn-danger">Отозвать</button>
							</form>
						<?php endif; ?>
					</div>
					<p class="ls-dim">Адрес эндпоинта: <code><?php echo esc_html( rest_url( self::NS . '/stats' ) ); ?></code> — без токена отвечает 401. С параметром <code>since=&lt;unix-время&gt;</code> отдаются только часы начиная с указанного.</p>
				</div>
			</section>
		</div>
		</div>
		<?php
	}
}
