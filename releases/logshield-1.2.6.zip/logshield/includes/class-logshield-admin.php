<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LogShield_Admin {

	const SLUG      = 'logshield-settings';
	const SLUG_DASH = 'logshield';

	/** Отдельный раздел в меню: «LogShield» → «Дашборд», «Настройки». */
	public static function add_menu() {
		// Кружок со счётчиком, как у комментариев: новые атакующие с прошлого
		// просмотра дашборда. Открыли дашборд — счётчик сбрасывается.
		if ( current_user_can( 'manage_options' ) && isset( $_GET['page'] ) && $_GET['page'] === self::SLUG_DASH ) {
			// Число до сброса — для бейджа вкладки «Атакующие».
			LogShield_Dashboard::remember_unseen();
			LogShield_Dashboard::mark_seen();
		}
		$new   = current_user_can( 'manage_options' ) ? LogShield_Dashboard::unseen_count() : 0;
		$title = 'LogShield';
		if ( $new ) {
			$title .= sprintf(
				' <span class="awaiting-mod count-%1$d"><span class="pending-count" aria-hidden="true">%1$d</span><span class="screen-reader-text">%2$s</span></span>',
				$new,
				esc_html( sprintf( 'новых атакующих: %d', $new ) )
			);
		}
		$dash = add_menu_page( 'LogShield', $title, 'manage_options', self::SLUG_DASH, [ 'LogShield_Dashboard', 'render' ], 'dashicons-shield', 81 );
		add_submenu_page( self::SLUG_DASH, 'LogShield — дашборд', 'Дашборд', 'manage_options', self::SLUG_DASH, [ 'LogShield_Dashboard', 'render' ] );
		$settings = add_submenu_page( self::SLUG_DASH, 'LogShield — настройки', 'Настройки', 'manage_options', self::SLUG, [ __CLASS__, 'render_page' ] );
		add_action( 'admin_enqueue_scripts', function ( $hook ) use ( $dash, $settings ) {
			if ( $hook === $dash ) LogShield_Dashboard::enqueue();
			if ( $hook === $settings ) self::enqueue_settings();
		} );
	}

	/**
	 * Стили и скрипт страницы настроек: общий dashboard.css (переменные темы,
	 * карточки, кнопки) и свой settings.css поверх него.
	 */
	public static function enqueue_settings() {
		$ver = function ( $file ) { return LOGSHIELD_VERSION . '-' . @filemtime( LOGSHIELD_DIR . 'assets/' . $file ); };
		wp_enqueue_style( 'logshield-dashboard', LOGSHIELD_URL . 'assets/dashboard.css', [], $ver( 'dashboard.css' ) );
		wp_enqueue_style( 'logshield-settings', LOGSHIELD_URL . 'assets/settings.css', [ 'logshield-dashboard' ], $ver( 'settings.css' ) );
		wp_enqueue_script( 'logshield-settings', LOGSHIELD_URL . 'assets/settings.js', [], $ver( 'settings.js' ), [ 'in_footer' => true, 'strategy' => 'defer' ] );
	}

	/**
	 * Поля правил обнаружения: имя => [ минимум, максимум (0 — без верхней границы), по умолчанию ].
	 * Общие для сохранения настроек и предпросмотра — значения приводятся одинаково.
	 */
	const RULE_FIELDS = [
		'rpm_threshold'           => [ 10, 0, 300 ],
		'brute_attempts'          => [ 3, 0, 10 ],
		'subnet_min_ips'          => [ 2, 256, 5 ],
		'subnet_min_attempts'     => [ 5, 0, 30 ],
		'scan_unique_paths'       => [ 5, 0, 15 ],
		'scan_min_requests'       => [ 5, 0, 20 ],
		'error_rate_pct'          => [ 1, 100, 50 ],
		'error_rate_min_requests' => [ 5, 0, 20 ],
		'sensitive_min_hits'      => [ 1, 50, 3 ],
		'enum_min_hits'           => [ 1, 50, 3 ],
	];

	/**
	 * Пороги правил из присланных полей: целое, в границах RULE_FIELDS.
	 * Поля нет — берётся $fallback[имя], а без него значение по умолчанию.
	 *
	 * @param array $src      $_POST (уже без слэшей) или его часть
	 * @param array $fallback значения для отсутствующих полей
	 * @return int[] имя => значение
	 */
	public static function sanitize_rules( array $src, array $fallback = [] ) {
		$out = [];
		foreach ( self::RULE_FIELDS as $name => list( $min, $max, $def ) ) {
			$v = ( isset( $src[ $name ] ) && is_scalar( $src[ $name ] ) ) ? (int) $src[ $name ] : (int) ( $fallback[ $name ] ?? $def );
			$v = max( $min, $v );
			if ( $max ) $v = min( $max, $v );
			$out[ $name ] = $v;
		}
		return $out;
	}

	/** Старый адрес «Настройки → LogShield» ведёт на новую страницу. */
	public static function legacy_redirect() {
		global $pagenow;
		if ( $pagenow === 'options-general.php' && isset( $_GET['page'] ) && $_GET['page'] === self::SLUG ) {
			wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG ) );
			exit;
		}
	}

	/** Параметры сообщения после действия (см. redirect_with_message()). */
	const MSG_ARGS = [ 'logshield_msg', 'logshield_type' ];

	/**
	 * Фильтр removable_query_args: WordPress пишет на странице канонический
	 * адрес без этих параметров и подменяет им адресную строку. Сообщение
	 * выводится один раз — при обновлении страницы или из закладки его нет.
	 */
	public static function removable_query_args( $args ) {
		return array_values( array_unique( array_merge( (array) $args, self::MSG_ARGS ) ) );
	}

	public static function notices() {
		if ( ! isset( $_GET['page'] ) || ! in_array( $_GET['page'], [ self::SLUG, self::SLUG_DASH ], true ) ) return;
		if ( ! isset( $_GET['logshield_msg'] ) ) return;
		$msg  = sanitize_text_field( wp_unslash( $_GET['logshield_msg'] ) );
		$type = ( isset( $_GET['logshield_type'] ) && $_GET['logshield_type'] === 'error' ) ? 'error' : 'success';
		printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $type ), esc_html( $msg ) );
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_save_settings' );

		$opts = LogShield_Plugin::get_options();
		$old_interval = $opts['interval'];

		$opts['log_path'] = isset( $_POST['log_path'] ) ? sanitize_text_field( wp_unslash( $_POST['log_path'] ) ) : '';
		$opts['interval']  = ( isset( $_POST['interval'] ) && in_array( $_POST['interval'], [ 'logshield_2h', 'logshield_3h', 'logshield_4h' ], true ) )
			? $_POST['interval'] : 'logshield_3h';
		$opts['dry_run']                 = isset( $_POST['dry_run'] );
		// Пороги правил: отсутствующее поле — значение по умолчанию (как раньше).
		foreach ( self::sanitize_rules( wp_unslash( $_POST ) ) as $name => $v ) $opts[ $name ] = $v;
		$opts['max_read_mb']             = min( 50, max( 1, (int) ( $_POST['max_read_mb'] ?? 5 ) ) );
		$opts['ipinfo_enabled']          = isset( $_POST['ipinfo_enabled'] );
		$opts['ban_expiry_days']         = max( 0, (int) ( $_POST['ban_expiry_days'] ?? 7 ) );
		$opts['notify_email']            = isset( $_POST['notify_email'] ) ? sanitize_email( wp_unslash( $_POST['notify_email'] ) ) : '';

		// Токен на страницу не выводится: пустое поле — оставить сохранённый.
		$tg_error = '';
		$token    = isset( $_POST['telegram_token'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['telegram_token'] ) ) ) : '';
		if ( ! empty( $_POST['telegram_token_clear'] ) ) {
			$opts['telegram_token'] = '';
		} elseif ( $token !== '' ) {
			if ( LogShield_Notifier::is_valid_token( $token ) ) {
				$opts['telegram_token'] = $token;
			} else {
				$tg_error = ' Токен Telegram не сохранён: неверный формат.';
			}
		}
		$chat_id = isset( $_POST['telegram_chat_id'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['telegram_chat_id'] ) ) ) : '';
		if ( $chat_id === '' || LogShield_Notifier::is_valid_chat_id( $chat_id ) ) {
			$opts['telegram_chat_id'] = $chat_id;
		} else {
			$tg_error .= ' chat_id не сохранён: неверный формат.';
		}

		// Ручной белый список и доверенные прокси: неверные строки отбрасываются
		// и перечисляются в сообщении, чтобы опечатка не потерялась молча.
		$list_error = '';
		$whitelist  = LogShield_Whitelist::parse_entries( isset( $_POST['whitelist_ips'] ) ? wp_unslash( $_POST['whitelist_ips'] ) : '' );
		$proxies    = LogShield_Whitelist::parse_entries( isset( $_POST['trusted_proxies'] ) ? wp_unslash( $_POST['trusted_proxies'] ) : '' );
		if ( $whitelist['invalid'] ) {
			$list_error .= ' Белый список: отброшены неверные строки — ' . self::short_list( array_map( 'sanitize_text_field', $whitelist['invalid'] ) ) . '.';
		}
		if ( $proxies['invalid'] ) {
			$list_error .= ' Доверенные прокси: отброшены неверные строки — ' . self::short_list( array_map( 'sanitize_text_field', $proxies['invalid'] ) ) . '.';
		}
		$old_whitelist           = array_values( (array) ( $opts['whitelist_ips'] ?? [] ) );
		$old_proxies             = array_values( (array) ( $opts['trusted_proxies'] ?? [] ) );
		$opts['whitelist_ips']   = $whitelist['valid'];
		$opts['trusted_proxies'] = $proxies['valid'];

		update_option( LOGSHIELD_OPTION, $opts );

		// Белый список или прокси изменились — снимаем баны, которые их теперь
		// задевают (так администратор выпускает сотрудника, которого Apache уже
		// не пускает, а бан адреса прокси закрыл бы сайт для всех).
		$released = [];
		if ( $whitelist['valid'] !== $old_whitelist || $proxies['valid'] !== $old_proxies ) {
			$released = LogShield_Whitelist::release_bans();
		}
		$rel_note = self::released_note( $released );

		if ( $old_interval !== $opts['interval'] ) {
			LogShield_Plugin::reschedule( $opts['interval'] );
		}
		// Включили определение страны, а баз ещё нет — скачать в фоне, не задерживая страницу.
		if ( $opts['ipinfo_enabled'] && ! is_file( LogShield_IPInfo::dir() . 'country.mmdb' ) && ! wp_next_scheduled( LOGSHIELD_CLEANUP_HOOK, [ 'geo' ] ) ) {
			wp_schedule_single_event( time() + 10, LOGSHIELD_CLEANUP_HOOK, [ 'geo' ] );
		}

		$is_error = $tg_error !== '' || $list_error !== '' || $released === false;
		self::redirect_with_message( 'Настройки сохранены.' . $rel_note . $list_error . $tg_error, $is_error ? 'error' : 'success' );
	}

	/**
	 * Пояснение к сообщению о снятых банах (с пробелом в начале) или ''.
	 *
	 * @param array|false $released результат LogShield_Whitelist::release_bans()
	 */
	public static function released_note( $released ) {
		if ( $released === false ) {
			$list = LogShield_Htaccess::last_released();
			return ' Не удалось снять блокировки, которые задевают белый список (' . self::short_list( $list ) . '): .htaccess не обновлён — '
				. LogShield_Htaccess::last_error() . '.';
		}
		if ( ! $released ) return '';
		return ' Сняты блокировки, которые задевали белый список (' . count( $released ) . '): ' . self::short_list( $released ) . '.';
	}

	/** До 10 адресов через запятую, остальное — «и ещё N». */
	public static function short_list( array $items ) {
		$shown = array_slice( $items, 0, 10 );
		$more  = count( $items ) - count( $shown );
		return implode( ', ', $shown ) . ( $more > 0 ? ' и ещё ' . $more : '' );
	}

	/** Кнопка «Обновить базы сейчас»: скачивает все четыре файла. */
	public static function geo_update() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_geo_update' );
		$errors = [];
		foreach ( LogShield_IPInfo::update( true ) as $file => $res ) {
			if ( $res !== true ) $errors[] = $file . ': ' . $res;
		}
		self::redirect_with_message( $errors ? 'Не все базы скачались. ' . implode( '; ', $errors ) : 'Базы стран и сетей обновлены.', $errors ? 'error' : 'success' );
	}

	public static function ping_rotate() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Нет прав' );
		check_admin_referer( 'logshield_ping_rotate' );
		LogShield_Ping::rotate();
		self::redirect_with_message( 'Создан новый адрес проверки доступности. Старый больше не работает — замените адрес в настройках воркера и выполните deploy.' );
	}

	public static function run_now() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_run_now' );

		$summary = LogShield_Detector::run();
		if ( ! empty( $summary['locked'] ) ) {
			// Идёт сканирование по расписанию (или вторая вкладка) — второй раз тот же кусок не разбираем.
			self::redirect_with_message( 'Сканирование уже выполняется. Результат появится в истории сканирований.', 'error' );
		}
		self::redirect_with_message( $summary['message'], $summary['ok'] ? 'success' : 'error' );
	}

	public static function unban_ip() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_unban' );
		$ip = isset( $_REQUEST['ip'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['ip'] ) ) : '';
		if ( $ip && ! LogShield_Htaccess::unban_ip( $ip ) ) {
			self::redirect_with_message( 'IP ' . $ip . ' убран из списка, но .htaccess не обновлён: ' . LogShield_Htaccess::last_error() . '.', 'error' );
		}
		// Блок переписан целиком по списку — прошлая неудачная запись больше не важна.
		if ( $ip ) LogShield_Detector::clear_write_error();
		self::redirect_with_message( 'IP ' . $ip . ' разблокирован.' );
	}

	public static function unban_all() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_unban_all' );
		if ( ! LogShield_Htaccess::unban_all() ) {
			self::redirect_with_message( 'Список банов очищен, но .htaccess не обновлён: ' . LogShield_Htaccess::last_error() . '.', 'error' );
		}
		LogShield_Detector::clear_write_error();
		self::redirect_with_message( 'Все блокировки сняты.' );
	}

	public static function add_my_ip() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_add_my_ip' );
		$ip = LogShield_Whitelist::get_client_ip();
		if ( $ip ) {
			$first = LogShield_Whitelist::add_admin_ip( $ip, false, wp_get_current_user()->user_login );
			// Новый адрес уже прошёл проверку в add_admin_ip; полный проход ловит
			// и баны, оставшиеся с прошлых версий для давно известных адресов.
			$released = $first === false ? false : LogShield_Whitelist::release_bans();
			if ( is_array( $released ) && is_array( $first ) ) $released = array_values( array_unique( array_merge( $first, $released ) ) );
			self::redirect_with_message( 'Ваш IP (' . $ip . ') добавлен в белый список.' . self::released_note( $released ), $released === false ? 'error' : 'success' );
		} else {
			self::redirect_with_message( 'Не удалось определить ваш IP.', 'error' );
		}
	}

	public static function telegram_test() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_telegram_test' );
		$opts = LogShield_Plugin::get_options();
		if ( ! LogShield_Notifier::telegram_configured( $opts ) ) {
			self::redirect_with_message( 'Сначала сохраните токен бота и chat_id.', 'error' );
		}
		$host   = wp_parse_url( home_url(), PHP_URL_HOST );
		$result = LogShield_Notifier::send_telegram(
			$opts['telegram_token'],
			$opts['telegram_chat_id'],
			'🛡 <b>LogShield</b> · ' . esc_html( $host ) . "\nТестовое сообщение: уведомления работают."
		);
		if ( $result === true ) {
			delete_option( LogShield_Notifier::FAIL_OPTION );
			self::redirect_with_message( 'Тестовое сообщение отправлено в Telegram.' );
		}
		self::redirect_with_message( $result, 'error' );
	}

	private static function found_key() {
		return 'logshield_found_logs_' . get_current_user_id();
	}

	public static function detect_log() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_detect_log' );
		$found = LogShield_LogFinder::find();
		set_transient( self::found_key(), $found, 15 * MINUTE_IN_SECONDS );

		$opts = LogShield_Plugin::get_options();
		if ( ! $found ) {
			self::redirect_with_message( 'Лог не найден в типичных местах. Укажите путь вручную.', 'error' );
		}
		// Текущий путь не работает, а уверенный кандидат есть — сразу ставим его.
		$current = LogShield_LogFinder::describe( $opts['log_path'] );
		$best    = LogShield_LogFinder::best_confident();
		if ( ! $current['ok'] && $best ) {
			$opts['log_path'] = $best;
			update_option( LOGSHIELD_OPTION, $opts );
			self::redirect_with_message( 'Лог найден и сохранён: ' . $best );
		}
		self::redirect_with_message( 'Найдено файлов лога: ' . count( $found ) . '. Выберите нужный в списке под полем пути.' );
	}

	public static function use_log() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_use_log' );
		$path  = isset( $_POST['path'] ) ? wp_unslash( $_POST['path'] ) : '';
		$found = get_transient( self::found_key() );
		// Принимаем только путь из списка найденных.
		if ( ! is_array( $found ) || ! in_array( $path, array_column( $found, 'path' ), true ) ) {
			self::redirect_with_message( 'Этого файла нет в списке найденных. Запустите поиск ещё раз.', 'error' );
		}
		$opts             = LogShield_Plugin::get_options();
		$opts['log_path'] = $path;
		update_option( LOGSHIELD_OPTION, $opts );
		self::redirect_with_message( 'Путь к логу сохранён: ' . $path );
	}

	/**
	 * Возврат на ту страницу, с которой пришло действие (поле ls_back),
	 * а на дашборде — и на ту же вкладку (поле ls_tab → #hash; только имена из
	 * LogShield_Dashboard::TABS, иначе без вкладки).
	 */
	public static function redirect_with_message( $msg, $type = 'success' ) {
		$page = ( isset( $_REQUEST['ls_back'] ) && $_REQUEST['ls_back'] === self::SLUG_DASH ) ? self::SLUG_DASH : self::SLUG;
		$url  = add_query_arg(
			[ 'page' => $page, 'logshield_msg' => rawurlencode( $msg ), 'logshield_type' => $type ],
			admin_url( 'admin.php' )
		);
		if ( $page === self::SLUG_DASH && isset( $_REQUEST['ls_tab'] ) ) {
			$tab = LogShield_Dashboard::sanitize_tab( wp_unslash( $_REQUEST['ls_tab'] ) );
			if ( $tab !== '' ) $url .= '#' . $tab;
		}
		wp_safe_redirect( $url );
		exit;
	}


	/** Сколько байт с конца лога читает предпросмотр (фильтр logshield_preview_bytes, не меньше 64 КБ). */
	public static function preview_bytes() {
		return max( 65536, (int) apply_filters( 'logshield_preview_bytes', 2 * MB_IN_BYTES ) );
	}

	/**
	 * Предпросмотр «кого поймал бы этот порог» (admin-ajax, POST: nonce и поля правил).
	 * Читает хвост текущего лога и дважды прогоняет LogShield_Detector::analyze():
	 * с сохранёнными порогами и с присланными. Ничего не сохраняет: analyze()
	 * не пишет, перенос неудачных входов (carry) не берётся и не записывается.
	 */
	public static function ajax_preview() {
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Недостаточно прав.', 403 );
		check_ajax_referer( 'logshield_preview', 'nonce' );
		$saved = LogShield_Plugin::get_options();
		$path  = (string) $saved['log_path'];
		if ( $path === '' || ! @is_file( $path ) || ! @is_readable( $path ) ) {
			wp_send_json_error( $path === ''
				? 'Лог не найден: путь к access_log не указан. Укажите его в разделе «Лог и расписание» (или нажмите «Найти автоматически») и сохраните настройки.'
				: 'Лог не найден или недоступен для чтения: ' . $path . '. Проверьте путь в разделе «Лог и расписание».' );
		}
		clearstatcache();
		$size  = (int) @filesize( $path );
		$start = max( 0, $size - self::preview_bytes() );
		$lines = self::read_tail( $path, $start, $size - $start );
		if ( ! $lines ) wp_send_json_error( 'В логе пока нет записей — проверять не на чем.' );

		$rules = self::sanitize_rules( wp_unslash( $_POST ), $saved );
		$new   = array_merge( $saved, $rules );
		$wl    = LogShield_Whitelist::get_full_whitelist( (array) $saved['whitelist_ips'] );
		$cur   = LogShield_Detector::analyze( $lines, $saved, $wl );
		$same  = true;
		foreach ( $rules as $k => $v ) if ( (int) $saved[ $k ] !== $v ) $same = false;
		$res   = $same ? $cur : LogShield_Detector::analyze( $lines, $new, $wl );

		// Период — по первой и последней распознанной строке.
		$from = $to = '';
		foreach ( $lines as $l ) { $e = LogShield_Parser::parse_line( $l ); if ( $e ) { $from = $e['date']; break; } }
		for ( $i = count( $lines ) - 1; $i >= 0; $i-- ) { $e = LogShield_Parser::parse_line( $lines[ $i ] ); if ( $e ) { $to = $e['date']; break; } }

		$banned    = array_keys( LogShield_Htaccess::get_banned() );
		$not_yet   = LogShield_Detector::without_banned( $res['flagged'], $banned );
		$labels    = LogShield_Stats::TYPES;
		$items     = [];
		foreach ( $res['flagged'] as $ip => $reasons ) {
			$ip      = (string) $ip;
			$items[] = [
				'ip'     => $ip,
				'types'  => array_values( array_map( function ( $t ) use ( $labels ) { return $labels[ $t ] ?? $t; }, (array) ( $res['types'][ $ip ] ?? [] ) ) ),
				'reason' => mb_substr( implode( '; ', (array) $reasons ), 0, 300 ),
				'new'    => ! isset( $cur['flagged'][ $ip ] ),
				'banned' => ! isset( $not_yet[ $ip ] ),
			];
		}
		// Сначала те, кого ловят только новые пороги, затем ещё не заблокированные.
		usort( $items, function ( $a, $b ) { return [ $b['new'], ! $b['banned'] ] <=> [ $a['new'], ! $a['banned'] ]; } );
		$lost = count( array_diff_key( $cur['flagged'], $res['flagged'] ) );

		wp_send_json_success( [
			'lines'    => count( $lines ),
			'unparsed' => (int) $res['unparsed'],
			'from'     => substr( $from, 0, 20 ),
			'to'       => substr( $to, 0, 20 ),
			'whole'    => $start === 0,
			'mb'       => round( ( $size - $start ) / MB_IN_BYTES, 1 ),
			'changed'  => ! $same,
			'current'  => count( $cur['flagged'] ),
			'flagged'  => count( $res['flagged'] ),
			'lost'     => $lost,
			'items'    => array_slice( $items, 0, 20 ),
			'more'     => max( 0, count( $items ) - 20 ),
		] );
	}

	/**
	 * Строки из куска файла [start, start+len): первая обрезанная (если start > 0)
	 * и последняя без перевода строки отбрасываются. Как чтение хвоста на дашборде.
	 */
	private static function read_tail( $path, $start, $len ) {
		if ( $len <= 0 ) return [];
		$fp = @fopen( $path, 'rb' );
		if ( ! $fp ) return [];
		fseek( $fp, $start );
		$data = (string) fread( $fp, $len );
		fclose( $fp );
		$lines = explode( "\n", $data );
		if ( $start > 0 ) array_shift( $lines );
		array_pop( $lines );
		return array_values( array_filter( array_map( 'rtrim', $lines ), 'strlen' ) );
	}

	/** Разделы страницы настроек: id => заголовок (оглавление и карточки). */
	const SECTIONS = [
		'ls-sec-log'     => 'Лог и расписание',
		'ls-sec-rules'   => 'Правила обнаружения',
		'ls-sec-ban'     => 'Блокировка',
		'ls-sec-notify'  => 'Уведомления',
		'ls-sec-geo'     => 'Гео и сведения об адресах',
		'ls-sec-white'   => 'Белый список и прокси',
		'ls-sec-service' => 'Служебное',
	];

	/** Пояснение к полю: в описании разрешён только <code>. */
	private static function desc( $id, $html ) {
		echo '<p class="ls-field-desc" id="' . esc_attr( $id ) . '">' . wp_kses( $html, [ 'code' => [] ] ) . '</p>';
	}

	/** Числовое поле с подписью и пояснением (aria-describedby). */
	private static function number_field( $name, $label, $value, $min, $max, $desc, $suffix = '' ) {
		?>
		<div class="ls-field">
			<label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>
			<span class="ls-field-ctl">
				<input type="number" class="ls-input ls-num" id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" min="<?php echo (int) $min; ?>"<?php echo $max ? ' max="' . (int) $max . '"' : ''; ?> step="1" inputmode="numeric" value="<?php echo esc_attr( $value ); ?>" aria-describedby="<?php echo esc_attr( $name ); ?>-desc">
				<?php if ( $suffix !== '' ) : ?><span class="ls-dim" aria-hidden="true"><?php echo esc_html( $suffix ); ?></span><?php endif; ?>
			</span>
			<?php self::desc( $name . '-desc', $desc ); ?>
		</div>
		<?php
	}

	/** Заголовок карточки раздела. */
	private static function section_head( $id ) {
		echo '<div class="ls-card-head"><h2 id="' . esc_attr( $id ) . '-title">' . esc_html( self::SECTIONS[ $id ] ) . '</h2></div>';
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$opts      = LogShield_Plugin::get_options();
		$admin_ips = LogShield_Whitelist::get_admin_ips();
		$next_run  = wp_next_scheduled( LOGSHIELD_CRON_HOOK );
		$my_ip     = LogShield_Whitelist::get_client_ip();
		// Полный белый список (сотрудники, ручной список с диапазонами, сервер, прокси, localhost).
		$my_why    = $my_ip ? LogShield_Whitelist::whitelist_reason( $my_ip, (array) $opts['whitelist_ips'] ) : null;
		// Результат кнопки «Найти автоматически» (null — поиск не запускали).
		$found     = get_transient( self::found_key() );
		$found     = is_array( $found ) ? $found : null;
		$post_url  = admin_url( 'admin-post.php' );
		$state     = LogShield_LogFinder::describe( $opts['log_path'] );
		$host      = wp_parse_url( home_url(), PHP_URL_HOST );
		// Сколько адресов тестовый режим заблокировал бы за 7 дней — для подтверждения выключения.
		$would     = $opts['dry_run'] ? LogShield_Dashboard::would_ban( 7 ) : null;
		if ( $would ) {
			$would_text = $would['ips'] || $would['nets']
				? sprintf( 'За последние 7 дней тестовый режим отметил бы для блокировки адресов: %d%s.', $would['ips'], $would['nets'] ? sprintf( ', подсетей: %d', $would['nets'] ) : '' )
				: 'За последние 7 дней блокировать было бы некого.';
		}
		?>
		<div class="wrap ls-wrap">
		<h1 class="screen-reader-text">LogShield — настройки</h1>
		<?php // Уведомления WordPress вставляет после первого заголовка, до панели. ?>
		<div class="ls-dash ls-settings" data-theme="<?php echo esc_attr( LogShield_Dashboard::get_theme() ); ?>">

			<header class="ls-head">
				<p class="ls-brand">
					<span class="ls-logo dashicons dashicons-shield" aria-hidden="true"></span>
					<span class="ls-title">Настройки</span>
					<span class="ls-dim ls-host"><?php echo esc_html( $host ); ?></span>
				</p>
				<?php if ( $opts['dry_run'] ) : ?>
					<span class="ls-badge ls-badge-warn"><span class="ls-dot" aria-hidden="true"></span>Тестовый режим</span>
				<?php else : ?>
					<span class="ls-badge ls-badge-ok"><span class="ls-dot" aria-hidden="true"></span>Защита включена</span>
				<?php endif; ?>
				<div class="ls-head-actions">
					<a class="ls-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::SLUG_DASH ) ); ?>"><span class="dashicons dashicons-chart-area" aria-hidden="true"></span> Дашборд</a>
				</div>
			</header>

			<?php if ( $opts['dry_run'] ) : ?>
				<section class="ls-dry" aria-label="Тестовый режим">
					<p><span aria-hidden="true">⚠</span> <strong class="ls-dry-title">Тестовый режим включён.</strong> Адреса обнаруживаются и записываются в историю сканирований, но не блокируются. <?php echo esc_html( $would_text ); ?> Проверьте их на дашборде, прежде чем отключать тестовый режим в разделе <a href="#ls-sec-ban">«Блокировка»</a>.</p>
				</section>
			<?php endif; ?>
			<?php if ( $my_ip && ! $my_why ) : ?>
				<section class="ls-dry" aria-label="Ваш адрес">
					<p><span aria-hidden="true">⚠</span> <strong class="ls-dry-title">Ваш адрес <code><?php echo esc_html( $my_ip ); ?></code> не в белом списке.</strong> Добавьте его, чтобы правила случайно не заблокировали вас.</p>
					<button type="submit" form="logshield-add-my-ip" class="ls-btn ls-btn-sm">Добавить мой IP в белый список</button>
				</section>
			<?php endif; ?>

			<div class="ls-set">
				<nav class="ls-toc" aria-label="Разделы настроек">
					<ul>
						<?php foreach ( self::SECTIONS as $id => $title ) : ?>
							<li><a href="#<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $title ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</nav>

				<div class="ls-set-main">
					<form id="ls-settings-form" class="ls-set-form" method="post" action="<?php echo esc_url( $post_url ); ?>" aria-label="Настройки LogShield">
						<input type="hidden" name="action" value="logshield_save_settings">
						<?php wp_nonce_field( 'logshield_save_settings' ); ?>

						<section class="ls-card ls-sec" id="ls-sec-log" tabindex="-1" aria-labelledby="ls-sec-log-title">
							<?php self::section_head( 'ls-sec-log' ); ?>
							<div class="ls-sec-body">
								<div class="ls-field">
									<label for="log_path">Путь к access_log</label>
									<span class="ls-field-ctl ls-field-wide">
										<input type="text" id="log_path" name="log_path" class="ls-input" value="<?php echo esc_attr( $opts['log_path'] ); ?>" placeholder="/home/user/access-logs/example.com" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="log_path-state log_path-desc">
										<button type="submit" form="logshield-detect-log" class="ls-btn">Найти автоматически</button>
									</span>
									<p id="log_path-state" class="<?php echo $state['ok'] ? 'ls-accent' : 'ls-warn'; ?>"><span aria-hidden="true"><?php echo $state['ok'] ? '✓' : '⚠'; ?></span> <?php echo esc_html( $state['text'] ); ?></p>
									<?php if ( is_array( $found ) ) : ?>
										<?php if ( ! $found ) : ?>
											<p><strong>Лог не найден в типичных местах.</strong> Узнайте путь у хостинга или в панели управления (раздел «Логи»). Возможно, PHP не разрешено читать каталог с логами (open_basedir).</p>
										<?php else : ?>
											<p><strong>Найдено:</strong></p>
											<ul class="ls-found">
												<?php foreach ( $found as $f ) : ?>
													<li>
														<button type="submit" form="logshield-use-log" name="path" value="<?php echo esc_attr( $f['path'] ); ?>" class="ls-btn ls-btn-sm"<?php disabled( $f['path'], $opts['log_path'] ); ?>><?php echo $f['path'] === $opts['log_path'] ? 'Выбран' : 'Использовать'; ?></button>
														<span><code><?php echo esc_html( $f['path'] ); ?></code>
														— <?php echo esc_html( size_format( $f['size'] ) . ', ' . wp_date( 'd.m.Y H:i', $f['mtime'] ) ); ?>
														<?php if ( $f['own_domain'] ) : ?> · есть ваш домен<?php elseif ( ! $f['near_site'] ) : ?> · <em>общий лог сервера, могут быть чужие сайты</em><?php endif; ?></span>
													</li>
												<?php endforeach; ?>
											</ul>
										<?php endif; ?>
									<?php endif; ?>
									<?php self::desc( 'log_path-desc', 'Полный путь на сервере (не URL). Если путь пуст, LogShield ищет лог сам при каждом сканировании. Типичные места: папка над сайтом (<code>…/access_log</code>), cPanel — <code>/home/USER/access-logs/DOMAIN</code>, ISPmanager — <code>/var/www/httpd-logs/DOMAIN.access.log</code>, Plesk — <code>/var/www/vhosts/DOMAIN/logs/access_log</code>.' ); ?>
								</div>
								<div class="ls-fields">
									<div class="ls-field">
										<label for="interval">Интервал сканирования</label>
										<select id="interval" name="interval" class="ls-input" aria-describedby="interval-desc">
											<option value="logshield_2h" <?php selected( $opts['interval'], 'logshield_2h' ); ?>>Каждые 2 часа</option>
											<option value="logshield_3h" <?php selected( $opts['interval'], 'logshield_3h' ); ?>>Каждые 3 часа</option>
											<option value="logshield_4h" <?php selected( $opts['interval'], 'logshield_4h' ); ?>>Каждые 4 часа</option>
										</select>
										<p class="ls-field-desc" id="interval-desc">Следующий запуск: <?php echo $next_run ? esc_html( wp_date( 'd.m.Y H:i:s', $next_run ) ) : 'не запланирован'; ?></p>
									</div>
									<?php self::number_field( 'max_read_mb', 'Макс. объём чтения лога за один запуск, МБ', $opts['max_read_mb'], 1, 50, 'Ограничивает нагрузку при больших логах — если накопился большой хвост, он будет обработан за несколько последующих запусков.' ); ?>
								</div>
							</div>
						</section>

						<section class="ls-card ls-sec" id="ls-sec-rules" tabindex="-1" aria-labelledby="ls-sec-rules-title">
							<?php self::section_head( 'ls-sec-rules' ); ?>
							<div class="ls-sec-body">
								<div class="ls-fields">
									<?php
									self::number_field( 'rpm_threshold', 'Порог запросов от одного IP за период', $opts['rpm_threshold'], 10, 0, 'Считаются все запросы между запусками. Успешные фоновые запросы WordPress (<code>admin-ajax.php</code>, <code>wp-cron.php</code>) не учитываются.' );
									self::number_field( 'brute_attempts', 'Порог неудачных входов с одного IP', $opts['brute_attempts'], 3, 0, 'Неудачный вход — <code>POST</code> на <code>wp-login.php</code> в любом каталоге с ответом не 302 (WordPress на неверный пароль отвечает 200, на успешный вход — перенаправлением).' );
									self::number_field( 'subnet_min_ips', 'Распределённый подбор: IP из одной подсети', $opts['subnet_min_ips'], 2, 256, 'Сколько разных адресов одной подсети (<code>/24</code> для IPv4, <code>/64</code> для IPv6) должны подбирать пароль.' );
									self::number_field( 'subnet_min_attempts', 'Распределённый подбор: неудачных входов из подсети', $opts['subnet_min_attempts'], 5, 0, 'Если из одной подсети пароль подбирают столько адресов и набирают столько неудачных входов, банится вся подсеть. Подсеть, в которой есть адрес из белого списка, не банится.' );
									self::number_field( 'scan_unique_paths', 'Порог разных путей с ошибкой 4xx (сканирование)', $opts['scan_unique_paths'], 5, 0, 'Считаются только пути, на которые сервер ответил 4xx (нет страницы, доступ закрыт). Поисковые боты и посетители ходят по живым страницам и под правило не попадают.' );
									self::number_field( 'scan_min_requests', 'Мин. запросов для детекта сканирования', $opts['scan_min_requests'], 5, 0, 'Адреса с меньшим числом запросов правило сканирования не проверяет.' );
									self::number_field( 'error_rate_pct', 'Порог процента ошибок (4xx/5xx)', $opts['error_rate_pct'], 1, 100, 'Доля ответов с ошибкой среди всех запросов адреса, в процентах.', '%' );
									self::number_field( 'error_rate_min_requests', 'Мин. запросов для детекта по ошибкам', $opts['error_rate_min_requests'], 5, 0, 'Адреса с меньшим числом запросов правило процента ошибок не проверяет.' );
									self::number_field( 'sensitive_min_hits', 'Разных чувствительных путей для бана', $opts['sensitive_min_hits'], 1, 50, 'Сколько разных путей вроде <code>/.env</code>, <code>/.git/config</code>, <code>/wp-config.php.bak</code> должен запросить IP, чтобы его забанили. Повторы одного пути и query string не считаются. 1 — банить за любое обращение (больше ложных срабатываний).' );
									self::number_field( 'enum_min_hits', 'Перебор пользователей: разных ID для бана', $opts['enum_min_hits'], 1, 50, 'Сканеры узнают логины, перебирая <code>/?author=1</code>, <code>/?author=2</code>… (WordPress перенаправляет на <code>/author/логин/</code>) или запрашивая <code>/wp-json/wp/v2/users</code>. Это разведка перед подбором пароля. Посетители открывают авторов по ссылкам <code>/author/имя/</code>, они не считаются.' );
									?>
								</div>
								<?php // Предпросмотр работает только со скриптом — он и показывает блок. ?>
								<div class="ls-preview" data-preview data-url="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'logshield_preview' ) ); ?>" hidden>
									<div class="ls-preview-head">
										<button type="button" class="ls-btn" data-preview-run aria-describedby="ls-preview-hint">Проверить на последних данных лога</button>
										<p class="ls-field-desc" id="ls-preview-hint">Правила с порогами из формы применяются к последним <?php echo esc_html( size_format( self::preview_bytes() ) ); ?> лога. Ничего не сохраняется и не блокируется; после изменения порога проверка запускается сама.</p>
									</div>
									<p class="ls-preview-status" role="status" data-preview-status></p>
									<div data-preview-list></div>
								</div>
							</div>
						</section>

						<section class="ls-card ls-sec" id="ls-sec-ban" tabindex="-1" aria-labelledby="ls-sec-ban-title">
							<?php self::section_head( 'ls-sec-ban' ); ?>
							<div class="ls-sec-body">
								<div class="ls-field">
									<span class="ls-checkrow">
										<input type="checkbox" id="dry_run" name="dry_run" <?php checked( $opts['dry_run'] ); ?> aria-describedby="dry_run-desc" data-dry-run>
										<label for="dry_run">Тестовый режим: обнаруживать, но не блокировать</label>
									</span>
									<?php self::desc( 'dry_run-desc', 'Рекомендуется для начала: адреса попадают в историю сканирований, но в <code>.htaccess</code> не записываются. Снимите флажок, когда убедитесь, что правила не задевают своих.' ); ?>
								</div>
								<div class="ls-fields">
									<?php self::number_field( 'ban_expiry_days', 'Срок блокировки, дней', $opts['ban_expiry_days'], 0, 0, '0 — блокировать навсегда.' ); ?>
								</div>
							</div>
						</section>

						<section class="ls-card ls-sec" id="ls-sec-notify" tabindex="-1" aria-labelledby="ls-sec-notify-title">
							<?php self::section_head( 'ls-sec-notify' ); ?>
							<div class="ls-sec-body">
								<div class="ls-fields">
									<div class="ls-field">
										<label for="notify_email">E-mail для уведомлений</label>
										<input type="email" id="notify_email" name="notify_email" class="ls-input" value="<?php echo esc_attr( $opts['notify_email'] ); ?>" autocomplete="email" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="notify_email-desc">
										<?php self::desc( 'notify_email-desc', 'Необязательно. Письмо приходит после сканирования, если кого-то поймали.' ); ?>
									</div>
									<div class="ls-field">
										<label for="telegram_token">Telegram: токен бота</label>
										<input type="password" id="telegram_token" name="telegram_token" class="ls-input" value="" autocomplete="off" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="telegram_token-desc">
										<p class="ls-field-desc" id="telegram_token-desc">
											<?php if ( ! empty( $opts['telegram_token'] ) ) : ?>
												Токен сохранён (…<?php echo esc_html( substr( $opts['telegram_token'], -4 ) ); ?>). Оставьте поле пустым, чтобы не менять.
											<?php else : ?>
												Создайте бота у <code>@BotFather</code> командой <code>/newbot</code> и вставьте выданный токен.
											<?php endif; ?>
										</p>
										<?php if ( ! empty( $opts['telegram_token'] ) ) : ?>
											<span class="ls-checkrow">
												<input type="checkbox" id="telegram_token_clear" name="telegram_token_clear" value="1">
												<label for="telegram_token_clear">Удалить токен (отключить Telegram)</label>
											</span>
										<?php endif; ?>
									</div>
									<div class="ls-field">
										<label for="telegram_chat_id">Telegram: chat_id</label>
										<input type="text" id="telegram_chat_id" name="telegram_chat_id" class="ls-input" value="<?php echo esc_attr( $opts['telegram_chat_id'] ); ?>" autocomplete="off" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="telegram_chat_id-desc">
										<?php self::desc( 'telegram_chat_id-desc', 'Куда слать: ваш числовой id (напишите боту <code>/start</code>, затем узнайте id, например у <code>@userinfobot</code>), id группы (начинается с минуса, бота нужно добавить в группу) или <code>@имя_канала</code>.' ); ?>
									</div>
								</div>
								<?php if ( LogShield_Notifier::telegram_configured( $opts ) ) : ?>
									<?php $tg_queue = (array) get_option( LogShield_Notifier::RETRY_OPTION, [] ); $tg_fail = get_option( LogShield_Notifier::FAIL_OPTION ); ?>
									<?php if ( $tg_queue ) : $tg_next = wp_next_scheduled( LogShield_Notifier::RETRY_HOOK ); ?>
										<p class="ls-note ls-note-warn"><span aria-hidden="true">⚠</span> Не доставлено в Telegram: <?php echo count( $tg_queue ); ?> — <?php echo esc_html( end( $tg_queue )['error'] ); ?>. Повтор <?php echo $tg_next ? esc_html( wp_date( 'H:i', $tg_next ) ) : 'при следующем запуске WP-Cron'; ?>.</p>
									<?php elseif ( $tg_fail ) : ?>
										<p class="ls-note ls-note-err"><span aria-hidden="true">✕</span> Уведомление <?php echo esc_html( wp_date( 'd.m H:i', $tg_fail['time'] ) ); ?> так и не дошло до Telegram: <?php echo esc_html( $tg_fail['error'] ); ?></p>
									<?php endif; ?>
									<p><button type="submit" form="logshield-telegram-test" class="ls-btn">Отправить тестовое сообщение в Telegram</button></p>
								<?php endif; ?>
							</div>
						</section>

						<section class="ls-card ls-sec" id="ls-sec-geo" tabindex="-1" aria-labelledby="ls-sec-geo-title">
							<?php self::section_head( 'ls-sec-geo' ); ?>
							<div class="ls-sec-body">
								<div class="ls-field">
									<span class="ls-checkrow">
										<input type="checkbox" id="ipinfo_enabled" name="ipinfo_enabled" value="1" <?php checked( ! empty( $opts['ipinfo_enabled'] ) ); ?> aria-describedby="ipinfo_enabled-desc">
										<label for="ipinfo_enabled">Определять страну, сеть, Tor, VPN и дата-центр</label>
									</span>
									<p class="ls-field-desc" id="ipinfo_enabled-desc">Только для информации, на блокировку не влияет. Определяется для пойманных правилами и для адресов, у которых за сканирование <?php echo (int) LogShield_IPInfo::MIN_HITS; ?>+ ошибок или неудачных входов; остальных посетителей не трогает. Нужны локальные базы (около 20 МБ в <code>wp-content/logshield-geo</code>): страна и сеть обновляются раз в месяц, Tor — раз в сутки, VPN — раз в неделю. Внешних запросов на каждый адрес нет.</p>
								</div>
								<?php if ( ! empty( $opts['ipinfo_enabled'] ) ) : ?>
									<ul class="ls-geo-status ls-list">
										<?php foreach ( LogShield_IPInfo::status() as $file => $st ) : ?>
											<li><code><?php echo esc_html( $file ); ?></code> —
												<?php if ( $st['exists'] ) : ?>
													<?php echo esc_html( size_format( $st['size'] ) . ', ' . wp_date( 'j.m.Y H:i', $st['time'] ) ); ?>
												<?php else : ?>
													ещё не скачан
												<?php endif; ?>
												<?php if ( $st['error'] ) : ?><span class="ls-danger">(ошибка: <?php echo esc_html( $st['error'] ); ?>)</span><?php endif; ?>
											</li>
										<?php endforeach; ?>
									</ul>
									<p><button type="submit" form="logshield-geo-update" class="ls-btn">Обновить базы сейчас</button></p>
								<?php endif; ?>
								<p class="ls-field-desc">Источники: <a href="https://db-ip.com">IP Geolocation by DB-IP</a> (CC BY 4.0), список выходных узлов Tor Project, список VPN <a href="https://github.com/X4BNet/lists_vpn">X4BNet/lists_vpn</a>. Метки приблизительные: обычный пользователь с VPN — не атакующий.</p>
							</div>
						</section>

						<section class="ls-card ls-sec" id="ls-sec-white" tabindex="-1" aria-labelledby="ls-sec-white-title">
							<?php self::section_head( 'ls-sec-white' ); ?>
							<div class="ls-sec-body">
								<div class="ls-myip">
									<p>Ваш текущий IP: <code><?php echo esc_html( $my_ip ?: 'не определён' ); ?></code>
									— <?php echo $my_why
										? '<span class="ls-accent"><span aria-hidden="true">✓</span> в белом списке (' . esc_html( $my_why['text'] ) . ')</span>'
										: '<span class="ls-warn"><span aria-hidden="true">⚠</span> не в белом списке</span>'; ?></p>
									<?php if ( $my_ip && ! $my_why ) : ?>
										<button type="submit" form="logshield-add-my-ip" class="ls-btn ls-btn-sm">Добавить мой IP в белый список</button>
									<?php endif; ?>
								</div>
								<div class="ls-field">
									<label for="whitelist_ips">Белый список IP (вручную)</label>
									<textarea id="whitelist_ips" name="whitelist_ips" rows="4" class="ls-input" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="whitelist_ips-desc"><?php echo esc_textarea( implode( "\n", $opts['whitelist_ips'] ) ); ?></textarea>
									<?php self::desc( 'whitelist_ips-desc', 'Один IP или диапазон на строку, например <code>203.0.113.7</code> или <code>203.0.113.0/24</code>. Неверные строки при сохранении отбрасываются (они будут перечислены в сообщении).' ); ?>
								</div>
								<div class="ls-field">
									<label for="trusted_proxies">Доверенные прокси</label>
									<textarea id="trusted_proxies" name="trusted_proxies" rows="4" class="ls-input" spellcheck="false" autocapitalize="none" autocorrect="off" aria-describedby="trusted_proxies-desc"><?php echo esc_textarea( implode( "\n", (array) $opts['trusted_proxies'] ) ); ?></textarea>
									<p><button type="button" class="ls-btn ls-btn-sm" data-fill-target="trusted_proxies" data-fill-lines="<?php echo esc_attr( implode( "\n", LogShield_Whitelist::CLOUDFLARE_RANGES ) ); ?>" hidden>Вставить диапазоны Cloudflare</button></p>
									<div class="ls-field-desc" id="trusted_proxies-desc">
										<p>Заполняйте, только если сайт стоит за Cloudflare или другим прокси, а на сервере нет <code>mod_remoteip</code>: тогда Apache видит у всех посетителей адрес прокси. Для запросов с этих адресов LogShield берёт адрес посетителя из заголовков <code>CF-Connecting-IP</code>, <code>X-Real-IP</code> или <code>X-Forwarded-For</code> — так в белый список попадает настоящий адрес сотрудника. Сами прокси тоже входят в белый список и никогда не блокируются: иначе бан закрыл бы сайт для всех.</p>
										<p>Один IP или диапазон на строку. Указывайте только адреса своего прокси. Если ошибиться: чужой адрес в списке никогда не будет заблокирован, а запросы с него смогут подделать эти заголовки и выдать себя за другой адрес; если же пропустить адрес своего прокси, все посетители будут выглядеть одним адресом прокси, и правила могут его забанить. Без прокси оставьте поле пустым.</p>
									</div>
								</div>
								<div class="ls-fields">
									<div class="ls-field">
										<h3 class="ls-sub-title">Сотрудники в белом списке</h3>
										<?php if ( empty( $admin_ips ) ) : ?>
											<p class="ls-field-desc">Пока нет данных (появятся, когда автор, редактор или администратор зайдёт в панель WordPress).</p>
										<?php else : ?>
											<ul class="ls-list">
												<?php foreach ( LogShield_Whitelist::get_admin_users() as $ip => $logins ) : ?>
													<li><code><?php echo esc_html( $ip ); ?></code>
														<?php if ( $logins ) : ?>
															— <?php echo esc_html( implode( ', ', $logins ) ); ?>
														<?php else : ?>
															— <span class="ls-dim">логин появится при следующем заходе</span>
														<?php endif; ?>
													</li>
												<?php endforeach; ?>
											</ul>
										<?php endif; ?>
									</div>
									<div class="ls-field">
										<h3 class="ls-sub-title">Адреса сервера в белом списке</h3>
										<?php $server_ips = LogShield_Whitelist::get_server_ips(); ?>
										<?php if ( empty( $server_ips ) ) : ?>
											<p class="ls-field-desc">Пока нет данных (появятся после первого запуска WP-Cron).</p>
										<?php else : ?>
											<ul class="ls-list"><?php foreach ( $server_ips as $ip ) echo '<li><code>' . esc_html( $ip ) . '</code></li>'; ?></ul>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</section>

						<?php // Закреплённая кнопка сохранения: прилипает к низу окна, пока видна форма. ?>
						<div class="ls-savebar">
							<p class="ls-save-hint" role="status" data-dirty-hint></p>
							<button type="submit" class="ls-btn ls-btn-accent">Сохранить настройки</button>
						</div>
					</form>

					<section class="ls-card ls-sec" id="ls-sec-service" tabindex="-1" aria-labelledby="ls-sec-service-title">
						<?php self::section_head( 'ls-sec-service' ); ?>
						<div class="ls-sec-body">
							<div class="ls-service-row">
								<p>Заблокированные адреса, графики и история сканирований — на странице <a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::SLUG_DASH ) ); ?>">LogShield → Дашборд</a>.</p>
								<form method="post" action="<?php echo esc_url( $post_url ); ?>">
									<input type="hidden" name="action" value="logshield_run_now">
									<?php wp_nonce_field( 'logshield_run_now' ); ?>
									<button type="submit" class="ls-btn"><span class="dashicons dashicons-update" aria-hidden="true"></span> Запустить сканирование сейчас</button>
								</form>
							</div>

							<div class="ls-field">
								<h3 class="ls-sub-title" id="logshield-ping">Адрес для проверки доступности</h3>
								<p class="ls-field-desc">Внешний пинг (воркер Cloudflare из <code>tools/uptime-worker</code>, UptimeRobot и т. п.) должен открывать этот адрес, а не главную. Ответ <code><?php echo esc_html( LogShield_Ping::REPLY ); ?></code> приходит, только когда WordPress загрузился полностью и база данных отвечает. Такие запросы LogShield не учитывает: они не попадают в правила, графики и хвост лога.</p>
								<label for="ls-ping-url" class="screen-reader-text">Адрес для проверки доступности</label>
								<input type="text" id="ls-ping-url" class="ls-input" readonly value="<?php echo esc_attr( LogShield_Ping::url() ); ?>" data-select-on-focus aria-describedby="ls-ping-desc">
								<p class="ls-field-desc" id="ls-ping-desc">Ключ в адресе держите в секрете: запрос с ним LogShield пропускает. Ключевое слово для проверки — <code><?php echo esc_html( LogShield_Ping::REPLY ); ?></code>.</p>
								<form method="post" action="<?php echo esc_url( $post_url ); ?>" data-confirm="Старый адрес перестанет работать, и пинг начнёт сообщать, что сайт недоступен, пока вы не обновите адрес у воркера. Продолжить?">
									<input type="hidden" name="action" value="logshield_ping_rotate">
									<?php wp_nonce_field( 'logshield_ping_rotate' ); ?>
									<button type="submit" class="ls-btn">Сменить ключ</button>
								</form>
							</div>

							<p class="ls-field-desc">Версия <?php echo esc_html( LOGSHIELD_VERSION ); ?>. Последняя проверка обновлений на GitHub: <?php echo esc_html( LogShield_Updater::is_dev_checkout() ? 'не проверяется (рабочая копия из git)' : LogShield_Updater::last_check_text() ); ?></p>
						</div>
					</section>
				</div>
			</div>

			<?php // Формы для кнопок внутри основной формы (form="…"): вложенные формы в HTML запрещены. ?>
			<form id="logshield-detect-log" method="post" action="<?php echo esc_url( $post_url ); ?>" hidden>
				<input type="hidden" name="action" value="logshield_detect_log">
				<?php wp_nonce_field( 'logshield_detect_log' ); ?>
			</form>
			<form id="logshield-geo-update" method="post" action="<?php echo esc_url( $post_url ); ?>" hidden>
				<input type="hidden" name="action" value="logshield_geo_update">
				<?php wp_nonce_field( 'logshield_geo_update' ); ?>
			</form>
			<form id="logshield-use-log" method="post" action="<?php echo esc_url( $post_url ); ?>" hidden>
				<input type="hidden" name="action" value="logshield_use_log">
				<?php wp_nonce_field( 'logshield_use_log' ); ?>
			</form>
			<?php if ( $my_ip && ! $my_why ) : ?>
				<form id="logshield-add-my-ip" method="post" action="<?php echo esc_url( $post_url ); ?>" hidden>
					<input type="hidden" name="action" value="logshield_add_my_ip">
					<?php wp_nonce_field( 'logshield_add_my_ip' ); ?>
				</form>
			<?php endif; ?>
			<form id="logshield-telegram-test" method="post" action="<?php echo esc_url( $post_url ); ?>" hidden>
				<input type="hidden" name="action" value="logshield_telegram_test">
				<?php wp_nonce_field( 'logshield_telegram_test' ); ?>
			</form>

			<?php // Подтверждения (settings.js). Без <dialog> скрипт спрашивает через confirm(), без скрипта — не спрашивает. ?>
			<dialog id="ls-confirm" class="ls-dialog" closedby="any" aria-labelledby="ls-confirm-title" aria-describedby="ls-confirm-text">
				<h2 id="ls-confirm-title">Подтвердите действие</h2>
				<p id="ls-confirm-text" class="ls-confirm-text" data-confirm-text></p>
				<form method="dialog" class="ls-dialog-actions">
					<button value="cancel" class="ls-btn" autofocus>Отмена</button>
					<button value="ok" class="ls-btn ls-btn-accent">Продолжить</button>
				</form>
			</dialog>
			<?php if ( $opts['dry_run'] ) : ?>
				<dialog id="ls-dry-confirm" class="ls-dialog" closedby="any" aria-labelledby="ls-dry-confirm-title" aria-describedby="ls-dry-confirm-desc"
					data-fallback="<?php echo esc_attr( 'Выключить тестовый режим? ' . $would_text . ' Со следующего сканирования нарушители будут блокироваться в .htaccess.' ); ?>">
					<h2 id="ls-dry-confirm-title">Выключить тестовый режим?</h2>
					<div id="ls-dry-confirm-desc">
						<p><?php echo esc_html( $would_text ); ?></p>
						<p>Со следующего сканирования новые нарушители будут блокироваться в <code>.htaccess</code>.</p>
						<?php if ( $my_why ) : ?>
							<p><span aria-hidden="true">✓</span> Ваш адрес <code><?php echo esc_html( $my_ip ); ?></code> в белом списке: <?php echo esc_html( $my_why['text'] ); ?>.</p>
						<?php else : ?>
							<p class="ls-warn-text"><span aria-hidden="true">⚠</span> Ваш адрес <code><?php echo esc_html( $my_ip ?: 'не определён' ); ?></code> не найден в белом списке.</p>
						<?php endif; ?>
					</div>
					<form method="dialog" class="ls-dialog-actions">
						<button value="cancel" class="ls-btn" autofocus>Отмена</button>
						<button value="ok" class="ls-btn ls-btn-accent">Выключить и сохранить</button>
					</form>
				</dialog>
			<?php endif; ?>
		</div>
		</div>
		<?php
	}
}

// Предпросмотр правил на странице настроек.
add_action( 'wp_ajax_logshield_preview', [ 'LogShield_Admin', 'ajax_preview' ] );
