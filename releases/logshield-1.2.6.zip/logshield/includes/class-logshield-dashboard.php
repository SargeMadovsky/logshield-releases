<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Дашборд «LogShield → Дашборд»: метрики, графики по часам, атакующие адреса,
 * история сканирований и хвост лога (с живым режимом, пока страница открыта).
 *
 * Внешних библиотек и CDN нет: графики рисуются в SVG своим скриптом.
 */
class LogShield_Dashboard {

	const TAIL_FIRST_BYTES = 32768; // хвост при открытии страницы
	const TAIL_MAX_BYTES   = 65536; // максимум нового за один опрос
	const TAIL_LINES       = 80;
	const BACKFILL_OPTION  = 'logshield_backfilled'; // путь лога, по которому уже строили историю

	const SEEN_META = 'logshield_seen_at'; // когда пользователь последний раз открывал дашборд

	/** Тема дашборда у пользователя: system | dark | light. Нет значения — тёмная (как было всегда). */
	const THEME_META    = 'logshield_theme';
	const THEMES        = [ 'system' => 'Как в системе', 'dark' => 'Тёмная', 'light' => 'Светлая' ];
	const DEFAULT_THEME = 'dark';

	/**
	 * Вкладки дашборда: имя (оно же #hash адреса и значение поля ls_tab) => подпись.
	 * Первая — по умолчанию.
	 */
	const TABS = [
		'overview'  => 'Обзор',
		'attackers' => 'Атакующие',
		'journal'   => 'Журнал',
		'log'       => 'Лог',
		'health'    => 'Состояние',
	];

	/**
	 * Счётчик новых атакующих и прежняя отметка просмотра — на момент открытия
	 * дашборда, до сброса (mark_seen() в admin_menu идёт раньше render()).
	 */
	private static $unseen_on_open = 0;
	private static $seen_before    = 0;

	/**
	 * Короткий индекс для кружка в меню: строка «время:n время:n …» по истории
	 * сканирований (от новых к старым), где n — сколько адресов этого
	 * сканирования не встречалось в более новых. Несколько сотен байт вместо
	 * 100+ КБ истории на каждой странице админки.
	 */
	const UNSEEN_INDEX_OPTION = 'logshield_unseen_index';

	/**
	 * Скрытые в таблице атакующих: ip|cidr => когда скрыли (autoload off).
	 * Строка снова видна, если адрес пойман позже. Записи старше
	 * DISMISS_TTL_DAYS удаляются, сверх DISMISS_MAX — самые старые.
	 */
	const DISMISSED_OPTION = 'logshield_dismissed';
	const DISMISS_MAX      = 2000;
	const DISMISS_TTL_DAYS = 30;

	/** Групповое действие: не больше стольких адресов за раз. */
	const BULK_MAX = 200;

	/** Сроки блокировки в панели адреса (дней); «по умолчанию» — из настроек. */
	const BAN_DAYS = [ 1, 7, 30 ];

	/** Последние запросы адреса: сколько байт с конца лога читать и сколько строк отдавать. */
	const IP_REQUESTS_BYTES = 2097152;
	const IP_REQUESTS_MAX   = 50;

	/** Сколько записей истории срабатываний на адрес отдавать панели. */
	const HISTORY_PER_IP = 10;

	/** Вычисленное за запрос: атакующие, список банов, история. */
	private static $memo = [];

	/** Хуки: индекс и кэш запроса обновляются при любой записи истории и банов. */
	public static function init() {
		$scan = LogShield_Detector::SCANLOG_OPTION;
		add_action( "add_option_{$scan}", function ( $name, $value ) { self::refresh_unseen_index( $value ); }, 10, 2 );
		add_action( "update_option_{$scan}", function ( $old, $value ) { self::refresh_unseen_index( $value ); }, 10, 2 );
		add_action( "delete_option_{$scan}", function () { self::refresh_unseen_index( [] ); } );
		$ban = LogShield_Htaccess::BANNED_OPTION;
		foreach ( [ "add_option_{$ban}", "update_option_{$ban}", "delete_option_{$ban}" ] as $hook ) {
			add_action( $hook, [ __CLASS__, 'flush_memo' ] );
		}
		add_action( 'admin_post_logshield_evictions_ack', [ __CLASS__, 'ack_evictions' ] );
		add_action( 'wp_ajax_logshield_theme', [ __CLASS__, 'ajax_theme' ] );
		add_action( 'admin_post_logshield_bulk', [ __CLASS__, 'bulk' ] );
		add_action( 'wp_ajax_logshield_ip_requests', [ __CLASS__, 'ajax_ip_requests' ] );
		$dis = self::DISMISSED_OPTION;
		foreach ( [ "add_option_{$dis}", "update_option_{$dis}", "delete_option_{$dis}" ] as $hook ) {
			add_action( $hook, [ __CLASS__, 'flush_memo' ] );
		}
	}

	/** «Понятно» у предупреждения о лимите блокировок: забыть сводку вытеснений. */
	public static function ack_evictions() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_evictions_ack' );
		LogShield_Htaccess::clear_evictions();
		LogShield_Admin::redirect_with_message( 'Предупреждение о лимите блокировок скрыто.' );
	}

	/** Сбросить вычисленное за запрос (после записи истории или банов; для тестов). */
	public static function flush_memo() {
		self::$memo = [];
	}

	/**
	 * Индекс по истории сканирований. Сканирование без новых адресов (n = 0)
	 * нужно только там, где старое сканирование новее его по времени (часы
	 * переводили): иначе обрыв подсчёта на нём ничего не меняет.
	 */
	public static function build_unseen_index( $scan_log ) {
		$pairs = [];
		$seen  = [];
		foreach ( (array) $scan_log as $run ) {
			$n = 0;
			foreach ( array_keys( (array) ( $run['flagged'] ?? [] ) ) as $ip ) {
				$ip = (string) $ip;
				if ( isset( $seen[ $ip ] ) ) continue;
				$seen[ $ip ] = true;
				$n++;
			}
			$pairs[] = [ (int) ( $run['time'] ?? 0 ), $n ];
		}
		$out       = [];
		$older_max = PHP_INT_MIN; // самое позднее время среди более старых сканирований с n > 0
		for ( $i = count( $pairs ) - 1; $i >= 0; $i-- ) {
			list( $t, $n ) = $pairs[ $i ];
			if ( $n > 0 || $older_max > $t ) $out[] = $t . ':' . $n;
			if ( $n > 0 ) $older_max = max( $older_max, $t );
		}
		return implode( ' ', array_reverse( $out ) );
	}

	public static function refresh_unseen_index( $scan_log ) {
		self::flush_memo();
		update_option( self::UNSEEN_INDEX_OPTION, self::build_unseen_index( $scan_log ), true );
	}

	private static function unseen_index() {
		$index = get_option( self::UNSEEN_INDEX_OPTION, false );
		if ( ! is_string( $index ) ) {
			// Установка до появления индекса: строим один раз по полной истории.
			$index = self::build_unseen_index( self::scan_log() );
			update_option( self::UNSEEN_INDEX_OPTION, $index, true );
		}
		return $index;
	}

	/**
	 * Сколько новых атакующих (IP и подсетей) нашли сканирования с момента,
	 * когда текущий пользователь последний раз открывал дашборд.
	 * Уже забаненные сюда не попадают — их убирает run() до записи в историю.
	 * Считается по короткому индексу, без загрузки истории сканирований.
	 */
	public static function unseen_count( $user_id = 0 ) {
		$user_id = $user_id ?: get_current_user_id();
		$seen    = (int) get_user_meta( $user_id, self::SEEN_META, true );
		if ( ! $seen ) {
			// Первый раз: не пугать всей историей, считать с установки отметки.
			update_user_meta( $user_id, self::SEEN_META, time() );
			return 0;
		}
		$count = 0;
		$index = self::unseen_index();
		if ( $index === '' ) return 0;
		foreach ( explode( ' ', $index ) as $pair ) {
			list( $t, $n ) = array_map( 'intval', explode( ':', $pair ) + [ 1 => 0 ] );
			if ( $t <= $seen ) break; // история — от новых к старым
			$count += $n;
		}
		return $count;
	}

	/** История сканирований — один раз за запрос. */
	private static function scan_log() {
		if ( ! isset( self::$memo['scan_log'] ) ) self::$memo['scan_log'] = (array) LogShield_Detector::get_scan_log();
		return self::$memo['scan_log'];
	}

	/** Список банов — один раз за запрос. */
	private static function banned() {
		if ( ! isset( self::$memo['banned'] ) ) self::$memo['banned'] = (array) LogShield_Htaccess::get_banned();
		return self::$memo['banned'];
	}

	/** Скрытые адреса без устаревших записей: ip|cidr => когда скрыли. Один раз за запрос. */
	public static function dismissed() {
		if ( isset( self::$memo['dismissed'] ) ) return self::$memo['dismissed'];
		$list = get_option( self::DISMISSED_OPTION, [] );
		return self::$memo['dismissed'] = self::prune_dismissed( is_array( $list ) ? $list : [] );
	}

	/** Убрать старше DISMISS_TTL_DAYS и урезать до DISMISS_MAX (остаются скрытые последними). */
	private static function prune_dismissed( array $list ) {
		$cutoff = time() - self::DISMISS_TTL_DAYS * DAY_IN_SECONDS;
		$out    = [];
		foreach ( $list as $ip => $t ) {
			$t = (int) $t;
			if ( $t >= $cutoff && LogShield_IP::is_valid_entry( (string) $ip ) ) $out[ (string) $ip ] = $t;
		}
		if ( count( $out ) > self::DISMISS_MAX ) {
			arsort( $out );
			$out = array_slice( $out, 0, self::DISMISS_MAX, true );
		}
		return $out;
	}

	/**
	 * Скрыть адреса в таблице атакующих (пока их не поймают снова).
	 *
	 * @param string[] $entries проверенные IP и CIDR
	 * @return int сколько скрыто
	 */
	public static function dismiss( array $entries ) {
		$list = self::dismissed();
		$now  = time();
		$n    = 0;
		foreach ( $entries as $e ) {
			$e = (string) $e;
			if ( ! LogShield_IP::is_valid_entry( $e ) ) continue;
			$list[ $e ] = $now;
			$n++;
		}
		update_option( self::DISMISSED_OPTION, self::prune_dismissed( $list ), false );
		self::flush_memo();
		return $n;
	}

	public static function mark_seen( $user_id = 0 ) {
		update_user_meta( $user_id ?: get_current_user_id(), self::SEEN_META, time() );
	}

	/**
	 * Запомнить счётчик и отметку до сброса: бейдж вкладки «Атакующие» показывает,
	 * сколько было новых на момент открытия. Вызывается из admin_menu перед mark_seen().
	 */
	public static function remember_unseen( $user_id = 0 ) {
		$user_id              = $user_id ?: get_current_user_id();
		self::$seen_before    = (int) get_user_meta( $user_id, self::SEEN_META, true );
		self::$unseen_on_open = self::unseen_count( $user_id );
	}

	/** Сколько новых атакующих было на момент открытия дашборда. */
	public static function unseen_on_open() {
		return self::$unseen_on_open;
	}

	/** Имя вкладки из запроса, если оно из белого списка; иначе ''. */
	public static function sanitize_tab( $tab ) {
		$tab = is_string( $tab ) ? $tab : '';
		return isset( self::TABS[ $tab ] ) ? $tab : '';
	}

	/** Тема пользователя: system | dark | light. */
	public static function get_theme( $user_id = 0 ) {
		$t = get_user_meta( $user_id ?: get_current_user_id(), self::THEME_META, true );
		return is_string( $t ) && isset( self::THEMES[ $t ] ) ? $t : self::DEFAULT_THEME;
	}

	/** Сохранение темы без перезагрузки (admin-ajax, POST: theme, nonce). */
	public static function ajax_theme() {
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden', 403 );
		check_ajax_referer( 'logshield_theme', 'nonce' );
		$theme = isset( $_POST['theme'] ) ? sanitize_key( wp_unslash( $_POST['theme'] ) ) : '';
		if ( ! isset( self::THEMES[ $theme ] ) ) wp_send_json_error( 'bad theme', 400 );
		update_user_meta( get_current_user_id(), self::THEME_META, $theme );
		wp_send_json_success( [ 'theme' => $theme ] );
	}

	/**
	 * Переключатель темы для шапки. Без скрипта не работает, поэтому скрыт:
	 * его показывает dashboard.js.
	 */
	private static function theme_control( $theme ) {
		?>
		<label class="ls-theme" data-theme-control hidden>
			<span class="screen-reader-text">Тема дашборда</span>
			<span class="dashicons dashicons-admin-appearance" aria-hidden="true"></span>
			<select class="ls-input ls-input-sm" data-theme-select autocomplete="off">
				<?php foreach ( self::THEMES as $k => $label ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $theme, $k ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<?php
	}

	/**
	 * Скрытые поля возврата: ls_back (на дашборд) и ls_tab (на вкладку).
	 * $follow — форма вне панелей (шапка, диалог): скрипт подставляет открытую вкладку.
	 */
	private static function back_fields( $tab, $follow = false ) {
		echo '<input type="hidden" name="ls_back" value="' . esc_attr( LogShield_Admin::SLUG_DASH ) . '">';
		echo '<input type="hidden" name="ls_tab" value="' . esc_attr( $tab ) . '"' . ( $follow ? ' data-ls-tab-follow' : '' ) . '>';
	}

	public static function enqueue() {
		$ver = LOGSHIELD_VERSION . '-' . @filemtime( LOGSHIELD_DIR . 'assets/dashboard.js' );
		wp_enqueue_style( 'logshield-dashboard', LOGSHIELD_URL . 'assets/dashboard.css', [], $ver );
		wp_enqueue_script( 'logshield-dashboard', LOGSHIELD_URL . 'assets/dashboard.js', [], $ver, [ 'in_footer' => true, 'strategy' => 'defer' ] );
		LogShield_IPInfo::enqueue();
		wp_add_inline_script( 'logshield-dashboard', 'window.LogShieldData = ' . wp_json_encode( self::data() ) . ';', 'before' );
	}

	/** Данные для скрипта: статистика за 30 дней и настройки живого хвоста. */
	private static function data() {
		$stats = [];
		foreach ( LogShield_Stats::get() as $hour => $h ) {
			$stats[] = [ (int) $hour, $h['req'], $h['e4'], $h['e5'], $h['fails'], $h['ips'], (object) $h['flag'] ];
		}
		$suspects = [];
		foreach ( self::attackers() as $a ) $suspects[] = $a['ip'];
		// События для отметок на графиках: сканирования [время, успешно, найдено] и время банов.
		$scans = [];
		foreach ( self::scan_log() as $run ) {
			$scans[] = [ (int) ( $run['time'] ?? 0 ), empty( $run['ok'] ) ? 0 : 1, count( (array) ( $run['flagged'] ?? [] ) ) ];
		}
		$bans = [];
		foreach ( self::banned() as $info ) {
			if ( ! empty( $info['banned_at'] ) ) $bans[] = (int) $info['banned_at'];
		}
		return [
			'events'   => [ 'scans' => $scans, 'bans' => $bans ],
			'now'      => time(),
			'stats'    => $stats,
			'types'    => LogShield_Stats::TYPES,
			'banned'   => count( self::banned() ),
			'suspects' => $suspects,
			'tail'     => [
				'url'   => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'logshield_tail' ),
			],
			'theme'    => [
				'url'   => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'logshield_theme' ),
			],
			'tabs'     => array_keys( self::TABS ),
			// Панель адреса: история срабатываний и последние запросы (admin-ajax).
			'history'  => (object) self::history(),
			'ipreq'    => [
				'url'   => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'logshield_ip_requests' ),
				'mb'    => round( self::ip_requests_bytes() / 1048576, 1 ),
			],
			// Прошлый просмотр дашборда (unix, 0 — первый): атакующие новее него — «новые».
			'seenBefore' => self::$seen_before,
		];
	}

	/**
	 * Атакующие: заблокированные и помеченные в последних сканированиях.
	 *
	 * @return array[] [ ip, reason, types, last, runs, banned, expires ]
	 */
	public static function attackers() {
		if ( isset( self::$memo['attackers'] ) ) return self::$memo['attackers'];
		$banned = self::banned();
		$out    = [];
		foreach ( self::scan_log() as $run ) {
			foreach ( (array) ( $run['flagged'] ?? [] ) as $ip => $reasons ) {
				$ip = (string) $ip;
				if ( isset( $out[ $ip ] ) ) { $out[ $ip ]['runs']++; continue; }
				$out[ $ip ] = [
					'ip'      => $ip,
					'reason'  => implode( '; ', (array) $reasons ),
					'types'   => (array) ( $run['types'][ $ip ] ?? [] ),
					'last'    => (int) $run['time'],
					'runs'    => 1,
					'banned'  => false,
					'expires' => 0,
				];
			}
		}
		foreach ( $banned as $ip => $info ) {
			$ip = (string) $ip;
			if ( ! isset( $out[ $ip ] ) ) {
				$out[ $ip ] = [ 'ip' => $ip, 'reason' => (string) $info['reason'], 'types' => [], 'last' => (int) $info['banned_at'], 'runs' => 0 ];
			}
			$out[ $ip ]['banned']  = true;
			$out[ $ip ]['expires'] = (int) $info['expires_at'];
		}
		// Помеченный IP мог попасть в забаненную потом подсеть.
		$ranges = array_filter( array_keys( $banned ), function ( $b ) { return strpos( (string) $b, '/' ) !== false; } );
		foreach ( $out as $ip => &$a ) {
			if ( ! $a['banned'] && strpos( $ip, '/' ) === false && $ranges && LogShield_IP::matches_any( $ip, $ranges ) ) {
				$a['banned'] = true;
			}
		}
		unset( $a );
		uasort( $out, function ( $x, $y ) { return $y['last'] <=> $x['last']; } );
		// Скрытые — если их не поймали после того, как скрыли. Они не занимают
		// место видимых: 200 видимых и до 100 скрытых (показываются переключателем).
		$dismissed = self::dismissed();
		$shown     = [];
		$hidden    = [];
		foreach ( $out as $ip => $a ) {
			$a['direct'] = isset( $banned[ $ip ] ); // свой бан (а не попал в забаненную подсеть)
			$a['hidden'] = isset( $dismissed[ $ip ] ) && $a['last'] <= $dismissed[ $ip ];
			if ( $a['hidden'] ) {
				if ( count( $hidden ) < 100 ) $hidden[] = $a;
			} elseif ( count( $shown ) < 200 ) {
				$shown[] = $a;
			}
		}
		return self::$memo['attackers'] = array_merge( $shown, $hidden );
	}

	/**
	 * Срабатывания правил по адресам из таблицы: ip => [ [ время, причина, время для показа ], … ],
	 * от новых к старым, не больше HISTORY_PER_IP на адрес.
	 */
	public static function history() {
		$want = [];
		foreach ( self::attackers() as $a ) $want[ $a['ip'] ] = true;
		$out = [];
		foreach ( self::scan_log() as $run ) {
			foreach ( (array) ( $run['flagged'] ?? [] ) as $ip => $reasons ) {
				$ip = (string) $ip;
				if ( ! isset( $want[ $ip ] ) || count( $out[ $ip ] ?? [] ) >= self::HISTORY_PER_IP ) continue;
				$t = (int) ( $run['time'] ?? 0 );
				// Время уже в часовом поясе сайта, как в таблице: у браузера пояс может быть другим.
				$out[ $ip ][] = [ $t, implode( '; ', (array) $reasons ), wp_date( 'd.m H:i', $t ) ];
			}
		}
		return $out;
	}

	/** Группы фильтра «Тип» в таблице атакующих: ключ => [ подпись, типы LogShield_Stats::TYPES ]. */
	const TYPE_GROUPS = [
		'brute'  => [ 'Подбор пароля', [ 'brute' ] ],
		'subnet' => [ 'Подсети', [ 'subnet' ] ],
		'scan'   => [ 'Сканеры', [ 'scan', 'sensitive' ] ],
		'enum'   => [ 'Перебор пользователей', [ 'enum' ] ],
		'other'  => [ 'Другое', [ 'rate', 'errors' ] ],
	];

	/** В какие группы фильтра попадает строка; без типов (ручной бан) — «Другое». */
	public static function row_groups( array $types ) {
		$out = [];
		foreach ( self::TYPE_GROUPS as $g => $def ) {
			if ( array_intersect( $types, $def[1] ) ) $out[] = $g;
		}
		$known = array_merge( ...array_column( array_values( self::TYPE_GROUPS ), 1 ) );
		if ( ! $out || array_diff( $types, $known ) ) $out[] = 'other';
		return array_values( array_unique( $out ) );
	}

	/** Сколько байт с конца лога смотреть для «Последних запросов» (фильтр logshield_ip_requests_bytes). */
	private static function ip_requests_bytes() {
		return max( 65536, (int) apply_filters( 'logshield_ip_requests_bytes', self::IP_REQUESTS_BYTES ) );
	}

	/**
	 * Проверки для карточки «Состояние»: расписание, последнее сканирование,
	 * файл лога и сколько лога ещё не прочитано.
	 *
	 * @return array[] [ level => ok|warn|err, title, text ]
	 */
	public static function health( array $opts, array $scan_log, $next_run, array $state ) {
		$now       = time();
		$schedules = wp_get_schedules();
		$interval  = (int) ( $schedules[ $opts['interval'] ]['interval'] ?? 3 * HOUR_IN_SECONDS );
		$no_cron   = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
		$out       = [];

		// Неудачная запись в .htaccess: держится, пока следующая запись не удастся.
		$write_err = LogShield_Detector::get_write_error();
		if ( $write_err ) {
			$out[] = [ 'err', '.htaccess', 'Блокировка не записана (' . wp_date( 'd.m H:i', (int) $write_err['time'] ) . '): ' . $write_err['error']
				. '. Найденные адреса НЕ заблокированы. Проверьте права на запись в .htaccess — предупреждение исчезнет после успешной записи.' ];
		}

		// Список банов упёрся в лимит: часть блокировок снята. Держится до «Понятно».
		$ev = LogShield_Htaccess::evictions();
		if ( ! empty( $ev['total'] ) ) {
			$manual = (int) ( $ev['manual'] ?? 0 );
			$out[]  = [ 'warn', 'Лимит блокировок', sprintf(
				'Из-за лимита в %d записей снято блокировок: %d%s, последний раз %s (%d). Первыми снимаются самые старые автоматические — те, что раньше всех истекают; ручные — только если их одних больше лимита.',
				LogShield_Htaccess::max_bans(),
				(int) $ev['total'],
				$manual ? ', из них ручных: ' . $manual : '',
				wp_date( 'd.m H:i', (int) ( $ev['last_at'] ?? 0 ) ),
				(int) ( $ev['last_count'] ?? 0 )
			), 'logshield_evictions_ack' ];
		}

		// Расписание.
		if ( ! $next_run ) {
			$out[] = [ 'err', 'Расписание', 'Сканирование не запланировано. Выключите и снова включите плагин.' ];
		} elseif ( $next_run < $now - 15 * MINUTE_IN_SECONDS ) {
			$out[] = [ 'warn', 'Расписание', 'Сканирование просрочено на ' . human_time_diff( $next_run, $now ) . '. '
				. ( $no_cron ? 'WP-Cron отключён (DISABLE_WP_CRON): нужен системный cron на wp-cron.php.' : 'WP-Cron запускается только при посещениях сайта; на тихом сайте лучше системный cron.' ) ];
		} else {
			$when  = $next_run <= $now ? 'вот-вот' : 'через ' . human_time_diff( $now, $next_run );
			$out[] = [ 'ok', 'Расписание', 'Следующее сканирование ' . $when . ' (' . wp_date( 'd.m H:i', $next_run ) . ').'
				. ( $no_cron ? ' WP-Cron отключён: проверьте, что системный cron вызывает wp-cron.php.' : '' ) ];
		}

		// Последнее сканирование.
		$last = $scan_log[0] ?? null;
		if ( ! $last ) {
			$out[] = [ 'warn', 'Сканирование', 'Ещё не запускалось.' ];
		} elseif ( empty( $last['ok'] ) ) {
			$out[] = [ 'err', 'Сканирование', human_time_diff( $last['time'], $now ) . ' назад с ошибкой: ' . $last['message'] ];
		} elseif ( $now - $last['time'] > 2 * $interval + HOUR_IN_SECONDS ) {
			$out[] = [ 'warn', 'Сканирование', 'Последнее было ' . human_time_diff( $last['time'], $now ) . ' назад — дольше двух интервалов.' ];
		} else {
			$n     = count( (array) ( $last['flagged'] ?? [] ) );
			$out[] = [ 'ok', 'Сканирование', human_time_diff( $last['time'], $now ) . ' назад, ' . ( $n ? 'найдено: ' . $n : 'нарушителей нет' ) . '.' ];
		}

		// Нераспознанные строки правила не видят: так можно спрятаться от проверки.
		if ( $last ) {
			$read     = (int) ( $last['read_lines'] ?? 0 );
			$unparsed = (int) ( $last['unparsed'] ?? 0 );
			if ( $unparsed >= 20 && $read > 0 && $unparsed > $read * 0.05 ) {
				$out[] = [ 'warn', 'Формат лога', sprintf(
					'В последнем сканировании не распознано %d из %d строк (%s%%). Эти строки правила не проверяют. Нужен формат Apache Combined или Common.',
					$unparsed,
					$read,
					number_format_i18n( $unparsed / $read * 100, 1 )
				) ];
			}
		}

		// Файл лога.
		$out[] = [ $state['ok'] ? 'ok' : 'err', 'Лог', ( $opts['log_path'] ?: 'путь не указан' ) . ' — ' . $state['text'] ];

		// Сколько осталось прочитать: за запуск читается не больше max_read_mb.
		if ( $state['ok'] ) {
			$pos  = (array) get_option( LogShield_Detector::OFFSET_OPTION, [] );
			$size = (int) @filesize( $opts['log_path'] );
			if ( ( $pos['path'] ?? '' ) !== $opts['log_path'] ) {
				$out[] = [ 'ok', 'Чтение', 'Первое сканирование запомнит конец лога, анализ начнётся со следующего.' ];
			} else {
				$left  = max( 0, $size - (int) ( $pos['offset'] ?? 0 ) );
				$chunk = max( 1, (int) $opts['max_read_mb'] ) * MB_IN_BYTES;
				$runs  = (int) ceil( $left / $chunk );
				if ( $runs <= 1 ) {
					$out[] = [ 'ok', 'Чтение', $left ? 'Новых записей ' . size_format( $left ) . ' — прочитает в следующий раз.' : 'Лог прочитан до конца.' ];
				} else {
					$out[] = [ 'warn', 'Чтение', 'Не прочитано ' . size_format( $left ) . ': при лимите ' . (int) $opts['max_read_mb'] . ' МБ догонит примерно за '
						. $runs . ' сканирований (≈ ' . human_time_diff( 0, $runs * $interval ) . ').' ];
				}
			}
		}
		return $out;
	}

	/**
	 * Кого заблокировал бы тестовый режим за последние $days дней:
	 * помеченные сканированиями адреса и подсети, ещё не заблокированные.
	 *
	 * @return array{ips:int, nets:int}
	 */
	public static function would_ban( $days = 7 ) {
		$since = time() - $days * DAY_IN_SECONDS;
		$seen  = [];
		foreach ( self::scan_log() as $run ) {
			if ( (int) ( $run['time'] ?? 0 ) < $since ) break; // история — от новых к старым
			foreach ( array_keys( (array) ( $run['flagged'] ?? [] ) ) as $ip ) $seen[ (string) $ip ] = true;
		}
		$banned = [];
		foreach ( self::attackers() as $a ) {
			if ( $a['banned'] ) $banned[ $a['ip'] ] = true;
		}
		$ips  = 0;
		$nets = 0;
		foreach ( array_keys( $seen ) as $ip ) {
			if ( isset( $banned[ $ip ] ) ) continue;
			if ( strpos( $ip, '/' ) === false ) $ips++; else $nets++;
		}
		return [ 'ips' => $ips, 'nets' => $nets ];
	}

	/**
	 * Чек-лист «Первый запуск» на вкладке «Обзор».
	 *
	 * Шаг «Проверьте список» отмечает браузер (dashboard.js, localStorage), когда
	 * пользователь открыл вкладку «Атакующие» после первого сканирования: отдельной
	 * user meta для этого нет. После включения защиты шаг считается пройденным —
	 * решение уже принято.
	 *
	 * @param array $state    LogShield_LogFinder::describe() текущего пути
	 * @param bool  $reviewed список уже проверен (для тестов; на странице — false, отмечает скрипт)
	 * @return array{steps: array[], done: int, current: string, show: bool}
	 *         steps: [ key, title, done, text ]; current — первый невыполненный шаг ('' — всё готово);
	 *         show — показывать карточку (есть невыполненные шаги; пока включён тестовый режим, это всегда так).
	 */
	public static function onboarding( array $opts, array $state, array $scan_log, $reviewed = false ) {
		$dry  = ! empty( $opts['dry_run'] );
		$path = (string) ( $opts['log_path'] ?? '' );
		$ok_run = null;
		foreach ( $scan_log as $run ) {
			if ( ! empty( $run['ok'] ) ) { $ok_run = $run; break; } // история — от новых к старым
		}
		$last = $scan_log[0] ?? null;

		$steps   = [];
		$steps[] = [ 'log', 'Лог найден', ! empty( $state['ok'] ),
			! empty( $state['ok'] ) ? $path : ( $path === '' ? 'Путь к access_log не указан и не найден автоматически.' : $path . ' — ' . ( $state['text'] ?? '' ) ) ];
		if ( $ok_run ) {
			$scan_text = 'Последнее успешное — ' . wp_date( 'd.m H:i', (int) $ok_run['time'] ) . '.';
		} elseif ( $last ) {
			$scan_text = 'Последнее закончилось ошибкой: ' . ( $last['message'] ?? '' );
		} else {
			$scan_text = 'Первое сканирование запомнит конец лога; со следующего начнётся анализ. Можно не ждать расписания.';
		}
		$steps[] = [ 'scan', 'Первое сканирование прошло', (bool) $ok_run, $scan_text ];
		$steps[] = [ 'review', 'Проверьте список атакующих (нет ли своих)', $reviewed || ! $dry,
			'Свой адрес, офис или сервис мониторинга в списке — добавьте в белый список, иначе после включения защиты он будет заблокирован.' ];
		$steps[] = [ 'protect', 'Включите защиту', ! $dry,
			$dry ? 'Сейчас тестовый режим: нарушители только записываются. После включения новые будут блокироваться в .htaccess.' : 'Нарушители блокируются в .htaccess.' ];

		$current = '';
		$done    = 0;
		foreach ( $steps as $s ) {
			if ( $s[2] ) $done++;
			elseif ( $current === '' ) $current = $s[0];
		}
		return [ 'steps' => $steps, 'done' => $done, 'current' => $current, 'show' => $current !== '' ];
	}

	/** Карточка «Первый запуск»: <ol> шагов, у невыполненных — действие. */
	private static function render_onboarding( array $ob, $post_url ) {
		if ( ! $ob['show'] ) return;
		$total = count( $ob['steps'] );
		// Ключ отметки «список проверен» в localStorage: свой у сайта и пользователя.
		$key = 'logshield-reviewed:' . get_current_user_id() . '@' . home_url( '/' );
		?>
		<section class="ls-card ls-onboard" aria-labelledby="ls-onboard-title" data-onboard data-review-key="<?php echo esc_attr( $key ); ?>">
			<div class="ls-card-head">
				<h2 id="ls-onboard-title">Первый запуск</h2>
				<p class="ls-legend" data-onboard-count>Готово <?php echo (int) $ob['done']; ?> из <?php echo (int) $total; ?></p>
			</div>
			<ol class="ls-steps">
				<?php foreach ( $ob['steps'] as $i => $s ) :
					list( $key_s, $title, $done, $text ) = $s;
					$cur = $key_s === $ob['current']; ?>
					<li class="ls-step<?php echo $done ? ' ls-step-done' : ''; ?>" data-step="<?php echo esc_attr( $key_s ); ?>" data-done="<?php echo $done ? '1' : '0'; ?>"<?php echo $cur ? ' aria-current="step"' : ''; ?>>
						<span class="ls-step-mark" aria-hidden="true"><span class="ls-step-n"><?php echo (int) $i + 1; ?></span></span>
						<div class="ls-step-body">
							<strong class="ls-step-title"><?php echo esc_html( $title ); ?></strong><span class="screen-reader-text" data-step-state><?php echo $done ? ' — выполнено' : ( $cur ? ' — текущий шаг' : ' — не выполнено' ); ?></span>
							<span class="ls-step-text"><?php echo esc_html( $text ); ?></span>
							<?php if ( ! $done ) : ?>
								<div class="ls-step-act">
									<?php if ( $key_s === 'log' ) : ?>
										<a class="ls-btn ls-btn-sm<?php echo $cur ? ' ls-btn-accent' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=' . LogShield_Admin::SLUG ) . '#log_path' ); ?>">Указать путь к логу</a>
									<?php elseif ( $key_s === 'scan' ) : ?>
										<form method="post" action="<?php echo esc_url( $post_url ); ?>">
											<input type="hidden" name="action" value="logshield_run_now">
											<?php self::back_fields( 'overview' ); ?>
											<?php wp_nonce_field( 'logshield_run_now' ); ?>
											<button class="ls-btn ls-btn-sm<?php echo $cur ? ' ls-btn-accent' : ''; ?>">Запустить сканирование</button>
										</form>
									<?php elseif ( $key_s === 'review' ) : ?>
										<a class="ls-btn ls-btn-sm<?php echo $cur ? ' ls-btn-accent' : ''; ?>" href="#attackers">Открыть «Атакующие»</a>
									<?php elseif ( $key_s === 'protect' ) : ?>
										<?php // Диалог #ls-protect есть, пока включён тестовый режим (а шаг не выполнен только тогда). ?>
										<button type="button" class="ls-btn ls-btn-sm<?php echo $cur ? ' ls-btn-accent' : ''; ?>" command="show-modal" commandfor="ls-protect">Включить защиту…</button>
									<?php endif; ?>
								</div>
							<?php endif; ?>
						</div>
					</li>
				<?php endforeach; ?>
			</ol>
		</section>
		<?php
	}

	/** Кнопка «Включить защиту» на дашборде: выключает тестовый режим. */
	public static function protect() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_protect' );
		$opts            = LogShield_Plugin::get_options();
		$opts['dry_run'] = false;
		update_option( LOGSHIELD_OPTION, $opts );
		LogShield_Admin::redirect_with_message( 'Защита включена: со следующего сканирования нарушители будут блокироваться в .htaccess.' );
	}

	/** Худший уровень пунктов «Состояния»: ok | warn | err. */
	public static function health_level( array $health ) {
		$worst = 'ok';
		foreach ( $health as $item ) {
			if ( $item[0] === 'err' ) return 'err';
			if ( $item[0] === 'warn' ) $worst = 'warn';
		}
		return $worst;
	}

	/** «Сканирование 12 минут назад · следующее в 14:20» для шапки. */
	private static function scan_status( array $scan_log, $next_run, $interval_label ) {
		$now  = time();
		$last = (int) ( $scan_log[0]['time'] ?? 0 );
		$out  = $last
			? 'Сканирование <time datetime="' . esc_attr( gmdate( 'c', $last ) ) . '" title="' . esc_attr( wp_date( 'd.m.Y H:i', $last ) ) . '">' . esc_html( human_time_diff( $last, $now ) ) . ' назад</time>'
			: 'Сканирований ещё не было';
		if ( ! $next_run ) {
			$out .= ' · <span class="ls-danger">следующее не запланировано</span>';
		} elseif ( $next_run <= $now ) {
			$out .= ' · следующее вот-вот';
		} else {
			$fmt  = wp_date( 'Y-m-d', $next_run ) === wp_date( 'Y-m-d', $now ) ? 'H:i' : 'd.m H:i';
			$out .= ' · следующее в <time datetime="' . esc_attr( gmdate( 'c', $next_run ) ) . '">' . esc_html( wp_date( $fmt, $next_run ) ) . '</time>';
		}
		return $out . ' <span class="ls-dim">(анализ лога раз в ' . esc_html( $interval_label ) . ')</span>';
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) return;
		$opts     = LogShield_Plugin::get_options();
		$scan_log = self::scan_log();
		$banned   = self::banned();
		$next_run = wp_next_scheduled( LOGSHIELD_CRON_HOOK );
		$state    = LogShield_LogFinder::describe( $opts['log_path'] );
		$attack   = self::attackers();
		$types    = LogShield_Stats::TYPES;
		$host     = wp_parse_url( home_url(), PHP_URL_HOST );
		$post_url = admin_url( 'admin-post.php' );
		$can_fill = $state['ok'] && get_option( self::BACKFILL_OPTION ) !== $opts['log_path'];
		$health   = self::health( $opts, $scan_log, $next_run, $state );
		$h_level  = self::health_level( $health );
		$unseen   = self::unseen_on_open();
		$theme    = self::get_theme();
		$levels   = [ 'ok' => [ '✓', 'в порядке' ], 'warn' => [ '⚠', 'внимание' ], 'err' => [ '✕', 'ошибка' ] ];
		$first    = array_key_first( self::TABS );
		$def_days = (int) $opts['ban_expiry_days'];
		$onboard  = self::onboarding( $opts, $state, $scan_log, false );
		// Группы для фильтра по типу: сколько строк в каждой (без скрытых).
		$groups   = array_fill_keys( array_keys( self::TYPE_GROUPS ), 0 );
		$n_hidden = 0;
		$ipinfo   = LogShield_IPInfo::get_all();
		foreach ( $attack as $a ) {
			if ( $a['hidden'] ) { $n_hidden++; continue; }
			foreach ( self::row_groups( $a['types'] ) as $g ) $groups[ $g ]++;
		}
		?>
		<div class="wrap ls-wrap">
		<h1 class="screen-reader-text">LogShield — дашборд</h1>
		<?php // Уведомления WordPress вставляет после первого заголовка, до панели. ?>
		<?php // data-theme ставит сервер — без мигания; тему меняет dashboard.js. ?>
		<div class="ls-dash" data-theme="<?php echo esc_attr( $theme ); ?>">

			<header class="ls-head">
				<p class="ls-brand">
					<span class="ls-logo dashicons dashicons-shield" aria-hidden="true"></span>
					<span class="ls-title">LogShield</span>
					<span class="ls-dim ls-host"><?php echo esc_html( $host ); ?></span>
				</p>
				<?php if ( $opts['dry_run'] ) : ?>
					<span class="ls-badge ls-badge-warn"><span class="ls-dot" aria-hidden="true"></span>Тестовый режим</span>
				<?php else : ?>
					<span class="ls-badge ls-badge-ok"><span class="ls-dot" aria-hidden="true"></span>Защита включена</span>
				<?php endif; ?>
				<p class="ls-head-status"><?php echo self::scan_status( $scan_log, $next_run, LogShield_Plugin::interval_label( $opts['interval'] ) ); // phpcs:ignore -- экранировано внутри ?></p>
				<div class="ls-head-actions">
					<?php self::theme_control( $theme ); ?>
					<form method="post" action="<?php echo esc_url( $post_url ); ?>">
						<input type="hidden" name="action" value="logshield_run_now">
						<?php self::back_fields( $first, true ); ?>
						<?php wp_nonce_field( 'logshield_run_now' ); ?>
						<button class="ls-btn ls-btn-accent"><span class="dashicons dashicons-update" aria-hidden="true"></span> Запустить<span class="screen-reader-text"> сканирование сейчас</span></button>
					</form>
					<a class="ls-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=' . LogShield_Admin::SLUG ) ); ?>"><span class="dashicons dashicons-admin-generic" aria-hidden="true"></span> Настройки</a>
				</div>
			</header>

			<?php if ( $opts['dry_run'] ) :
				$would = self::would_ban( 7 );
				$my_ip = LogShield_Whitelist::get_client_ip();
				$my_why = $my_ip ? LogShield_Whitelist::whitelist_reason( $my_ip, (array) $opts['whitelist_ips'] ) : null; ?>
				<section class="ls-dry" aria-label="Тестовый режим">
					<p>
						<span aria-hidden="true">⚠</span> <strong class="ls-dry-title">Тестовый режим: никого не блокирует.</strong>
						<?php if ( $would['ips'] || $would['nets'] ) : ?>
							За 7 дней заблокировал бы адресов: <strong><?php echo (int) $would['ips']; ?></strong><?php if ( $would['nets'] ) : ?>, подсетей: <strong><?php echo (int) $would['nets']; ?></strong><?php endif; ?> — проверьте, нет ли своих, во вкладке <a href="#attackers">«Атакующие»</a>.
						<?php else : ?>
							За 7 дней блокировать было бы некого.
						<?php endif; ?>
					</p>
					<?php // Где нет command/commandfor, диалог открывает dashboard.js. ?>
					<button type="button" class="ls-btn ls-btn-accent ls-btn-sm" command="show-modal" commandfor="ls-protect">Включить защиту…</button>
				</section>
				<dialog id="ls-protect" class="ls-dialog" aria-labelledby="ls-protect-title" aria-describedby="ls-protect-desc">
					<h2 id="ls-protect-title">Включить защиту?</h2>
					<div id="ls-protect-desc">
						<p>Со следующего сканирования новые нарушители будут блокироваться в <code>.htaccess</code>. Уже найденных можно заблокировать вручную в таблице.</p>
						<?php if ( $my_why ) : ?>
							<p><span aria-hidden="true">✓</span> Ваш адрес <code><?php echo esc_html( $my_ip ); ?></code> в белом списке: <?php echo esc_html( $my_why['text'] ); ?>.</p>
						<?php else : ?>
							<p class="ls-warn-text"><span aria-hidden="true">⚠</span> Ваш адрес <code><?php echo esc_html( $my_ip ?: 'не определён' ); ?></code> не найден в белом списке. Добавьте его в настройках, прежде чем включать.</p>
						<?php endif; ?>
						<p class="ls-dim">Вернуть тестовый режим можно в настройках.</p>
					</div>
					<div class="ls-dialog-actions">
						<form method="dialog">
							<button class="ls-btn" autofocus>Отмена</button>
						</form>
						<form method="post" action="<?php echo esc_url( $post_url ); ?>">
							<input type="hidden" name="action" value="logshield_protect">
							<?php self::back_fields( $first, true ); ?>
							<?php wp_nonce_field( 'logshield_protect' ); ?>
							<button class="ls-btn ls-btn-accent">Включить защиту</button>
						</form>
					</div>
				</dialog>
			<?php endif; ?>

			<?php
			// Вкладки. Без скрипта список вкладок скрыт и все панели идут подряд.
			// Выбор — по нажатию (Enter/пробел/щелчок), а не по фокусу: выбор меняет адрес (#hash).
			?>
			<div class="ls-tablist" role="tablist" aria-label="Разделы дашборда" data-tablist hidden>
				<?php foreach ( self::TABS as $k => $label ) : $on = $k === $first; ?>
					<button type="button" role="tab" class="ls-tab" id="ls-tab-<?php echo esc_attr( $k ); ?>" data-tab="<?php echo esc_attr( $k ); ?>" aria-selected="<?php echo $on ? 'true' : 'false'; ?>" tabindex="<?php echo $on ? '0' : '-1'; ?>">
						<?php echo esc_html( $label ); ?>
						<?php if ( $k === 'attackers' && $unseen ) : ?>
							<span class="ls-tab-count" data-tab-badge><span aria-hidden="true"><?php echo (int) $unseen; ?></span><span class="screen-reader-text">, новых: <?php echo (int) $unseen; ?></span></span>
						<?php elseif ( $k === 'health' && $h_level !== 'ok' ) : ?>
							<span class="ls-tab-alert ls-tab-alert-<?php echo esc_attr( $h_level ); ?>" data-tab-badge><span aria-hidden="true"><?php echo esc_html( $levels[ $h_level ][0] ); ?></span><span class="screen-reader-text">, <?php echo $h_level === 'err' ? 'есть ошибки' : 'есть предупреждения'; ?></span></span>
						<?php endif; ?>
					</button>
				<?php endforeach; ?>
			</div>
			<?php
			// До загрузки dashboard.js (он с defer) — сразу показать вкладку из #hash,
			// чтобы не мелькали все панели подряд. Всё остальное делает dashboard.js.
			wp_print_inline_script_tag(
				'(function(s){var r=s.parentNode,l=r.querySelector("[data-tablist]"),t=location.hash.slice(1);'
				. 'if(!l)return;if(!/^[a-z]+$/.test(t)||!l.querySelector("#ls-tab-"+t))t=l.querySelector("[role=tab]").dataset.tab;'
				. 'r.setAttribute("data-boot-tab",t);l.hidden=false;'
				. 'l.querySelectorAll("[role=tab]").forEach(function(b){var on=b.dataset.tab===t;b.setAttribute("aria-selected",on);b.tabIndex=on?0:-1;});'
				. '})(document.currentScript);'
			);
			?>

			<div class="ls-panels">

			<div class="ls-panel" id="ls-panel-overview" role="tabpanel" aria-labelledby="ls-tab-overview" data-panel="overview">
				<?php self::render_onboarding( $onboard, $post_url ); ?>
				<div class="ls-range" role="group" aria-label="Период графиков">
					<button type="button" class="ls-btn ls-btn-sm" data-range="24" aria-pressed="true">24 часа</button>
					<button type="button" class="ls-btn ls-btn-sm" data-range="168" aria-pressed="false">7 дней</button>
					<button type="button" class="ls-btn ls-btn-sm" data-range="720" aria-pressed="false">30 дней</button>
				</div>

				<section class="ls-metrics" aria-label="Итоги за период">
					<div class="ls-card"><p class="ls-label">Запросов</p><p class="ls-value ls-accent" data-metric="req">—</p></div>
					<div class="ls-card"><p class="ls-label">Ошибки 4xx/5xx</p><p class="ls-value ls-danger" data-metric="err">—</p></div>
					<div class="ls-card"><p class="ls-label">Неудачных входов</p><p class="ls-value ls-warn" data-metric="fails">—</p></div>
					<div class="ls-card"><p class="ls-label">Атакующих найдено</p><p class="ls-value ls-danger" data-metric="flag">—</p></div>
					<div class="ls-card"><p class="ls-label">Заблокировано сейчас</p><p class="ls-value" data-metric="banned">—</p></div>
				</section>

				<div class="ls-empty ls-card" hidden>
					<p><strong>Графиков пока нет.</strong> Статистика копится при каждом сканировании; первое сканирование только запоминает позицию в логе.</p>
					<?php if ( $can_fill ) : ?>
						<form method="post" action="<?php echo esc_url( $post_url ); ?>">
							<input type="hidden" name="action" value="logshield_backfill">
							<?php self::back_fields( 'overview' ); ?>
							<?php wp_nonce_field( 'logshield_backfill' ); ?>
							<button class="ls-btn ls-btn-accent">Построить графики по уже записанному логу</button>
							<span class="ls-dim">— прочитает до <?php echo (int) $opts['max_read_mb']; ?> МБ, ничего не блокирует</span>
						</form>
					<?php endif; ?>
				</div>

				<section class="ls-card ls-chart-card">
					<div class="ls-card-head">
						<h2>Трафик</h2>
						<p class="ls-legend"><span class="ls-key ls-key-accent"></span>Запросы <span class="ls-key ls-key-danger"></span>Ошибки 4xx/5xx <span class="ls-legend-ev" aria-hidden="true"><svg class="ls-mk-key" viewBox="0 0 10 10"><circle class="ls-mk-scan" cx="5" cy="5" r="3"/></svg>сканирование <svg class="ls-mk-key" viewBox="0 0 10 10"><path class="ls-mk-hit" d="M0 1h10L5 9z"/></svg>нашло атакующих <svg class="ls-mk-key" viewBox="0 0 10 10"><rect class="ls-mk-ban" x="1" y="1" width="8" height="8"/></svg>блокировка</span></p>
					</div>
					<div class="ls-chart" data-chart="traffic"></div>
					<details class="ls-chart-data">
						<summary>Данные графика таблицей</summary>
						<div class="ls-table-wrap" tabindex="0" role="region" aria-label="Трафик по периодам">
							<table class="ls-table" data-chart-table="traffic"></table>
						</div>
					</details>
				</section>

				<div class="ls-grid-2">
					<section class="ls-card ls-chart-card">
						<div class="ls-card-head">
							<h2>Неудачные входы</h2>
							<p class="ls-legend"><span class="ls-key ls-key-warn"></span>POST на wp-login.php без входа <span class="ls-legend-ev" aria-hidden="true"><svg class="ls-mk-key" viewBox="0 0 10 10"><circle class="ls-mk-scan" cx="5" cy="5" r="3"/></svg>сканирование <svg class="ls-mk-key" viewBox="0 0 10 10"><path class="ls-mk-hit" d="M0 1h10L5 9z"/></svg>нашло атакующих <svg class="ls-mk-key" viewBox="0 0 10 10"><rect class="ls-mk-ban" x="1" y="1" width="8" height="8"/></svg>блокировка</span></p>
						</div>
						<div class="ls-chart" data-chart="fails"></div>
						<details class="ls-chart-data">
							<summary>Данные графика таблицей</summary>
							<div class="ls-table-wrap" tabindex="0" role="region" aria-label="Неудачные входы по периодам">
								<table class="ls-table" data-chart-table="fails"></table>
							</div>
						</details>
					</section>
					<section class="ls-card">
						<div class="ls-card-head"><h2>Типы атак</h2><p class="ls-legend">адресов за период</p></div>
						<ul class="ls-types" data-types></ul>
					</section>
				</div>

				<?php LogShield_IPInfo::render_card(); ?>

				<p class="ls-dim ls-foot">Графики строятся по данным сканирований и нагрузки не добавляют.</p>
			</div>

			<?php // Таблица атакующих: разметка как была; форма каждой строки возвращает на эту вкладку (ls_tab). ?>
			<div class="ls-panel" id="ls-panel-attackers" role="tabpanel" aria-labelledby="ls-tab-attackers" data-panel="attackers">
				<?php // Ручная блокировка адреса или сети: тот же admin_post_logshield_ban, что у кнопки в строке. ?>
				<section class="ls-card ls-mban" aria-labelledby="ls-mban-title">
					<h2 id="ls-mban-title" class="ls-mban-title">Заблокировать адрес или сеть</h2>
					<form method="post" action="<?php echo esc_url( $post_url ); ?>" class="ls-mban-form" aria-labelledby="ls-mban-title" data-mban>
						<input type="hidden" name="action" value="logshield_ban">
						<?php self::back_fields( 'attackers' ); ?>
						<?php wp_nonce_field( 'logshield_ban' ); ?>
						<div class="ls-mban-field ls-mban-ip">
							<label for="ls-mban-ip">IP или сеть</label>
							<?php // inputmode="url": на телефоне клавиатура с «.», «/» и буквами (IPv6), а не только цифры. ?>
							<input type="text" id="ls-mban-ip" name="ip" required maxlength="64"
								inputmode="url" autocomplete="off" autocapitalize="none" autocorrect="off" spellcheck="false" enterkeyhint="go"
								pattern="[0-9A-Fa-f:.\/]+" placeholder="203.0.113.5 или 203.0.113.0/24"
								aria-describedby="ls-mban-hint" data-mban-ip>
						</div>
						<div class="ls-mban-field">
							<label for="ls-mban-days">Срок</label>
							<?php self::days_select( $def_days, 'ls-mban-days' ); ?>
						</div>
						<div class="ls-mban-field ls-mban-reason">
							<label for="ls-mban-reason">Причина <span class="ls-dim">(необязательно)</span></label>
							<input type="text" id="ls-mban-reason" name="reason" maxlength="<?php echo (int) self::MANUAL_REASON_MAX; ?>" autocomplete="off" enterkeyhint="go">
						</div>
						<button class="ls-btn ls-btn-danger">Заблокировать</button>
						<p id="ls-mban-hint" class="ls-dim ls-mban-hint">IPv4 или IPv6, сеть — в виде CIDR: не шире /<?php echo (int) self::MANUAL_MIN_BITS_V4; ?> для IPv4 и /<?php echo (int) self::MANUAL_MIN_BITS_V6; ?> для IPv6. Записывается в <code>.htaccess</code> сразу, и в тестовом режиме тоже. Адрес из белого списка не заблокируется.</p>
					</form>
				</section>

				<section class="ls-card ls-attackers-card">
					<div class="ls-card-head">
						<h2 id="ls-attackers-title">Атакующие адреса</h2>
						<p class="ls-legend"><?php echo count( $attack ); ?></p>
					</div>
					<?php if ( ! $attack ) : ?>
						<p class="ls-dim ls-pad">Пока никого не поймали.</p>
					<?php else : ?>
						<?php // Фильтры, выбор строк и панель адреса работают только со скриптом — он их и показывает. ?>
						<div class="ls-filters" data-attack-filters hidden>
							<label class="ls-f-search">
								<span>Поиск</span>
								<input type="search" class="ls-input" data-f-q placeholder="IP, причина, страна или сеть" autocomplete="off" spellcheck="false">
							</label>
							<div class="ls-chips" role="group" aria-labelledby="ls-f-type-label" data-f-type>
								<span class="ls-chips-label" id="ls-f-type-label">Тип</span>
								<button type="button" class="ls-chip" aria-pressed="true" data-v="">Все</button>
								<?php foreach ( self::TYPE_GROUPS as $g => $def ) : if ( ! $groups[ $g ] ) continue; ?>
									<button type="button" class="ls-chip" aria-pressed="false" data-v="<?php echo esc_attr( $g ); ?>"><?php echo esc_html( $def[0] ); ?> <span class="ls-chip-n"><?php echo (int) $groups[ $g ]; ?></span></button>
								<?php endforeach; ?>
							</div>
							<div class="ls-chips" role="group" aria-labelledby="ls-f-status-label" data-f-status>
								<span class="ls-chips-label" id="ls-f-status-label">Статус</span>
								<button type="button" class="ls-chip" aria-pressed="true" data-v="">Все</button>
								<button type="button" class="ls-chip" aria-pressed="false" data-v="seen">Не заблокированы</button>
								<button type="button" class="ls-chip" aria-pressed="false" data-v="banned">Заблокированы</button>
							</div>
							<?php if ( $n_hidden ) : ?>
								<button type="button" class="ls-chip" aria-pressed="false" data-f-hidden>Показать скрытые (<?php echo (int) $n_hidden; ?>)</button>
							<?php endif; ?>
							<p class="ls-dim ls-f-count" role="status" data-f-count></p>
						</div>

						<?php // Панель действий с выбранными: видна, когда выбрана хотя бы одна строка. ?>
						<div class="ls-bulk" data-bulk hidden>
							<p class="ls-bulk-count" data-bulk-count></p>
							<div class="ls-bulk-bar" role="toolbar" focusgroup="toolbar wrap" aria-label="Действия с выбранными адресами" aria-controls="ls-attackers">
								<button type="button" class="ls-btn ls-btn-sm ls-btn-danger" data-bulk-op="ban">Заблокировать</button>
								<button type="button" class="ls-btn ls-btn-sm" data-bulk-op="unban">Разблокировать</button>
								<button type="button" class="ls-btn ls-btn-sm" data-bulk-op="hide">Скрыть</button>
								<button type="button" class="ls-btn ls-btn-sm" data-bulk-op="clear">Снять выделение</button>
							</div>
						</div>
						<?php // Объявления о выборе и результатах — вне панели, всегда в DOM. ?>
						<p class="screen-reader-text" role="status" data-bulk-live></p>
						<form method="post" action="<?php echo esc_url( $post_url ); ?>" data-bulk-form hidden>
							<input type="hidden" name="action" value="logshield_bulk">
							<input type="hidden" name="op" value="" data-bulk-input-op>
							<?php self::back_fields( 'attackers' ); ?>
							<?php wp_nonce_field( 'logshield_bulk' ); ?>
						</form>

						<div class="ls-table-wrap" tabindex="0" role="region" aria-labelledby="ls-attackers-title">
							<table class="ls-table ls-table-stack" id="ls-attackers" data-attackers>
								<thead><tr>
									<th scope="col" class="ls-sel-col"><label class="ls-sel-all"><input type="checkbox" class="ls-check" data-sel-all aria-label="Выбрать все видимые"><span class="ls-sel-all-text" aria-hidden="true">Выбрать все видимые</span></label></th>
									<th scope="col" data-type="ip"><button type="button" class="ls-sort" commandfor="ls-attackers" command="--sort">Адрес<span class="ls-sort-icon" aria-hidden="true"></span></button></th>
									<th scope="col">Что делал</th>
									<th scope="col" data-type="number" aria-sort="descending"><button type="button" class="ls-sort" commandfor="ls-attackers" command="--sort">Когда<span class="ls-sort-icon" aria-hidden="true"></span></button></th>
									<th scope="col">Статус</th>
									<th scope="col"><span class="screen-reader-text">Действие</span></th>
								</tr></thead>
								<tbody>
								<?php foreach ( $attack as $a ) :
									$is_new = self::$seen_before > 0 && $a['last'] > self::$seen_before;
									$geo    = $ipinfo[ $a['ip'] ] ?? null;
									// Поиск: адрес, причина, страна, сеть и номер AS.
									$q = $a['ip'] . ' ' . $a['reason'];
									if ( $geo ) $q .= ' ' . ( $geo['country'] ?? '' ) . ' ' . ( $geo['cc'] ?? '' ) . ' ' . ( $geo['org'] ?? '' ) . ( ! empty( $geo['asn'] ) ? ' AS' . $geo['asn'] : '' );
									foreach ( $a['types'] as $t ) $q .= ' ' . ( $types[ $t ] ?? $t );
									?>
									<tr data-ip="<?php echo esc_attr( $a['ip'] ); ?>" data-types="<?php echo esc_attr( implode( ' ', $a['types'] ) ); ?>" data-groups="<?php echo esc_attr( implode( ' ', self::row_groups( $a['types'] ) ) ); ?>" data-status="<?php echo $a['banned'] ? 'banned' : 'seen'; ?>" data-direct="<?php echo $a['direct'] ? '1' : '0'; ?>" data-expires="<?php echo $a['expires'] ? esc_attr( wp_date( 'd.m.Y', (int) $a['expires'] ) ) : ''; ?>" data-q="<?php echo esc_attr( mb_strtolower( $q ) ); ?>"<?php echo $a['hidden'] ? ' data-dismissed hidden' : ''; ?><?php echo $is_new ? ' data-new' : ''; ?>>
										<?php // label вокруг флажка — область касания больше самого флажка (на сенсорном экране 44 px). ?>
										<td class="ls-sel-col"><label class="ls-sel"><input type="checkbox" class="ls-check" data-sel value="<?php echo esc_attr( $a['ip'] ); ?>" aria-label="Выбрать <?php echo esc_attr( $a['ip'] ); ?>"></label></td>
										<th scope="row" data-value="<?php echo esc_attr( $a['ip'] ); ?>">
											<button type="button" class="ls-ip-btn" data-ip-open aria-haspopup="dialog" title="Подробнее об адресе"><code><?php echo esc_html( $a['ip'] ); ?></code><span class="screen-reader-text">, подробнее</span></button>
											<?php if ( $is_new ) : ?><span class="ls-tag ls-tag-new">новый</span><?php endif; ?>
											<?php if ( $a['hidden'] ) : ?><span class="ls-tag ls-tag-dismissed">скрыт</span><?php endif; ?>
											<?php echo LogShield_IPInfo::badge( $a['ip'], $ipinfo ); // phpcs:ignore -- экранировано внутри ?>
										</th>
										<td data-label="Что делал">
											<?php foreach ( $a['types'] as $t ) : ?>
												<span class="ls-tag ls-tag-<?php echo esc_attr( $t ); ?>"><?php echo esc_html( $types[ $t ] ?? $t ); ?></span>
											<?php endforeach; ?>
											<span class="ls-reason"><?php echo esc_html( $a['reason'] ); ?></span>
										</td>
										<td class="ls-nowrap" data-label="Когда" data-value="<?php echo (int) $a['last']; ?>"><?php echo esc_html( wp_date( 'd.m H:i', $a['last'] ) ); ?><?php if ( $a['runs'] > 1 ) : ?><br><span class="ls-dim"><?php echo (int) $a['runs']; ?> скан.</span><?php endif; ?></td>
										<td class="ls-nowrap" data-label="Статус">
											<?php if ( $a['banned'] ) : ?>
												<span class="ls-tag ls-tag-banned">Заблокирован</span>
												<?php if ( ! $a['direct'] ) : ?><br><span class="ls-dim">в подсети</span><?php elseif ( $a['expires'] ) : ?><br><span class="ls-dim">до <?php echo esc_html( wp_date( 'd.m.Y', $a['expires'] ) ); ?></span><?php endif; ?>
											<?php else : ?>
												<span class="ls-tag ls-tag-seen">Обнаружен</span>
											<?php endif; ?>
										</td>
										<td>
											<form method="post" action="<?php echo esc_url( $post_url ); ?>">
												<?php self::back_fields( 'attackers' ); ?>
												<input type="hidden" name="ip" value="<?php echo esc_attr( $a['ip'] ); ?>">
												<?php if ( $a['banned'] && $a['direct'] ) : ?>
													<input type="hidden" name="action" value="logshield_unban">
													<?php wp_nonce_field( 'logshield_unban' ); ?>
													<button class="ls-btn ls-btn-sm">Разблокировать<span class="screen-reader-text"> <?php echo esc_html( $a['ip'] ); ?></span></button>
												<?php elseif ( ! $a['banned'] ) : ?>
													<input type="hidden" name="action" value="logshield_ban">
													<?php wp_nonce_field( 'logshield_ban' ); ?>
													<button class="ls-btn ls-btn-sm ls-btn-danger">Заблокировать<span class="screen-reader-text"> <?php echo esc_html( $a['ip'] ); ?></span></button>
												<?php endif; ?>
											</form>
										</td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>

						<?php
						// Панель адреса: одна на таблицу, содержимое подставляет dashboard.js.
						// Нативный модальный <dialog>: фокус, Esc, inert страницы и возврат фокуса даёт браузер.
						?>
						<dialog id="ls-ip-panel" class="ls-dialog ls-side" aria-labelledby="ls-ip-title" closedby="any" data-ip-panel>
							<div class="ls-side-head">
								<h2 id="ls-ip-title"><code data-p-ip></code></h2>
								<form method="dialog"><button class="ls-btn ls-btn-sm" autofocus>Закрыть</button></form>
							</div>
							<div class="ls-side-body">
								<div data-p-geo></div>
								<section class="ls-side-sec" aria-labelledby="ls-ip-status-h">
									<h3 id="ls-ip-status-h">Статус</h3>
									<p data-p-status></p>
								</section>
								<section class="ls-side-sec" aria-labelledby="ls-ip-act-h">
									<h3 id="ls-ip-act-h">Действия</h3>
									<div class="ls-side-actions">
										<form method="post" action="<?php echo esc_url( $post_url ); ?>" class="ls-side-ban" data-p-form="ban">
											<input type="hidden" name="action" value="logshield_bulk">
											<input type="hidden" name="op" value="ban">
											<input type="hidden" name="items[]" value="" data-p-item>
											<?php self::back_fields( 'attackers' ); ?>
											<?php wp_nonce_field( 'logshield_bulk' ); ?>
											<label><span>Заблокировать на</span>
												<?php self::days_select( $def_days ); ?>
											</label>
											<button class="ls-btn ls-btn-sm ls-btn-danger">Заблокировать</button>
										</form>
										<form method="post" action="<?php echo esc_url( $post_url ); ?>" data-p-form="unban">
											<input type="hidden" name="action" value="logshield_bulk">
											<input type="hidden" name="op" value="unban">
											<input type="hidden" name="items[]" value="" data-p-item>
											<?php self::back_fields( 'attackers' ); ?>
											<?php wp_nonce_field( 'logshield_bulk' ); ?>
											<button class="ls-btn ls-btn-sm">Разблокировать</button>
										</form>
										<form method="post" action="<?php echo esc_url( $post_url ); ?>" data-p-form="whitelist" data-confirm="">
											<input type="hidden" name="action" value="logshield_bulk">
											<input type="hidden" name="op" value="whitelist">
											<input type="hidden" name="items[]" value="" data-p-item>
											<?php self::back_fields( 'attackers' ); ?>
											<?php wp_nonce_field( 'logshield_bulk' ); ?>
											<button class="ls-btn ls-btn-sm">В белый список</button>
										</form>
										<form method="post" action="<?php echo esc_url( $post_url ); ?>" data-p-form="hide">
											<input type="hidden" name="action" value="logshield_bulk">
											<input type="hidden" name="op" value="hide">
											<input type="hidden" name="items[]" value="" data-p-item>
											<?php self::back_fields( 'attackers' ); ?>
											<?php wp_nonce_field( 'logshield_bulk' ); ?>
											<button class="ls-btn ls-btn-sm">Скрыть</button>
										</form>
									</div>
								</section>
								<section class="ls-side-sec" aria-labelledby="ls-ip-hist-h">
									<h3 id="ls-ip-hist-h">Срабатывания правил</h3>
									<p class="ls-dim" data-p-hist-empty hidden>В истории сканирований этого адреса нет (заблокирован вручную или запись устарела).</p>
									<ol class="ls-side-list" data-p-hist></ol>
								</section>
								<section class="ls-side-sec" aria-labelledby="ls-ip-req-h">
									<h3 id="ls-ip-req-h">Последние запросы</h3>
									<p class="ls-dim" role="status" data-p-req-status></p>
									<ol class="ls-reqs" data-p-reqs></ol>
								</section>
							</div>
						</dialog>
						<?php $banned_count = count( $banned ); ?>
						<?php if ( $banned_count ) : ?>
							<p class="ls-pad">
								<?php // Где нет command/commandfor, диалог открывает dashboard.js. ?>
								<button type="button" class="ls-btn ls-btn-sm" command="show-modal" commandfor="ls-unban-all">Разблокировать все…</button>
							</p>
							<dialog id="ls-unban-all" class="ls-dialog" aria-labelledby="ls-unban-all-title" aria-describedby="ls-unban-all-desc">
								<h2 id="ls-unban-all-title">Снять все блокировки?</h2>
								<p id="ls-unban-all-desc">Из <code>.htaccess</code> будут удалены все заблокированные адреса и подсети (<?php echo (int) $banned_count; ?>). Вернуть их можно только новой блокировкой.</p>
								<div class="ls-dialog-actions">
									<form method="dialog">
										<button class="ls-btn" autofocus>Отмена</button>
									</form>
									<form method="post" action="<?php echo esc_url( $post_url ); ?>">
										<input type="hidden" name="action" value="logshield_unban_all">
										<?php self::back_fields( 'attackers' ); ?>
										<?php wp_nonce_field( 'logshield_unban_all' ); ?>
										<button class="ls-btn ls-btn-danger">Снять все блокировки</button>
									</form>
								</div>
							</dialog>
						<?php endif; ?>
					<?php endif; ?>
				</section>
			</div>

			<div class="ls-panel" id="ls-panel-journal" role="tabpanel" aria-labelledby="ls-tab-journal" data-panel="journal">
				<section class="ls-card">
					<div class="ls-card-head"><h2 id="ls-runs-title">Сканирования</h2><p class="ls-legend">последние 20</p></div>
					<?php if ( ! $scan_log ) : ?>
						<p class="ls-dim ls-pad">Сканирование ещё не запускалось.</p>
					<?php else : ?>
						<div class="ls-runs-wrap" tabindex="0" role="region" aria-labelledby="ls-runs-title">
						<ol class="ls-runs">
							<?php foreach ( array_slice( $scan_log, 0, 20 ) as $run ) :
								$n = count( (array) ( $run['flagged'] ?? [] ) );
								// Итог словом и значком, а не только цветом полосы.
								if ( empty( $run['ok'] ) ) {
									$cls = 'ls-run-err'; $icon = '⚠'; $word = 'ошибка';
								} elseif ( $n ) {
									$cls = 'ls-run-hit'; $icon = '●'; $word = 'найдено: ' . $n;
								} else {
									$cls = 'ls-run-ok'; $icon = '✓'; $word = 'чисто';
								} ?>
								<li class="<?php echo esc_attr( $cls ); ?>">
									<span class="ls-run-time"><?php echo esc_html( wp_date( 'd.m H:i', $run['time'] ) ); ?> · <span class="ls-run-state"><span aria-hidden="true"><?php echo esc_html( $icon ); ?></span> <?php echo esc_html( $word ); ?></span></span>
									<span><?php echo esc_html( $run['message'] ); ?></span>
								</li>
							<?php endforeach; ?>
						</ol>
						</div>
					<?php endif; ?>
				</section>
			</div>

			<div class="ls-panel" id="ls-panel-log" role="tabpanel" aria-labelledby="ls-tab-log" data-panel="log">
				<section class="ls-card">
					<div class="ls-card-head">
						<h2>Последние записи лога</h2>
						<div class="ls-tail-tools">
							<div role="group" aria-label="Фильтр записей">
								<button type="button" class="ls-btn ls-btn-sm" data-filter="all" aria-pressed="true">Все</button>
								<button type="button" class="ls-btn ls-btn-sm" data-filter="4xx" aria-pressed="false">4xx</button>
								<button type="button" class="ls-btn ls-btn-sm" data-filter="5xx" aria-pressed="false">5xx</button>
								<button type="button" class="ls-btn ls-btn-sm" data-filter="bad" aria-pressed="false">Атакующие</button>
							</div>
							<button type="button" class="ls-btn ls-btn-sm" data-ua aria-pressed="false">User-Agent</button>
							<button type="button" class="ls-btn ls-btn-sm" data-live aria-pressed="false"><span class="ls-dot" aria-hidden="true"></span> Живой режим</button>
						</div>
					</div>
					<p class="ls-dim ls-pad ls-tail-note" data-tail-status role="status"><?php echo $state['ok'] ? 'Загрузка…' : 'Лог недоступен — укажите путь в настройках.'; ?></p>
					<div class="ls-tail" data-tail tabindex="0" role="region" aria-label="Последние записи лога"></div>
				</section>
				<p class="ls-dim ls-foot">Лог читается, только пока открыта эта вкладка. Живой режим опрашивает его раз в 5 секунд, а пока новых записей нет — всё реже, до раза в 30 секунд; на скрытой вкладке браузера опросов нет.</p>
			</div>

			<div class="ls-panel" id="ls-panel-health" role="tabpanel" aria-labelledby="ls-tab-health" data-panel="health">
				<section class="ls-card" aria-labelledby="ls-health-title">
					<div class="ls-card-head"><h2 id="ls-health-title">Состояние</h2></div>
					<ul class="ls-health">
						<?php foreach ( $health as $item ) :
							list( $lvl, $title, $text ) = $item;
							$ack = $item[3] ?? ''; ?>
							<li class="ls-h-<?php echo esc_attr( $lvl ); ?>">
								<span class="ls-h-icon" aria-hidden="true"><?php echo esc_html( $levels[ $lvl ][0] ); ?></span>
								<?php // div, а не span: внутри бывает форма «Понятно» (форма в строчном элементе — неверная разметка). Пункт списка — flex, так что вид тот же. ?>
								<div><strong><?php echo esc_html( $title ); ?></strong><span class="screen-reader-text"> (<?php echo esc_html( $levels[ $lvl ][1] ); ?>)</span><br><?php echo esc_html( $text ); ?>
									<?php if ( $ack ) : ?>
										<form method="post" action="<?php echo esc_url( $post_url ); ?>">
											<input type="hidden" name="action" value="<?php echo esc_attr( $ack ); ?>">
											<?php self::back_fields( 'health' ); ?>
											<?php wp_nonce_field( $ack ); ?>
											<button class="ls-btn ls-btn-sm">Понятно<span class="screen-reader-text">: <?php echo esc_html( $title ); ?></span></button>
										</form>
									<?php endif; ?>
								</div>
							</li>
						<?php endforeach; ?>
					</ul>
				</section>
			</div>

			</div>
		</div>
		</div>
		<?php
	}

	/** Самая широкая сеть для ручной блокировки: IPv4 /16 (65 536 адресов), IPv6 /32. */
	const MANUAL_MIN_BITS_V4 = 16;
	const MANUAL_MIN_BITS_V6 = 32;
	/** Длина своей причины ручной блокировки, символов. */
	const MANUAL_REASON_MAX = 200;

	/**
	 * Адрес из формы ручной блокировки: IP или CIDR.
	 * IP — в каноническом виде (IPv6 сжат), сеть — адрес сети и маска (203.0.113.77/24 → 203.0.113.0/24),
	 * /32 у IPv4 и /128 у IPv6 — просто адрес. Сеть шире /16 (IPv4) или /32 (IPv6) не принимается:
	 * такой бан закрыл бы сайт для целого провайдера.
	 *
	 * @return array{ok:bool, entry:string, error:string, changed:bool} changed — вид отличается от введённого
	 */
	public static function manual_entry( $raw ) {
		$raw = trim( (string) $raw );
		$bad = [ 'ok' => false, 'entry' => '', 'changed' => false ];
		if ( $raw === '' ) return $bad + [ 'error' => 'Укажите IP-адрес или сеть.' ];
		if ( strlen( $raw ) > 64 ) return $bad + [ 'error' => 'Неверный адрес.' ];
		if ( filter_var( $raw, FILTER_VALIDATE_IP ) ) {
			$ip = inet_ntop( inet_pton( $raw ) );
			return [ 'ok' => true, 'entry' => $ip, 'error' => '', 'changed' => $ip !== $raw ];
		}
		$c = LogShield_IP::parse_cidr( $raw );
		if ( ! $c ) {
			return $bad + [ 'error' => 'Неверный адрес: «' . $raw . '». Нужен IP (203.0.113.5, 2001:db8::1) или сеть CIDR (203.0.113.0/24).' ];
		}
		$v6  = strlen( $c['net'] ) === 16;
		$min = $v6 ? self::MANUAL_MIN_BITS_V6 : self::MANUAL_MIN_BITS_V4;
		if ( $c['bits'] < $min ) {
			return $bad + [ 'error' => sprintf(
				'Сеть %s слишком широкая: вручную можно заблокировать не больше /%d для %s. Укажите сеть уже (например, /%d) или несколько сетей по очереди.',
				$c['canonical'], $min, $v6 ? 'IPv6' : 'IPv4', $v6 ? 48 : 24
			) ];
		}
		$entry = $c['bits'] === strlen( $c['net'] ) * 8 ? inet_ntop( $c['net'] ) : $c['canonical'];
		return [ 'ok' => true, 'entry' => $entry, 'error' => '', 'changed' => $entry !== $raw ];
	}

	/**
	 * Срок блокировки из формы: default или одно из BAN_DAYS; null — неверный.
	 */
	private static function parse_days( $raw, $default ) {
		$d = is_string( $raw ) ? sanitize_text_field( $raw ) : 'default';
		if ( $d === '' || $d === 'default' ) return (int) $default;
		if ( ctype_digit( $d ) && in_array( (int) $d, self::BAN_DAYS, true ) ) return (int) $d;
		return null;
	}

	/** Выбор срока блокировки: «по умолчанию (N дней)» и BAN_DAYS. */
	private static function days_select( $def_days, $id = '' ) {
		?>
		<select name="days" class="ls-input ls-input-sm"<?php echo $id ? ' id="' . esc_attr( $id ) . '"' : ''; ?>>
			<option value="default"><?php echo esc_html( $def_days > 0 ? 'по умолчанию (' . $def_days . ' ' . self::days_word( $def_days ) . ')' : 'по умолчанию (бессрочно)' ); ?></option>
			<?php foreach ( self::BAN_DAYS as $d ) : ?>
				<option value="<?php echo (int) $d; ?>"><?php echo (int) $d . ' ' . esc_html( self::days_word( $d ) ); ?></option>
			<?php endforeach; ?>
		</select>
		<?php
	}

	/**
	 * Ручной бан с дашборда: кнопка в строке таблицы (поле ip) и форма
	 * «Заблокировать адрес или сеть» (ip — IP или CIDR, days, reason — необязательно).
	 * Применяется сразу, и в тестовом режиме тоже.
	 */
	public static function ban() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_ban' );
		$raw = isset( $_POST['ip'] ) && is_string( $_POST['ip'] ) ? sanitize_text_field( wp_unslash( $_POST['ip'] ) ) : '';
		$e   = self::manual_entry( $raw );
		if ( ! $e['ok'] ) LogShield_Admin::redirect_with_message( $e['error'], 'error' );
		$ip   = $e['entry'];
		$opts = LogShield_Plugin::get_options();
		$days = self::parse_days( isset( $_POST['days'] ) ? wp_unslash( $_POST['days'] ) : 'default', $opts['ban_expiry_days'] );
		if ( $days === null ) LogShield_Admin::redirect_with_message( 'Неверный срок блокировки.', 'error' );

		$whitelist = LogShield_Whitelist::get_full_whitelist( (array) $opts['whitelist_ips'] );
		foreach ( $whitelist as $w ) {
			if ( LogShield_IP::overlaps( $w, $ip ) ) {
				LogShield_Admin::redirect_with_message( ( strpos( $ip, '/' ) !== false ? 'Сеть ' : 'Адрес ' ) . $ip . ' пересекается с белым списком (' . $w . ') — не блокирую.', 'error' );
			}
		}
		$banned = self::banned();
		if ( isset( $banned[ $ip ] ) ) {
			LogShield_Admin::redirect_with_message( $ip . ' уже заблокирован.', 'error' );
		}
		// Уже внутри заблокированной сети (она не уже нашей): новая запись ничего не добавит.
		$bits = function ( $x ) { $p = explode( '/', $x ); return isset( $p[1] ) ? (int) $p[1] : ( strpos( $x, ':' ) !== false ? 128 : 32 ); };
		foreach ( array_keys( $banned ) as $b ) {
			$b = (string) $b;
			if ( strpos( $b, '/' ) !== false && LogShield_IP::overlaps( $b, $ip ) && $bits( $ip ) >= $bits( $b ) ) {
				LogShield_Admin::redirect_with_message( $ip . ' уже входит в заблокированную сеть ' . $b . '.', 'error' );
			}
		}

		$own = isset( $_POST['reason'] ) && is_string( $_POST['reason'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['reason'] ) ) ) : '';
		if ( $own !== '' ) {
			$reason = mb_substr( $own, 0, self::MANUAL_REASON_MAX ) . ' (вручную)';
		} else {
			$reason = 'вручную с дашборда';
			foreach ( self::attackers() as $a ) {
				if ( $a['ip'] === $ip ) { $reason = $a['reason'] . ' (вручную)'; break; }
			}
		}
		// Ручная блокировка применяется сразу, и в тестовом режиме тоже:
		// тестовый режим касается только автоматических банов по расписанию.
		$ok = LogShield_Htaccess::ban_ips( [ $ip => $reason ], $days, true );
		// Записывается весь список банов: удачная запись догнала и прошлые неудачные.
		if ( $ok ) LogShield_Detector::clear_write_error();
		$term = $days > 0 ? ' на ' . $days . ' ' . self::days_word( $days ) : ' бессрочно';
		$note = $e['changed'] ? ' (введено «' . trim( $raw ) . '», записано в каноническом виде)' : '';
		LogShield_Admin::redirect_with_message(
			$ok
				? 'Заблокирован' . $term . ': ' . $ip . $note . ' — записано в ' . LogShield_Htaccess::get_htaccess_path() . '.'
				: 'Не удалось заблокировать ' . $ip . ': ' . LogShield_Htaccess::last_error() . '. Адрес остался в списке банов — запись повторится при следующем изменении списка.',
			$ok ? 'success' : 'error'
		);
	}

	/**
	 * Графики по уже записанному логу: читает до max_read_mb перед текущей
	 * позицией сканера (чтобы не посчитать одно и то же дважды). Только
	 * статистика — никого не банит и не уведомляет. Один раз на путь.
	 */
	public static function backfill() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав' );
		check_admin_referer( 'logshield_backfill' );
		$opts = LogShield_Plugin::get_options();
		$path = $opts['log_path'];
		if ( ! LogShield_LogFinder::describe( $path )['ok'] ) {
			LogShield_Admin::redirect_with_message( 'Лог недоступен — укажите путь в настройках.', 'error' );
		}
		if ( get_option( self::BACKFILL_OPTION ) === $path ) {
			LogShield_Admin::redirect_with_message( 'Графики по этому логу уже построены.', 'error' );
		}
		clearstatcache();
		$size  = (int) @filesize( $path );
		$state = get_option( LogShield_Detector::OFFSET_OPTION, [ 'path' => '', 'offset' => 0 ] );
		$end   = ( $state['path'] === $path ) ? min( (int) $state['offset'], $size ) : $size;
		$start = max( 0, $end - max( 1, (int) $opts['max_read_mb'] ) * 1024 * 1024 );
		$lines = self::read_range( $path, $start, $end - $start );

		$whitelist = LogShield_Whitelist::get_full_whitelist( (array) $opts['whitelist_ips'] );
		$result    = LogShield_Detector::analyze( $lines, $opts, $whitelist );
		LogShield_Stats::record( $result['hourly'], [] );
		update_option( self::BACKFILL_OPTION, $path, false );
		if ( $state['path'] !== $path ) {
			// Сканер ещё не запускался на этом логе: дальше он начнёт с конца файла.
			update_option( LogShield_Detector::OFFSET_OPTION, [ 'path' => $path, 'offset' => $end ], false );
		}
		LogShield_Admin::redirect_with_message( sprintf( 'Графики построены: %d строк, %d часов.', count( $lines ), count( $result['hourly'] ) ) );
	}

	/** IP как есть, CIDR — в каноническом виде; мусор — null. */
	private static function entry( $raw ) {
		$raw = trim( (string) $raw );
		if ( filter_var( $raw, FILTER_VALIDATE_IP ) ) return $raw;
		$c = LogShield_IP::parse_cidr( $raw );
		return $c ? $c['canonical'] : null;
	}

	/**
	 * Действия таблицы атакующих и панели адреса (admin-post):
	 * op = ban | unban | hide | whitelist, items[] — до BULK_MAX адресов (IP или CIDR),
	 * days — срок блокировки для ban: default или одно из BAN_DAYS.
	 * Блокировка применяется сразу и в тестовом режиме (как ручной бан);
	 * файл .htaccess пишется один раз на всё действие.
	 */
	public static function bulk() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Недостаточно прав', 403 );
		check_admin_referer( 'logshield_bulk' );
		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		if ( ! in_array( $op, [ 'ban', 'unban', 'hide', 'whitelist' ], true ) ) {
			LogShield_Admin::redirect_with_message( 'Неизвестное действие.', 'error' );
		}
		$raw = isset( $_POST['items'] ) ? wp_unslash( $_POST['items'] ) : [];
		if ( ! is_array( $raw ) ) $raw = [ $raw ];
		if ( count( $raw ) > self::BULK_MAX ) {
			LogShield_Admin::redirect_with_message( sprintf( 'Слишком много адресов за раз: %d. Можно не больше %d — выделите меньше.', count( $raw ), self::BULK_MAX ), 'error' );
		}
		$items = [];
		$bad   = 0;
		foreach ( $raw as $r ) {
			$c = is_string( $r ) ? self::entry( sanitize_text_field( $r ) ) : null;
			if ( $c === null ) { $bad++; continue; }
			$items[ $c ] = true;
		}
		$items    = array_keys( $items );
		$bad_note = $bad ? ' Отброшено неверных адресов: ' . $bad . '.' : '';
		if ( ! $items ) {
			LogShield_Admin::redirect_with_message( 'Не выбрано ни одного верного адреса.' . $bad_note, 'error' );
		}
		$opts = LogShield_Plugin::get_options();
		$list = function ( array $a ) { return LogShield_Admin::short_list( $a ); };

		if ( $op === 'ban' ) {
			$days = self::parse_days( isset( $_POST['days'] ) ? wp_unslash( $_POST['days'] ) : 'default', $opts['ban_expiry_days'] );
			if ( $days === null ) {
				LogShield_Admin::redirect_with_message( 'Неверный срок блокировки.', 'error' );
			}
			$whitelist = LogShield_Whitelist::get_full_whitelist( (array) $opts['whitelist_ips'] );
			$banned    = self::banned();
			$reasons   = [];
			foreach ( self::attackers() as $a ) $reasons[ $a['ip'] ] = $a['reason'];
			$skip = [];
			$have = [];
			$to   = [];
			foreach ( $items as $ip ) {
				foreach ( $whitelist as $w ) {
					if ( LogShield_IP::overlaps( $w, $ip ) ) { $skip[] = $w === $ip ? $ip : $ip . ' (' . $w . ')'; continue 2; }
				}
				if ( isset( $banned[ $ip ] ) ) { $have[] = $ip; continue; }
				$to[ $ip ] = isset( $reasons[ $ip ] ) && $reasons[ $ip ] !== '' ? $reasons[ $ip ] . ' (вручную)' : 'вручную с дашборда';
			}
			$notes = ( $skip ? ' Пропущены — пересекаются с белым списком: ' . $list( $skip ) . '.' : '' )
				. ( $have ? ' Уже заблокированы: ' . $list( $have ) . '.' : '' ) . $bad_note;
			if ( ! $to ) {
				LogShield_Admin::redirect_with_message( 'Никто не заблокирован.' . $notes, 'error' );
			}
			// Один вызов — одна запись .htaccess и один бэкап на всю группу.
			$ok = LogShield_Htaccess::ban_ips( $to, $days, true );
			if ( $ok ) LogShield_Detector::clear_write_error();
			$term = $days > 0 ? ' на ' . $days . ' ' . self::days_word( $days ) : ' бессрочно';
			LogShield_Admin::redirect_with_message(
				$ok
					? 'Заблокировано' . $term . ': ' . count( $to ) . ' (' . $list( array_keys( $to ) ) . ').' . $notes
					: 'Не удалось записать .htaccess: ' . LogShield_Htaccess::last_error() . '. Адреса (' . count( $to ) . ') остались в списке банов — запись повторится при следующем изменении списка.' . $notes,
				$ok && ! $skip ? 'success' : 'error'
			);
		}

		if ( $op === 'unban' ) {
			$removed = LogShield_Htaccess::unban_ips( $items );
			if ( $removed === false ) {
				LogShield_Admin::redirect_with_message( 'Не удалось записать .htaccess: ' . LogShield_Htaccess::last_error() . '. Блокировки не сняты.' . $bad_note, 'error' );
			}
			if ( ! $removed ) {
				LogShield_Admin::redirect_with_message( 'Среди выбранных нет заблокированных адресов (адрес внутри заблокированной подсети разблокируется вместе с подсетью).' . $bad_note, 'error' );
			}
			LogShield_Detector::clear_write_error();
			$rest = count( $items ) - count( $removed );
			LogShield_Admin::redirect_with_message( 'Разблокировано: ' . count( $removed ) . ' (' . $list( $removed ) . ').' . ( $rest > 0 ? ' Не были заблокированы: ' . $rest . '.' : '' ) . $bad_note );
		}

		if ( $op === 'hide' ) {
			$n = self::dismiss( $items );
			LogShield_Admin::redirect_with_message( 'Скрыто: ' . $n . '. Строка вернётся, если адрес поймают снова.' . $bad_note );
		}

		// whitelist: в ручной белый список, затем снять баны, которые он теперь задевает.
		$parsed = LogShield_Whitelist::parse_entries( implode( "\n", $items ) );
		$old    = array_values( (array) ( $opts['whitelist_ips'] ?? [] ) );
		$new    = array_values( array_diff( $parsed['valid'], $old ) );
		if ( $new ) {
			$opts['whitelist_ips'] = array_merge( $old, $new );
			update_option( LOGSHIELD_OPTION, $opts );
		}
		$released = LogShield_Whitelist::release_bans();
		LogShield_Admin::redirect_with_message(
			( $new ? 'В белый список добавлено: ' . $list( $new ) . '. Эти адреса больше не будут блокироваться.' : 'Адреса уже были в белом списке.' )
				. LogShield_Admin::released_note( $released ) . $bad_note,
			$released === false ? 'error' : 'success'
		);
	}

	/** «день», «дня», «дней». */
	private static function days_word( $n ) {
		$n10 = $n % 10;
		$n100 = $n % 100;
		if ( $n10 === 1 && $n100 !== 11 ) return 'день';
		if ( $n10 >= 2 && $n10 <= 4 && ( $n100 < 12 || $n100 > 14 ) ) return 'дня';
		return 'дней';
	}

	/**
	 * Последние запросы адреса для панели: до IP_REQUESTS_MAX строк из последних
	 * ip_requests_bytes() байт лога, новые сверху. Для диапазона — все адреса внутри.
	 */
	public static function ajax_ip_requests() {
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden', 403 );
		check_ajax_referer( 'logshield_ip_requests', 'nonce' );
		$ip = self::entry( isset( $_GET['ip'] ) ? sanitize_text_field( wp_unslash( $_GET['ip'] ) ) : '' );
		if ( $ip === null ) wp_send_json_error( 'Неверный адрес.' );
		$path = LogShield_Plugin::get_options()['log_path'];
		if ( $path === '' || ! @is_readable( $path ) || @is_dir( $path ) ) {
			wp_send_json_error( 'Лог недоступен — укажите путь в настройках.' );
		}
		clearstatcache();
		$size  = (int) @filesize( $path );
		$bytes = self::ip_requests_bytes();
		$start = max( 0, $size - $bytes );
		$lines = self::read_range( $path, $start, $size - $start );
		$range = strpos( $ip, '/' ) !== false;
		$bin   = $range ? false : @inet_pton( $ip );
		$out   = [];
		$more  = false;
		for ( $i = count( $lines ) - 1; $i >= 0; $i-- ) {
			// Быстрая отсечка для одиночного IPv4: адреса нет в строке — не разбираем.
			if ( ! $range && strpos( $ip, ':' ) === false && strpos( $lines[ $i ], $ip ) === false ) continue;
			$e = LogShield_Parser::parse_line( $lines[ $i ] );
			if ( ! $e ) continue;
			$hit = $range ? LogShield_IP::matches( $e['ip'], $ip ) : ( $e['ip'] === $ip || ( $bin !== false && @inet_pton( $e['ip'] ) === $bin ) );
			if ( ! $hit || LogShield_Whitelist::is_own_request( $e ) ) continue;
			if ( count( $out ) >= self::IP_REQUESTS_MAX ) { $more = true; break; }
			$out[] = [
				't'  => substr( $e['date'], 0, 20 ),
				'ip' => $e['ip'],
				'm'  => substr( $e['method'], 0, 10 ),
				'p'  => mb_substr( $e['path'], 0, 200 ),
				's'  => (int) $e['status'],
				'ua' => mb_substr( $e['user_agent'], 0, 140 ),
			];
		}
		wp_send_json_success( [
			'items' => $out,
			'more'  => $more,
			'whole' => $start === 0,
			'mb'    => round( ( $size - $start ) / 1048576, 1 ),
		] );
	}

	/** Хвост лога для дашборда. offset < 0 — последние строки; иначе новое с offset. */
	public static function ajax_tail() {
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'forbidden', 403 );
		check_ajax_referer( 'logshield_tail', 'nonce' );
		$path   = LogShield_Plugin::get_options()['log_path'];
		$offset = isset( $_GET['offset'] ) ? (int) $_GET['offset'] : -1;
		$size   = $path === '' ? false : @filesize( $path );
		// Частый случай живого режима: файл не вырос — ответ без проверок и чтения.
		if ( $size !== false && $offset >= 0 && $offset === (int) $size ) {
			wp_send_json_success( [ 'offset' => $offset, 'lines' => [], 'reset' => false ] );
		}
		if ( $path === '' || ! @is_readable( $path ) || @is_dir( $path ) ) {
			wp_send_json_error( 'Лог недоступен — укажите путь в настройках.' );
		}
		$size   = (int) $size;
		$reset  = false;
		if ( $offset < 0 || $offset > $size ) {
			// Первый запрос или лог ротировали — показываем хвост заново.
			$reset  = $offset > $size;
			$start  = max( 0, $size - self::TAIL_FIRST_BYTES );
			$lines  = self::read_range( $path, $start, $size - $start );
			$lines  = array_slice( $lines, -self::TAIL_LINES );
		} else {
			// Отстали слишком сильно — пропускаем середину.
			$start = max( $offset, $size - self::TAIL_MAX_BYTES );
			$lines = self::read_range( $path, $start, $size - $start, $start === $offset );
		}
		$out = [];
		foreach ( $lines as $line ) {
			$e = LogShield_Parser::parse_line( $line );
			if ( ! $e || LogShield_Whitelist::is_own_request( $e ) ) continue;
			$out[] = [
				't'  => substr( $e['date'], 12, 8 ),
				'd'  => substr( $e['date'], 0, 6 ),
				'ip' => $e['ip'],
				'm'  => substr( $e['method'], 0, 10 ),
				'p'  => mb_substr( $e['path'], 0, 200 ),
				's'  => $e['status'],
				'ua' => mb_substr( $e['user_agent'], 0, 140 ),
			];
		}
		wp_send_json_success( [ 'offset' => $size, 'lines' => $out, 'reset' => $reset ] );
	}

	/**
	 * Строки из куска файла [start, start+len). Если start не на границе
	 * строки, первая (обрезанная) строка отбрасывается; хвост без перевода
	 * строки — тоже (допишется к следующему опросу).
	 */
	private static function read_range( $path, $start, $len, $at_line_start = false ) {
		if ( $len <= 0 ) return [];
		$fp = @fopen( $path, 'rb' );
		if ( ! $fp ) return [];
		fseek( $fp, $start );
		$data = (string) fread( $fp, $len );
		fclose( $fp );
		$lines = explode( "\n", $data );
		if ( $start > 0 && ! $at_line_start ) array_shift( $lines );
		array_pop( $lines ); // после последнего \n — пусто или неполная строка
		return array_values( array_filter( array_map( 'rtrim', $lines ), 'strlen' ) );
	}
}

// Индекс кружка в меню обновляется при каждой записи истории сканирований
// (в том числе из WP-Cron), поэтому хуки ставятся при подключении файла.
LogShield_Dashboard::init();
