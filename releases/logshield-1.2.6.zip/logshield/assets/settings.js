// Страница настроек LogShield, без inline-обработчиков:
// - подтверждение опасных действий (<form data-confirm="…">) и выключения тестового режима
//   в нативном <dialog> (без поддержки <dialog> — window.confirm);
// - подсказка о несохранённых изменениях и предупреждение при уходе со страницы;
// - предпросмотр «кого поймали бы эти пороги» (admin-ajax logshield_preview);
// - выделение адреса проверки доступности при фокусе, кнопки «вставить список»
//   (<button data-fill-target="id поля" data-fill-lines="строки">), подсветка раздела в оглавлении.
(() => {
	'use strict';
	const $ = (s, r = document) => r.querySelector(s);
	const $$ = (s, r = document) => [...r.querySelectorAll(s)];
	const mainForm = $('#ls-settings-form');

	document.addEventListener('focusin', (e) => {
		if (e.target.matches('input[data-select-on-focus]')) e.target.select();
	});

	// ---- «Вставить список»: кнопки работают только со скриптом — он их и показывает ----
	for (const b of $$('button[data-fill-target]')) b.hidden = false;
	document.addEventListener('click', (e) => {
		const b = e.target.closest('button[data-fill-target]');
		if (!b) return;
		const field = document.getElementById(b.dataset.fillTarget);
		if (!field) return;
		// Дописываем только недостающие строки, уже введённое не трогаем.
		const have = field.value.split(/[\r\n,]+/).map((s) => s.trim()).filter(Boolean);
		const add = b.dataset.fillLines.split('\n').filter((s) => s && !have.includes(s));
		if (add.length) {
			field.value = have.concat(add).join('\n');
			field.dispatchEvent(new Event('input', { bubbles: true })); // форма помечается изменённой
		}
		field.focus();
	});

	// ---- Подтверждение в <dialog> ----
	const hasDialog = typeof HTMLDialogElement === 'function' && 'showModal' in HTMLDialogElement.prototype;
	// Закрытие щелчком по фону: closedby="any"; где атрибута нет — по координатам
	// (нажатие и отпускание снаружи, чтобы выделение текста мышью не закрывало диалог).
	if (hasDialog && !('closedBy' in HTMLDialogElement.prototype)) {
		for (const d of $$('dialog[closedby="any"]')) {
			const outside = (e) => {
				const r = d.getBoundingClientRect();
				return e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom;
			};
			let pressedOutside = false;
			d.addEventListener('pointerdown', (e) => { pressedOutside = outside(e); });
			d.addEventListener('pointerup', (e) => { if (pressedOutside && outside(e)) d.close(); });
		}
	}

	/** Спрашивает в диалоге; ok() — только если нажали кнопку value="ok". */
	function ask(dialog, text, ok) {
		if (!hasDialog || !dialog) {
			if (window.confirm(text)) ok();
			return;
		}
		dialog.returnValue = '';
		dialog.addEventListener('close', () => {
			const v = dialog.returnValue;
			dialog.returnValue = ''; // Esc и щелчок по фону значения не ставят — не оставляем старое
			if (v === 'ok') ok();
		}, { once: true });
		dialog.showModal();
	}

	const generic = $('#ls-confirm');
	const dryBox = mainForm && mainForm.querySelector('input[data-dry-run]');
	const dryDialog = $('#ls-dry-confirm');

	document.addEventListener('submit', (e) => {
		const f = e.target;
		if (!(f instanceof HTMLFormElement)) return;
		if (f.dataset.lsConfirmed) { delete f.dataset.lsConfirmed; return; } // уже подтвердили
		let dialog;
		let text;
		// Тестовый режим был включён (defaultChecked — состояние при загрузке), а флажок сняли.
		if (f === mainForm && dryBox && dryBox.defaultChecked && !dryBox.checked) {
			dialog = dryDialog;
			text = dryDialog ? dryDialog.dataset.fallback : 'Выключить тестовый режим?';
		} else if (f.dataset.confirm) {
			dialog = generic;
			text = f.dataset.confirm;
			if (generic) $('[data-confirm-text]', generic).textContent = text;
		} else {
			return;
		}
		e.preventDefault();
		const submitter = e.submitter && e.submitter.form === f ? e.submitter : null;
		ask(dialog, text, () => {
			f.dataset.lsConfirmed = '1';
			if (submitter) f.requestSubmit(submitter); else f.requestSubmit();
		});
	});

	if (!mainForm) return;

	// ---- Несохранённые изменения ----
	// Этот обработчик submit зарегистрирован после подтверждения: отменённая отправка флаг не снимает.
	const hint = $('[data-dirty-hint]', mainForm);
	let dirty = false;
	const onBeforeUnload = (e) => { e.preventDefault(); e.returnValue = ''; };
	function setDirty(v) {
		if (dirty === v) return;
		dirty = v;
		mainForm.toggleAttribute('data-dirty', v);
		if (hint) hint.textContent = v ? 'Есть несохранённые изменения' : '';
		// Слушатель только пока есть что терять: иначе страница не попадает в кэш «назад/вперёд».
		if (v) window.addEventListener('beforeunload', onBeforeUnload);
		else window.removeEventListener('beforeunload', onBeforeUnload);
	}
	mainForm.addEventListener('input', () => setDirty(true));
	mainForm.addEventListener('change', () => setDirty(true));
	document.addEventListener('submit', (e) => {
		if (e.target === mainForm && !e.defaultPrevented) setDirty(false);
	});

	// ---- Оглавление: какой раздел сейчас на экране (aria-current) ----
	const tocLinks = $$('.ls-toc a[href^="#"]');
	if (tocLinks.length && 'IntersectionObserver' in window) {
		const byId = new Map(tocLinks.map((a) => [a.hash.slice(1), a]));
		const io = new IntersectionObserver((entries) => {
			for (const en of entries) {
				if (!en.isIntersecting) continue;
				for (const a of tocLinks) a.setAttribute('aria-current', String(a === byId.get(en.target.id)));
			}
		}, { rootMargin: '-45% 0px -50% 0px' });
		for (const id of byId.keys()) {
			const s = document.getElementById(id);
			if (s) io.observe(s);
		}
	}

	// ---- Предпросмотр правил ----
	const box = $('[data-preview]');
	if (!box || !window.fetch || !window.AbortController) return;
	box.hidden = false;
	const rules = box.closest('.ls-sec');
	const runBtn = $('[data-preview-run]', box);
	const status = $('[data-preview-status]', box);
	const list = $('[data-preview-list]', box);
	const fields = $$('input[name]', rules);
	let ctrl = null;
	let timer = 0;

	const plural = (n, one, few, many) => {
		const n10 = n % 10, n100 = n % 100;
		return n10 === 1 && n100 !== 11 ? one : n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14) ? few : many;
	};
	const addr = (n) => `${n} ${plural(n, 'адрес', 'адреса', 'адресов')}`;
	const el = (tag, cls, text) => {
		const x = document.createElement(tag);
		if (cls) x.className = cls;
		if (text !== undefined) x.textContent = text;
		return x;
	};

	function showError(msg) {
		status.classList.remove('ls-loading');
		status.classList.add('ls-err');
		status.textContent = msg;
		list.replaceChildren();
	}

	function render(d) {
		status.classList.remove('ls-loading', 'ls-err');
		const span = d.from && d.to ? ` (${d.from} — ${d.to}${d.whole ? '' : `, последние ${d.mb} МБ`})` : '';
		let text = `Прочитано строк: ${d.lines}${span}. `;
		text += d.changed
			? `Сейчас поймано: ${d.current} → с новыми порогами: ${d.flagged}.`
			: `С сохранёнными порогами поймано: ${addr(d.flagged)}.`;
		if (d.changed && d.lost) text += ` Перестанут попадаться: ${addr(d.lost)}.`;
		if (d.unparsed) text += ` Не разобрано строк: ${d.unparsed}.`;
		status.textContent = text;
		if (!d.items.length) {
			list.replaceChildren();
			return;
		}
		const ul = el('ul', 'ls-pv-list');
		for (const it of d.items) {
			const li = el('li');
			li.append(el('code', '', it.ip));
			if (it.types.length) li.append(el('span', 'ls-pv-types', it.types.join(', ')));
			if (d.changed && it.new) li.append(el('span', 'ls-pv-tag ls-pv-new', 'только с новыми порогами'));
			if (it.banned) li.append(el('span', 'ls-pv-tag ls-pv-banned', 'уже заблокирован'));
			if (it.reason) li.append(el('span', 'ls-pv-reason', it.reason));
			ul.append(li);
		}
		const out = [ul];
		if (d.more) out.push(el('p', 'ls-field-desc', `…и ещё ${addr(d.more)}.`));
		list.replaceChildren(...out);
	}

	async function run() {
		clearTimeout(timer);
		if (ctrl) ctrl.abort(); // одновременно — только один запрос
		const mine = ctrl = new AbortController();
		const body = new FormData();
		body.append('action', 'logshield_preview');
		body.append('nonce', box.dataset.nonce);
		for (const f of fields) body.append(f.name, f.value);
		status.classList.remove('ls-err');
		status.classList.add('ls-loading');
		status.textContent = 'Проверяю на последних данных лога…';
		runBtn.setAttribute('aria-busy', 'true');
		try {
			const r = await fetch(box.dataset.url, { method: 'POST', body, credentials: 'same-origin', signal: mine.signal });
			const j = await r.json().catch(() => null);
			if (mine !== ctrl) return;
			if (!j) showError(`Не удалось проверить: сервер ответил ${r.status}.`);
			else if (!j.success) showError(typeof j.data === 'string' ? j.data : 'Не удалось проверить.');
			else render(j.data);
		} catch (err) {
			if (err.name !== 'AbortError' && mine === ctrl) showError('Не удалось проверить: нет связи с сервером.');
		} finally {
			if (mine === ctrl) {
				ctrl = null;
				runBtn.removeAttribute('aria-busy');
			}
		}
	}

	runBtn.addEventListener('click', run);
	// Автопроверка через 800 мс после изменения порогов, если значения допустимы.
	rules.addEventListener('input', (e) => {
		if (!e.target.matches('input[name]')) return;
		clearTimeout(timer);
		if (fields.every((f) => f.checkValidity())) timer = setTimeout(run, 800);
	});
})();
