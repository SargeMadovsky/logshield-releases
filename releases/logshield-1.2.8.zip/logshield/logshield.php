<?php
/**
 * Plugin Name: LogShield
 * Description: Периодический анализ access_log, обнаружение атакующих IP и автоматическая блокировка через .htaccess. Работает не в реальном времени, а по расписанию (раз в 2–4 часа), чтобы не нагружать сервер.
 * Version: 1.2.8
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: LogShield
 * License: GPL v2 or later
 * Text Domain: logshield
 * Domain Path: /languages
 * Update URI: https://github.com/SargeMadovsky/logshield-releases
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LOGSHIELD_VERSION', '1.2.8' );
define( 'LOGSHIELD_FILE', __FILE__ );
define( 'LOGSHIELD_DIR', plugin_dir_path( __FILE__ ) );
define( 'LOGSHIELD_URL', plugin_dir_url( __FILE__ ) );
define( 'LOGSHIELD_OPTION', 'logshield_options' );
define( 'LOGSHIELD_CRON_HOOK', 'logshield_scan_event' );
define( 'LOGSHIELD_CLEANUP_HOOK', 'logshield_cleanup_event' );

require_once LOGSHIELD_DIR . 'includes/class-logshield-ip.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-parser.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-logfinder.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-whitelist.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-ping.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-htaccess.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-stats.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-mmdb.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-ipinfo.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-detector.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-notifier.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-admin.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-dashboard.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-api.php';
require_once LOGSHIELD_DIR . 'includes/class-logshield-updater.php';

// REST-эндпоинт статистики для внешней сводной панели и страница выпуска токена.
LogShield_API::init();

// Обновления из публичного репозитория сборок на GitHub (не с wordpress.org).
LogShield_Updater::init();

class LogShield_Plugin {

	public static function default_options() {
		return [
			'log_path'                => '',
			'interval'                 => 'logshield_3h',
			'dry_run'                  => true,
			// Запросов с одного IP за любые 60 с по времени строк лога; 0 — правило выключено.
			'rate_per_min'             => 40,
			'brute_attempts'           => 10,
			'scan_unique_paths'        => 15,
			'scan_min_requests'        => 20,
			'error_rate_pct'           => 50,
			'error_rate_min_requests'  => 20,
			'sensitive_min_hits'       => 3,
			'enum_min_hits'            => 3,
			'subnet_min_ips'           => 5,
			'subnet_min_attempts'      => 30,
			'max_read_mb'              => 5,
			'ban_expiry_days'          => 7,
			'whitelist_ips'            => [],
			// IP/CIDR прокси (Cloudflare и т. п.), от которых принимаются заголовки адреса клиента.
			'trusted_proxies'          => [],
			'notify_email'             => '',
			'telegram_token'           => '',
			'telegram_chat_id'         => '',
			'ipinfo_enabled'           => true,
		];
	}

	public static function get_options() {
		$opts = get_option( LOGSHIELD_OPTION, [] );
		return wp_parse_args( $opts, self::default_options() );
	}

	public static function activate() {
		$opts = self::get_options();
		if ( $opts['log_path'] === '' ) {
			$opts['log_path'] = (string) LogShield_LogFinder::best_confident();
		}
		update_option( LOGSHIELD_OPTION, $opts );

		// Защита от блокировки самого себя: сразу добавляем IP текущего администратора.
		$ip = LogShield_Whitelist::get_client_ip();
		if ( $ip ) {
			LogShield_Whitelist::add_admin_ip( $ip, false, wp_get_current_user()->user_login );
		}

		if ( ! wp_next_scheduled( LOGSHIELD_CRON_HOOK ) ) {
			wp_schedule_event( time() + 300, $opts['interval'], LOGSHIELD_CRON_HOOK );
		}
		if ( ! wp_next_scheduled( LOGSHIELD_CLEANUP_HOOK ) ) {
			wp_schedule_event( time() + 60, 'daily', LOGSHIELD_CLEANUP_HOOK );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( LOGSHIELD_CRON_HOOK );
		wp_clear_scheduled_hook( LOGSHIELD_CLEANUP_HOOK );
		wp_clear_scheduled_hook( LOGSHIELD_CLEANUP_HOOK, [ 'geo' ] );
		wp_clear_scheduled_hook( LogShield_Notifier::RETRY_HOOK );
		wp_clear_scheduled_hook( LogShield_Updater::FETCH_HOOK );
	}

	public static function cron_schedules( $schedules ) {
		// Фильтр cron_schedules может сработать раньше init (WP-Cron, другие плагины),
		// а до загрузки текстового домена переводить нельзя: WordPress 6.7+ выдаёт
		// уведомление _load_textdomain_just_in_time. Тогда подписи остаются исходными.
		$tr = did_action( 'init' );
		$schedules['logshield_2h'] = [ 'interval' => 2 * HOUR_IN_SECONDS, 'display' => $tr ? __( 'Каждые 2 часа (LogShield)', 'logshield' ) : 'Каждые 2 часа (LogShield)' ];
		$schedules['logshield_3h'] = [ 'interval' => 3 * HOUR_IN_SECONDS, 'display' => $tr ? __( 'Каждые 3 часа (LogShield)', 'logshield' ) : 'Каждые 3 часа (LogShield)' ];
		$schedules['logshield_4h'] = [ 'interval' => 4 * HOUR_IN_SECONDS, 'display' => $tr ? __( 'Каждые 4 часа (LogShield)', 'logshield' ) : 'Каждые 4 часа (LogShield)' ];
		return $schedules;
	}

	/**
	 * Переводы плагина: languages/logshield-<локаль>.mo. Подключается на init
	 * с приоритетом 0: раньше переводить строки нельзя (см. cron_schedules()).
	 */
	public static function load_textdomain() {
		load_plugin_textdomain( 'logshield', false, dirname( plugin_basename( LOGSHIELD_FILE ) ) . '/languages' );
	}

	/**
	 * Переведённая строка с простой разметкой (<code>, <strong>, ссылки, <time>):
	 * переводчик может переставить слова вокруг тегов, а лишнее вырезается.
	 */
	public static function kses( $html ) {
		return wp_kses( $html, [
			'code'   => [],
			'strong' => [],
			'b'      => [],
			'em'     => [],
			'br'     => [],
			'span'   => [ 'class' => true ],
			'a'      => [ 'href' => true, 'target' => true, 'rel' => true ],
			'time'   => [ 'datetime' => true, 'title' => true ],
		] );
	}

	/**
	 * Русское множественное число, которое можно перевести.
	 *
	 * Без .mo функция _n() выбирает форму по английскому правилу (1 / не 1),
	 * и «2 адреса» превратилось бы в «2 адресов». Поэтому $nooped — это
	 * _n_noop( 'форма для 1', 'форма для 5', 'logshield' ), $few — форма для 2–4.
	 * Если перевод нашёлся (строка отличается от обеих исходных), возвращается он,
	 * иначе форма выбирается по русскому правилу 1 / 2–4 / 5+.
	 */
	public static function plural( $n, $nooped, $few ) {
		$n          = (int) $n;
		$translated = translate_nooped_plural( $nooped, $n, 'logshield' );
		if ( $translated !== $nooped['singular'] && $translated !== $nooped['plural'] ) return $translated;
		$m10  = abs( $n ) % 10;
		$m100 = abs( $n ) % 100;
		if ( $m10 === 1 && $m100 !== 11 ) return $nooped['singular'];
		if ( $m10 >= 2 && $m10 <= 4 && ( $m100 < 12 || $m100 > 14 ) ) return $few;
		return $nooped['plural'];
	}

	/**
	 * Формы множественного числа для скриптов (assets/*.js, функция plural()).
	 * native — перевода нет, скрипт выбирает из forms (1 / 2–4 / 5+) по русскому правилу;
	 * иначе forms — переводы для 1, 2 и 5, а форму скрипт выбирает через Intl.PluralRules
	 * по языку страницы. В формах «%d» заменяется числом.
	 */
	public static function js_plural( $nooped, $few ) {
		$one  = translate_nooped_plural( $nooped, 1, 'logshield' );
		$many = translate_nooped_plural( $nooped, 5, 'logshield' );
		if ( $one === $nooped['singular'] && $many === $nooped['plural'] ) {
			return [ 'native' => true, 'forms' => [ $nooped['singular'], $few, $nooped['plural'] ] ];
		}
		return [ 'native' => false, 'forms' => [ $one, translate_nooped_plural( $nooped, 2, 'logshield' ), $many ] ];
	}

	/**
	 * Период расписания словами для шапки дашборда: «3 ч», «90 мин».
	 * Берётся из wp_get_schedules(); если расписание не зарегистрировано —
	 * по имени (logshield_3h) или 3 ч по умолчанию.
	 */
	public static function interval_label( $interval ) {
		$schedules = function_exists( 'wp_get_schedules' ) ? wp_get_schedules() : [];
		$sec       = (int) ( $schedules[ $interval ]['interval'] ?? 0 );
		if ( $sec <= 0 && preg_match( '/(\d+)h$/', (string) $interval, $m ) ) $sec = (int) $m[1] * HOUR_IN_SECONDS;
		if ( $sec <= 0 ) $sec = 3 * HOUR_IN_SECONDS;
		if ( $sec % HOUR_IN_SECONDS === 0 ) {
			/* translators: %d: число часов между сканированиями. */
			return sprintf( __( '%d ч', 'logshield' ), $sec / HOUR_IN_SECONDS );
		}
		/* translators: %d: число минут между сканированиями. */
		return sprintf( __( '%d мин', 'logshield' ), max( 1, (int) round( $sec / MINUTE_IN_SECONDS ) ) );
	}

	public static function reschedule( $new_interval ) {
		wp_clear_scheduled_hook( LOGSHIELD_CRON_HOOK );
		wp_schedule_event( time() + 60, $new_interval, LOGSHIELD_CRON_HOOK );
	}

	public static function run_scan() {
		LogShield_Detector::run();
	}

	public static function run_cleanup() {
		LogShield_Htaccess::cleanup_expired();
		// Страховка: баны, которые задевают белый список. Забаненный сотрудник
		// получает 403 и не может войти, чтобы его адрес сняли по входу.
		LogShield_Whitelist::release_bans();
		if ( LogShield_IPInfo::enabled() ) LogShield_IPInfo::update();
	}
}

register_activation_hook( __FILE__, [ 'LogShield_Plugin', 'activate' ] );
register_deactivation_hook( __FILE__, [ 'LogShield_Plugin', 'deactivate' ] );

add_action( 'init', [ 'LogShield_Plugin', 'load_textdomain' ], 0 );
add_filter( 'cron_schedules', [ 'LogShield_Plugin', 'cron_schedules' ] );
add_action( LOGSHIELD_CRON_HOOK, [ 'LogShield_Plugin', 'run_scan' ] );
add_action( LOGSHIELD_CLEANUP_HOOK, [ 'LogShield_Plugin', 'run_cleanup' ] );
add_action( LogShield_Notifier::RETRY_HOOK, [ 'LogShield_Notifier', 'retry_queue' ] );

// Авто-whitelist: IP сотрудников при входе и при работе по cookie, IP самого сервера.
add_action( 'wp_login', [ 'LogShield_Whitelist', 'on_login' ], 10, 2 );
add_action( 'init', [ 'LogShield_Whitelist', 'on_init' ] );
// Адрес проверки доступности: отвечаем, когда WordPress загружен полностью.
add_action( 'wp_loaded', [ 'LogShield_Ping', 'maybe_respond' ], PHP_INT_MAX );

// Админка.
add_action( 'admin_menu', [ 'LogShield_Admin', 'add_menu' ] );
add_action( 'admin_post_logshield_save_settings', [ 'LogShield_Admin', 'save_settings' ] );
add_action( 'admin_post_logshield_run_now', [ 'LogShield_Admin', 'run_now' ] );
add_action( 'admin_post_logshield_unban', [ 'LogShield_Admin', 'unban_ip' ] );
add_action( 'admin_post_logshield_unban_all', [ 'LogShield_Admin', 'unban_all' ] );
add_action( 'admin_post_logshield_add_my_ip', [ 'LogShield_Admin', 'add_my_ip' ] );
add_action( 'admin_post_logshield_telegram_test', [ 'LogShield_Admin', 'telegram_test' ] );
add_action( 'admin_post_logshield_detect_log', [ 'LogShield_Admin', 'detect_log' ] );
add_action( 'admin_post_logshield_use_log', [ 'LogShield_Admin', 'use_log' ] );
add_action( 'admin_post_logshield_geo_update', [ 'LogShield_Admin', 'geo_update' ] );
add_action( 'admin_post_logshield_ping_rotate', [ 'LogShield_Admin', 'ping_rotate' ] );
add_action( 'admin_post_logshield_ban', [ 'LogShield_Dashboard', 'ban' ] );
add_action( 'admin_post_logshield_backfill', [ 'LogShield_Dashboard', 'backfill' ] );
add_action( 'admin_post_logshield_protect', [ 'LogShield_Dashboard', 'protect' ] );
add_action( 'wp_ajax_logshield_tail', [ 'LogShield_Dashboard', 'ajax_tail' ] );
add_action( 'admin_init', [ 'LogShield_Admin', 'legacy_redirect' ] );
add_action( 'admin_notices', [ 'LogShield_Admin', 'notices' ] );
// Сообщение после действия показывается один раз: WordPress убирает эти
// параметры из адресной строки (history.replaceState), и при обновлении
// страницы или из закладки его уже нет.
add_filter( 'removable_query_args', [ 'LogShield_Admin', 'removable_query_args' ] );
