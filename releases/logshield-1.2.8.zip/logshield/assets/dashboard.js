/* LogShield — дашборд. Без библиотек: графики рисуются в SVG. */
(() => {
	'use strict';
	const SVG = 'http://www.w3.org/2000/svg';
	const HOUR = 3600;
	const nf = new Intl.NumberFormat('ru-RU');
	const pad = (n) => String(n).padStart(2, '0');
	// Тексты на языке сайта (LogShield_Dashboard::js_l10n()); нет перевода — ключ как есть.
	const L10N = window.LogShieldL10n || {};
	const _t = (k) => (typeof L10N[k] === 'string' ? L10N[k] : k);
	const _f = (k, ...a) => {
		let i = 0;
		return _t(k).replace(/%(?:(\d+)\$)?[sd]/g, (m, p) => String(p ? a[p - 1] : a[i++]));
	};
	// Множественное число: формы для 1 / 2–4 / 5+ (см. LogShield_Plugin::js_plural()).
	const ruForm = (n) => {
		const n10 = n % 10, n100 = n % 100;
		return n10 === 1 && n100 !== 11 ? 0 : n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14) ? 1 : 2;
	};
	const _n = (n, key) => {
		const p = L10N[key];
		if (!p || !p.forms) return String(n);
		let i = ruForm(n);
		if (!p.native) {
			try {
				const c = new Intl.PluralRules(document.documentElement.lang || undefined).select(n);
				i = c === 'one' ? 0 : c === 'few' ? 1 : 2;
			} catch { /* язык не распознан — русское правило */ }
		}
		return p.forms[i].replace('%d', String(n));
	};
	let uid = 0; // уникальные id градиентов, если источников на странице несколько

	/**
	 * Дашборд одного источника. root — контейнер с [data-metric], [data-chart], [data-types];
	 * D — { now, stats, types, banned }. Возвращает { render(hours) }.
	 */
	function mount(root, D) {
		// Строки статистики: [час (unix), запросы, 4xx, 5xx, неудачные входы, IP, {тип: число}]
		const byHour = new Map(D.stats.map((r) => [r[0], r]));
		const inst = ++uid;

		/** Корзины для периода: 24 ч → по часу, 7 дней → по 6 ч, 30 дней → по суткам (по местному времени). */
		function buckets(hours) {
			const step = hours <= 24 ? 1 : hours <= 168 ? 6 : 24;
			const end = new Date(D.now * 1000);
			end.setMinutes(0, 0, 0);
			end.setHours(Math.floor(end.getHours() / step) * step);
			const list = [];
			const count = Math.ceil(hours / step);
			for (let i = count - 1; i >= 0; i--) {
				const start = new Date(end);
				start.setHours(end.getHours() - i * step);
				list.push({ start, step, req: 0, err: 0, fails: 0, ips: 0, flag: {}, scans: 0, found: 0, errors: 0, bans: 0 });
			}
			// События (сканирования и баны) раскладываем по тем же корзинам.
			const at = (t) => list.findIndex((b) => t >= b.start / 1000 && t < b.start / 1000 + b.step * HOUR);
			for (const [t, ok, n] of D.events?.scans || []) {
				const b = list[at(t)];
				if (!b) continue;
				b.scans++;
				b.found += n;
				if (!ok) b.errors++;
			}
			for (const t of D.events?.bans || []) {
				const b = list[at(t)];
				if (b) b.bans++;
			}
			for (const b of list) {
				const from = b.start.getTime() / 1000;
				for (let h = from; h < from + b.step * HOUR; h += HOUR) {
					const r = byHour.get(h);
					if (!r) continue;
					b.req += r[1];
					b.err += r[2] + r[3];
					b.fails += r[4];
					b.ips = Math.max(b.ips, r[5]);
					for (const [t, n] of Object.entries(r[6] || {})) b.flag[t] = (b.flag[t] || 0) + n;
				}
			}
			return list;
		}

		function label(b, short) {
			const d = b.start;
			if (b.step === 1) return `${pad(d.getHours())}:00`;
			if (b.step === 24 || short) return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}`;
			return `${pad(d.getDate())}.${pad(d.getMonth() + 1)} ${pad(d.getHours())}:00`;
		}

		function el(name, attrs = {}, parent) {
			const node = document.createElementNS(SVG, name);
			for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
			if (parent) parent.append(node);
			return node;
		}

		/** «Красивый» максимум оси: 1, 2, 5 × 10^n. */
		function niceMax(v) {
			if (v <= 0) return 1;
			const p = 10 ** Math.floor(Math.log10(v));
			return [1, 2, 5, 10].map((m) => m * p).find((m) => m >= v);
		}

		/**
		 * Рисует график. series: [{ key, color, kind: 'area' | 'line' | 'bar' }].
		 * Подсказка показывает значения корзины под курсором.
		 */
		function chart(box, list, series, describe) {
			box.textContent = '';
			const H = box.dataset.chart === 'fails' ? 180 : 220;
			const L = 44, R = 8, T = 22, B = 22; // сверху — полоса для отметок событий
			const svg = el('svg', { role: 'img' }, box);
			// viewBox по реальной ширине: единица SVG = пиксель, подписи и столбцы
			// не растягиваются на широком экране. Перерисовка при смене ширины — ниже.
			const W = Math.round(svg.getBoundingClientRect().width) || 800;
			svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
			const max = niceMax(Math.max(0, ...list.flatMap((b) => series.map((s) => b[s.key]))));
			const x = (i) => L + (list.length === 1 ? 0 : (i / (list.length - 1)) * (W - L - R));
			const y = (v) => T + (1 - v / max) * (H - T - B);
			const slot = (W - L - R) / list.length;

			for (let k = 0; k <= 4; k++) {
				const v = (max / 4) * k;
				el('line', { class: 'ls-grid-line', x1: L, x2: W - R, y1: y(v), y2: y(v) }, svg);
				el('text', { class: 'ls-axis', x: L - 6, y: y(v) + 3, 'text-anchor': 'end' }, svg).textContent = v >= 1000 ? `${+(v / 1000).toFixed(1)}k` : +v.toFixed(1);
			}
			const every = Math.ceil(list.length / Math.max(2, Math.floor((W - L - R) / 80)));
			list.forEach((b, i) => {
				if (i % every) return;
				const cx = series.some((s) => s.kind === 'bar') ? L + slot * (i + 0.5) : x(i);
				el('text', { class: 'ls-axis', x: cx, y: H - 6, 'text-anchor': 'middle' }, svg).textContent = label(b, true);
			});

			const total = list.reduce((s, b) => s + series.reduce((a, se) => a + b[se.key], 0), 0);
			if (!total) {
				el('text', { class: 'ls-nodata', x: (W + L) / 2, y: H / 2, 'text-anchor': 'middle' }, svg).textContent = _t('noData');
			}

			for (const s of series) {
				if (s.kind === 'bar') {
					list.forEach((b, i) => {
						if (!b[s.key]) return;
						const w = Math.max(2, slot * 0.7);
						el('rect', { x: L + slot * i + (slot - w) / 2, y: y(b[s.key]), width: w, height: y(0) - y(b[s.key]), rx: 2 }, svg).style.fill = s.color;
					});
					continue;
				}
				const pts = list.map((b, i) => `${x(i)},${y(b[s.key])}`).join(' ');
				if (s.kind === 'area') {
					const grad = `ls-g${inst}-${box.dataset.chart}-${s.key}`;
					const defs = el('defs', {}, svg);
					const lg = el('linearGradient', { id: grad, x1: 0, x2: 0, y1: 0, y2: 1 }, defs);
					el('stop', { offset: '0%', 'stop-opacity': 0.35 }, lg).style.stopColor = s.color;
					el('stop', { offset: '100%', 'stop-opacity': 0 }, lg).style.stopColor = s.color;
					el('polygon', { points: `${x(0)},${y(0)} ${pts} ${x(list.length - 1)},${y(0)}`, fill: `url(#${grad})` }, svg);
				}
				el('polyline', { points: pts, fill: 'none', 'stroke-width': 2, 'vector-effect': 'non-scaling-stroke', 'stroke-linejoin': 'round' }, svg).style.stroke = s.color;
			}
			const bar = series.some((s) => s.kind === 'bar');
			const cxOf = (i) => (bar ? L + slot * (i + 0.5) : x(i));

			// Отметки событий над графиком: форма и цвет говорят об одном и том же,
			// подробности — в подсказке и в таблице данных.
			list.forEach((b, i) => {
				const cx = cxOf(i);
				const both = b.scans && b.bans;
				if (b.scans) {
					const sx = both ? cx - 6 : cx;
					if (b.errors) el('path', { class: 'ls-mk-err', d: `M${sx - 5} 13h10L${sx} 4z` }, svg);
					else if (b.found) el('path', { class: 'ls-mk-hit', d: `M${sx - 5} 4h10L${sx} 13z` }, svg);
					else el('circle', { class: 'ls-mk-scan', cx: sx, cy: 9, r: 3 }, svg);
				}
				if (b.bans) el('rect', { class: 'ls-mk-ban', x: (both ? cx + 6 : cx) - 4, y: 5, width: 8, height: 8, rx: 1 }, svg);
				if (b.found || b.bans) el('line', { class: 'ls-mk-guide', x1: cx, x2: cx, y1: 15, y2: H - B }, svg);
			});

			// Подсказка: мышь, касание и клавиатура (стрелки, Home/End).
			svg.setAttribute('role', 'group');
			svg.setAttribute('aria-roledescription', _t('chartRole'));
			svg.setAttribute('aria-label', _f('chartLabel', describe));
			svg.setAttribute('tabindex', '0');
			const cursor = el('line', { class: 'ls-cursor', y1: T, y2: H - B, visibility: 'hidden' }, svg);
			const tip = document.createElement('div');
			tip.className = 'ls-tip';
			tip.hidden = true;
			box.append(tip);
			// Для скринридера — только при переходах с клавиатуры, мышь не озвучиваем.
			const live = document.createElement('div');
			live.className = 'screen-reader-text';
			live.setAttribute('role', 'status');
			box.append(live);
			let cur = -1;

			const describeBucket = (b) => {
				const parts = [label(b), ...series.map((s) => `${s.name}: ${nf.format(b[s.key])}`)];
				if (b.scans) parts.push(_f('tipScans', b.scans) + (b.found ? _f('tipFound', nf.format(b.found)) : '') + (b.errors ? _f('tipErrors', b.errors) : ''));
				if (b.bans) parts.push(_f('tipBans', b.bans));
				return parts.join(' · ');
			};
			function show(i, announce) {
				cur = Math.min(list.length - 1, Math.max(0, i));
				const cx = cxOf(cur);
				cursor.setAttribute('x1', cx);
				cursor.setAttribute('x2', cx);
				cursor.setAttribute('visibility', 'visible');
				tip.textContent = describeBucket(list[cur]);
				tip.hidden = false;
				// Подсказка не вылезает за края карточки.
				// У SVG нет offsetLeft/offsetTop: считаем от рамки карточки.
				const sr = svg.getBoundingClientRect(), br = box.getBoundingClientRect();
				const bw = box.clientWidth, tw = tip.offsetWidth;
				const px = sr.left - br.left + (cx / W) * sr.width;
				tip.style.left = `${Math.min(bw - tw / 2 - 4, Math.max(tw / 2 + 4, px))}px`;
				tip.style.top = `${sr.top - br.top + (T / H) * sr.height}px`;
				if (announce) live.textContent = tip.textContent;
			}
			function hide() {
				tip.hidden = true;
				cursor.setAttribute('visibility', 'hidden');
			}
			const indexAt = (clientX) => {
				const rect = svg.getBoundingClientRect();
				const px = ((clientX - rect.left) / rect.width) * W;
				return bar ? Math.floor((px - L) / slot) : Math.round(((px - L) / (W - L - R)) * (list.length - 1));
			};
			svg.addEventListener('pointermove', (e) => show(indexAt(e.clientX), false));
			svg.addEventListener('pointerdown', (e) => show(indexAt(e.clientX), false));
			// После касания подсказка остаётся, пока не коснутся другого места.
			svg.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse' && document.activeElement !== svg) hide(); });
			svg.addEventListener('focus', () => show(cur < 0 ? list.length - 1 : cur, true));
			svg.addEventListener('blur', hide);
			svg.addEventListener('keydown', (e) => {
				const step = { ArrowLeft: -1, ArrowRight: 1, PageUp: -6, PageDown: 6 }[e.key];
				if (step) show(cur + step, true);
				else if (e.key === 'Home') show(0, true);
				else if (e.key === 'End') show(list.length - 1, true);
				else if (e.key === 'Escape') { hide(); return; }
				else return;
				e.preventDefault();
			});
			// Перерисовка создаёт график заново: прежний обработчик на document снимаем.
			box.lsAbort?.abort();
			box.lsAbort = new AbortController();
			document.addEventListener('pointerdown', (e) => { if (!box.contains(e.target) && document.activeElement !== svg) hide(); }, { signal: box.lsAbort.signal });

			fillTable(box.dataset.chart, list, series);
		}

		/** Те же корзины таблицей: подсказка графика доступна только мышью. */
		function fillTable(name, list, series) {
			const table = root.querySelector(`[data-chart-table="${name}"]`);
			if (!table) return;
			table.textContent = '';
			const head = table.createTHead().insertRow();
			const withEvents = list.some((b) => b.scans || b.bans);
			const heads = [_t('period'), ...series.map((s) => s.name[0].toUpperCase() + s.name.slice(1))];
			if (withEvents) heads.push(_t('events'));
			for (const text of heads) {
				const th = document.createElement('th');
				th.scope = 'col';
				th.textContent = text;
				head.append(th);
			}
			const body = table.createTBody();
			for (const b of list) {
				const tr = body.insertRow();
				const th = document.createElement('th');
				th.scope = 'row';
				th.textContent = label(b);
				tr.append(th);
				for (const s of series) tr.insertCell().textContent = nf.format(b[s.key]);
				if (withEvents) {
					const ev = [];
					if (b.scans) ev.push(_f('evScans', b.scans) + (b.found ? _f('evFound', b.found) : '') + (b.errors ? _f('evErrors', b.errors) : ''));
					if (b.bans) ev.push(_f('evBans', b.bans));
					const td = tr.insertCell();
					td.className = 'ls-ev-cell';
					td.textContent = ev.join('; ') || '—';
				}
			}
		}

		function setMetric(name, text) {
			const node = root.querySelector(`[data-metric="${name}"]`);
			if (node) node.textContent = text;
		}

		function renderTypes(list) {
			const ul = root.querySelector('[data-types]');
			if (!ul) return;
			const sums = {};
			for (const b of list) for (const [t, n] of Object.entries(b.flag)) sums[t] = (sums[t] || 0) + n;
			const rows = Object.entries(D.types).map(([k, name]) => [name, sums[k] || 0, k]).sort((a, b) => b[1] - a[1]);
			const max = Math.max(1, ...rows.map((r) => r[1]));
			ul.textContent = '';
			for (const [name, n] of rows) {
				const li = document.createElement('li');
				const t = document.createElement('span');
				t.textContent = name;
				const v = document.createElement('span');
				v.className = 'ls-num';
				v.textContent = nf.format(n);
				const bar = document.createElement('span');
				bar.className = 'ls-bar';
				const fill = document.createElement('span');
				fill.style.width = `${(n / max) * 100}%`;
				bar.append(fill);
				li.append(t, v, bar);
				ul.append(li);
			}
		}

		function render(hours) {
			const list = buckets(hours);
			const sum = (k) => list.reduce((s, b) => s + b[k], 0);
			const req = sum('req'), err = sum('err'), fails = sum('fails');
			const flag = list.reduce((s, b) => s + Object.values(b.flag).reduce((a, n) => a + n, 0), 0);
			setMetric('req', nf.format(req));
			setMetric('err', req ? `${nf.format(err)} · ${(err / req * 100).toFixed(1)}%` : '0');
			setMetric('fails', nf.format(fails));
			setMetric('flag', nf.format(flag));
			setMetric('banned', nf.format(D.banned));

			const period = _t(hours <= 24 ? 'period24h' : hours <= 168 ? 'period7d' : 'period30d');
			const traffic = root.querySelector('[data-chart="traffic"]');
			const failsBox = root.querySelector('[data-chart="fails"]');
			// Цвета серий — CSS-переменные темы в style, а не вычисленные значения:
			// при смене темы график перекрашивается сам, без перерисовки.
			if (traffic) chart(traffic, list, [
				{ key: 'req', name: _t('seriesReq'), color: 'var(--ls-accent)', kind: 'area' },
				{ key: 'err', name: _t('seriesErr'), color: 'var(--ls-danger)', kind: 'line' },
			], _f('traffic', period, nf.format(req), nf.format(err)));
			if (failsBox) chart(failsBox, list, [
				{ key: 'fails', name: _t('seriesFails'), color: 'var(--ls-warn)', kind: 'bar' },
			], _f('failsChart', period, nf.format(fails)));
			renderTypes(list);
		}

		return { render };
	}

	// Подтверждение опасных действий без inline-обработчиков: <form data-confirm="…">.
	document.addEventListener('submit', (e) => {
		const f = e.target.closest('form[data-confirm]');
		if (f && !window.confirm(f.dataset.confirm)) e.preventDefault();
	});
	// Кнопка «Копировать» для только что выпущенного токена.
	document.addEventListener('click', async (e) => {
		const btn = e.target.closest('[data-copy]');
		if (!btn) return;
		const input = document.getElementById(btn.dataset.copy);
		if (!input) return;
		try {
			await navigator.clipboard.writeText(input.value);
			btn.textContent = _t('copied');
		} catch {
			input.select();
		}
	});

	const all = [];
	const main = document.querySelector('.ls-dash');
	if (!main) return;

	// ---- Вкладки ----
	// Без скрипта видны все панели подряд. Встроенный скрипт в разметке уже выбрал вкладку из #hash
	// (data-boot-tab), здесь — переключение, клавиатура и история.
	// Ручная активация: стрелки только двигают фокус, вкладку открывает Enter/пробел/клик —
	// выбор меняет адрес (#hash) и запускает опрос лога.
	const tablist = main.querySelector('[data-tablist]');
	const tabs = tablist ? [...tablist.querySelectorAll('[role="tab"]')] : [];
	const panels = new Map(tabs.map((t) => [t.dataset.tab, main.querySelector(`[data-panel="${t.dataset.tab}"]`)]));
	const tabHooks = {}; // имя → { show(), hide() }, регистрируют блоки ниже
	const untilFound = 'onbeforematch' in HTMLElement.prototype;
	let currentTab = tabs.length ? null : 'all'; // без вкладок (страница API) всё «открыто»
	const isTabOpen = (name) => currentTab === 'all' || currentTab === name;

	function selectTab(name, { push = false, focus = false } = {}) {
		if (!panels.has(name)) name = tabs[0].dataset.tab;
		if (name === currentTab) return;
		const prev = currentTab;
		currentTab = name;
		for (const t of tabs) {
			const on = t.dataset.tab === name;
			t.setAttribute('aria-selected', String(on));
			t.tabIndex = on ? 0 : -1;
			if (on && focus) t.focus();
			if (on && prev) t.scrollIntoView({ block: 'nearest', inline: 'nearest', container: 'nearest' });
		}
		// hidden="until-found": поиск по странице (Ctrl+F) находит текст в закрытой вкладке и открывает её.
		for (const [k, p] of panels) {
			if (k === name) p.removeAttribute('hidden');
			else p.setAttribute('hidden', untilFound ? 'until-found' : '');
		}
		main.removeAttribute('data-boot-tab');
		// Формы вне панелей (шапка, диалоги) возвращают на открытую вкладку.
		main.querySelectorAll('input[data-ls-tab-follow]').forEach((i) => { i.value = name; });
		if (push && location.hash !== `#${name}`) history.pushState(null, '', `#${name}`);
		if (prev) tabHooks[prev]?.hide?.();
		tabHooks[name]?.show?.();
	}
	const tabFromHash = () => location.hash.slice(1);

	if (tabs.length) {
		tablist.hidden = false;
		tablist.addEventListener('click', (e) => {
			const t = e.target.closest('[role="tab"]');
			if (t) selectTab(t.dataset.tab, { push: true });
		});
		tablist.addEventListener('keydown', (e) => {
			const i = tabs.indexOf(document.activeElement);
			if (i < 0) return;
			const to = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: tabs.length - 1 }[e.key];
			if (to === undefined) return;
			e.preventDefault();
			const t = tabs[(to + tabs.length) % tabs.length];
			t.focus();
			t.scrollIntoView({ block: 'nearest', inline: 'nearest', container: 'nearest' });
		});
		// Фокус, вошедший в список, попадает на выбранную вкладку (tabindex=0 только у неё);
		// ушёл, не выбрав, — сфокусированная возвращает tabindex=-1.
		tablist.addEventListener('focusout', (e) => {
			if (tablist.contains(e.relatedTarget)) return;
			for (const t of tabs) t.tabIndex = t.getAttribute('aria-selected') === 'true' ? 0 : -1;
		});
		tablist.addEventListener('focusin', (e) => {
			for (const t of tabs) t.tabIndex = t === e.target ? 0 : -1;
		});
		for (const [k, p] of panels) p?.addEventListener('beforematch', () => selectTab(k, { push: true }));
		// «Назад»/«Вперёд» и ссылки вида <a href="#attackers">.
		const restore = () => { if (panels.has(tabFromHash())) selectTab(tabFromHash()); else if (!location.hash) selectTab(tabs[0].dataset.tab); };
		window.addEventListener('popstate', restore);
		window.addEventListener('hashchange', restore);
		selectTab(main.dataset.bootTab || tabFromHash());
	}

	// ---- «Первый запуск»: шаг «Проверьте список» отмечается, когда открыта вкладка «Атакующие». ----
	// Отметка — в localStorage (ключ свой у пользователя и сайта); засчитывается, только когда
	// первое сканирование уже прошло: до него список пуст и проверять нечего.
	const onboard = main.querySelector('[data-onboard]');
	if (onboard) {
		const key = onboard.dataset.reviewKey;
		const step = (name) => onboard.querySelector(`[data-step="${name}"]`);
		const isDone = (li) => li?.dataset.done === '1';
		const stored = () => { try { return localStorage.getItem(key) === '1'; } catch { return false; } };
		const refresh = () => {
			const items = [...onboard.querySelectorAll('[data-step]')];
			const cur = items.find((li) => !isDone(li));
			const n = items.filter(isDone).length;
			for (const li of items) {
				const done = isDone(li);
				li.classList.toggle('ls-step-done', done);
				if (li === cur) li.setAttribute('aria-current', 'step'); else li.removeAttribute('aria-current');
				const st = li.querySelector('[data-step-state]');
				if (st) st.textContent = ' ' + _t(done ? 'stepDone' : (li === cur ? 'stepCurrent' : 'stepTodo'));
				if (done) li.querySelector('.ls-step-act')?.remove();
				li.querySelectorAll('.ls-step-act .ls-btn').forEach((b) => b.classList.toggle('ls-btn-accent', li === cur));
			}
			const count = onboard.querySelector('[data-onboard-count]');
			if (count) count.textContent = _f('onboardCount', n, items.length);
			if (!cur) onboard.hidden = true;
		};
		const markReviewed = () => {
			const li = step('review');
			if (!li || isDone(li) || !isDone(step('scan'))) return;
			try { localStorage.setItem(key, '1'); } catch { /* приватный режим: отметка до перезагрузки */ }
			li.dataset.done = '1';
			refresh();
		};
		if (stored() && isDone(step('scan')) && step('review')) step('review').dataset.done = '1';
		refresh();
		const prevHook = tabHooks.attackers;
		tabHooks.attackers = {
			show() { prevHook?.show?.(); markReviewed(); },
			hide() { prevHook?.hide?.(); },
		};
		if (isTabOpen('attackers')) markReviewed();
	}

	// ---- Ручная блокировка: понятное сообщение вместо стандартного «не соответствует формату». ----
	const mbanIp = main.querySelector('[data-mban-ip]');
	if (mbanIp) {
		const check = () => {
			const v = mbanIp.value.trim();
			mbanIp.setCustomValidity(v && mbanIp.validity.patternMismatch
				? _t('ipFormat') : '');
		};
		mbanIp.addEventListener('input', check);
		mbanIp.addEventListener('invalid', check);
	}

	// ---- Тема: как в системе / тёмная / светлая. Хранится у пользователя, атрибут ставит сервер. ----
	const themeCtl = main.querySelector('[data-theme-control]');
	const themeCfg = window.LogShieldData?.theme;
	if (themeCtl && themeCfg) {
		const sel = themeCtl.querySelector('[data-theme-select]');
		const sysOpt = sel.querySelector('option[value="system"]');
		const sysBase = sysOpt.textContent;
		const mq = matchMedia('(prefers-color-scheme: dark)');
		// У варианта «как в системе» видно, что сейчас выбрано в системе.
		const showSystem = () => { sysOpt.textContent = _f(mq.matches ? 'themeNowDark' : 'themeNowLight', sysBase); };
		showSystem();
		mq.addEventListener('change', showSystem);
		const note = document.createElement('span');
		note.className = 'screen-reader-text';
		note.setAttribute('role', 'status');
		themeCtl.after(note);
		const apply = (v) => document.querySelectorAll('.ls-dash').forEach((d) => { d.dataset.theme = v; });
		// Браузер может восстановить старое значение селекта (назад/обновление) — верим data-theme от сервера.
		const cur = main.dataset.theme;
		if (cur && sel.querySelector(`option[value="${cur}"]`)) sel.value = cur;
		let saved = sel.value;
		themeCtl.hidden = false;
		sel.addEventListener('change', async () => {
			const v = sel.value;
			apply(v);
			note.textContent = '';
			try {
				const body = new FormData();
				body.append('nonce', themeCfg.nonce);
				body.append('theme', v);
				const res = await fetch(themeCfg.url, { method: 'POST', body, credentials: 'same-origin' });
				const json = await res.json();
				if (!json.success) throw new Error(String(json.data));
				saved = v;
			} catch {
				sel.value = saved;
				apply(saved);
				note.textContent = _t('themeFail');
				sel.title = _t('themeFailTitle');
			}
		});
	}

	if (window.LogShieldData) {
		all.push(mount(main, window.LogShieldData));
		const empty = main.querySelector('.ls-empty');
		if (empty) empty.hidden = window.LogShieldData.stats.length > 0;
	}
	if (!all.length) return;
	const renderAll = (h) => all.forEach((m) => m.render(h));

	// Период
	const rangeBtns = main.querySelectorAll('[data-range]');
	let hours = 24;
	try { hours = Number(localStorage.getItem('logshield-range')) || 24; } catch {}
	if (![24, 168, 720].includes(hours)) hours = 24;
	function pickRange(h) {
		hours = h;
		rangeBtns.forEach((b) => b.setAttribute('aria-pressed', String(Number(b.dataset.range) === h)));
		try { localStorage.setItem('logshield-range', String(h)); } catch {}
		renderAll(h);
	}
	rangeBtns.forEach((b) => b.addEventListener('click', () => pickRange(Number(b.dataset.range))));
	pickRange(hours);

	// Перерисовка только при смене ширины: раскрытие таблицы данных меняет лишь высоту.
	let resizeTimer;
	let lastWidth = 0;
	const firstCard = main.querySelector('.ls-chart-card');
	if (firstCard) {
		new ResizeObserver(([entry]) => {
			const w = Math.round(entry.contentRect.width);
			if (w === lastWidth) return;
			lastWidth = w;
			clearTimeout(resizeTimer);
			resizeTimer = setTimeout(() => renderAll(hours), 150);
		}).observe(firstCard);
		// Пока «Обзор» был закрыт, ширина графиков не измерялась: перерисовываем сразу при открытии.
		tabHooks.overview = {
			show() {
				const w = Math.round(firstCard.getBoundingClientRect().width);
				if (!w || w === lastWidth) return;
				lastWidth = w;
				clearTimeout(resizeTimer);
				renderAll(hours);
			},
		};
	}

	// Подтверждение «Разблокировать все» — <dialog>. Кнопка открывает его через
	// command="show-modal"; где Invoker Commands ещё нет, открываем сами.
	if (!('commandForElement' in HTMLButtonElement.prototype)) {
		main.querySelectorAll('button[command="show-modal"][commandfor]').forEach((b) => b.addEventListener('click', () => {
			document.getElementById(b.getAttribute('commandfor'))?.showModal();
		}));
	}

	// ---- Атакующие: сортировка, фильтры, выбор строк, групповые действия, панель адреса ----
	const atTable = main.querySelector('[data-attackers]');
	if (atTable) {
		const AD = window.LogShieldData || {};
		const tbody = atTable.tBodies[0];
		const rows = [...tbody.rows];
		const collator = new Intl.Collator('ru', { numeric: true, sensitivity: 'base' });
		const fBox = main.querySelector('[data-attack-filters]');
		const fQ = fBox.querySelector('[data-f-q]');
		const fCount = fBox.querySelector('[data-f-count]');
		const hiddenBtn = fBox.querySelector('[data-f-hidden]');
		const live = main.querySelector('[data-bulk-live]');
		fBox.hidden = false;
		atTable.dataset.js = ''; // показывает колонку выбора
		const f = { q: '', group: '', status: '', dismissed: false };

		const value = (row, i) => row.cells[i].dataset.value ?? row.cells[i].textContent.trim();
		const addrWord = (n) => _n(n, 'addr');
		// Объявление для скринридера: всегда в DOM, вне панели; повтор того же текста тоже озвучивается.
		let liveTimer;
		function announce(text) {
			clearTimeout(liveTimer);
			liveTimer = setTimeout(() => { live.textContent = ''; requestAnimationFrame(() => { live.textContent = text; }); }, 250);
		}

		function sortBy(th, direction) {
			for (const h of atTable.tHead.rows[0].cells) h.removeAttribute('aria-sort');
			th.setAttribute('aria-sort', direction);
			const i = th.cellIndex;
			const k = direction === 'ascending' ? 1 : -1;
			const sorted = [...tbody.rows].sort((a, b) => k * (th.dataset.type === 'number'
				? Number(value(a, i)) - Number(value(b, i))
				: collator.compare(value(a, i), value(b, i))));
			// Переставляем те же строки, не пересоздавая их (фокус и отметки сохраняются).
			for (const r of sorted) (tbody.moveBefore ? tbody.moveBefore(r, null) : tbody.append(r));
			fCount.textContent = _f(direction === 'ascending' ? 'sortAsc' : 'sortDesc', th.textContent.trim().toLowerCase());
		}
		function onSort(btn) {
			const th = btn.closest('th');
			sortBy(th, th.getAttribute('aria-sort') === 'ascending' ? 'descending' : 'ascending');
		}
		// Invoker Commands: command="--sort" commandfor="ls-attackers"; иначе — обычный click.
		if ('commandForElement' in HTMLButtonElement.prototype) {
			atTable.addEventListener('command', (e) => { if (e.command === '--sort') onSort(e.source); });
		} else {
			atTable.querySelectorAll('.ls-sort').forEach((b) => b.addEventListener('click', () => onSort(b)));
		}

		// Фильтры: поиск (адрес, причина, страна, сеть, AS), чипы типа и статуса, «Показать скрытые».
		function applyFilters() {
			let shown = 0;
			let total = 0;
			for (const r of rows) {
				const dismissed = 'dismissed' in r.dataset;
				if (!dismissed || f.dismissed) total++;
				const ok = (!dismissed || f.dismissed)
					&& (!f.q || r.dataset.q.includes(f.q))
					&& (!f.group || r.dataset.groups.split(' ').includes(f.group))
					&& (!f.status || r.dataset.status === f.status);
				r.hidden = !ok;
				if (ok) shown++;
			}
			fCount.textContent = shown === total ? _f('total', total) : _f('shown', shown, total);
			syncSelection();
		}
		// Группа чипов — взаимоисключающий выбор через aria-pressed (ровно один true).
		for (const [sel, key] of [['[data-f-type]', 'group'], ['[data-f-status]', 'status']]) {
			const group = fBox.querySelector(sel);
			if (!group) continue;
			group.addEventListener('click', (e) => {
				const chip = e.target.closest('.ls-chip');
				if (!chip) return;
				for (const c of group.querySelectorAll('.ls-chip')) c.setAttribute('aria-pressed', String(c === chip));
				f[key] = chip.dataset.v;
				applyFilters();
			});
		}
		hiddenBtn?.addEventListener('click', () => {
			f.dismissed = hiddenBtn.getAttribute('aria-pressed') !== 'true';
			hiddenBtn.setAttribute('aria-pressed', String(f.dismissed));
			applyFilters();
		});
		let fTimer;
		fQ.addEventListener('input', () => {
			clearTimeout(fTimer);
			fTimer = setTimeout(() => { f.q = fQ.value.trim().toLowerCase(); applyFilters(); }, 150);
		});

		// ---- Выбор строк ----
		// Отметки переживают фильтрацию (скрытая строка остаётся выбранной),
		// но действия применяются только к выбранным и видимым.
		const selAll = atTable.querySelector('[data-sel-all]');
		const box = (r) => r.querySelector('[data-sel]');
		const bulk = main.querySelector('[data-bulk]');
		const bulkCount = bulk.querySelector('[data-bulk-count]');
		const bar = bulk.querySelector('[role="toolbar"]');
		const opBtns = Object.fromEntries([...bar.querySelectorAll('[data-bulk-op]')].map((b) => [b.dataset.bulkOp, b]));
		const bulkForm = main.querySelector('[data-bulk-form]');
		const BULK_MAX = 200;
		let anchor = null; // строка последнего щелчка для Shift+щелчка

		const selectedRows = () => rows.filter((r) => box(r).checked);
		const visibleRows = () => [...tbody.rows].filter((r) => !r.hidden);
		const targets = (op, vis) => vis.filter((r) => op === 'ban' ? r.dataset.status !== 'banned'
			: op === 'unban' ? r.dataset.direct === '1'
				: op === 'hide' ? !('dismissed' in r.dataset) : true);

		function syncSelection() {
			const sel = selectedRows();
			const vis = sel.filter((r) => !r.hidden);
			const visAll = visibleRows();
			const visChecked = visAll.filter((r) => box(r).checked).length;
			selAll.checked = visAll.length > 0 && visChecked === visAll.length;
			selAll.indeterminate = visChecked > 0 && visChecked < visAll.length;
			selAll.disabled = visAll.length === 0;
			bulk.hidden = sel.length === 0;
			const hid = sel.length - vis.length;
			bulkCount.textContent = _f('selected', sel.length) + (hid ? ' · ' + _f('selectedHidden', hid, vis.length) : '');
			const labels = { ban: _t('opBan'), unban: _t('opUnban'), hide: _t('opHide') };
			for (const [op, label] of Object.entries(labels)) {
				const n = targets(op, vis).length;
				opBtns[op].textContent = n ? `${label} (${n})` : label;
				opBtns[op].setAttribute('aria-disabled', String(n === 0));
			}
			for (const r of rows) r.toggleAttribute('data-selected', box(r).checked);
		}

		tbody.addEventListener('click', (e) => {
			const cb = e.target.closest('[data-sel]');
			if (!cb) return;
			const row = cb.closest('tr');
			// Shift+щелчок: диапазон видимых строк от прошлого щелчка до этого получает то же состояние.
			if (e.shiftKey && anchor && anchor !== row && !anchor.hidden) {
				const vis = visibleRows();
				const a = vis.indexOf(anchor), b = vis.indexOf(row);
				if (a >= 0 && b >= 0) {
					for (const r of vis.slice(Math.min(a, b), Math.max(a, b) + 1)) box(r).checked = cb.checked;
				}
			}
			anchor = row;
			syncSelection();
			announce(_f('selected', selectedRows().length));
		});
		selAll.addEventListener('change', () => {
			for (const r of visibleRows()) box(r).checked = selAll.checked;
			anchor = null;
			syncSelection();
			announce(selAll.checked ? _f('selectedAll', visibleRows().length, selectedRows().length) : _f('selected', selectedRows().length));
		});

		function clearSelection() {
			for (const r of rows) box(r).checked = false;
			anchor = null;
			syncSelection();
			selAll.focus(); // панель скрылась вместе с кнопкой
			announce(_t('selCleared'));
		}

		bar.addEventListener('click', (e) => {
			const btn = e.target.closest('[data-bulk-op]');
			if (!btn) return;
			const op = btn.dataset.bulkOp;
			if (op === 'clear') { clearSelection(); return; }
			const sel = selectedRows();
			const vis = sel.filter((r) => !r.hidden);
			const list = targets(op, vis);
			if (btn.getAttribute('aria-disabled') === 'true' || !list.length) {
				announce(_t(op === 'ban' ? 'noneBan' : op === 'unban' ? 'noneUnban' : 'noneHide'));
				return;
			}
			if (list.length > BULK_MAX) { announce(_f('tooMany', BULK_MAX, list.length)); return; }
			const hid = sel.length - vis.length;
			const rest = hid ? '\n\n' + (hid === 1 ? _f('restOne', hid) : _n(hid, 'rest')) : '';
			bulkForm.querySelectorAll('input[name="items[]"]').forEach((i) => i.remove());
			for (const r of list) {
				const i = document.createElement('input');
				i.type = 'hidden';
				i.name = 'items[]';
				i.value = r.dataset.ip;
				bulkForm.append(i);
			}
			bulkForm.querySelector('[data-bulk-input-op]').value = op;
			// Подтверждение — общим обработчиком form[data-confirm] (с числом адресов).
			if (op === 'ban') bulkForm.dataset.confirm = _f('confirmBan', addrWord(list.length)) + rest;
			else if (op === 'unban') bulkForm.dataset.confirm = _f(list.length === 1 ? 'confirmUnbanOne' : 'confirmUnban', addrWord(list.length)) + rest;
			else delete bulkForm.dataset.confirm;
			bulkForm.requestSubmit();
		});

		// Панель действий — role="toolbar" с одной точкой табуляции. Нативный focusgroup
		// делает это сам; где его нет — переносимый tabindex и стрелки.
		if (!('focusGroup' in HTMLElement.prototype)) {
			const items = [...bar.querySelectorAll('button')];
			items.forEach((b, i) => (b.tabIndex = i ? -1 : 0));
			bar.addEventListener('focusin', ({ target }) => {
				if (items.includes(target)) items.forEach((b) => (b.tabIndex = b === target ? 0 : -1));
			});
			bar.addEventListener('keydown', (e) => {
				const rtl = getComputedStyle(bar).direction === 'rtl';
				const steps = { ArrowRight: rtl ? -1 : 1, ArrowLeft: rtl ? 1 : -1 };
				const i = items.indexOf(document.activeElement);
				if (i < 0) return;
				let next;
				if (e.key in steps) next = (i + steps[e.key] + items.length) % items.length;
				else if (e.key === 'Home') next = 0;
				else if (e.key === 'End') next = items.length - 1;
				else return;
				e.preventDefault();
				items[next].focus();
			});
		}

		// ---- Панель адреса (<dialog> справа, на узком экране — снизу) ----
		const panel = main.querySelector('[data-ip-panel]');
		if (panel) {
			const $ = (s) => panel.querySelector(s);
			const reqList = $('[data-p-reqs]');
			const reqStatus = $('[data-p-req-status]');
			const forms = Object.fromEntries([...panel.querySelectorAll('[data-p-form]')].map((fm) => [fm.dataset.pForm, fm]));
			const mbFmt = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 1 });
			let opener = null;
			let ctrl = null;

			const el = (tag, cls, text) => {
				const n = document.createElement(tag);
				if (cls) n.className = cls;
				if (text !== undefined) n.textContent = text;
				return n;
			};

			async function loadRequests(ip) {
				ctrl?.abort();
				ctrl = new AbortController();
				reqList.replaceChildren();
				reqList.setAttribute('aria-busy', 'true');
				reqStatus.textContent = _t('reqLoading');
				reqStatus.classList.add('ls-loading');
				try {
					// Адрес уже несёт маркер action=logshield_ip_requests (свой запрос в логе), остальное — в теле.
					const body = new URLSearchParams({ nonce: AD.ipreq.nonce, ip });
					const res = await fetch(AD.ipreq.url, { method: 'POST', body, credentials: 'same-origin', signal: ctrl.signal });
					const json = await res.json();
					if (!json.success) throw new Error(typeof json.data === 'string' ? json.data : _t('reqFail'));
					const { items, more, whole, mb } = json.data;
					const range = ip.includes('/');
					for (const it of items) {
						const li = el('li', 'ls-req');
						li.append(el('span', 'ls-t', it.t));
						if (range) li.append(el('span', 'ls-ip', it.ip));
						li.append(el('span', 'ls-m', it.m), el('span', `ls-s ls-s${String(it.s)[0]}`, String(it.s)), el('span', 'ls-p', it.p));
						if (it.ua) li.append(el('span', 'ls-ua', it.ua));
						reqList.append(li);
					}
					const where = whole ? _t('reqWhole') : _f('reqLastMb', mbFmt.format(mb));
					reqStatus.textContent = items.length
						? _f(more ? 'reqFoundLast' : 'reqFound', _n(items.length, 'reqs'), where)
						: (whole ? _t('reqNoneWhole') : _f('reqNoneMb', mbFmt.format(mb)));
				} catch (err) {
					if (err.name === 'AbortError') return;
					reqStatus.textContent = err.message || _t('reqFail');
				} finally {
					reqList.removeAttribute('aria-busy');
					reqStatus.classList.remove('ls-loading');
				}
			}

			function openPanel(row, btn) {
				const ip = row.dataset.ip;
				const banned = row.dataset.status === 'banned';
				const direct = row.dataset.direct === '1';
				const dismissed = 'dismissed' in row.dataset;
				const range = ip.includes('/');
				$('[data-p-ip]').textContent = ip;
				const geo = row.querySelector('.ls-geo');
				$('[data-p-geo]').replaceChildren(...(geo ? [geo.cloneNode(true)] : []));
				const exp = row.dataset.expires; // дата уже в поясе сайта
				let st = !banned ? _t('stNotBanned')
					: !direct ? _t('stInSubnet')
						: exp ? _f('stUntil', exp) : _t('stForever');
				if (dismissed) st += ' ' + _t('stHidden');
				// Закрыт ещё и строкой .htaccess вне LogShield: «Разблокировать» его не откроет.
				if (row.dataset.foreign) st += ' ' + _f('stForeign', row.dataset.foreign);
				$('[data-p-status]').textContent = st;
				for (const i of panel.querySelectorAll('[data-p-item]')) i.value = ip;
				forms.ban.hidden = banned;
				forms.unban.hidden = !direct;
				forms.hide.hidden = dismissed;
				forms.whitelist.dataset.confirm = _f(range ? 'confirmWlRange' : 'confirmWl', ip);

				const hist = (AD.history || {})[ip] || [];
				const hl = $('[data-p-hist]');
				hl.replaceChildren(...hist.map(([, reason, when]) => {
					const li = el('li');
					li.append(el('span', 'ls-t', when), el('span', '', reason));
					return li;
				}));
				$('[data-p-hist-empty]').hidden = hist.length > 0;

				opener = btn;
				panel.showModal();
				panel.querySelector('.ls-side-body').scrollTop = 0;
				loadRequests(ip);
			}

			tbody.addEventListener('click', (e) => {
				const btn = e.target.closest('[data-ip-open]');
				if (btn) openPanel(btn.closest('tr'), btn);
			});
			panel.addEventListener('close', () => {
				ctrl?.abort();
				// Браузер возвращает фокус сам; на случай закрытия щелчком по фону — явно на кнопку адреса.
				if (opener?.isConnected) opener.focus();
			});
			// Закрытие щелчком по фону: closedby="any"; где атрибута нет — по координатам
			// (нажатие и отпускание снаружи, чтобы выделение текста мышью не закрывало панель).
			if (!('closedBy' in HTMLDialogElement.prototype)) {
				const outside = (e) => {
					const r = panel.getBoundingClientRect();
					return e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom;
				};
				let pressedOutside = false;
				panel.addEventListener('pointerdown', (e) => { pressedOutside = outside(e); });
				panel.addEventListener('pointerup', (e) => { if (pressedOutside && outside(e)) panel.close(); });
			}
		}

		applyFilters();
	}

	// ---- Хвост лога ----
	const root = main;
	const D = window.LogShieldData;
	const tailBox = root.querySelector('[data-tail]');
	if (!D || !tailBox) return;
	const tailStatus = root.querySelector('[data-tail-status]');
	const liveBtn = root.querySelector('[data-live]');
	const filterBtns = root.querySelectorAll('[data-filter]');
	const suspects = D.suspects;
	const isSuspect = (ip) => suspects.some((s) => s === ip || (s.includes('/') && inSubnet(ip, s)));
	const tailHidden = root.querySelector('[data-tail-hidden]');
	const MAX_ROWS = 500;
	const FILTER_KEY = 'logshield-tail-filter';
	let offset = -1;
	// «Скрыть обычное» — по умолчанию; выбор запоминается.
	let filter = 'quiet';
	try {
		const saved = localStorage.getItem(FILTER_KEY);
		if (saved && [...filterBtns].some((b) => b.dataset.filter === saved)) filter = saved;
	} catch {}
	filterBtns.forEach((x) => x.setAttribute('aria-pressed', String(x.dataset.filter === filter)));
	let tailOk = false; // последний опрос удался — можно писать «пусто» в строку статуса
	let timer = null;
	let busy = false;

	/** Только /24 для IPv4 и /64 для IPv6 — других подсетей детектор не создаёт. */
	function inSubnet(ip, cidr) {
		const [net, bits] = cidr.split('/');
		if (net.includes(':') !== ip.includes(':')) return false;
		if (!ip.includes(':')) {
			const toInt = (a) => a.split('.').reduce((s, o) => s * 256 + Number(o), 0);
			const size = 2 ** (32 - Number(bits));
			return Math.floor(toInt(ip) / size) === Math.floor(toInt(net) / size);
		}
		const groups = (a) => {
			const [h, t = ''] = a.split('::');
			const hs = h ? h.split(':') : [], ts = t ? t.split(':') : [];
			return [...hs, ...Array(8 - hs.length - ts.length).fill('0'), ...ts].map((g) => parseInt(g || '0', 16));
		};
		const n = Math.floor(Number(bits) / 16);
		const a = groups(ip), b = groups(net);
		return a.slice(0, n).every((g, i) => g === b[i]);
	}

	function matchesFilter(row) {
		const s = Number(row.dataset.status);
		if (filter === '4xx') return s >= 400 && s < 500;
		if (filter === '5xx') return s >= 500;
		if (filter === 'bad') return row.classList.contains('ls-bad');
		// Обычную строку (n: 1) помечает сервер: белый список, успешные ответы без признаков атаки.
		if (filter === 'quiet') return !row.dataset.n;
		return true;
	}

	/** Счётчик скрытых обычных строк и подсказка, если после фильтра ничего не осталось. */
	function updateView() {
		let shown = 0, routine = 0;
		for (const row of tailBox.children) {
			if (!row.hidden) shown++;
			else if (row.dataset.n) routine++;
		}
		if (tailHidden) tailHidden.textContent = filter === 'quiet' && routine ? _f('tailHidden', routine) : '';
		if (!tailOk) return;
		if (!tailBox.childElementCount) tailStatus.textContent = _t('tailEmpty');
		else if (shown) tailStatus.textContent = '';
		else tailStatus.textContent = filter === 'quiet'
			? _t('tailOnlyRoutine')
			: _t('tailNoMatch');
	}

	function addRows(lines, fresh) {
		const frag = document.createDocumentFragment();
		for (const l of lines) {
			const row = document.createElement('div');
			row.className = 'ls-row' + (isSuspect(l.ip) ? ' ls-bad' : '') + (fresh ? ' ls-new' : '');
			row.dataset.status = l.s;
			if (l.n) row.dataset.n = '1';
			// User-Agent — отдельная ячейка, а не title: так он виден с клавиатуры и на сенсорном экране.
			const cells = [[l.t, 'ls-t'], [l.ip, 'ls-ip'], [l.m, 'ls-m'], [l.s, `ls-s${String(l.s)[0]}`], [l.p, 'ls-p'], [l.ua || '—', 'ls-ua']];
			for (const [text, cls] of cells) {
				const c = document.createElement('span');
				c.className = cls;
				c.textContent = text;
				row.append(c);
			}
			row.hidden = !matchesFilter(row);
			frag.prepend(row); // новые сверху
		}
		tailBox.prepend(frag);
		while (tailBox.childElementCount > MAX_ROWS) tailBox.lastElementChild.remove();
	}

	/**
	 * Один запрос хвоста. Возвращает число новых строк, null — запрос уже идёт,
	 * -1 — ошибка. Фоновые опросы живого режима идут с низким приоритетом,
	 * чтобы не мешать остальным запросам страницы.
	 */
	async function poll(background = false) {
		if (busy) return null;
		busy = true;
		try {
			// Адрес уже несёт маркер action=logshield_tail (свой запрос в логе), остальное — в теле.
			const body = new URLSearchParams({ nonce: D.tail.nonce, offset: String(offset) });
			const res = await fetch(D.tail.url, { method: 'POST', body, credentials: 'same-origin', priority: background ? 'low' : 'auto' });
			const json = await res.json();
			if (!json.success) { tailOk = false; tailStatus.textContent = json.data || _t('tailFail'); stopLive(); return -1; }
			const first = offset < 0 || json.data.reset;
			if (first) tailBox.textContent = '';
			addRows(json.data.lines, !first);
			offset = json.data.offset;
			tailOk = true;
			updateView();
			return json.data.lines.length;
		} catch {
			tailOk = false;
			tailStatus.textContent = _t('tailNetwork');
			return -1;
		} finally {
			busy = false;
		}
	}

	// Живой режим: каждый опрос загружает весь WordPress, поэтому, пока новых
	// записей нет, интервал растёт 5 → 10 → 20 → 30 с. Новые строки или действие
	// пользователя с хвостом возвращают 5 с. Пока вкладка скрыта, опросов нет.
	const STEPS = [5000, 10000, 20000, 30000];
	let step = 0;
	let live = false;

	function schedule() {
		clearTimeout(timer);
		timer = null;
		if (live && !document.hidden && isTabOpen('log')) timer = setTimeout(() => tick(), STEPS[step]);
	}
	async function tick(background = true) {
		timer = null;
		const got = await poll(background);
		if (!live) return;
		if (got > 0) step = 0;
		else if (got !== null) step = Math.min(step + 1, STEPS.length - 1);
		schedule();
	}
	/** Пользователь что-то сделал с хвостом — снова опрашивать часто. */
	function wake() {
		if (!live || step === 0) return;
		step = 0;
		schedule();
	}

	function startLive() {
		live = true;
		step = 0;
		liveBtn.setAttribute('aria-pressed', 'true');
		tick(false);
	}
	function stopLive() {
		live = false;
		liveBtn.setAttribute('aria-pressed', 'false');
		clearTimeout(timer);
		timer = null;
	}
	liveBtn.addEventListener('click', () => (live ? stopLive() : startLive()));

	// Показ User-Agent под каждой записью; выбор запоминается.
	const uaBtn = root.querySelector('[data-ua]');
	if (uaBtn) {
		const setUa = (on) => {
			uaBtn.setAttribute('aria-pressed', String(on));
			tailBox.classList.toggle('ls-show-ua', on);
			try { localStorage.setItem('logshield-ua', on ? '1' : '0'); } catch {}
		};
		let uaOn = false;
		try { uaOn = localStorage.getItem('logshield-ua') === '1'; } catch {}
		setUa(uaOn);
		uaBtn.addEventListener('click', () => { setUa(uaBtn.getAttribute('aria-pressed') !== 'true'); wake(); });
	}
	// Скрыли вкладку браузера — опросы останавливаются; вернулись — сразу опрос и дальше по расписанию.
	document.addEventListener('visibilitychange', () => {
		if (!live || !isTabOpen('log')) return;
		if (document.hidden) { clearTimeout(timer); timer = null; return; }
		step = 0;
		tick(false);
	});

	filterBtns.forEach((b) => b.addEventListener('click', () => {
		wake();
		filter = b.dataset.filter;
		filterBtns.forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
		for (const row of tailBox.children) row.hidden = !matchesFilter(row);
		try { localStorage.setItem(FILTER_KEY, filter); } catch {}
		updateView();
	}));

	// Лог читается только при открытой вкладке «Лог»: первый запрос — при первом открытии.
	let tailStarted = false;
	function startTail() {
		if (tailStarted) return;
		tailStarted = true;
		if (tailStatus.textContent !== _t('logMissing')) poll();
	}
	tabHooks.log = {
		show() {
			startTail();
			if (live && !document.hidden) { step = 0; tick(false); }
		},
		hide() { clearTimeout(timer); timer = null; },
	};
	if (isTabOpen('log')) startTail();
})();
