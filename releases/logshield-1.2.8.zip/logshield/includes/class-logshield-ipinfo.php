<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Страна, сеть (AS) и метки Tor / VPN / дата-центр для настойчивых адресов.
 *
 * Только для информации: на правила блокировки не влияет. Определяется не для
 * всех из лога, а для тех, кто 10+ раз получил ошибку или не смог войти
 * (см. LogShield_Detector::analyze → noisy), и для пойманных правилами.
 *
 * Всё локально, без запросов к внешним сервисам на каждый адрес:
 * - страна и AS — бесплатные базы DB-IP Lite (CC BY 4.0), раз в месяц;
 * - Tor — список выходных узлов Tor Project, раз в сутки;
 * - VPN — открытый список диапазонов X4BNet/lists_vpn, раз в неделю;
 * - дата-центр — AS из списка хостингов или «hosting/cloud/…» в названии.
 * Обновление идёт в ежедневном cron плагина и скачивает только устаревшее,
 * по одному файлу за вызов (см. update()).
 */
class LogShield_IPInfo {

	const OPTION     = 'logshield_ipinfo';      // ip|cidr => сведения (autoload off)
	const STATE      = 'logshield_geo_state';   // файл => [ время загрузки, ошибка ]
	const MIN_HITS   = 10;                      // неудачных обращений, чтобы определять
	const KEEP_DAYS  = 30;
	const MAX_ITEMS  = 1000;
	const RECHECK    = 7 * DAY_IN_SECONDS;      // сведения об адресе освежаются раз в неделю

	/** Метки и их подписи на дашборде. */
	const TAGS = [
		'tor'     => 'Tor',
		'vpn'     => 'VPN',
		'hosting' => 'дата-центр',
	];

	/** Подпись метки на языке сайта (константа TAGS — исходные подписи). */
	public static function tag_label( $tag ) {
		switch ( $tag ) {
			case 'tor':     return 'Tor';
			case 'vpn':     return 'VPN';
			case 'hosting': return __( 'дата-центр', 'logshield' );
		}
		return (string) $tag;
	}

	/** AS крупных хостингов и облаков, которых нет в «hosting/cloud» по названию. */
	const HOSTING_ASNS = [
		14061, 16509, 14618, 15169, 396982, 8075, 24940, 16276, 9009, 60068, 212238, 20473, 63949,
		51167, 12876, 197540, 45102, 132203, 31898, 36352, 200019, 49505, 9123, 216246, 210644,
		62240, 202425, 53667, 46562, 40021, 13335, 54113, 35916, 8100, 136907, 55286, 19318, 30633,
		26496, 21859, 29802, 51396, 213230, 57523, 48282, 50867, 44477, 35048, 199524, 47583,
	];
	const HOSTING_WORDS = '/host|cloud|server|data ?cent|datacamp|colo|vps|dedicated|digitalocean|hetzner|\bovh|linode|vultr|choopa|contabo|leaseweb|m247|scaleway|selectel|timeweb|aeza|amazon|google|microsoft|oracle|alibaba|tencent|akamai|fastly|cdn77|stark industries|pfcloud|serverius|frantech|buyvm/i';

	// ---------- файлы баз ----------

	public static function dir() {
		return trailingslashit( WP_CONTENT_DIR ) . 'logshield-geo/';
	}

	/** Источники: файл => [ url, срок годности ]. URL можно поменять фильтром. */
	public static function sources() {
		$month = gmdate( 'Y-m' );
		return apply_filters( 'logshield_geo_sources', [
			'country.mmdb' => [ "https://download.db-ip.com/free/dbip-country-lite-$month.mmdb.gz", 30 * DAY_IN_SECONDS ],
			'asn.mmdb'     => [ "https://download.db-ip.com/free/dbip-asn-lite-$month.mmdb.gz", 30 * DAY_IN_SECONDS ],
			'tor.txt'      => [ 'https://check.torproject.org/torbulkexitlist', DAY_IN_SECONDS ],
			'vpn.txt'      => [ 'https://raw.githubusercontent.com/X4BNet/lists_vpn/main/output/vpn/ipv4.txt', 7 * DAY_IN_SECONDS ],
		] );
	}

	public static function enabled() {
		return ! empty( LogShield_Plugin::get_options()['ipinfo_enabled'] );
	}

	// На виртуальном хостинге PHP часто живёт 30 секунд. Раньше все четыре файла качались
	// одним вызовом с таймаутом 120 с, а состояние писалось в конце: процесс убивали на
	// середине, и каждый день всё начиналось заново. Теперь состояние пишется после
	// каждого файла, cron качает один файл за вызов, а запрос укладывается в остаток времени.
	const RETRY_AFTER = 6 * HOUR_IN_SECONDS;     // после ошибки или обрыва файл не трогаем столько
	const NEXT_DELAY  = 5 * MINUTE_IN_SECONDS;   // через сколько докачивать следующий файл
	const MAX_TIMEOUT = 25;                      // таймаут одного запроса, с (фильтр logshield_geo_timeout)
	const MIN_TIMEOUT = 5;                       // меньше — запрос не начинаем
	const RESERVE     = 5;                       // запас на распаковку, проверку и запись, с
	const DEFERRED    = 'отложено: не хватило времени на запрос';

	/**
	 * Скачивает устаревшие базы.
	 *
	 * Из cron ($force = false): не больше одного файла за вызов. Если устаревших файлов
	 * больше, ставится разовое событие LOGSHIELD_CLEANUP_HOOK с аргументом 'geo' через
	 * несколько минут: оно снова вызовет run_cleanup() → update() и возьмёт следующий файл.
	 * Файл, который не скачался (или загрузка которого оборвалась), откладывается на
	 * RETRY_AFTER и остальным не мешает.
	 *
	 * Кнопка в настройках ($force = true): все файлы подряд, пока хватает времени.
	 * Не успевшие файлы возвращаются с текстом DEFERRED.
	 *
	 * @return array файл => true | текст ошибки
	 */
	public static function update( $force = false ) {
		$dir = self::dir();
		/* translators: %s: путь к папке. */
		if ( ! wp_mkdir_p( $dir ) ) return [ 'all' => sprintf( __( 'не удалось создать %s', 'logshield' ), $dir ) ];
		if ( ! file_exists( $dir . 'index.php' ) ) @file_put_contents( $dir . 'index.php', "<?php // Silence is golden.\n" );

		$sources = self::sources();
		$due     = $force ? array_keys( $sources ) : self::due_files();
		$out     = [];
		foreach ( $due as $i => $file ) {
			if ( ! $force && $i > 0 ) break; // остальные — в следующем событии
			$timeout = self::timeout();
			if ( ! $timeout ) {
				foreach ( array_slice( $due, $i ) as $rest ) $out[ $rest ] = __( 'отложено: не хватило времени на запрос', 'logshield' );
				break;
			}
			// Следующее событие ставим до загрузки: если процесс убьют, остальные файлы не застрянут.
			if ( ! $force && count( $due ) > 1 ) self::schedule_next();

			$old = self::state()[ $file ] ?? [];
			// Отметка начала: если процесс убьют посреди загрузки, файл будет отложен, а не
			// повторяться (и снова обрываться) при каждом запуске.
			self::put_state( $file, [ 'time' => (int) ( $old['time'] ?? 0 ), 'error' => (string) ( $old['error'] ?? '' ), 'started' => time() ] );
			$res = self::fetch( $sources[ $file ][0], $dir . $file, $timeout );
			self::put_state( $file, [ 'time' => time(), 'error' => $res === true ? '' : $res ] );
			if ( $file === 'vpn.txt' && $res === true ) @unlink( $dir . 'vpn.bin' ); // пересоберётся
			$out[ $file ] = $res;
		}
		if ( self::due_files() ) self::schedule_next();
		return $out;
	}

	/** Файлы, которые пора скачать: устарели и не отложены после ошибки или обрыва. */
	public static function due_files( $now = null ) {
		$now   = $now ?: time();
		$state = self::state();
		$due   = [];
		foreach ( self::sources() as $file => list( , $ttl ) ) {
			$path = self::dir() . $file;
			$st   = $state[ $file ] ?? [];
			if ( is_file( $path ) && filemtime( $path ) > $now - $ttl ) continue;
			if ( ! empty( $st['started'] ) && $st['started'] > $now - self::RETRY_AFTER ) continue; // идёт или оборвалась
			if ( ! empty( $st['error'] ) && ( $st['time'] ?? 0 ) > $now - self::RETRY_AFTER ) continue;
			$due[] = $file;
		}
		return $due;
	}

	private static function state() {
		$state = get_option( self::STATE, [] );
		return is_array( $state ) ? $state : [];
	}

	/** Состояние пишется сразу после каждого файла. */
	private static function put_state( $file, array $st ) {
		$state          = self::state();
		$state[ $file ] = $st;
		update_option( self::STATE, $state, false );
	}

	private static function schedule_next() {
		if ( ! wp_next_scheduled( LOGSHIELD_CLEANUP_HOOK, [ 'geo' ] ) ) {
			wp_schedule_single_event( time() + self::NEXT_DELAY, LOGSHIELD_CLEANUP_HOOK, [ 'geo' ] );
		}
	}

	/**
	 * Сколько секунд осталось до max_execution_time (по времени с начала запроса);
	 * null — ограничения нет. Фильтр logshield_geo_time_left — для тестов и особых хостингов.
	 */
	public static function time_left() {
		$left = null;
		$max  = (int) ini_get( 'max_execution_time' );
		if ( $max > 0 ) {
			$start = isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : microtime( true );
			$left  = $max - ( microtime( true ) - $start );
		}
		return apply_filters( 'logshield_geo_time_left', $left );
	}

	/** Таймаут следующего запроса, с; 0 — времени на запрос уже нет. */
	public static function timeout() {
		$cap  = max( 1, (int) apply_filters( 'logshield_geo_timeout', self::MAX_TIMEOUT ) );
		$left = self::time_left();
		$t    = $left === null ? $cap : (int) min( $cap, floor( $left - self::RESERVE ) );
		return $t >= min( self::MIN_TIMEOUT, $cap ) ? $t : 0;
	}

	/** Один файл; базы DB-IP в начале месяца — с откатом на прошлый месяц. */
	private static function fetch( $url, $path, $timeout ) {
		$res   = self::download( $url, $path, $timeout );
		$month = gmdate( 'Y-m' );
		if ( $res !== true && substr( $url, -3 ) === '.gz' && strpos( $url, $month ) !== false ) {
			// В первые дни месяца новой базы может ещё не быть — берём прошлый месяц.
			$t = self::timeout();
			if ( $t ) $res = self::download( str_replace( $month, gmdate( 'Y-m', strtotime( 'first day of last month' ) ), $url ), $path, $t );
		}
		return $res;
	}

	/** Скачивает во временный файл, распаковывает .gz, проверяет и подменяет. */
	private static function download( $url, $path, $timeout ) {
		$tmp  = $path . '.part';
		$args = [ 'timeout' => $timeout, 'user-agent' => 'LogShield/' . LOGSHIELD_VERSION ];
		// Большие базы — сразу в файл, чтобы не держать в памяти. Списки (до ~200 КБ) —
		// в память: без curl WordPress пишет в файл ответ «chunked» вместе со служебными
		// размерами кусков, а Tor Project и GitHub отдают именно так.
		$stream = substr( $url, -3 ) === '.gz';
		if ( $stream ) $args += [ 'stream' => true, 'filename' => $tmp ];
		$resp = wp_remote_get( $url, $args );
		if ( is_wp_error( $resp ) ) { @unlink( $tmp ); return $resp->get_error_message(); }
		$code = wp_remote_retrieve_response_code( $resp );
		if ( $code !== 200 ) { @unlink( $tmp ); return 'HTTP ' . $code; }
		if ( ! $stream && false === file_put_contents( $tmp, wp_remote_retrieve_body( $resp ) ) ) return __( 'не удалось сохранить', 'logshield' );

		if ( substr( $url, -3 ) === '.gz' ) {
			$gz  = gzopen( $tmp, 'rb' );
			$raw = $path . '.raw';
			$fp  = fopen( $raw, 'wb' );
			if ( ! $gz || ! $fp ) { @unlink( $tmp ); return __( 'не удалось распаковать', 'logshield' ); }
			while ( ! gzeof( $gz ) ) fwrite( $fp, gzread( $gz, 1 << 20 ) );
			gzclose( $gz ); fclose( $fp ); @unlink( $tmp );
			$tmp = $raw;
		}
		$ok = substr( $path, -5 ) === '.mmdb' ? LogShield_MMDB::open( $tmp ) !== null : self::looks_like_list( $tmp );
		if ( ! $ok ) { @unlink( $tmp ); return __( 'файл не похож на базу', 'logshield' ); }
		if ( ! @rename( $tmp, $path ) ) {
			@unlink( $path );
			if ( ! @rename( $tmp, $path ) ) { @unlink( $tmp ); return __( 'не удалось сохранить', 'logshield' ); }
		}
		return true;
	}

	/** Список адресов: первые непустые строки — IP или CIDR (комментарии # пропускаются). */
	private static function looks_like_list( $file ) {
		$fp = fopen( $file, 'rb' );
		if ( ! $fp ) return false;
		$good = 0;
		for ( $i = 0; $i < 50 && $good < 5 && ( $line = fgets( $fp, 256 ) ) !== false; $i++ ) {
			$line = trim( $line );
			if ( $line === '' || $line[0] === '#' ) continue;
			if ( ! LogShield_IP::is_valid_entry( $line ) ) { fclose( $fp ); return false; }
			$good++;
		}
		fclose( $fp );
		return $good > 0;
	}

	/** Состояние баз для страницы настроек: файл => [ есть, размер, дата, ошибка ]. */
	public static function status() {
		$state = self::state();
		$out   = [];
		foreach ( array_keys( self::sources() ) as $file ) {
			$path  = self::dir() . $file;
			$error = $state[ $file ]['error'] ?? '';
			if ( ! empty( $state[ $file ]['started'] ) && $state[ $file ]['started'] < time() - 2 * self::MAX_TIMEOUT ) {
				$error = __( 'загрузка оборвалась (не хватило времени или памяти PHP), повтор через несколько часов', 'logshield' );
			}
			$out[ $file ] = [
				'exists' => is_file( $path ),
				'size'   => is_file( $path ) ? filesize( $path ) : 0,
				'time'   => is_file( $path ) ? filemtime( $path ) : 0,
				'error'  => $error,
			];
		}
		return $out;
	}

	public static function delete_files() {
		foreach ( (array) glob( self::dir() . '*' ) as $f ) @unlink( $f );
		@rmdir( self::dir() );
	}

	// ---------- определение ----------

	/**
	 * Сведения об адресе. Для подсети — по её первому адресу.
	 *
	 * @return array [ cc, country, asn, org, tags[] ] (пустые строки, если неизвестно)
	 */
	public static function lookup( $ip ) {
		static $country = false, $asn = false;
		if ( $country === false ) {
			$country = LogShield_MMDB::open( self::dir() . 'country.mmdb' );
			$asn     = LogShield_MMDB::open( self::dir() . 'asn.mmdb' );
		}
		$ip  = strtok( (string) $ip, '/' );
		$out = [ 'cc' => '', 'country' => '', 'asn' => 0, 'org' => '', 'tags' => [] ];
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) return $out;

		if ( $country && ( $r = $country->get( $ip ) ) ) {
			$c              = $r['country'] ?? [];
			$out['cc']      = strtoupper( (string) ( $c['iso_code'] ?? '' ) );
			$out['country'] = (string) ( $c['names']['ru'] ?? ( $c['names']['en'] ?? '' ) );
		}
		if ( $asn && ( $r = $asn->get( $ip ) ) ) {
			$out['asn'] = (int) ( $r['autonomous_system_number'] ?? 0 );
			$out['org'] = (string) ( $r['autonomous_system_organization'] ?? '' );
		}
		if ( self::in_tor( $ip ) ) $out['tags'][] = 'tor';
		if ( self::in_vpn( $ip ) ) $out['tags'][] = 'vpn';
		if ( in_array( $out['asn'], self::HOSTING_ASNS, true ) || ( $out['org'] !== '' && preg_match( self::HOSTING_WORDS, $out['org'] ) ) ) {
			$out['tags'][] = 'hosting';
		}
		return $out;
	}

	private static function in_tor( $ip ) {
		static $set = null;
		if ( $set === null ) {
			$f   = self::dir() . 'tor.txt';
			$set = is_file( $f ) ? array_flip( array_filter( array_map( 'trim', file( $f ) ) ) ) : [];
		}
		return isset( $set[ $ip ] );
	}

	/** Список VPN (IPv4 CIDR) хранится отсортированными диапазонами; поиск — двоичный. */
	private static function in_vpn( $ip ) {
		static $ranges = null;
		if ( strpos( $ip, ':' ) !== false ) return false;
		if ( $ranges === null ) $ranges = self::vpn_ranges();
		$n = count( $ranges ) / 2;
		if ( ! $n ) return false;
		$x  = (int) sprintf( '%u', ip2long( $ip ) );
		$lo = 0; $hi = $n - 1;
		while ( $lo <= $hi ) {
			$mid = ( $lo + $hi ) >> 1;
			if ( $x < $ranges[ 2 * $mid ] ) $hi = $mid - 1;
			elseif ( $x > $ranges[ 2 * $mid + 1 ] ) $lo = $mid + 1;
			else return true;
		}
		return false;
	}

	private static function vpn_ranges() {
		$txt = self::dir() . 'vpn.txt';
		$bin = self::dir() . 'vpn.bin';
		if ( is_file( $bin ) && is_file( $txt ) && filemtime( $bin ) >= filemtime( $txt ) ) {
			return array_values( unpack( 'N*', file_get_contents( $bin ) ) ?: [] );
		}
		if ( ! is_file( $txt ) ) return [];
		$list = [];
		foreach ( file( $txt ) as $line ) {
			if ( ! preg_match( '~^\s*(\d+\.\d+\.\d+\.\d+)(?:/(\d+))?~', $line, $m ) ) continue;
			$bits  = isset( $m[2] ) ? (int) $m[2] : 32;
			$start = (int) sprintf( '%u', ip2long( $m[1] ) );
			if ( $bits < 0 || $bits > 32 ) continue;
			$size   = 2 ** ( 32 - $bits );
			$start  = $start - ( $start % $size );
			$list[] = [ $start, $start + $size - 1 ];
		}
		usort( $list, function ( $a, $b ) { return $a[0] <=> $b[0]; } );
		$flat = [];
		foreach ( $list as $r ) { // склеиваем пересекающиеся
			$k = count( $flat );
			if ( $k && $r[0] <= $flat[ $k - 1 ] + 1 ) { $flat[ $k - 1 ] = max( $flat[ $k - 1 ], $r[1] ); continue; }
			$flat[] = $r[0];
			$flat[] = $r[1];
		}
		@file_put_contents( $bin, $flat ? pack( 'N*', ...$flat ) : '' );
		return $flat;
	}

	// ---------- кэш сведений ----------

	public static function get_all() {
		$all = get_option( self::OPTION, [] );
		return is_array( $all ) ? $all : [];
	}

	/**
	 * Определяет и запоминает сведения о настойчивых адресах. Вызывается из run().
	 *
	 * @param array $hits    ip => число неудачных обращений за сканирование
	 * @param array $flagged ip|cidr, пойманные правилами (определяются при любом числе)
	 */
	public static function remember( array $hits, array $flagged = [], $now = null ) {
		$now = $now ?: time();
		$all = self::get_all();
		$use = self::enabled() && is_file( self::dir() . 'country.mmdb' );
		foreach ( $flagged as $key ) if ( ! isset( $hits[ $key ] ) ) $hits[ (string) $key ] = 0;
		foreach ( $hits as $ip => $n ) {
			$ip  = (string) $ip;
			$old = $all[ $ip ] ?? null;
			$e   = $old ?: [ 'cc' => '', 'country' => '', 'asn' => 0, 'org' => '', 'tags' => [], 'hits' => 0, 'first' => $now, 'checked' => 0 ];
			if ( $use && ( ! $old || $old['checked'] < $now - self::RECHECK ) ) {
				$e            = array_merge( $e, self::lookup( $ip ) );
				$e['checked'] = $now;
			}
			$e['hits'] += (int) $n;
			$e['last']  = $now;
			$all[ $ip ] = $e;
		}
		// Старое и лишнее — прочь.
		$all = array_filter( $all, function ( $e ) use ( $now ) { return ( $e['last'] ?? 0 ) >= $now - self::KEEP_DAYS * DAY_IN_SECONDS; } );
		if ( count( $all ) > self::MAX_ITEMS ) {
			uasort( $all, function ( $a, $b ) { return $b['last'] <=> $a['last']; } );
			$all = array_slice( $all, 0, self::MAX_ITEMS, true );
		}
		update_option( self::OPTION, $all, false );
	}

	/** Флаг-эмодзи по коду страны (для Telegram: там флаги видны на всех системах). */
	public static function flag_emoji( $cc ) {
		if ( ! preg_match( '/^[A-Z]{2}$/', $cc ) ) return '';
		return mb_chr( 0x1F1E6 + ord( $cc[0] ) - 65 ) . mb_chr( 0x1F1E6 + ord( $cc[1] ) - 65 );
	}

	/** Короткая подпись: «🇷🇺 Россия · AS216246 Aeza Group LLC · VPN, дата-центр». */
	public static function describe( array $e, $emoji = true ) {
		$parts = [];
		if ( $e['cc'] ) $parts[] = trim( ( $emoji ? self::flag_emoji( $e['cc'] ) . ' ' : '' ) . ( $e['country'] ?: $e['cc'] ) );
		if ( $e['asn'] ) $parts[] = 'AS' . $e['asn'] . ( $e['org'] ? ' ' . $e['org'] : '' );
		$tags = array_map( function ( $t ) { return self::tag_label( $t ); }, (array) $e['tags'] );
		if ( $tags ) $parts[] = implode( ', ', $tags );
		return implode( ' · ', $parts );
	}
	// ---------- дашборд ----------

	public static function enqueue() {
		wp_enqueue_style( 'logshield-ipinfo', LOGSHIELD_URL . 'assets/ipinfo.css', [ 'logshield-dashboard' ], LOGSHIELD_VERSION . '-' . @filemtime( LOGSHIELD_DIR . 'assets/ipinfo.css' ) );
	}

	/** Флаг страны: SVG из assets/flags (эмодзи-флаги Windows не рисует). */
	public static function flag( $cc ) {
		$cc = strtolower( (string) $cc );
		if ( ! preg_match( '/^[a-z]{2}$/', $cc ) || ! is_file( LOGSHIELD_DIR . 'assets/flags/' . $cc . '.svg' ) ) return '';
		return '<img class="ls-flag" src="' . esc_url( LOGSHIELD_URL . 'assets/flags/' . $cc . '.svg' ) . '" alt="" width="20" height="15" loading="lazy" decoding="async">';
	}

	/** Строка «флаг Страна · сеть · метки» под адресом в таблице атакующих. */
	public static function badge( $ip, array $all = null ) {
		static $cache = null;
		if ( $all === null ) $all = $cache ?? ( $cache = self::get_all() );
		$e = $all[ $ip ] ?? null;
		if ( ! $e || ( ! $e['cc'] && ! $e['asn'] && ! $e['tags'] ) ) return '';
		$html = '<span class="ls-geo">';
		if ( $e['cc'] ) {
			$html .= self::flag( $e['cc'] ) . '<span class="ls-geo-country">' . esc_html( $e['country'] ?: $e['cc'] ) . '</span>';
		}
		if ( $e['org'] || $e['asn'] ) {
			$html .= '<span class="ls-geo-org" title="' . esc_attr( 'AS' . $e['asn'] ) . '">' . esc_html( $e['org'] ?: 'AS' . $e['asn'] ) . '</span>';
		}
		foreach ( (array) $e['tags'] as $t ) {
			$html .= '<span class="ls-geo-tag ls-geo-' . esc_attr( $t ) . '">' . esc_html( self::tag_label( $t ) ) . '</span>';
		}
		return $html . '</span>';
	}

	/** Карточка «Настойчивые адреса»: 10+ ошибок или неудачных входов, по убыванию. */
	public static function render_card() {
		$all = self::get_all();
		if ( ! self::enabled() && ! $all ) return;
		$have_db = is_file( self::dir() . 'country.mmdb' );
		uasort( $all, function ( $a, $b ) { return $b['hits'] <=> $a['hits'] ?: $b['last'] <=> $a['last']; } );
		$top  = array_slice( $all, 0, 50, true );
		$by_c = [];
		foreach ( $all as $e ) if ( $e['cc'] ) $by_c[ $e['cc'] ] = ( $by_c[ $e['cc'] ] ?? 0 ) + 1;
		arsort( $by_c );
		?>
		<section class="ls-card ls-span-2 ls-geo-card" aria-labelledby="ls-geo-title">
			<div class="ls-card-head">
				<h2 id="ls-geo-title"><?php esc_html_e( 'Настойчивые адреса', 'logshield' ); ?></h2>
				<p class="ls-legend"><?php
					/* translators: %d: порог ошибок или неудачных входов за одно сканирование. */
					echo esc_html( sprintf( __( 'за 30 дней: %d+ ошибок или неудачных входов за сканирование · страна и сеть только для информации, на блокировку не влияют', 'logshield' ), (int) self::MIN_HITS ) );
				?></p>
			</div>
			<?php if ( ! $have_db && self::enabled() ) : ?>
				<p class="ls-pad ls-dim"><?php
					/* translators: %s: адрес страницы настроек. */
					echo LogShield_Plugin::kses( sprintf( __( 'Базы стран ещё не скачаны — это сделает ежедневная задача, или нажмите «Обновить базы сейчас» в <a href="%s">настройках</a>.', 'logshield' ), esc_url( admin_url( 'admin.php?page=' . LogShield_Admin::SLUG ) ) ) );
				?></p>
			<?php endif; ?>
			<?php if ( ! $top ) : ?>
				<p class="ls-pad ls-dim"><?php esc_html_e( 'Пока никого. Появятся после сканирования, если кто-то настойчиво получает ошибки.', 'logshield' ); ?></p>
			<?php else : ?>
				<?php if ( $by_c ) : ?>
					<ul class="ls-geo-countries" aria-label="<?php esc_attr_e( 'Страны', 'logshield' ); ?>">
						<?php foreach ( array_slice( $by_c, 0, 12, true ) as $cc => $n ) : $name = ''; foreach ( $all as $e ) { if ( $e['cc'] === $cc ) { $name = $e['country']; break; } } ?>
							<li><?php echo self::flag( $cc ); // phpcs:ignore ?> <?php echo esc_html( $name ?: $cc ); ?> <b><?php echo (int) $n; ?></b></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<div class="ls-table-wrap" tabindex="0" role="region" aria-labelledby="ls-geo-title">
					<table class="ls-table ls-table-stack">
						<thead><tr>
							<th scope="col"><?php esc_html_e( 'Адрес', 'logshield' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Страна и сеть', 'logshield' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Ошибок', 'logshield' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Последний раз', 'logshield' ); ?></th>
						</tr></thead>
						<tbody>
						<?php foreach ( $top as $ip => $e ) : ?>
							<tr>
								<th scope="row"><code><?php echo esc_html( $ip ); ?></code></th>
								<td data-label="<?php esc_attr_e( 'Страна и сеть', 'logshield' ); ?>"><?php echo self::badge( (string) $ip, $all ) ?: '<span class="ls-dim">' . esc_html__( 'неизвестно', 'logshield' ) . '</span>'; // phpcs:ignore ?></td>
								<td class="ls-nowrap" data-label="<?php esc_attr_e( 'Ошибок', 'logshield' ); ?>"><?php echo (int) $e['hits']; ?></td>
								<td class="ls-nowrap" data-label="<?php esc_attr_e( 'Последний раз', 'logshield' ); ?>"><?php echo esc_html( wp_date( 'd.m H:i', $e['last'] ) ); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
			<p class="ls-pad ls-dim ls-geo-credit"><a href="https://db-ip.com">IP Geolocation by DB-IP</a> · Tor Project · X4BNet/lists_vpn · <?php esc_html_e( 'флаги flag-icons (MIT)', 'logshield' ); ?></p>
		</section>
		<?php
	}
}
